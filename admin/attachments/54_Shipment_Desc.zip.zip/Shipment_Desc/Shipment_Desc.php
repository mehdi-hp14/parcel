<?php
/*
ImageToShow for Prestashop 1.6.1

Auther : Esmaiel Fakhimi
09303730609

*/
if (!defined('_PS_VERSION_'))
	exit ;
class Shipment_Desc extends Module{

	private $_html = '';
	private $_postErrors = array();
	
	public function __construct() {
		$this->name = 'تصویر حامل در سفارش';
		$this->tab = 'others';
		$this->version = '1.0';
		$this->author = 'اسماعیل فخیمی شریف';
		
		parent::__construct();
		
		$this->displayName = $this->l('ماژول تصویر حامل');
		$this->description = $this->l('نمایش تصویر حامل در صفحه محصولات در زیر کلید افزودن به سبد خرید.');
		$this->confirmUninstall = $this->l('آیا از حذف کحص.ل اطمینان دارید؟');
	}
	
    public function install()
    {
        if (!parent::install() or !$this->registerHook('displayRightColumnProduct'))
            return false;

        return true;
	}
    public function uninstall()
    {
        // Uninstall
        if (!parent::uninstall() or !$this->unregisterHook('displayRightColumnProduct'))
            return false;

        return true;
    }
	
	
	public function getContent() {

		if (Tools::isSubmit('submit')) {
			$error_m="";
			if(isset($_FILES['imageToShow']) AND $_FILES['imageToShow']['name'] !="" AND $_FILES['imageToShow']['name']!=null){
				$target_dir = "../";
				$target_file = $target_dir .$id ."_". basename($_FILES["imageToShow"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				$format = explode(".",basename($_FILES["imageToShow"]["name"]));
				$format = $format[(count($format)-1)];
				$filename = $id ."_". basename($_FILES["imageToShow"]["name"]).".".$format;
				$target_file = $target_dir .$id ."_". basename($_FILES["imageToShow"]["name"]).".".$format;
				
				if($_FILES["imageToShow"]["size"] > 52428801) {
					$error_m .= "Invalid file size<br>";
					$uploadOk = 0;
				} elseif($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
					$error_m .= "Invalid file format<br>";
					$uploadOk = 0;
				} 
				if ($uploadOk == 0) {
					$error_m .= "Sorry, your file was not uploaded.<br>";
				} else {
					if (move_uploaded_file($_FILES["imageToShow"]["tmp_name"], $target_file)) {
						Configuration::updateValue('Image', $target_file);
						$error_m .= "The file ". basename( $_FILES["uploaded_file"]["name"]). " has been uploaded.<br>";
					} else {
						$error_m .= "Sorry, there was an error uploading your file.<br>";
					}
				}
			}
			
			$this->_html .= '<div class="conf confirm">' . $error_m . '</div>';
		}

		$this->_generateForm();
		return $this->_html;
	}

	private function _generateForm() {
		$this->_html .= '<div align="center"><form action="' . $_SERVER['REQUEST_URI'] . '" method="post" enctype="multipart/form-data">';
		$this->_html .= $this->l('تصویر مورد نظر :') . '<br/><br/>';
		$this->_html .= '<input type="file" name="imageToShow"   accept=".gif,.jpg,.jpeg,.png"><br/><br/>';
		$this->_html .= '<input type="submit" name="submit"';
		$this->_html .= 'value="' . $this->l('Save it!') . '" class="button" />';
		$this->_html .= '</form></div>';
	}

    public function hookdisplayRightColumnProduct($params)
    {
		return "<div><center><img src=\"".Configuration::get('Image')."\"></center></div>";
    }
}

?>