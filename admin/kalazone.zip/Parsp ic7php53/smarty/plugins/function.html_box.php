<?php
	/**
	 * Enter description here...
	 *
	 * @param array $params: ('name' => string, 'values'=>array, 'table'=>string)
	 * @param Smarty $smarty
	 * @return string
	 *  @ use in html tag (between) 	 
	 */
	function smarty_function_html_box($params, &$smarty){
		$uid = rand_name(2);
		$addp=$params['addp'];
		$params['addp']=null;
		//$params = array_splice($params,4);
		$param="{";
		foreach( $params as $key => $value ){
		  if ($key=="iframe" || $key=="url") $value.=$addp;
      if (is_numeric($value) )
        $param.= $key.":".$value.",";
      else		                      
		    $param.= $key.":'".$value."',";
		  
		}
		$param.="closejs:function(){closeJS()}}";                		
		return " class=button onclick=".'"'."TINY.box.show(".$param.")".'"';
	}
?>