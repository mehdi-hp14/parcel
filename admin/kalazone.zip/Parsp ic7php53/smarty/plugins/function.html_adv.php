<?php
	/**
	 * Enter description here...
	 * Example : {adv place="inblock" posname="block1" }
	 * @param array $params: ('type' => string, 'categories'=>array, 'advname'=>string)
	 * @param Smarty $smarty
	 * @return string
	 */
	function smarty_function_html_adv($params, &$smarty){
		$uid = rand_name(2);
		extract($params);
		$where="";
		
		if (isset($place))
		{
    		
		if ($place=='inblock')		
        $where=" ad_place=0 ";        		                
    elseif ($place=='incategory')
        $where=" ad_place=1 and ad_condition LIKE  '%,$categoryID,%'";        
    elseif ($place=='inflash')    
        $where=" ad_place=2 ";
     
       
      if (isset($_GET['viewblocks']))
          if (isset($_GET['incategory']) && $place=='incategory')  
            echo "<div style='border: 2px;
border-color: black;
border-style: initial;
border-width: 2px;
background: coral;
padding: 15px 5px 15px 5px;
border-radius: 5px;
margin-top: 5px;'><center><B>".STRING_POSITION." ".ADMIN_ADVERTIESMENT." ".ADMIN_ADVERTIESMENT_INCATEGORY."<br/><br> <span style='color:green;'> ".STRING_BLOCK." ".$posname."</span></B><center></div>";      
      else
          if ($place=='inblock')
            echo "<div style='border: 2px;
border-color: black;
border-style: initial;
border-width: 2px;
background: coral;
padding: 15px 5px 15px 5px;
border-radius: 5px;
margin-top: 5px;'><center><B>".STRING_POSITION." ".ADMIN_ADVERTIESMENT." ".ADMIN_ADVERTIESMENT_INBLOCK."<br/><br> <span style='color:blue;font-size:15px;'> ".STRING_BLOCK." ".$posname."</span></B><center></div>";
          

        
    $time=time();            
    $where= $where. " and enabled = 1 AND position_name = '" . $posname .
                        "' AND (
                          (start_time <= '" . $time . "' AND end_time >= '" . $time . "') OR 
                          (start_time = '' AND end_time >= '" . $time . "') OR
                          (start_time <= '" . $time . "' AND (end_time = '' or end_time IS NULL))
                        ) and ((click_max=0) OR (click_max > click_count))";                        
                        
    $q = db_query('SELECT * FROM ' .ADS_TABLE. " AS ad where $where ORDER by ad_order");        
             
    while ($row = db_fetch_assoc($q))                
      $res[] = $row;
    $where="";        
    if ($place!='inflash')
    {                 
      foreach ($res AS $row)
      {
      
      $row['ad_id']=$row['adId'];
      if ($row["ad_link"]=="")
        $row["ad_link"]=BASE_URL;
      //$row['ad_link']=$row['ad_link'];
                   	    	      			
        switch ($row['media_type']) {
        case 0:
                $src = (strpos($row['ad_code'], 'http://') === false && strpos($row['ad_code'], 'https://') === false) ?
                        BASE_URL."/uploads/afficheimg/$row[ad_code]" : $row['ad_code'];
                $ads[] = "<a href='".BASE_URL."index.php?ad_id=".$row['ad_id']."&amp;uri=".urlencode($row["ad_link"]). "' target='".(isset($target)?$style:'_blank')."'>
                <img src='$src' ".(isset($width)?' width="'.$width.'"':'').' '.(isset($height)?' height="'.$height.'"':'').' '.(isset($style)?' style="'.$style.'"':'')."border='0' /></a>";
                break;
        case 1: // Flash
                $src = (strpos($row['ad_code'], 'http://') === false && strpos($row['ad_code'], 'https://') === false) ?
                         BASE_URL."/uploads/afficheimg/$row[ad_code]" : $row['ad_code'];
                         
                $ads[] = "<a href='".BASE_URL."index.php?ad_id=".$row['ad_id']."&amp;uri=".urlencode($row["ad_link"]). "' target='".(isset($target)?$style:'_blank')."'>".
                         "<object classid=\"clsid:d27cdb6e-ae6d-11cf-96b8-444553540000\" " .
                         "codebase=\"http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0\"  " 
                         .(isset($width)?' width="'.$width.'"':'').' '.(isset($height)?' height="'.$height.'"':'').
                          ">
                           <param name='movie' value='$src'>
                           <param name='quality' value='high'>                          
                           <embed src='$src' quality='high'
                           pluginspage='http://www.macromedia.com/go/getflashplayer'
                           type='application/x-shockwave-flash' ".
                           (isset($width)?' width="'.$width.'"':'').' '.(isset($height)?' height="'.$height.'"':'').
                           "></embed>
                         </object></a>";
                break;
        case 2: // HTML  
                $ads[] =  PrepareHTML_Code($row['ad_code']);
                break;
        case 3: // TEXT
                $ads[] = "<a href='".BASE_URL."index.php?ad_id=$row[ad_id]&amp;uri=" .urlencode($row["ad_link"]). "'
                target='_blank'>" .htmlspecialchars($row['ad_code']). '</a><br/>';
                break;        
        case 4: // CODE
                 $ads[] = eval($row['ad_code']);
                 break;
       case 5:
                $ads[]="<a href='".BASE_URL."index.php?ad_id=$row[ad_id]&amp;uri=" .urlencode($row["ad_link"]). "'
                target='_blank'>" .'<div id="flash_adv">
                <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cabversion=6,0,0,0" '.(isset($width)?' width="'.$width.'"':'').' '.(isset($height)?' height="'.$height.'"':'').'>
                <param name="movie" value="'.$flash_src.'"><param name="quality" value="high">
                <param name="wmode" value="opaque">        
                <embed src="data/flashdata/dynfocus/dynfocus.swf" 
                quality="high" '.(isset($width)?' width="'.$width.'"':'').' '.(isset($height)?' height="'.$height.'"':'').' allowscriptaccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="transparent">
                </object></div></a>';
       case 6:
                $ads[]='<div id="flash_cycle">
                <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cabversion=6,0,0,0" width="484" height="200">
                <param name="movie" value="data/flashdata/dynfocus/dynfocus.swf">
                <param name="quality" value="high"><param name="wmode" value="opaque"><param name="FlashVars" value="pics=data/afficheimg/20081027angsif.jpg|data/afficheimg/20081027wdwd.jpg|data/afficheimg/20081027xuorxj.jpg&amp;links=http%3A//www.ecshop.com|http%3A//www.wdwd.com|http%3A//help.ecshop.com/index.php%3Fdoc-view-108.htm&amp;texts=ECShop|WDWD|ECShop&amp;pic_width=484&amp;pic_height=200&amp;show_text=1&amp;txtcolor=000000&amp;bgcolor=DDDDDD&amp;button_pos=4&amp;stop_time=3000">
                <embed src="data/flashdata/dynfocus/dynfocus.swf" flashvars="pics=data/afficheimg/20081027angsif.jpg|data/afficheimg/20081027wdwd.jpg|data/afficheimg/20081027xuorxj.jpg&amp;links=http%3A//www.ecshop.com|http%3A//www.wdwd.com|http%3A//help.ecshop.com/index.php%3Fdoc-view-108.htm&amp;texts=ECShop|WDWD|ECShop&amp;pic_width=484&amp;pic_height=200&amp;show_text=1&amp;txtcolor=000000&amp;bgcolor=DDDDDD&amp;button_pos=4&amp;stop_time=3000" quality="high" width="484" height="200" allowscriptaccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="transparent">
                </object></div>';      	
      	break;
      }
      }
    }  
    else
    {
      return '';    
    }
    
    
    if (count($ads))
    {
      if (!isset($tableless))      
      {
      $content= '<table cellpadding="5" cellspacing="5" '.
      (isset($style)?' style="'.$style.'"':'').' '.(isset($class)?' class="'.$class.'"':'').
      (isset($align)?' align="'.$align.'"':'').' '.
      '><tbody>';
      }
      foreach ($ads as $key=>$value) {
              if (!isset($tableless))
              {
                $content.="<tr><td>$value</td></tr>";
              }
              else
              {
                if (!isset($liclass))
                    $content.=$value;
                else
                    $content.="<li  style=\"position: absolute;left: 0px;top: 0px;bottom: 0px;right: 0px;display: none;\"> $value</li>";
              }
                    	
      }
      if (!isset($tableless))      
      $content.='</tbody></table>';
      return $content;    
    }
        				
		}
		else
		{
    return "";
    }
		
	}
?>