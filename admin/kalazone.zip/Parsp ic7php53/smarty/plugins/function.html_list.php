<?php
	/**
	 * Navid Milanizadeh
	 * Googoole@yahoo.com
	 * @param array $params: ('name' => string, 'values'=>array, 'table'=>string)
	 * @param Smarty $smarty
	 * @return string
	 */
	function smarty_function_html_list($params, &$smarty){
		$uid = rand_name(2);		
		extract($params);
		
		$langManager = &LanguagesManager::getInstance();
		$languages = $langManager->languages;
		$default = $langManager->getDefaultLanguage();
		$html_langs_hidden = '';
		$html_langs = '';
		$dbfield = isset($dbfield)?$dbfield:$name;    
		$lang_num = count($languages);
		foreach ($languages as $languageEntry){		
			/*@var $languageEntry Language*/            
			$lang_iso2 = $languageEntry->iso2;			
			$input_name = $name.'_'.$lang_iso2;
			if(strpos($name,'%lang%') !== false){
				$input_name = str_replace('%lang%', $lang_iso2, $name);
			}
			if(isset($namespace)){
				$input_name = "{$namespace}[$input_name]";
			}
			
      if (!isset($values[$dbfield.'_'.$lang_iso2]))
        $values[$dbfield.'_'.$lang_iso2]="";
      					
		}
		
		$id = $input_name.'s_hd-'.$uid;
		$id = preg_replace('/[^\w%]+/s','_',$id);
  $rlist = array();
  $qryl="SELECT * FROM ".TBL_PRODUCT_LIST;
  $q = db_query($qryl) or die (db_error());
  
	while ($row = db_fetch_row($q))	
	   $rlist[$row['list_id']]=$row['list_name'];    
   
		
		//special offers // ****************************************************************************** //
	$result = array();
	if (trim($listcode)=="*")
	   $qry="SELECT productID,".TBL_PRODUCT_LIST_ITEM.".list_id,orderbtn,postbtn FROM ".TBL_PRODUCT_LIST_ITEM.",".TBL_PRODUCT_LIST." where ".TBL_PRODUCT_LIST.".list_id=".TBL_PRODUCT_LIST_ITEM.".list_id order by list_id,priority,productID";
  else    
	   $qry="SELECT productID,orderbtn,postbtn,list_id FROM ".TBL_PRODUCT_LIST_ITEM.",".TBL_PRODUCT_LIST." where ".TBL_PRODUCT_LIST.".list_id=".TBL_PRODUCT_LIST_ITEM.".list_id and list_id='".$listcode."' order by priority,productID";     
	$q = db_query($qry) or die (db_error());
	while ($row = db_fetch_row($q))
	{	  
		$q1 = db_query("SELECT productID, ".LanguagesManager::sql_prepareField('name')." AS name, default_picture, Price, categoryID, product_code,".LanguagesManager::sql_prepareField('brief_description')." AS brief_description,cod_link,in_stock FROM ".
					PRODUCTS_TABLE.
          " where productID=$row[0]") or die (db_error());
          				
		if ($row1 = db_fetch_row($q1))
		{  
    $extra = GetExtraParametrs($row[0]);                   	      	      
			if ( is_null($row1[2]) )
				continue;
			$picture = db_query( "select filename, thumbnail, enlarged from ".
				PRODUCT_PICTURES." where photoID=".$row1[2] );				
			$picture_row = db_fetch_row( $picture );
			 
			if ( $picture_row )
			{
			 	if ( file_exists( "./uploads/products_pictures/".$picture_row[0] ) )
				{
				  
				  //$row1['productID'] = $row1['productID'];
				  $price_surplus=0;
				  if(count($extra)>0)
            {
            $variants=$extra[0]['values_to_select'][0];            
            $price_surplus=$variants['price_surplus'];
            $row1['option_values']=$variants['variantID'];
            }                        
          $price=$row1[3]+$price_surplus;  
					$row1[2] = $picture_row[0];
					$row1[3] = show_price($price);
					$row1['orderbtn'] = $row['orderbtn'];
					$row1['postbtn'] = $row['postbtn'];
					$row1['list_id']=$row['list_id'];
          if ($row1['in_stock']==0)
          {   
            $row1['orderbtn'] = 'off';
//					  $row1['postbtn'] = 'off';
          }                              					
					$result[] = $row1;
				}
			}
			
		}
	}
  $special_offers=$result;

//            $smarty->assign('whatshow','toprow');
//            $smarty->assign('title',$title);
//            $smarty->display('list_bit.tpl.html');	
            
$list_id='';
if (count($special_offers)==0) return ;		
for ($i=0;$i<count($special_offers) ;$i++ ) {
    if ($special_offers[$i]['list_id']!=$list_id)
    {
      if (trim($listcode)=="*" && $i>0 )
      {                  
            $smarty->assign('whatshow','bottomrow');            
            $smarty->display('list_bit.tpl.html');                
      }
      $j=0;
            $smarty->assign('whatshow','toprow');
            $smarty->assign('title',$rlist[$special_offers[$i]['list_id']]);
            $smarty->display('list_bit.tpl.html'); 
    }
    $j=$j+1;
    $list_id=$special_offers[$i]['list_id'];
    
      $template_dir="./templates/frontend/".$templateDirectory;;
      $smarty->assign('whatshow','detail');
      $smarty->assign('listitem',$special_offers[$i]);
      $smarty->assign('listitem_url',renderURL('?productID='.$special_offers[$i]['productID'].'&product_slug='.$special_offers[$i][1]));  
      $smarty->display('list_bit.tpl.html');
			 
       if ((($j) % ($cols1))==0)
          { 
            $smarty->assign('whatshow','rowseprator');
            $smarty->display('list_bit.tpl.html');
          }         
       else
          {
            $smarty->assign('whatshow','colseprator');
            $smarty->display('list_bit.tpl.html');
          }
         
	
}
		        $smarty->assign('whatshow','bottomrow');            
            $smarty->display('list_bit.tpl.html');    

	}
?>