<?php
	/**
	 * Enter description here...
	 *
	 * @param array $params: (name => string, values=>array, table=>string, rows=>int cols=>int)
	 * @param Smarty $smarty
	 * @return string
	 */
	function smarty_function_html_textarea($params, &$smarty){
		
		extract($params);
		$uid = rand_name(2);
		if (!isset($id)) $id=$uid;
		$langManager = &LanguagesManager::getInstance();
		$languages = $langManager->languages;
		$html_langs_hidden = '';
		$html_langs = '';
		$dbfield = isset($dbfield)?$dbfield:$name;
		
		$lang_num = count($languages);
		
		foreach ($languages as $languageEntry){
			/*@var $languageEntry Language*/
			$lang_iso2 = $languageEntry->iso2;
			$input_name = $name.'_'.$lang_iso2;
			if(strpos($name,'%lang%') !== false){
				$input_name = str_replace('%lang%', $lang_iso2, $name);
			}  
			if (!isset($values[$dbfield.'_'.$lang_iso2]))
        $values[$dbfield.'_'.$lang_iso2]=" ";
      //$lang_html =($values[$dbfield.'_'.$lang_iso2]);  
			$lang_html = "\n".'			
			  <tr>
				'.($lang_num>1?'
				<td style="vertical-align:top; padding-top:5px!important;" '.(isset($style)&&preg_match('@width:\s?100\%@', $style)?' width="1%"':'').'>'.($languageEntry->getThumbnailURL()?'<img hspace="4" src="'.xHtmlSpecialChars($languageEntry->getThumbnailURL()).'" alt="'.xHtmlSpecialChars($languageEntry->getName()).'" />':xHtmlSpecialChars($languageEntry->getName())).'</td>
				':'').'
				<td>
					<textarea lang="'.$lang_iso2.'" name="'.xHtmlSpecialChars($input_name).'" '.(isset($id)?" id='{$id}_{$lang_iso2}'":'').(isset($rows)?" rows='{$rows}'":'').(isset($cols)?" cols='{$cols}'":'').(isset($style)?" style='{$style}'":'').(isset($class)?" class='{$class}'":'').'>'.str_replace('\"','',($values[$dbfield.'_'.$lang_iso2])).'</textarea>
				</td>
  			</tr>';
  		$lang = LanguagesManager::getDefaultLanguage();
      
			if($values[$dbfield.'_'.$lang_iso2] || $languageEntry->isDefault()){			
				$html_langs .= $lang_html;
			}else{				
				$html_langs_hidden .= $lang_html;
			}
		}

		echo '		
		<table'.(isset($style)?' style="'.$style.'"':'').' cellpadding="0" cellspacing="0" class="lang_fields">
		<tr>
			<td><table'.(isset($style)?' style="'.$style.'"':'').' cellpadding="0" cellspacing="0">'.$html_langs.'</table>
				
			'.($lang_num>1&&$html_langs_hidden?'
				<div id="'.xHtmlSpecialChars($input_name.'s_hd-'.$uid).'" style="display:none;">
				<table'.(isset($style)?' style="'.$style.'"':'').' cellpadding="0" cellspacing="0">'.$html_langs_hidden.'</table>
				</div></td>
				
			<td width="11" valign="bottom" '.(isset($style)&&preg_match('@width:\s?100\%@', $style)?' width="1%"':'').'><a title="'.xHtmlSpecialChars(STRING_SHOW).'" href="#expand" class="expand_languages" rel="'.xHtmlSpecialChars($input_name.'s_hd-'.$uid).'"><img hspace="4" src="./images/arrow_down.png" alt="'.xHtmlSpecialChars(translate('loc_show_empty_translations')).'" width="11" height="11" /></a>
			':'').'
			</td>
		</tr>
		</table>';

foreach ($languages as $languageEntry){
      $CKEditor = new CKEditor();
      			
			$CKEditor->config['width'] = $width;
			$CKEditor->config['height'] = $height;			
			$CKEditor->basePath = './ckeditor/';
			$CKEditor->config['skin']='moonocolor';      			
			//$CKEditor->config['ImageUpload']='false';
			//$CKEditor->config['removeDialogTabs']='link:upload;image:Upload';
			$CKEditor->config['language'] = $languageEntry->iso2;
			$CKEditor->config['toolbar'] = array(
			 array('Source','-','DocProps','Preview','Print','-','Templates'),
			 array('Cut','Copy','Paste','PasteText','PasteFromWord','-','Find','Replace'),
       array('Link','Unlink','Anchor'),
			 array('BidiRtl','BidiLtr','-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock'),
			 array('TextColor','BGColor','-','Bold','Italic','Underline','Strike','Subscript','Superscript','-','RemoveFormat' ),       	     	     	    
	     array('NumberedList','BulletedList','-','Image','Flash','Table','HorizontalRule','Smiley','SpecialChar','PageBreak','Iframe'),
	     array('Styles','Font','FontSize')	     
      );
      $lang_iso2 = $languageEntry->iso2;
      
		  $CKEditor->replace($id.'_'.$lang_iso2);

		}		
    							
	}
?>