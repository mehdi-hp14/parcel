<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class xml2array {
		var $arrOutput = array(  );
		var $resParser = null;
		var $strXmlData = null;

		function parse($strInputXML) {
			$this->resParser = xml_parser_create(  );
			xml_set_object( $this->resParser, $this );
			xml_set_element_handler( $this->resParser, 'tagOpen', 'tagClosed' );
			xml_set_character_data_handler( $this->resParser, 'tagData' );
			$this->strXmlData = xml_parse( $this->resParser, $strInputXML );

			if (!$this->strXmlData) {
				exit( sprintf( 'XML error: %s at line %d', xml_error_string( xml_get_error_code( $this->resParser ) ), xml_get_current_line_number( $this->resParser ) ) );
			}

			xml_parser_free( $this->resParser );
			return $this->arrOutput;
		}

		function tagopen($parser, $name, $attrs) {
			$tag = array( 'name' => $name, 'attrs' => $attrs );
			array_push( $this->arrOutput, $tag );
		}

		function tagdata($parser, $tagData) {
			if (trim( $tagData )) {
				if (isset( $this->arrOutput[count( $this->arrOutput ) - 1]['tagData'] )) {
					$this->arrOutput[count( $this->arrOutput ) - 1]->tagData .= $tagData;
					return null;
				}

				$this->arrOutput[count( $this->arrOutput ) - 1]['tagData'] = $tagData;
			}

		}

		function tagclosed($parser, $name) {
			$this->arrOutput[count( $this->arrOutput ) - 2]['children'][] = $this->arrOutput[count( $this->arrOutput ) - 1];
			array_pop( $this->arrOutput );
		}
	}

?>