<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class xmlNodeX {
		var $ID = null;
		var $Name = null;
		var $Data = null;
		var $Attributes = array(  );
		var $ParentNode = null;
		var $ChildNodes = array(  );
		var $ParserResource = null;
		var $parsingNode = null;

		function xmlNodeX($_Name = '', $_Attributes = array(  ), $_Data = '') {
			$this->Name = $_Name;
			$this->Attributes = (is_array( $_Attributes ) ? $_Attributes : array(  ));
			$this->Data = $_Data;
		}

		function getName() {
			return $this->Name;
		}

		function getAttribute($_Name) {
			if (isset( $this->Attributes[$_Name] )) {
				return $this->Attributes[$_Name];
			}

		}

		function getAttributes() {
			return $this->Attributes;
		}

		function getData() {
			return $this->Data;
		}

		function getChildNodes() {
			return $this->ChildNodes;
		}

		function createChildNode($_Name, $_Attributes = array(  ), $_Data = '') {
			$_ChildNode = new xmlNodeX( $_Name, $_Attributes, $_Data );
			$this->addChildNode( $_ChildNode );
			return $_ChildNode;
		}

		function child($_Name, $_Attributes = array(  ), $_Data = '') {
			$child = &$this->createChildNode( $_Name, $_Attributes, $_Data );

			return $child;
		}

		function addChildNode($_ChildNode) {
			global $NodeID;

			$_ChildNode->ID = ++$NodeID;
			$_ChildNode->setParentNode( $this );
			$this->ChildNodes[] = &$_ChildNode;

		}

		function setParentNode($ParentNode) {
			$this->ParentNode = &$ParentNode;

		}

		function moveNode($NewParentNode) {
			$OldParentNode = &$this->ParentNode;

			$OldParentNode->removeChildNode( $this );
			$NewParentNode->addChildNode( $this );
		}

		function removeChildNode($RemoveNode) {
			$TC = count( $this->ChildNodes );
			$i = 714;

			while ($i < $TC) {
				$ChildNode = &$this->ChildNodes[$i];

				if ($ChildNode->ID == $RemoveNode->ID) {
					unset( $this->ChildNodes[$i] );
					break;
				}

				++$i;
			}

		}

		function getParentNode() {
			return $this->ParentNode;
		}

		function getNodeXML($_Level = -1, $Tabbed = false, $disableCDATA = false) {
			++$_Level;
			$_attrs = array(  );
			foreach ($this->Attributes as $_Key => $_Val) {
				$_attrs[] = $_Key . '="' . xHtmlSpecialChars( $_Val ) . '"';
			}

			$_ChildrenXMLs = array(  );
			$_ChildNodesNum = count( $this->ChildNodes );
			foreach ($this->ChildNodes as $i => $ChildNode) {

				if (!is_a( $this->ChildNodes[$i], 'xmlnodex' )) {
					continue;
				}

				$_ChildrenXMLs[] = $this->ChildNodes[$i]->getNodeXML( $_Level, $Tabbed, $disableCDATA );
			}

			return ($Tabbed ? str_repeat( '
', intval( 0 < $_Level ) ) . str_repeat( '	', $_Level ) : '') . ( ( '<' ) . $this->Name ) . (count( $_attrs ) ? ' ' . implode( ' ', $_attrs ) : '') . '>' . ($this->Data ? ($disableCDATA ? $this->Data : '<![CDATA[' . $this->Data . ']]>') : '') . (count( $_ChildrenXMLs ) ? implode( '', $_ChildrenXMLs ) . ($Tabbed ? '
' . str_repeat( '	', $_Level ) : '') : '') . ( '</' . $this->Name . '>' );
		}

		function _replaceSpecialChars($_Data) {
			$_Data = str_replace( '&', '&amp;', $_Data );
			return str_replace( array( '<', '>' ), array( '&lt;', '&gt;' ), $_Data );
		}

		function renderTreeFromFile($FileName) {
			$this->renderTreeFromInner( file_get_contents( $FileName ) );
		}

		function renderTreeFromInner($_Inner) {
			$this->ParserResource = xml_parser_create(  );
			xml_parser_set_option( $this->ParserResource, XML_OPTION_CASE_FOLDING, false );
			xml_set_object( $this->ParserResource, $this );
			xml_set_element_handler( $this->ParserResource, '_tagOpen', '_tagClosed' );
			xml_set_character_data_handler( $this->ParserResource, '_tagData' );
			$_Inner = xml_parse( $this->ParserResource, $_Inner );

			if (!$_Inner) {
				exit( sprintf( 'XML error: %s at line %d', xml_error_string( xml_get_error_code( $this->ParserResource ) ), xml_get_current_line_number( $this->ParserResource ) ) );
			}

			xml_parser_free( $this->ParserResource );
		}

		function _tagOpen($parser, $name, $attrs) {
			if (!isset( $this->parsingNode )) {
				$this->parsingNode = &$this;

				$this->Name = $name;
				$this->Attributes = $attrs;
				return null;
			}

			$_tParent = &$this->parsingNode;
			$this->parsingNode = &$_tParent->createChildNode( $name, $attrs );

		}

		function _tagData($parser, $tagData) {
			if (( trim( $tagData ) || $this->parsingNode->Data )) {
				$this->parsingNode->Data .= $tagData;
			}

		}

		function _tagClosed($parser, $name) {
			if (!$this->parsingNode->getParentNode(  )) {
				return null;
			}

			$this->parsingNode = &$this->parsingNode->getParentNode(  );

		}

		function getChildrenByName($_Name) {
			$_TC = count( $this->ChildNodes );
			$Nodes = array(  );
			$j = 724;

			while ($j < $_TC) {
				if (!is_a( $this->ChildNodes[$j], 'xmlnodex' )) {
					continue;
				}


				if ($this->ChildNodes[$j]->getName(  ) == $_Name) {
					$Nodes[] = &$this->ChildNodes[$j];
				}

				++$j;
			}

			return $Nodes;
		}

		function getChildData($_ChildName) {
			$children = $this->getChildrenByName( $_ChildName );
			foreach ($children as $_child) {
				return $_child->getData(  );
			}

			return '';
		}

		function getFirstChildByName($ChildName) {
			$r_Children = $this->getChildrenByName( $ChildName );

			if (!count( $r_Children )) {
				$r_Children = null;
				return $r_Children;
			}

			return $r_Children[0];
		}

		function xPath($_xPath) {
			$TagNames = explode( '/', $_xPath );
			$_TagName = '';
			$Nodes = array(  );

			if (count( $TagNames )) {
				$_TagName = array_shift( $TagNames );

				if (!$_TagName) {
					continue;
				}

				$Ignore = false;

				if (preg_match( '/\[(.*?)\]/', $_TagName, $SubPatterns )) {
					$_TagName = preg_replace( '/\[.*?\]/', '', $_TagName );
					$r_tAttributes = explode( ',', $SubPatterns[1] );
					foreach ($r_tAttributes as $_Attribite) {
						$_Attribite = explode( '=', $_Attribite );
						$AttributeName = preg_replace( '/^\@/', '', $_Attribite[0] );
						$AttributeValue = preg_replace( '/^"(.*?)"$/', '', $_Attribite[1] );

						if ($this->getAttribute( $AttributeName ) != $AttributeValue) {
							$Ignore = true;
							break;
						}
					}
				}


				if (( ( !count( $TagNames ) && $_TagName == $this->getName(  ) ) && !$Ignore )) {
					$r_t = array( $this );
					return $r_t;
				}

				$chTagName = $TagNames[0];
				$r_Attributes = array(  );

				if (preg_match( '/\[(.*?)\]/', $chTagName, $SubPatterns )) {
					$chTagName = preg_replace( '/\[.*?\]/', '', $chTagName );
					$r_tAttributes = explode( ',', $SubPatterns[1] );
					foreach ($r_tAttributes as $_Attribite) {
						$_Attribite = explode( '=', $_Attribite );
						$r_Attributes[preg_replace( '/^\@/', '', $_Attribite[0] )] = preg_replace( '/^"(.*?)"$/', '$1', $_Attribite[1] );
					}
				}

				$ChildNodes = $this->getChildrenByName( $chTagName );
				$_TC = count( $ChildNodes );
				$n = 870;

				while ($n < $_TC) {
					$Ignore = false;
					foreach ($r_Attributes as $AttributeName => $AttributeValue) {

						if ($ChildNodes[$n]->getAttribute( $AttributeName ) != $AttributeValue) {
							$Ignore = true;
							break;
						}
					}


					if ($Ignore) {
						continue;
					}

					$Nodes = array_merge( $Nodes, $ChildNodes[$n]->xPath( '/' . implode( '/', $TagNames ) ) );
					++$n;
				}

				break;
			}

			return $Nodes;
		}

		function saveToFile($FileName, $Tabbed = false) {
			$fp = fopen( $FileName, 'w' );
			fwrite( $fp, $this->getNodeXML( -1, $Tabbed ) );
			fclose( $fp );
		}

		function setData($Data) {
			$this->Data = $Data;
		}

		function attribute($k, $v = null) {
			if (!is_null( $v )) {
				$this->Attributes[$k] = $v;
			}

			return $this->getAttribute( $k );
		}
	}

	$NodeID = 692;
?>