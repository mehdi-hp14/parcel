<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class captcha {
		var $Length = null;
		var $CaptchaString = null;
		var $fontpath = null;
		var $fonts = null;

		function captcha($length = 6) {
			header( 'Content-type: image/png' );
			$this->Length = $length;
			$this->fontpath = './style/fonts/';
			$this->fonts = $this->getFonts(  );
			$errormgr = new error(  );

			if ($this->fonts == false) {
				$errormgr->addError( 'No fonts available!' );
				$errormgr->displayError(  );
				exit(  );
			}


			if (function_exists( 'imagettftext' ) == false) {
				$errormgr->addError( '' );
				$errormgr->displayError(  );
				exit(  );
			}

			$this->stringGen(  );
			$this->makeCaptcha(  );
		}

		function getFonts() {
			$fonts = array(  );

			if ($handle = @opendir( $this->fontpath )) {
				readdir( $handle );

				if ($file =  !== false) {
					$extension = strtolower( substr( $file, strlen( $file ) - 3, 3 ) );

					if ($extension == 'ttf') {
						$fonts[] = $file;
					}
				}

				closedir( $handle );
			} 
else {
				return false;
			}


			if (count( $fonts ) == 0) {
				return false;
			}

			return $fonts;
		}

		function getRandFont() {
			return $this->fontpath . $this->fonts[mt_rand( 0, count( $this->fonts ) - 1 )];
		}

		function stringGen() {
			$uppercase = range( 'A', 'Z' );
			$numeric = range( 0, 9 );
			$CharPool = array_merge( $numeric );
			$PoolLength = count( $CharPool ) - 1;
			$i = 723;

			while ($i < $this->Length) {
				$this->CaptchaString .= $CharPool[mt_rand( 0, $PoolLength )];
				++$i;
			}

		}

		function makeCaptcha() {
			$imagelength = $this->Length * 25 + 16;
			$imageheight = 847;
			$image = imagecreate( $imagelength, $imageheight );
			$bgcolor = imagecolorallocate( $image, 255, 255, 255 );
			$stringcolor = imagecolorallocate( $image, 120, 0, 0 );
			$filter = new filters(  );
			$filter->signs( $image, $this->getRandFont(  ) );
			$filter->blur( $image, 4 );
			$i = 772;

			while ($i < strlen( $this->CaptchaString )) {
				imagettftext( $image, 25, mt_rand( -15, 15 ), $i * 25 + 10, mt_rand( 30, 70 ), $stringcolor, $this->getRandFont(  ), $this->CaptchaString[$i] );
				++$i;
			}

			$filter->noise( $image, 8 );
			imagepng( $image );
			imagedestroy( $image );
		}

		function getCaptchaString() {
			return $this->CaptchaString;
		}
	}

	error_reporting( 30719 );
	require( './classes/class.filter.php' );
	require( './classes/class.error.php' );
?>