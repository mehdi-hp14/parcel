<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	require_once( './classes/class.virtual.module.php' );
	class smsmail extends virtualmodule {
		var $Request = null;
		var $Responce = null;

		function smsmail($_ModuleConfigID = 0) {
			$this->LanguageDir = './includes/modules/smsmail/languages/';
			$this->ModuleType = SMSMAIL_MODULE;
			virtualmodule::virtualmodule( $_ModuleConfigID );
		}

		function sendsms($_SMSMessage, $_PhonesList, $_Params = array(  )) {
			if (!is_array( $_PhonesList )) {
				$_PhonesList = array( $_PhonesList );
			}

			$this->Request = $this->_preparerequest( $_SMSMessage, $_PhonesList, $_Params );
			$this->Responce = $this->_sendrequest( $this->Request );
			return $this->_parseresponce( $this->Responce );
		}

		function _preparerequest($_SMSMessage, $_PhonesList, $_Params) {
		}

		function _sendrequest($_Request) {
		}

		function _parseresponce($_Responce) {
		}

		function _translit($_Message) {
			$s = strtr( $_Message, array( '�' => 'a', '�' => 'b', '�' => 'v', '�' => 'g', '�' => 'd', '�' => 'e', '�' => 'jo', '�' => 'zh', '�' => 'z', '�' => 'i', '�' => 'jj', '�' => 'k', '�' => 'l', '�' => 'm', '�' => 'n', '�' => 'o', '�' => 'p', '�' => 'r', '�' => 's', '�' => 't', '�' => 'u', '�' => 'f', '�' => 'kh', '�' => 'c', '�' => 'ch', '�' => 'sh', '�' => 'shh', '�' => '"', '�' => 'y', '�' => '\'', '�' => 'eh', '�' => 'yu', '�' => 'ya', '�' => 'A', '�' => 'B', '�' => 'V', '�' => 'G', '�' => 'D', '�' => 'E', '�' => 'JO', '�' => 'ZH', '�' => 'Z', '�' => 'I', '�' => 'JJ', '�' => 'K', '�' => 'L', '�' => 'M', '�' => 'N', '�' => 'O', '�' => 'P', '�' => 'R', '�' => 'S', '�' => 'T', '�' => 'U', '�' => 'F', '�' => 'KH', '�' => 'C', '�' => 'CH', '�' => 'SH', '�' => 'SHH', '�' => '"', '�' => 'Y', '�' => '\'', '�' => 'EH', '�' => 'YU', '�' => 'YA' ) );
			return $s;
		}
	}

?>