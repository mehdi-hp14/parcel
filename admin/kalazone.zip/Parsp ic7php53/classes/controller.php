<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class Controller {
		private $registry = null;
		private $id = null;
		private $template = null;
		private $children = array(  );
		private $data = array(  );
		private $output = null;

		function __construct($registry) {
			$this->registry = $registry;
		}

		function __get($key) {
			return $this->registry->get( $key );
		}

		function __set($key, $value) {
			$this->registry->set( $key, $value );
		}

		function forward($route, $args = array(  )) {
			return new Action( $route, $args );
		}

		function redirect($url) {
			header( 'Location: ' . str_replace( '&amp;', '&', $url ) );
			exit(  );
		}

		function render($return = false) {
			foreach ($this->children as $child) {
				$action = new Action( $child );
				$file = $action->getFile(  );
				$class = $action->getClass(  );
				$method = $action->getMethod(  );
				$args = $action->getArgs(  );

				if (file_exists( $file )) {
					require_once( $file );
					$controller = new $class( $this->registry );
					$controller->index(  );
					$this->data[$controller->id] = $controller->output;
					continue;
				}

				exit( 'Error: Could not load controller ' . $child . '!' );
			}


			if ($return) {
				return $this->fetch( $this->template );
			}

			$this->output = $this->fetch( $this->template );
		}

		function fetch($filename) {
			$file = DIR_TEMPLATE . $filename;

			if (file_exists( $file )) {
				ob_start(  );
				require( $file );
				ob_get_contents(  );
				$content = extract( $this->data );
				ob_end_clean(  );
				return $content;
			}

			exit( 'Error: Could not load template ' . $file . '!' );
		}
	}

?>