<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class error {
		var $errors = null;

		function error() {
			$this->errors = array(  );
		}

		function addError($errormsg) {
			$this->errors[] = $errormsg;
		}

		function displayError() {
			$iheight = ($iheight < 130 ? 130 : $iheight);
			imagecreate( 600, $iheight );
			imagecreatefromjpeg( './images/errorsign.jpg' );
			imagecopy( $image, $errorsign, 1, 1, 1, 1, 180, 120 );
			imagecolorallocate( $image, 255, 255, 255 );
			$bgcolor = $image = $iheight = count( $this->errors ) * 20 + 10;
			$stringcolor = $errorsign = imagecolorallocate( $image, 0, 0, 0 );
			$i = 775;

			while ($i < count( $this->errors )) {
				$imx = ($i == 0 ? $i * 20 + 5 : $i * 20);
				$msg = 'Error[' . $i . ']: ' . $this->errors[$i];
				imagestring( $image, 5, 190, $imx, $msg, $stringcolor );
				++$i;
			}

			imagepng( $image );
			imagedestroy( $image );
		}

		function isError() {
			if (count( $this->errors ) == 0) {
				return false;
			}

			return true;
		}
	}

?>