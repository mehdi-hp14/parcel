<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class Grid extends Object {
		var $query_total_rows_num = null;
		var $query_select_rows = null;
		var $rows_num = 20;
		var $total_rows_num = null;
		var $headers = array(  );
		var $sort_fields = array(  );
		var $default_sort_field = '';
		var $default_sort_direction = '';
		var $show_rows_num_select = true;
		var $get_sort_name = 'sort';
		var $get_direction_name = 'direction';
		var $smarty_headers_name = 'GridHeaders';
		var $__debug = false;
		var $__row_handler = '';

		function setRowHandler($func_code) {
			$this->__row_handler = $func_code;
		}

		function registerHeader($title, $field_name = '', $default_sort = false, $default_sort_direction = 'asc', $align = '', $add_str = '') {
			$GetVars = $_GET;
			$this->headers[] = array( 'header_name' => translate( $title ), 'ascsort' => ($field_name ? array( 'getvars' => '&' . $this->get_sort_name . '=' . $field_name . '&' . $this->get_direction_name . '=ASC' ) : ''), 'descsort' => ($field_name ? array( 'getvars' => '&' . $this->get_sort_name . '=' . $field_name . '&' . $this->get_direction_name . '=DESC' ) : ''), 'add_str' => $add_str );
			$this->sort_fields[$field_name] = 1;
			$j = count( $this->headers ) - 1;

			if (( ( isset( $GetVars[$this->get_sort_name] ) && isset( $GetVars[$this->get_direction_name] ) ) && $this->headers[$j]['ascsort']['getvars'] == '&' . $this->get_sort_name . '=' . $GetVars[$this->get_sort_name] . '&' . $this->get_direction_name . '=' . $GetVars[$this->get_direction_name] )) {
				$this->headers[$j]['ascsort']['enabled'] = 1;
			} 
else {
				if (( ( isset( $GetVars[$this->get_sort_name] ) && isset( $GetVars[$this->get_direction_name] ) ) && $this->headers[$j]['descsort']['getvars'] == '&' . $this->get_sort_name . '=' . $GetVars[$this->get_sort_name] . '&' . $this->get_direction_name . '=' . $GetVars[$this->get_direction_name] )) {
					$this->headers[$j]['descsort']['enabled'] = 1;
				}
			}


			if (( !isset( $GetVars[$this->get_sort_name] ) && $default_sort )) {
				$this->headers[$j][strtolower( $this->default_sort_direction ) . 'sort']['enabled'] = 1;
			}

			$this->headers[$j]['defsort'] = $this->headers[$j][$default_sort_direction . 'sort'];

			if ($default_sort) {
				$this->default_sort_field = $field_name;
				( $default_sort && $default_sort_direction );
			}


			if () {
				$this->default_sort_direction = $default_sort_direction;
			}


			if ($align) {
				$this->headers[$j]['align'] = $align;
			}

		}

		function prepare() {
			$GetVars = $_GET;
			$PostVars = $_POST;

			if (isset( $PostVars['rows_num'] )) {
				renderURL( 'rows_num=' . $PostVars['rows_num'], '', true );
			}

			db_phquery( $this->query_total_rows_num );

			if ($this->__debug) {
				print '<br />' . $DBHandler->last_sql;
			}

			$this->total_rows_num = mysql_fetch_row( 0 );
			$rows_show_all = ( isset( $GetVars['rows_num'] ) && $GetVars['rows_num'] == 'show_all' );
			$this->rows_num = (( isset( $GetVars['rows_num'] ) && 0 < intval( $GetVars['rows_num'] ) ) ? intval( $GetVars['rows_num'] ) : $this->rows_num);
			$total_pages = ceil( $this->total_rows_num / $this->rows_num );
			$page = (( isset( $GetVars['page'] ) && 0 < intval( $GetVars['page'] ) ) ? intval( $GetVars['page'] ) : 1);

			if ($total_pages < $page) {
				$page = $func;
			}


			if ($page < 1) {
				$page = 918;
			}

			$sort = (( isset( $GetVars[$this->get_sort_name] ) && isset( $this->sort_fields[$GetVars[$this->get_sort_name]] ) ) ? $GetVars[$this->get_sort_name] : $this->default_sort_field);
			$direction = (( isset( $GetVars[$this->get_direction_name] ) && in_array( $GetVars[$this->get_direction_name], array( 'ASC', 'DESC' ) ) ) ? $GetVars[$this->get_direction_name] : $this->default_sort_direction);
			$DBRes = db_phquery( $this->query_select_rows . ($sort ? ' ORDER BY ' . $sort . ($direction ? ' ' . $direction : '') : '') . ($rows_show_all ? '' : ' LIMIT ' . ( $page - 1 ) * $this->rows_num . ', ' . $this->rows_num) );

			if ($this->__debug) {
				print '<br />' . $DBHandler->last_sql;
			}


			if ($this->__row_handler) {
				$func = create_function( '$row', $this->__row_handler );
			}

			$GridRows = array(  );

			if ($_row = mysql_fetch_assoc( $DBRes['resource'] )) {
				if (empty( $$func )) {
					$_row = call_user_func( $func, $_row );
				}

				$GridRows[] = $_row;
			}


			if ($this->show_rows_num_select) {
				$smarty->assign( 'rows_show_all', $rows_show_all );
			}


			if ($this->show_rows_num_select) {
				$smarty->assign( 'rows', array( 10 => 10, 20 => 20, 50 => 50, 100 => 100 ) );
			}

			$smart['rows_num'] = $this->rows_num;
			$smart['Lister'] = ($rows_show_all ? '' : getListerRange( $page, $total_pages, $this->rows_num ));
			$smart['GridRows'] = $GridRows;
			$smart['total_rows_num'] = $this->total_rows_num;
			$smart[$this->smarty_headers_name] = $this->headers;
			$smart['GridHeadersNum'] = count( $this->headers );
			return $smart;
		}

		function exportRows() {
			$Register = &Register::getInstance(  );
			$GetVars = &$Register->get( VAR_GET );
			$DBHandler = &$Register->get( VAR_DBHANDLER );
			$PostVars = &$Register->get( VAR_POST );

			$sort = (( isset( $GetVars[$this->get_sort_name] ) && isset( $this->sort_fields[$GetVars[$this->get_sort_name]] ) ) ? $GetVars[$this->get_sort_name] : $this->default_sort_field);
			$direction = (( isset( $GetVars[$this->get_direction_name] ) && in_array( $GetVars[$this->get_direction_name], array( 'ASC', 'DESC' ) ) ) ? $GetVars[$this->get_direction_name] : $this->default_sort_direction);
			$DBRes = $DBHandler->ph_query( $this->query_select_rows . ($sort ? ' ORDER BY ' . $sort . ($direction ? ' ' . $direction : '') : '') );

			if ($this->__debug) {
				print '<br />' . $DBHandler->last_sql;
			}


			if ($this->__row_handler) {
				$func = create_function( '$row', $this->__row_handler );
			}

			$GridRows = array(  );

			if ($_row = $DBRes->fetchAssoc(  )) {
				if (empty( $$func )) {
					$_row = call_user_func( $func, $_row );
				}

				$GridRows[] = $_row;
			}

			return $GridRows;
		}
	}

?>