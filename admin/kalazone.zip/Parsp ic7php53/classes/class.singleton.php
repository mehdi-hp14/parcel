<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class Singleton {
		function getInstance() {
			static $me = null;

			if (is_object( $me )) {
				return $me;
			}

			$me = new Register(  );
			return $me;
		}
	}

?>