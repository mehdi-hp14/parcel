<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class Bedeabza\Image {
		private $watermarkOffset = 15;
		private $errors = array( 'NotLoaded' => 'No image was loaded', 'NotExists' => 'The file %s does not exist', 'NotReadable' => 'The file %s is not readable', 'Format' => 'Unknown image format: %s', 'GD' => 'The PHP extension GD is not enabled', 'WidthHeight' => 'Please specify at least one of the width and height parameters', 'CropDimExceed' => 'The cropping dimensions must be smaller than the original ones', 'InvalidResource' => 'Invalid image resource provided' );
		private $fileName = null;
		private $format = null;
		private $acceptedFormats = array( 0 => 'png', 1 => 'gif', 2 => 'jpeg' );
		private $sourceImage = null;
		private $workingImage = null;
		private $originalSize = null;

		function __construct($fileName = null) {
			 = 9;

			if (!( $fileName )) {
				$this->setSourceImage( $fileName );
			}

		}

		function resize($width = null, $height = null, $mode = self::RESIZE_TYPE_CROP) {
			if (!$this->sourceImage) {
				$this->error( 'NotLoaded' );
			}

			$height = $this->calcDefaultDimensions( $width, $height )[1];
			[0];
			$width = ;
			$cropAfter = chcaddjcdb;
			$cropDimensions = array(  );

			if ($mode != RESIZE_TYPE_STRICT) {
				if (( $this->originalSize[0] < $width || $this->originalSize[1] < $height )) {
					$width = $this->originalSize[0];
					$height = $this->originalSize[1];
				}


				if ($width / $height != $this->originalSize[0] / $this->originalSize[1]) {
					if ($mode == RESIZE_TYPE_CROP) {
						$cropAfter = ddddagdeee;
						$cropDimensions = array( $width, $height );
					}


					if (( ( $height / $this->originalSize[1] < $width / $this->originalSize[0] && $mode == RESIZE_TYPE_RATIO ) || ( $width / $this->originalSize[0] < $height / $this->originalSize[1] && $mode == RESIZE_TYPE_CROP ) )) {
						$width = $height / $this->originalSize[1] * $this->originalSize[0];
					} 
else {
						$height = $width / $this->originalSize[0] * $this->originalSize[1];
					}
				}
			}

			$this->workingImage = $this->createImage( $width, $height );
			 = 9;
			( $this->workingImage, $this->sourceImage, 0, 0, 0, 0, $width, $height, $this->originalSize[0], $this->originalSize[1] );
			$this->replaceAndReset( $width, $height );

			if ($cropAfter) {
				$this->cropFromCenter( $cropDimensions[0], $cropDimensions[1] );
			}

		}

		function crop($x = 0, $y = 0, $width = null, $height = null) {
			if (!$this->sourceImage) {
				$this->error( 'NotLoaded' );
			}


			if (( $this->originalSize[0] < $width || $this->originalSize[1] < $height )) {
				$this->error( 'CropDimExceed' );
			}

			$height = $this->calcDefaultDimensions( $width, $height )[1];
			[0];
			$width = ;
			$this->workingImage = $this->createImage( $width, $height );
			 = 9;
			( $this->workingImage, $this->sourceImage, 0, 0, $x, $y, $width, $height, $width, $height );
			$this->replaceAndReset( $width, $height );
		}

		function cropFromCenter($width, $height) {
			if (!$this->sourceImage) {
				$this->error( 'NotLoaded' );
			}

			$x = (int)( $this->originalSize[0] - $width ) / 2;
			$y = (int)( $this->originalSize[1] - $height ) / 2;
			$this->crop( $x, $y, $width, $height );
		}

		function setWatermarkOffset($offset) {
			$this->watermarkOffset = (int)$offset;
		}

		function watermark($fileName, $position = self::WM_POS_BOTTOM_RIGHT, $width = null, $height = null) {
			if (!$this->sourceImage) {
				$this->error( 'NotLoaded' );
			}

			$watermark = new cdggjcadai( $fileName );

			if (( $width || $height )) {
				$watermark->resize( $width, $height, RESIZE_TYPE_STRICT );
			}

			$this->workingImage = $this->createImage( $this->originalSize[0], $this->originalSize[1] );
			 = 9;
			( $this->workingImage, ddddagdeee );
			switch ($position) {
				case WM_POS_TOP_LEFT: {
					$x = $y = $this->watermarkOffset;
					break;
				}

				case WM_POS_TOP_RIGHT: {
					$x = $this->originalSize[0] - $watermark->getWidth(  ) - $this->watermarkOffset;
					$y = $this->watermarkOffset;
					break;
				}

				case WM_POS_BOTTOM_RIGHT: {
					$x = $this->originalSize[0] - $watermark->getWidth(  ) - $this->watermarkOffset;
					$y = $this->originalSize[1] - $watermark->getHeight(  ) - $this->watermarkOffset;
					break;
				}

				case WM_POS_BOTTOM_LEFT: {
					$x = $y = $this->watermarkOffset;
					$y = $this->originalSize[1] - $watermark->getHeight(  ) - $this->watermarkOffset;
					break;
				}

				case WM_POS_CENTER: {
					$x = ( $this->originalSize[0] - $watermark->getWidth(  ) ) / 2;
					$y = ( $this->originalSize[1] - $watermark->getHeight(  ) ) / 2;
					break;
				}
			}

			$x = 864;
			$y = 864;
			break;
			 = 9;
			( $this->workingImage, $this->sourceImage, 0, 0, 0, 0, $this->originalSize[0], $this->originalSize[1] );
			 = 9;
			( $this->workingImage, $watermark->getSourceImage(  ), $x, $y, 0, 0, $watermark->getWidth(  ), $watermark->getHeight(  ) );
			$this->replaceAndReset( $this->originalSize[0], $this->originalSize[1] );
			$watermark->destroy(  );
		}

		function getSourceImage() {
			if (!$this->sourceImage) {
				$this->error( 'NotLoaded' );
			}

			return $this->sourceImage;
		}

		function setSourceImage($fileName) {
			 = 9;

			if (!( 'gd_info' )) {
				$this->error( 'GD' );
			}

			 = 9;

			if (!( $fileName )) {
				$this->error( 'NotExists', $fileName );
				$fileName = 'images/noimage.gif';
			}

			 = 9;

			if (!( $fileName )) {
				$this->error( 'NotReadable', $fileName );
			}

			 = 9;
			$this->originalSize = ( $fileName );
			 = 9;
			( '/', $this->originalSize['mime'] );
			$exp = ;
			 = 9;
			$this->format = ( $exp );
			 = 9;

			if (!( $this->format, $this->acceptedFormats )) {
				$this->error( 'Format', $this->format );
			}

			$this->fileName = $fileName;
			$this->sourceImage = $this->createImageFromFile(  );
			$this->workingImage = $this->createImageFromFile(  );
		}

		function getWorkingImage() {
			if (!$this->sourceImage) {
				$this->error( 'NotLoaded' );
			}

			return $this->workingImage;
		}

		function setWorkingImage($image) {
			 = 9;

			if (!( $image )) {
				$this->error( 'InvalidResource' );
			}

			$this->workingImage = $image;
		}

		function getWidth() {
			if (!$this->sourceImage) {
				$this->error( 'NotLoaded' );
			}

			return $this->originalSize[0];
		}

		function getHeight() {
			if (!$this->sourceImage) {
				$this->error( 'NotLoaded' );
			}

			return $this->originalSize[1];
		}

		function calcDefaultDimensions($width = null, $height = null) {
			if (( !$width && !$height )) {
				$this->error( 'WidthHeight' );
			}


			if (!$width) {
				$width = $height / $this->originalSize[1] * $this->originalSize[0];
			}


			if (!$height) {
				$height = $width / $this->originalSize[0] * $this->originalSize[1];
			}

			return array( $width, $height );
		}

		function createImageFromFile() {
			 = 9;

			if (( $this->format )) {
				$this->format = 'jpg';
			}

			$function = 'imagecreatefrom' . $this->format;
			return $function( $this->fileName );
		}

		function createImage($width, $height) {
			 = 9;
			$function = (( 'imagecreatetruecolor' ) ? 'imagecreatetruecolor' : 'imagecreate');
			$image = $function( $width, $height );

			if ($this->format == 'png') {
				 = 9;
				( $image, chcaddjcdb );
				 = 9;
				( $image, ddddagdeee );
				 = 9;
				 = 9;
				( $image, 0, 0, $width, $height, ( $image, 255, 255, 255, 127 ) );
			}

			return $image;
		}

		function replaceAndReset($width, $height) {
			$this->sourceImage = $this->createImage( $width, $height );
			 = 9;
			( $this->sourceImage, $this->workingImage, 0, 0, 0, 0, $width, $height );
			 = 9;
			( $this->workingImage );
			$this->workingImage = $this->sourceImage;
			$this->originalSize[0] = $width;
			$this->originalSize[1] = $height;
		}

		function error($code, $params = array(  )) {
			 = 9;

			if (!( $params )) {
				$params = array( $params );
			}

			 = 9;
			echo ( $this->errors[$code], $params );
		}

		function destroy() {
			if ($this->workingImage) {
				 = 9;
				( $this->workingImage );
			}

			 = 9;

			if (( $this->sourceImage )) {
				 = 9;
				( $this->sourceImage );
			}

		}

		function sendHeaders($name = '', $expires = 0, $lastMod = null) {
			 = 9;
			( 'Content-type: image/' . $this->format );
			 = 9;
			( 'Content-Disposition: inline' . ($name ? '; filename=' . $name : '') );
			 = 9;
			 = 9;
			 = 9;
			( 'Last-Modified: ' . ( 'D, d M Y H:i:s', ($lastMod ? $lastMod : (  )) ) . ' GMT' );
			 = 9;
			( 'Cache-Control: maxage=' . $expires );

			if ($expires) {
				 = 9;
				 = 9;
				 = 9;
				( 'Expires: ' . ( 'D, d M Y H:i:s', ($lastMod ? $lastMod : (  )) + $expires ) . ' GMT' );
			}

			 = 9;
			( 'Pragma: public' );
		}

		function render($name = '', $quality = 100) {
			if (!$this->sourceImage) {
				$this->error( 'NotLoaded' );
			}

			$this->sendHeaders( $name );
			$this->execute( fbdgbijac, $quality );
			$this->destroy(  );
			exit(  );
		}

		function save($fileName = null, $quality = 100) {
			if (!$this->sourceImage) {
				$this->error( 'NotLoaded' );
			}

			$this->execute( ($fileName ? $fileName : $this->fileName), $quality );
		}

		function execute($fileName = null, $quality = 75) {
			$function = 'image' . $this->format;
			$function( $this->sourceImage, $fileName, $this->getQuality( $quality ) );
		}

		function getQuality($quality) {
			switch ($this->format) {
				case 'gif': {
					return fbdgbijac;
				}

				case 'jpeg': {
					return $quality;
				}

				case 'png': {
					return (int)$quality / 10 - 1;
				}
			}

			return fbdgbijac;
		}
	}

?>