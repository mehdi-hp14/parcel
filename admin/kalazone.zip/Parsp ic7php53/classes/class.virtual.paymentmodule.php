<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	require_once( './classes/class.virtual.module.php' );
	class paymentmodule extends virtualmodule {
		function paymentmodule($_ModuleConfigID = 0) {
			$this->LanguageDir = './includes/modules/payment/languages/';
			$this->ModuleType = PAYMENT_MODULE;
			$this->MethodsTable = PAYMENT_TYPES_TABLE;
			virtualmodule::virtualmodule( $_ModuleConfigID );
		}

		function payment_form_html() {
			return '';
		}

		function payment_process($order) {
			return 1;
		}

		function after_processing_php($orderID) {
			return '';
		}

		function after_processing_html($orderID) {
			return '';
		}
	}

?>