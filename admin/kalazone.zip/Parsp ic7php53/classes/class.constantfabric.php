<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class constantfabric {
		function generateconstant($_ConstantName) {
			static $GeneratorCounter = 1001;

			if (!$_ConstantName) {
				return false;
			}


			if (defined( $_ConstantName )) {
				return false;
			}

			define( $_ConstantName, $GeneratorCounter );
			return $GeneratorCounter++;
		}
	}

?>