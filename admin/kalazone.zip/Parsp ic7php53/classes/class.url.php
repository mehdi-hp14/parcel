<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class URL {
		var $URI = '';
		var $Scheme = '';
		var $Host = '';
		var $Path = '';
		var $Query = '';
		var $Fragment = '';
		var $Port = '';

		function isRealHost() {
			return isset( $_SERVER['HTTP_X_REAL_HOST'] );
		}

		function loadFromServerInfo() {
			$this->Scheme = (URL::isHttps(  ) ? 'https' : 'http');

			if ($this->isRealHost(  )) {
				$this->Host = $_SERVER['HTTP_X_REAL_HOST'];
			} 
else {
				$this->Host = (isset( $_SERVER['HTTP_HOST'] ) ? $_SERVER['HTTP_HOST'] : $_SERVER['HTTPS_HOST']);
			}

			$this->Host = preg_replace( '/:([\d]+)$/', '', $this->Host );
			$Parsed = parse_url( $_SERVER['REQUEST_URI'] );
			$this->Path = (isset( $Parsed['path'] ) ? $Parsed['path'] : '');
			$this->Query = (isset( $Parsed['query'] ) ? $Parsed['query'] : '');
			$this->Fragment = (isset( $Parsed['fragment'] ) ? $Parsed['fragment'] : '');

			if ($this->isRealHost(  )) {
				$this->Path = str_replace( '/sabadekharid/', '/', $this->Path );
				$this->Path = str_replace( '//', '/', $this->Path );
			}

			$this->constructURI(  );
		}

		function set($url) {
			$this->URI = $url;
			$parsed = parse_url( $this->URI );
			$this->Scheme = (isset( $parsed['scheme'] ) ? $parsed['scheme'] : '');
			$this->Host = (isset( $parsed['host'] ) ? $parsed['host'] : '');
			$this->Path = (isset( $parsed['path'] ) ? $parsed['path'] : '');
			$this->Query = (isset( $parsed['query'] ) ? $parsed['query'] : '');
			$this->Fragment = (isset( $parsed['fragment'] ) ? $parsed['fragment'] : '');
		}

		function constructURI() {
			$this->URI = $this->Scheme . '://' . $this->Host . $this->Path . ($this->Query ? '?' . $this->Query : '') . ($this->Fragment ? '#' . $this->Fragment : '');
		}

		function getScheme() {
			return $this->Scheme;
		}

		function setScheme($Scheme) {
			$this->Scheme = $Scheme;
			$this->constructURI(  );
		}

		function getHost() {
			return $this->Host;
		}

		function setHost($Host) {
			$this->Host = $Host;
			$this->constructURI(  );
		}

		function setPath($Path) {
			if (substr( $Path, 0, 1 ) == '/') {
				$this->Path = $Path;
			} 
else {
				$this->Path = preg_replace( '@\/[^\/]*$@', '/', $this->Path ) . $Path;
			}


			if ($this->isRealHost(  )) {
				$this->Path = str_replace( '/shop/', '/', $this->Path );
				$this->Path = str_replace( '//', '/', $this->Path );
			}

			$this->constructURI(  );
		}

		function getURI() {
			return $this->URI;
		}

		function setQuery($Query) {
			$this->Query = str_replace( '?', '', renderURL( $Query, '?' . $this->Query, false, false ) );
			$this->constructURI(  );
		}

		function redirect() {
			Redirect( $this->getURI(  ) );
		}

		function getPath() {
			return $this->Path;
		}

		function getPathQuery() {
			return $this->Path . ($this->Query ? '?' . $this->Query : '');
		}

		function isHttps() {
			$https = false;

			if (( isset( $_SERVER['HTTPS'] ) && strtolower( $_SERVER['HTTPS'] ) != 'off' )) {
				$https = true;
			}


			if (( isset( $_SERVER['SCRIPT_URI'] ) && preg_match( '@^https://@', $_SERVER['SCRIPT_URI'] ) )) {
				$https = true;
			}


			if (( isset( $_SERVER['SCRIPT_URI'] ) && preg_match( '@^http://[^/^:]+:443/@', $_SERVER['SCRIPT_URI'] ) )) {
				$https = true;
			}


			if (( isset( $_SERVER['HTTP_X_SCHEME'] ) && preg_match( '@^https@i', $_SERVER['HTTP_X_SCHEME'] ) )) {
				$https = true;
			}


			if (( isset( $_SERVER['DOCUMENT_ROOT'] ) && preg_match( '@/httpsdocs/?@i', $_SERVER['DOCUMENT_ROOT'] ) )) {
				$https = true;
			}

			return $https;
		}
	}

?>