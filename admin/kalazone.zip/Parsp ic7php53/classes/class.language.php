<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'LOCALTYPE_HIDDEN', 'hidden' );
	define( 'LOCALTYPE_FRONTEND', 'front' );
	define( 'LOCALTYPE_BACKEND', 'back' );
	define( 'LOCALTYPE_GENERAL', 'general' );
	class Language extends Object {
		var $id = '';
		var $iso2 = '';
		var $name = '';
		var $enabled = '';
		var $priority = '';
		var $thumbnail = '';
		var $direction = '';
		var $isdefault = '';

		function setName($name) {
			$this->name = $name;
		}

		function setISO2($iso2) {
			$this->iso2 = substr( $iso2, 0, 2 );
		}

		function enabled($enabled = null) {
			if (!is_null( $enabled )) {
				$this->enabled = $enabled;
			}

			return $this->enabled;
		}

		function setPriority($priority) {
			$this->priority = $priority;
		}

		function getPriority() {
			return $this->priority;
		}

		function setThumbnail($thumbnail) {
			$this->thumbnail = $thumbnail;
		}

		function getName() {
			return $this->name;
		}

		function getThumbnail() {
			return $this->thumbnail;
		}

		function getThumbnailURL() {
			return (( file_exists( $this->getThumbnail(  ) ) && $this->getThumbnail(  ) ) ? $this->getThumbnail(  ) : '');
		}

		function loadById($id) {
			$dbq = db_query( 'SELECT * FROM ' . LANGUAGE_TABLE . ' WHERE id=' . $id );

			if (!mysql_num_rows( $dbq['resource'] )) {
				return 'error_nolang';
			}

			$this->loadFromArray( mysql_fetch_assoc( $dbq['resource'] ) );
		}

		function loadByISO2($iso2) {
			$dbq = db_query( 'SELECT * FROM ' . LANGUAGE_TABLE . ' WHERE iso2=\'' . $iso2 . '\'' );

			if (!mysql_num_rows( $dbq['resource'] )) {
				return 'error_nolang';
			}

			$this->loadFromArray( mysql_fetch_assoc( $dbq['resource'] ) );
		}

		function save() {
			$this->setISO2( $this->iso2 );
			ClassManager::includeClass( 'LanguagesManager' );
			$is_new = 1017;
			$is_new = !( 0 < $this->id );
			$update_mlfields = false;

			if ($this->isdefault) {
				$dbq = 'UPDATE ?#LANGUAGE_TABLE SET  `isdefault`=false';
				db_phquery( $dbq );
			}


			if (!$is_new) {
				$DBRes = db_query( 'SELECT * FROM ' . LANGUAGE_TABLE . ' WHERE iso2=\'' . $this->iso2 . '\' AND id<>' . $this->id );
			} 
else {
				$DBRes = db_query( 'SELECT * FROM ' . LANGUAGE_TABLE . ' WHERE iso2=\'' . $this->iso2 . '\'' );
			}


			if (mysql_num_rows( $DBRes )) {
				return 'THIS LANGUAGE IS RESERVED';
			}


			if (!$is_new) {
				$origLanguageEntry = new Language(  );
				$origLanguageEntry->loadById( $this->id );
				$update_mlfields = $origLanguageEntry->iso2 != $this->iso2;
				$dbq = 'UPDATE ?#LANGUAGE_TABLE SET `name`=?name, `thumbnail`=?thumbnail, `enabled`=?enabled, `priority`=?priority, `iso2`=?iso2, `direction`=?direction , `isdefault`=?isdefault
					      WHERE `id`=?id';
			} 
else {
				$dbq = '
					INSERT ?#LANGUAGE_TABLE (`name`,`thumbnail`, `enabled`, `priority`, `iso2`, `direction`,`isdefault`)
					VALUES(?name, ?thumbnail, ?enabled, ?priority, ?iso2, ?direction,?isdefault)';
			}


			if ($this->priority <= 0) {
				$this->priority = 1 + LanguagesManager::getMaxLanguagePriority(  );
			}

			$DBRes = db_phquery( $dbq, $this->getVars(  ) );

			if ($is_new) {
				$this->id = db_insert_id(  );
				$ml_tables_info = LanguagesManager::getMLTablesInfo(  );

				if (count( $ml_tables_info )) {
					$dbstructure = new xmlNodeX(  );
					$dbstructure->renderTreeFromFile( DIR_ROOT . '/cfg/db_structure.xml' );
				}

				foreach ($ml_tables_info as $table_name => $table_fields) {

					if (!count( $table_fields )) {
						continue;
					}

					$xpath = 'DataBaseStructure/tables/table[@name="' . $table_name . '"]/column[@MULTI=true]';
					$r_xnColumn = $dbstructure->xPath( $xpath );
					$r_columns = array(  );
					foreach ($r_xnColumn as $xnColumn) {
						$r_columns[$xnColumn->getData(  )] = $xnColumn;
					}

					foreach ($table_fields as $i => $field) {
						$xmlColumn = new XmlNode(  );
						$xmlColumn->SetXmlNodeAttributes( $r_columns[$field]->getAttributes(  ) );
						define( 'INSTALL_LANGS', $this->iso2 );
						$xmlColumn->SetXmlNodeData( $field );
						$table_fields[$i] = GetColumnSQL( $xmlColumn, false );
					}


					if (defined( 'DBTABLE_PREFIX' )) {
						$table_name_new = str_replace( DBTABLE_PREFIX, 'Parsp_', $table_name );
					}

					$dbq = '
						ALTER TABLE `' . $table_name_new . '` ADD ' . implode( ', ADD ', $table_fields ) . '
	  				';
					$DBHandler = new DataBase(  );
					$DBHandler->connect( DB_HOST, DB_USER, DB_PASS );
					$DBHandler->selectDB( DB_NAME );
					$DBRes = $DBHandler->ph_query( $dbq );
				}
			}


			if ($update_mlfields) {
				$ml_tables_info = LanguagesManager::getMLTablesInfo(  );

				if (count( $ml_tables_info )) {
					$dbstructure = new xmlNodeX(  );
					$dbstructure->renderTreeFromFile( DIR_ROOT . '/cfg/db_structure.xml' );
				}

				foreach ($ml_tables_info as $table_name => $table_fields) {

					if (!count( $table_fields )) {
						continue;
					}

					$xpath = 'DataBaseStructure/tables/table[@name="' . (defined( 'DBTABLE_PREFIX' ) ? str_replace( DBTABLE_PREFIX, 'Parsp_', $table_name ) : $table_name) . '"]/column[@MULTI=true]';
					$r_xnColumn = $dbstructure->xPath( $xpath );
					$r_columns = array(  );
					foreach ($r_xnColumn as $xnColumn) {
						$r_columns[$xnColumn->getData(  )] = $xnColumn;
					}

					foreach ($table_fields as $i => $field) {
						$xmlColumn = new XmlNode(  );
						$xmlColumn->SetXmlNodeAttributes( $r_columns[$field]->getAttributes(  ) );
						$xmlColumn->SetXmlNodeData( $field . '_' . $this->iso2 );
						$field_definition = GetColumnSQL( $xmlColumn, false );
						$dbq = '
							ALTER TABLE `' . $table_name . '` CHANGE ' . ( $field . '_' . $origLanguageEntry->iso2 ) . ' ' . $field_definition . '
		  				';
						$DBHandler = new DataBase(  );
						$DBHandler->connect( DB_HOST, DB_USER, DB_PASS );
						$DBHandler->selectDB( DB_NAME );
						$DBRes = $DBHandler->ph_query( $dbq );
					}
				}
			}

		}

		function getLocals($group, $full_info, $group_by_subgroups) {
			$dbq = '
				SELECT `id`,`expstr`, `translate` ' . ($full_info ? ', `grname`, `subgroup`' : '') . ' FROM ' . LOCALS_TABLE . ' WHERE iso2=? AND `grname` IN (?@)
				ORDER BY `id` ASC
			';

			if (!is_array( $group )) {
				$group = strtolower( $group );
			} 
else {
				$group = 'admin';
			}

			$DBRes = db_phquery( $dbq, $this->iso2, (is_array( $group ) ? $group : array( $group )) );
			$locals = array(  );

			if ($row = mysql_fetch_assoc( $DBRes['resource'] )) {
				$locals[$row['expstr']] = ($full_info ? $row : $row['translate']);
			}

			return $locals;
		}

		function updateLocal($local_key, $local_value) {
			if (db_phquery_fetch( DBRFETCH_FIRST, 'SELECT 1 FROM ' . LOCALS_TABLE . ' WHERE `expstr`=? AND `iso2`=?', $local_key, $this->iso2 )) {
				$dbq = '
 					UPDATE ' . LOCALS_TABLE . ' SET `translate`=? WHERE `expstr`=? AND `iso2`=?
				';
				$DBRes = db_phquery( $dbq, $local_value, $local_key, $this->iso2 );
				return null;
			}

			$DefLanguageEntry = &ClassManager::getInstance( 'Language' );

			$res = $DefLanguageEntry->loadById( CONF_DEFAULT_LANG );
			$def_local = $DefLanguageEntry->getLocal( $local_key );
			return $this->addLocal( $local_key, $local_value, $def_local['group'], $def_local['subgroup'] );
		}

		function addLocal($local_key, $local_value, $local_group, $local_subgroup) {
			$dbq = 'INSERT ' . LOCALS_TABLE . ' (`expstr`, `iso2`, `translate`, `grname`, `subgroup`)
				VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE `translate`=VALUES(`translate`)';
			$DBRes = db_phquery( $dbq, $local_key, $this->iso2, $local_value, $local_group, $local_subgroup );
		}

		function getLocal($local_key) {
			$dbq = '
				SELECT * FROM ' . LOCALS_TABLE . ' WHERE `expstr`=? AND `iso2`=?
			';
			$DBRes = db_phquery( $dbq, $local_key, $this->iso2 );
			return mysql_fetch_assoc( $DBRes );
		}

		function deleteLocal($local_key) {
			$dbq = '
				DELETE FROM ' . LOCALS_TABLE . ' WHERE `expstr`=?
			';
			return db_phquery( $dbq, $local_key );
		}

		function delete() {
			$dbq = '
				DELETE FROM ' . LOCALS_TABLE . ' WHERE iso2=?';
			db_phquery( $dbq, $this->iso2 );
			$dbq = '
				DELETE FROM ?#LANGUAGE_TABLE WHERE id=?';
			db_phquery( $dbq, $this->id );
			$ml_tables_info = LanguagesManager::getMLTablesInfo(  );
			foreach ($ml_tables_info as $table_name => $table_fields) {

				if (!count( $table_fields )) {
					continue;
				}

				foreach ($table_fields as $i => $field) {
					$table_fields[$i] = $field . '_' . $this->iso2;
				}

				$dbq = '
					ALTER TABLE `' . $table_name . '` DROP `' . implode( '`, DROP `', $table_fields ) . '`
  				';
				db_phquery( $dbq );
			}

		}

		function isDefault() {
			$DMS = db_query( 'SELECT id FROM ' . LANGUAGE_TABLE . ' WHERE isdefault=true' );
			$row = db_fetch_row( $DMS );
			return $this->id == $row['id'];
		}

		function _getCacheDir() {
			return DIR_TEMP . '/loc_cache';
		}

		function _getCachePath($cache_key) {
			return $this->_getCacheDir(  ) . '/serlang' . $this->id . '_' . md5( $cache_key ) . '.cch';
		}

		function _findCache($cache_key) {
			if (!file_exists( $this->_getCachePath( $cache_key ) )) {
				return false;
			}

			return file_exists( $this->_getCachePath( $cache_key ) );
		}

		function _getCache($cache_key) {
			return unserialize( file_get_contents( $this->_getCachePath( $cache_key ) ) );
		}

		function _makeCache($cache_key, $data) {
			checkPath( $this->_getCacheDir(  ) );
			$fp = fopen( $this->_getCachePath( $cache_key ), 'w' );
			fwrite( $fp, serialize( $data ) );
			fclose( $fp );
		}

		function _dumpArray($data) {
			if (!is_array( $data )) {
				return '\'' . str_replace( '\'', '\\'', str_replace( '\\', '\\', $data ) ) . '\',';
			}

			$_dump = '';
			foreach ($data as $k => $v) {
				$_dump .= '\'' . str_replace( '\'', '\\'', str_replace( '\\', '\\', $k ) ) . '\' => ' . (is_array( $v ) ? 'array(' . $this->_dumpArray( $v ) . '),' : '\'' . str_replace( '\'', '\\'', str_replace( '\\', '\\', $v ) ) . '\',');
			}

			return $_dump;
		}

		function setdefault($type) {
			$this->isdefault = $type;
		}

		function _dropCache() {
			if (file_exists( $this->_getCacheDir(  ) )) {
				delete_file( $this->_getCacheDir(  ) );
			}

			return true;
		}
	}

?>