<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class pData {
		var $Data = null;
		var $Palette = array( 0 => array( 'R' => 188, 'G' => 224, 'B' => 46, 'Alpha' => 100 ), 1 => array( 'R' => 224, 'G' => 100, 'B' => 46, 'Alpha' => 100 ), 2 => array( 'R' => 224, 'G' => 214, 'B' => 46, 'Alpha' => 100 ), 3 => array( 'R' => 46, 'G' => 151, 'B' => 224, 'Alpha' => 100 ), 4 => array( 'R' => 176, 'G' => 46, 'B' => 224, 'Alpha' => 100 ), 5 => array( 'R' => 224, 'G' => 46, 'B' => 117, 'Alpha' => 100 ), 6 => array( 'R' => 92, 'G' => 224, 'B' => 46, 'Alpha' => 100 ), 7 => array( 'R' => 224, 'G' => 176, 'B' => 46, 'Alpha' => 100 ) );

		function pData() {
			$this->Data = '';
			$this->Data['XAxisDisplay'] = AXIS_FORMAT_DEFAULT;
			$this->Data['XAxisFormat'] = null;
			$this->Data['XAxisName'] = null;
			$this->Data['XAxisUnit'] = null;
			$this->Data['Abscissa'] = null;
			$this->Data['AbsicssaPosition'] = AXIS_POSITION_BOTTOM;
			$this->Data['Axis'][0]['Display'] = AXIS_FORMAT_DEFAULT;
			$this->Data['Axis'][0]['Position'] = AXIS_POSITION_LEFT;
			$this->Data['Axis'][0]['Identity'] = AXIS_Y;
		}

		function addPoints($Values, $SerieName = 'Serie1') {
			if (!isset( $this->Data['Series'][$SerieName] )) {
				$this->initialise( $SerieName );
			}


			if (is_array( $Values )) {
				foreach ($Values as $Key => $Value) {
					$this->Data['Series'][$SerieName]['Data'][] = $Value;
				}
			} 
else {
				$this->Data['Series'][$SerieName]['Data'][] = $Values;
			}


			if ($Values != VOID) {
				$StrippedData = $this->stripVOID( $this->Data['Series'][$SerieName]['Data'] );

				if (empty( $$StrippedData )) {
					$this->Data['Series'][$SerieName]['Max'] = 0;
					$this->Data['Series'][$SerieName]['Min'] = 0;
					return 0;
				}

				$this->Data['Series'][$SerieName]['Max'] = max( $StrippedData );
				$this->Data['Series'][$SerieName]['Min'] = min( $StrippedData );
			}

		}

		function stripVOID($Values) {
			if (!is_array( $Values )) {
				return array(  );
			}

			$Result = array(  );
			foreach ($Values as $Key => $Value) {

				if ($Value != VOID) {
					$Result[] = $Value;
					continue;
				}
			}

			return $Result;
		}

		function getSerieCount($Serie) {
			if (isset( $this->Data['Series'][$Serie]['Data'] )) {
				return sizeof( $this->Data['Series'][$Serie]['Data'] );
			}

			return 0;
		}

		function removeSerie($Series) {
			if (!is_array( $Series )) {
				$Series = $this->convertToArray( $Series );
			}

			foreach ($Series as $Key => $Serie) {

				if (isset( $this->Data['Series'][$Serie] )) {
					unset( $this->Data['Series'][$Serie] );
					continue;
				}
			}

		}

		function getValueAt($Serie, $Index = 0) {
			if (isset( $this->Data['Series'][$Serie]['Data'][$Index] )) {
				return $this->Data['Series'][$Serie]['Data'][$Index];
			}

		}

		function getValues($Serie) {
			if (isset( $this->Data['Series'][$Serie]['Data'] )) {
				return $this->Data['Series'][$Serie]['Data'];
			}

		}

		function reverseSerie($Series) {
			if (!is_array( $Series )) {
				$Series = $this->convertToArray( $Series );
			}

			foreach ($Series as $Key => $Serie) {

				if (isset( $this->Data['Series'][$Serie]['Data'] )) {
					$this->Data['Series'][$Serie]['Data'] = array_reverse( $this->Data['Series'][$Serie]['Data'] );
					continue;
				}
			}

		}

		function getSum($Serie) {
			if (isset( $this->Data['Series'][$Serie] )) {
				return array_sum( $this->Data['Series'][$Serie]['Data'] );
			}

		}

		function getMax($Serie) {
			if (isset( $this->Data['Series'][$Serie]['Max'] )) {
				return $this->Data['Series'][$Serie]['Max'];
			}

		}

		function getMin($Serie) {
			if (isset( $this->Data['Series'][$Serie]['Min'] )) {
				return $this->Data['Series'][$Serie]['Min'];
			}

		}

		function setSerieShape($Series, $Shape = ) {
			if (!is_array( $Series )) {
				$Series = $this->convertToArray( $Series );
			}

			foreach ($Series as $Key => $Serie) {

				if (isset( $this->Data['Series'][$Serie] )) {
					$this->Data['Series'][$Serie]['Shape'] = $Shape;
					continue;
				}
			}

		}

		function setSerieDescription($Series, $Description = 'My serie') {
			if (!is_array( $Series )) {
				$Series = $this->convertToArray( $Series );
			}

			foreach ($Series as $Key => $Serie) {

				if (isset( $this->Data['Series'][$Serie] )) {
					$this->Data['Series'][$Serie]['Description'] = $Description;
					continue;
				}
			}

		}

		function setSerieDrawable($Series, $Drawable = true) {
			if (!is_array( $Series )) {
				$Series = $this->convertToArray( $Series );
			}

			foreach ($Series as $Key => $Serie) {

				if (isset( $this->Data['Series'][$Serie] )) {
					$this->Data['Series'][$Serie]['isDrawable'] = $Drawable;
					continue;
				}
			}

		}

		function setSeriePicture($Series, $Picture = null) {
			if (!is_array( $Series )) {
				$Series = $this->convertToArray( $Series );
			}

			foreach ($Series as $Key => $Serie) {

				if (isset( $this->Data['Series'][$Serie] )) {
					$this->Data['Series'][$Serie]['Picture'] = $Picture;
					continue;
				}
			}

		}

		function setXAxisName($Name) {
			$this->Data['XAxisName'] = $Name;
		}

		function setXAxisDisplay($Mode, $Format = null) {
			$this->Data['XAxisDisplay'] = $Mode;
			$this->Data['XAxisFormat'] = $Format;
		}

		function setXAxisUnit($Unit) {
			$this->Data['XAxisUnit'] = $Unit;
		}

		function setAbscissa($Serie) {
			if (isset( $this->Data['Series'][$Serie] )) {
				$this->Data['Abscissa'] = $Serie;
			}

		}

		function setAbsicssaPosition($Position = ) {
			$this->Data['AbsicssaPosition'] = $Position;
		}

		function setAbscissaName($Name) {
			$this->Data['AbscissaName'] = $Name;
		}

		function setScatterSerie($SerieX, $SerieY, $ID = 0) {
			if (( isset( $this->Data['Series'][$SerieX] ) && isset( $this->Data['Series'][$SerieY] ) )) {
				$this->initScatterSerie( $ID );
				$this->Data['ScatterSeries'][$ID]['X'] = $SerieX;
				$this->Data['ScatterSeries'][$ID]['Y'] = $SerieY;
			}

		}

		function setScatterSerieShape($ID, $Shape = ) {
			if (isset( $this->Data['ScatterSeries'][$ID] )) {
				$this->Data['ScatterSeries'][$ID]['Shape'] = $Shape;
			}

		}

		function setScatterSerieDescription($ID, $Description = 'My serie') {
			if (isset( $this->Data['ScatterSeries'][$ID] )) {
				$this->Data['ScatterSeries'][$ID]['Description'] = $Description;
			}

		}

		function setScatterSeriePicture($ID, $Picture = null) {
			if (isset( $this->Data['ScatterSeries'][$ID] )) {
				$this->Data['ScatterSeries'][$ID]['Picture'] = $Picture;
			}

		}

		function setScatterSerieDrawable($ID, $Drawable = true) {
			if (isset( $this->Data['ScatterSeries'][$ID] )) {
				$this->Data['ScatterSeries'][$ID]['isDrawable'] = $Drawable;
			}

		}

		function setScatterSerieTicks($ID, $Width = 0) {
			if (isset( $this->Data['ScatterSeries'][$ID] )) {
				$this->Data['ScatterSeries'][$ID]['Ticks'] = $Width;
			}

		}

		function setScatterSerieWeight($ID, $Weight = 0) {
			if (isset( $this->Data['ScatterSeries'][$ID] )) {
				$this->Data['ScatterSeries'][$ID]['Weight'] = $Weight;
			}

		}

		function setScatterSerieColor($ID, $Format) {
			$R = (isset( $Format['R'] ) ? $Format['R'] : 0);
			$G = (isset( $Format['G'] ) ? $Format['G'] : 0);
			$B = (isset( $Format['B'] ) ? $Format['B'] : 0);
			$Alpha = (isset( $Format['Alpha'] ) ? $Format['Alpha'] : 100);

			if (isset( $this->Data['ScatterSeries'][$ID] )) {
				$this->Data['ScatterSeries'][$ID]['Color']['R'] = $R;
				$this->Data['ScatterSeries'][$ID]['Color']['G'] = $G;
				$this->Data['ScatterSeries'][$ID]['Color']['B'] = $B;
				$this->Data['ScatterSeries'][$ID]['Color']['Alpha'] = $Alpha;
			}

		}

		function limits() {
			$GlobalMin = ABSOLUTE_MAX;
			$GlobalMax = ABSOLUTE_MIN;
			foreach ($this->Data['Series'] as $Key => $Value) {

				if (( $this->Data['Abscissa'] != $Key && $this->Data['Series'][$Key]['isDrawable'] == true )) {
					if ($this->Data['Series'][$Key]['Min'] < $GlobalMin) {
						$GlobalMin = $this->Data['Series'][$Key]['Min'];
					}


					if ($GlobalMax < $this->Data['Series'][$Key]['Max']) {
						$GlobalMax = $this->Data['Series'][$Key]['Max'];
						continue;
					}

					continue;
				}
			}

			$this->Data['Min'] = $GlobalMin;
			$this->Data['Max'] = $GlobalMax;
			return array( $GlobalMin, $GlobalMax );
		}

		function drawAll() {
			foreach ($this->Data['Series'] as $Key => $Value) {

				if ($this->Data['Abscissa'] != $Key) {
					$this->Data['Series'][$Key]['isDrawable'] = true;
					continue;
				}
			}

		}

		function getSerieAverage($Serie) {
			if (isset( $this->Data['Series'][$Serie] )) {
				$SerieData = $this->stripVOID( $this->Data['Series'][$Serie]['Data'] );
				return array_sum( $SerieData ) / sizeof( $SerieData );
			}

		}

		function getGeometricMean($Serie) {
			if (isset( $this->Data['Series'][$Serie] )) {
				$SerieData = $this->stripVOID( $this->Data['Series'][$Serie]['Data'] );
				$Seriesum = 725;
				foreach ($SerieData as $Key => $Value) {
					$Seriesum = $Seriesum * $Value;
				}

				return pow( $Seriesum, 1 / sizeof( $SerieData ) );
			}

		}

		function getHarmonicMean($Serie) {
			if (isset( $this->Data['Series'][$Serie] )) {
				$SerieData = $this->stripVOID( $this->Data['Series'][$Serie]['Data'] );
				$Seriesum = 721;
				foreach ($SerieData as $Key => $Value) {
					$Seriesum = $Seriesum + 1 / $Value;
				}

				return sizeof( $SerieData ) / $Seriesum;
			}

		}

		function getStandardDeviation($Serie) {
			if (isset( $this->Data['Series'][$Serie] )) {
				$Average = $this->getSerieAverage( $Serie );
				$SerieData = $this->stripVOID( $this->Data['Series'][$Serie]['Data'] );
				$DeviationSum = 731;
				foreach ($SerieData as $Value) {
					$DeviationSum = $DeviationSum + ( $Value - $Average ) * ( $Value - $Average );
				}

				$Deviation = sqrt( $DeviationSum / count( $SerieData ) );
				return $Deviation;
			}

		}

		function getCoefficientOfVariation($Serie) {
			if (isset( $this->Data['Series'][$Serie] )) {
				$Average = $this->getSerieAverage( $Serie );
				$StandardDeviation = $this->getStandardDeviation( $Serie );

				if ($StandardDeviation != 0) {
					return $StandardDeviation / $Average;
				}

				return null;
			}

		}

		function getSerieMedian($Serie) {
			if (isset( $this->Data['Series'][$Serie] )) {
				$SerieData = $this->stripVOID( $this->Data['Series'][$Serie]['Data'] );
				sort( $SerieData );
				$SerieCenter = floor( sizeof( $SerieData ) / 2 );

				if (isset( $SerieData[$SerieCenter] )) {
					return $SerieData[$SerieCenter];
				}

				return null;
			}

		}

		function getSeriePercentile($Serie = 'Serie1', $Percentil = 95) {
			if (!isset( $this->Data['Series'][$Serie]['Data'] )) {
				return null;
			}

			$Values = count( $this->Data['Series'][$Serie]['Data'] ) - 1;

			if ($Values < 0) {
				$Values = 736;
			}

			$PercentilID = floor( $Values / 100 * $Percentil + 0.5 );
			$SortedValues = $this->Data['Series'][$Serie]['Data'];
			sort( $SortedValues );

			if (is_numeric( $SortedValues[$PercentilID] )) {
				return $SortedValues[$PercentilID];
			}

		}

		function addRandomValues($SerieName = 'Serie1', $Options = '') {
			$Values = (isset( $Options['Values'] ) ? $Options['Values'] : 20);
			$Min = (isset( $Options['Min'] ) ? $Options['Min'] : 0);
			$Max = (isset( $Options['Max'] ) ? $Options['Max'] : 100);
			$withFloat = (isset( $Options['withFloat'] ) ? $Options['withFloat'] : false);
			$i = 747;

			while ($i <= $Values) {
				if ($withFloat) {
					$Value = rand( $Min * 100, $Max * 100 ) / 100;
				} 
else {
					$Value = rand( $Min, $Max );
				}

				$this->addPoints( $Value, $SerieName );
				++$i;
			}

		}

		function containsData() {
			if (!isset( $this->Data['Series'] )) {
				return false;
			}

			$Result = false;
			foreach ($this->Data['Series'] as $Key => $Value) {

				if (( $this->Data['Abscissa'] != $Key && $this->Data['Series'][$Key]['isDrawable'] == true )) {
					$Result = true;
					continue;
				}
			}

			return $Result;
		}

		function setAxisDisplay($AxisID, $Mode = , $Format = null) {
			if (isset( $this->Data['Axis'][$AxisID] )) {
				$this->Data['Axis'][$AxisID]['Display'] = $Mode;

				if ($Format != null) {
					$this->Data['Axis'][$AxisID]['Format'] = $Format;
				}
			}

		}

		function setAxisPosition($AxisID, $Position = ) {
			if (isset( $this->Data['Axis'][$AxisID] )) {
				$this->Data['Axis'][$AxisID]['Position'] = $Position;
			}

		}

		function setAxisUnit($AxisID, $Unit) {
			if (isset( $this->Data['Axis'][$AxisID] )) {
				$this->Data['Axis'][$AxisID]['Unit'] = $Unit;
			}

		}

		function setAxisName($AxisID, $Name) {
			if (isset( $this->Data['Axis'][$AxisID] )) {
				$this->Data['Axis'][$AxisID]['Name'] = $Name;
			}

		}

		function setAxisColor($AxisID, $Format) {
			$R = (isset( $Format['R'] ) ? $Format['R'] : 0);
			$G = (isset( $Format['G'] ) ? $Format['G'] : 0);
			$B = (isset( $Format['B'] ) ? $Format['B'] : 0);
			$Alpha = (isset( $Format['Alpha'] ) ? $Format['Alpha'] : 100);

			if (isset( $this->Data['Axis'][$AxisID] )) {
				$this->Data['Axis'][$AxisID]['Color']['R'] = $R;
				$this->Data['Axis'][$AxisID]['Color']['G'] = $G;
				$this->Data['Axis'][$AxisID]['Color']['B'] = $B;
				$this->Data['Axis'][$AxisID]['Color']['Alpha'] = $Alpha;
			}

		}

		function setAxisXY($AxisID, $Identity = ) {
			if (isset( $this->Data['Axis'][$AxisID] )) {
				$this->Data['Axis'][$AxisID]['Identity'] = $Identity;
			}

		}

		function setSerieOnAxis($Series, $AxisID) {
			if (!is_array( $Series )) {
				$Series = $this->convertToArray( $Series );
			}

			foreach ($Series as $Key => $Serie) {
				$PreviousAxis = $this->Data['Series'][$Serie]['Axis'];

				if (!isset( $this->Data['Axis'][$AxisID] )) {
					$this->Data['Axis'][$AxisID]['Position'] = AXIS_POSITION_LEFT;
					$this->Data['Axis'][$AxisID]['Identity'] = AXIS_Y;
				}

				$this->Data['Series'][$Serie]['Axis'] = $AxisID;
				$Found = false;
				foreach ($this->Data['Series'] as $SerieName => $Values) {

					if ($Values['Axis'] == $PreviousAxis) {
						$Found = true;
						continue;
					}
				}


				if (!$Found) {
					unset( $this->Data['Axis'][$PreviousAxis] );
					continue;
				}
			}

		}

		function setSerieTicks($Series, $Width = 0) {
			if (!is_array( $Series )) {
				$Series = $this->convertToArray( $Series );
			}

			foreach ($Series as $Key => $Serie) {

				if (isset( $this->Data['Series'][$Serie] )) {
					$this->Data['Series'][$Serie]['Ticks'] = $Width;
					continue;
				}
			}

		}

		function setSerieWeight($Series, $Weight = 0) {
			if (!is_array( $Series )) {
				$Series = $this->convertToArray( $Series );
			}

			foreach ($Series as $Key => $Serie) {

				if (isset( $this->Data['Series'][$Serie] )) {
					$this->Data['Series'][$Serie]['Weight'] = $Weight;
					continue;
				}
			}

		}

		function getSeriePalette($Serie) {
			if (!isset( $this->Data['Series'][$Serie] )) {
				return null;
			}

			$Result = '';
			$Result['R'] = $this->Data['Series'][$Serie]['Color']['R'];
			$Result['G'] = $this->Data['Series'][$Serie]['Color']['G'];
			$Result['B'] = $this->Data['Series'][$Serie]['Color']['B'];
			$Result['Alpha'] = $this->Data['Series'][$Serie]['Color']['Alpha'];
			return $Result;
		}

		function setPalette($Series, $Format = null) {
			if (!is_array( $Series )) {
				$Series = $this->convertToArray( $Series );
			}

			foreach ($Series as $Key => $Serie) {
				$R = (isset( $Format['R'] ) ? $Format['R'] : 0);
				$G = (isset( $Format['G'] ) ? $Format['G'] : 0);
				$B = (isset( $Format['B'] ) ? $Format['B'] : 0);
				$Alpha = (isset( $Format['Alpha'] ) ? $Format['Alpha'] : 100);

				if (isset( $this->Data['Series'][$Serie] )) {
					$OldR = $this->Data['Series'][$Serie]['Color']['R'];
					$OldG = $this->Data['Series'][$Serie]['Color']['G'];
					$OldB = $this->Data['Series'][$Serie]['Color']['B'];
					$this->Data['Series'][$Serie]['Color']['R'] = $R;
					$this->Data['Series'][$Serie]['Color']['G'] = $G;
					$this->Data['Series'][$Serie]['Color']['B'] = $B;
					$this->Data['Series'][$Serie]['Color']['Alpha'] = $Alpha;
					foreach ($this->Palette as $Key => $Value) {

						if (( ( $Value['R'] == $OldR && $Value['G'] == $OldG ) && $Value['B'] == $OldB )) {
							$this->Palette[$Key]['R'] = $R;
							$this->Palette[$Key]['G'] = $G;
							$this->Palette[$Key]['B'] = $B;
							$this->Palette[$Key]['Alpha'] = $Alpha;
							continue;
						}
					}

					continue;
				}
			}

		}

		function loadPalette($FileName, $Overwrite = false) {
			if (!file_exists( $FileName )) {
				return -1;
			}


			if ($Overwrite) {
				$this->Palette = '';
			}

			$fileHandle = @fopen( $FileName, 'r' );

			if (!$fileHandle) {
				return -1;
			}


			while (!feof( $fileHandle )) {
				$buffer = fgets( $fileHandle, 4096 );

				if (preg_match( '/,/', $buffer )) {
					$Alpha = preg_split( '/,/', $buffer )[3];
					[2];
					$B = ;
					[1];
					$G = ;
					[0];
					$R = ;

					if ($this->Palette == '') {
						$ID = 797;
					} 
else {
						$ID = count( $this->Palette );
					}

					$this->Palette[$ID] = array( 'R' => $R, 'G' => $G, 'B' => $B, 'Alpha' => $Alpha );
					continue;
				}
			}

			fclose( $fileHandle );
			$ID = 797;

			if (isset( $this->Data['Series'] )) {
				foreach ($this->Data['Series'] as $Key => $Value) {

					if (!isset( $this->Palette[$ID] )) {
						$this->Data['Series'][$Key]['Color'] = array( 'R' => 0, 'G' => 0, 'B' => 0, 'Alpha' => 0 );
					} 
else {
						$this->Data['Series'][$Key]['Color'] = $this->Palette[$ID];
					}

					++$ID;
				}
			}

		}

		function initScatterSerie($ID) {
			if (isset( $this->Data['ScatterSeries'][$ID] )) {
				return 0;
			}

			$this->Data['ScatterSeries'][$ID]['Description'] = 'Scatter ' . $ID;
			$this->Data['ScatterSeries'][$ID]['isDrawable'] = true;
			$this->Data['ScatterSeries'][$ID]['Picture'] = null;
			$this->Data['ScatterSeries'][$ID]['Ticks'] = 0;
			$this->Data['ScatterSeries'][$ID]['Weight'] = 0;

			if (isset( $this->Palette[$ID] )) {
				$this->Data['ScatterSeries'][$ID]['Color'] = $this->Palette[$ID];
				return null;
			}

			$this->Data['ScatterSeries'][$ID]['Color']['R'] = rand( 0, 255 );
			$this->Data['ScatterSeries'][$ID]['Color']['G'] = rand( 0, 255 );
			$this->Data['ScatterSeries'][$ID]['Color']['B'] = rand( 0, 255 );
			$this->Data['ScatterSeries'][$ID]['Color']['Alpha'] = 100;
		}

		function initialise($Serie) {
			if (isset( $this->Data['Series'] )) {
				$ID = count( $this->Data['Series'] );
			} 
else {
				$ID = 797;
			}

			$this->Data['Series'][$Serie]['Description'] = $Serie;
			$this->Data['Series'][$Serie]['isDrawable'] = true;
			$this->Data['Series'][$Serie]['Picture'] = null;
			$this->Data['Series'][$Serie]['Max'] = null;
			$this->Data['Series'][$Serie]['Min'] = null;
			$this->Data['Series'][$Serie]['Axis'] = 0;
			$this->Data['Series'][$Serie]['Ticks'] = 0;
			$this->Data['Series'][$Serie]['Weight'] = 0;
			$this->Data['Series'][$Serie]['Shape'] = SERIE_SHAPE_FILLEDCIRCLE;

			if (isset( $this->Palette[$ID] )) {
				$this->Data['Series'][$Serie]['Color'] = $this->Palette[$ID];
				return null;
			}

			$this->Data['Series'][$Serie]['Color']['R'] = rand( 0, 255 );
			$this->Data['Series'][$Serie]['Color']['G'] = rand( 0, 255 );
			$this->Data['Series'][$Serie]['Color']['B'] = rand( 0, 255 );
			$this->Data['Series'][$Serie]['Color']['Alpha'] = 100;
		}

		function normalize($NormalizationFactor = 100, $UnitChange = null, $Round = 1) {
			$Abscissa = $this->Data['Abscissa'];
			$SelectedSeries = '';
			$MaxVal = 875;
			foreach ($this->Data['Axis'] as $AxisID => $Axis) {

				if ($UnitChange != null) {
					$this->Data['Axis'][$AxisID]['Unit'] = $UnitChange;
				}

				foreach ($this->Data['Series'] as $SerieName => $Serie) {

					if (( ( $Serie['Axis'] == $AxisID && $Serie['isDrawable'] == true ) && $SerieName != $Abscissa )) {
						$SelectedSeries[$SerieName] = $SerieName;

						if ($MaxVal < count( $Serie['Data'] )) {
							$MaxVal = count( $Serie['Data'] );
							continue;
						}

						continue;
					}
				}
			}

			$i = 875;

			while ($i <= $MaxVal - 1) {
				$Factor = 875;
				foreach ($SelectedSeries as $Key => $SerieName) {
					$Value = $this->Data['Series'][$SerieName]['Data'][$i];

					if ($Value != VOID) {
						$Factor = $Factor + abs( $Value );
						continue;
					}
				}


				if ($Factor != 0) {
					$Factor = $NormalizationFactor / $Factor;
					foreach ($SelectedSeries as $Key => $SerieName) {
						$Value = $this->Data['Series'][$SerieName]['Data'][$i];

						if (( $Value != VOID && $Factor != $NormalizationFactor )) {
							$this->Data['Series'][$SerieName]['Data'][$i] = round( abs( $Value ) * $Factor, $Round );
							continue;
						}


						if (( $Value == VOID || $Value == 0 )) {
							$this->Data['Series'][$SerieName]['Data'][$i] = VOID;
							continue;
						}


						if ($Factor == $NormalizationFactor) {
							$this->Data['Series'][$SerieName]['Data'][$i] = $NormalizationFactor;
							continue;
						}
					}
				}

				++$i;
			}

			foreach ($SelectedSeries as $Key => $SerieName) {
				$this->Data['Series'][$SerieName]['Max'] = max( $this->stripVOID( $this->Data['Series'][$SerieName]['Data'] ) );
				$this->Data['Series'][$SerieName]['Min'] = min( $this->stripVOID( $this->Data['Series'][$SerieName]['Data'] ) );
			}

		}

		function importFromCSV($FileName, $Options = '') {
			$Delimiter = (isset( $Options['Delimiter'] ) ? $Options['Delimiter'] : ',');
			$GotHeader = (isset( $Options['GotHeader'] ) ? $Options['GotHeader'] : false);
			$SkipColumns = (isset( $Options['SkipColumns'] ) ? $Options['SkipColumns'] : array( -1 ));
			$DefaultSerieName = (isset( $Options['DefaultSerieName'] ) ? $Options['DefaultSerieName'] : 'Serie');
			$Handle = @fopen( $FileName, 'r' );

			if ($Handle) {
				$HeaderParsed = false;
				$SerieNames = '';

				while (!feof( $Handle )) {
					$Buffer = fgets( $Handle, 4096 );
					$Buffer = str_replace( chr( 10 ), '', $Buffer );
					$Buffer = str_replace( chr( 13 ), '', $Buffer );
					$Values = preg_split( '/' . $Delimiter . '/', $Buffer );

					if ($Buffer != '') {
						if (( $GotHeader && !$HeaderParsed )) {
							foreach ($Values as $Key => $Name) {

								if (!in_array( $Key, $SkipColumns )) {
									$SerieNames[$Key] = $Name;
									continue;
								}
							}

							$HeaderParsed = true;
							continue;
						}


						if ($SerieNames == '') {
							foreach ($Values as $Key => $Name) {

								if (!in_array( $Key, $SkipColumns )) {
									$SerieNames[$Key] = $DefaultSerieName . $Key;
									continue;
								}
							}
						}

						foreach ($Values as $Key => $Value) {

							if (!in_array( $Key, $SkipColumns )) {
								$this->addPoints( $Value, $SerieNames[$Key] );
								continue;
							}
						}

						continue;
					}
				}

				fclose( $Handle );
			}

		}

		function createFunctionSerie($SerieName, $Formula = '', $Options = '') {
			$MinX = (isset( $Options['MinX'] ) ? $Options['MinX'] : -10);
			$MaxX = (isset( $Options['MaxX'] ) ? $Options['MaxX'] : 10);
			$XStep = (isset( $Options['XStep'] ) ? $Options['XStep'] : 1);
			$AutoDescription = (isset( $Options['AutoDescription'] ) ? $Options['AutoDescription'] : false);
			$RecordAbscissa = (isset( $Options['RecordAbscissa'] ) ? $Options['RecordAbscissa'] : false);
			$AbscissaSerie = (isset( $Options['AbscissaSerie'] ) ? $Options['AbscissaSerie'] : 'Abscissa');

			if ($Formula == '') {
				return 0;
			}

			$Result = '';
			$Abscissa = '';
			$i = $Abscissa;

			while ($i <= $MaxX) {
				$Expression = '$return = \'!\'.(' . str_replace( 'z', $i, $Formula ) . ');';

				if (@eval( $Expression ) === false) {
					$return = VOID;
				}


				if ($return == '!') {
					$return = VOID;
				} 
else {
					$return = $this->right( $return, strlen( $return ) - 1 );
				}


				if ($return == 'NAN') {
					$return = VOID;
				}


				if ($return == 'INF') {
					$return = VOID;
				}


				if ($return == '-INF') {
					$return = VOID;
				}

				$Abscissa[] = $i;
				$Result[] = $return;
				$i = $i + $XStep;
			}

			$this->addPoints( $Result, $SerieName );

			if ($AutoDescription) {
				$this->setSerieDescription( $SerieName, $Formula );
			}


			if ($RecordAbscissa) {
				$this->addPoints( $Abscissa, $AbscissaSerie );
			}

		}

		function negateValues($Series) {
			if (!is_array( $Series )) {
				$Series = $this->convertToArray( $Series );
			}

			foreach ($Series as $Key => $SerieName) {

				if (isset( $this->Data['Series'][$SerieName] )) {
					$Data = '';
					foreach ($this->Data['Series'][$SerieName]['Data'] as $Key => $Value) {

						if ($Value == VOID) {
							$Data[] = VOID;
							continue;
						}

						$Data[] = 0 - $Value;
					}

					$this->Data['Series'][$SerieName]['Data'] = $Data;
					$this->Data['Series'][$SerieName]['Max'] = max( $this->stripVOID( $this->Data['Series'][$SerieName]['Data'] ) );
					$this->Data['Series'][$SerieName]['Min'] = min( $this->stripVOID( $this->Data['Series'][$SerieName]['Data'] ) );
					continue;
				}
			}

		}

		function getData() {
			return $this->Data;
		}

		function savePalette($ID, $Color) {
			$this->Palette[$ID] = $Color;
		}

		function getPalette() {
			return $this->Palette;
		}

		function saveAxisConfig($Axis) {
			$this->Data['Axis'] = $Axis;
		}

		function saveYMargin($Value) {
			$this->Data['YMargin'] = $Value;
		}

		function saveExtendedData($Tag, $Values) {
			$this->Data['Extended'][$Tag] = $Values;
		}

		function saveOrientation($Orientation) {
			$this->Data['Orientation'] = $Orientation;
		}

		function convertToArray($Value) {
			$Values = '';
			$Values[] = $Value;
			return $Values;
		}

		function __toString() {
			return 'pData object.';
		}

		function left($value, $NbChar) {
			return substr( $value, 0, $NbChar );
		}

		function right($value, $NbChar) {
			return substr( $value, strlen( $value ) - $NbChar, $NbChar );
		}

		function mid($value, $Depart, $NbChar) {
			return substr( $value, $Depart - 1, $NbChar );
		}
	}

	define( 'AXIS_FORMAT_DEFAULT', 680001 );
	define( 'AXIS_FORMAT_TIME', 680002 );
	define( 'AXIS_FORMAT_DATE', 680003 );
	define( 'AXIS_FORMAT_METRIC', 680004 );
	define( 'AXIS_FORMAT_CURRENCY', 680005 );
	define( 'AXIS_FORMAT_CUSTOM', 680006 );
	define( 'AXIS_POSITION_LEFT', 681001 );
	define( 'AXIS_POSITION_RIGHT', 681002 );
	define( 'AXIS_POSITION_TOP', 681001 );
	define( 'AXIS_POSITION_BOTTOM', 681002 );
	define( 'SERIE_SHAPE_FILLEDCIRCLE', 681011 );
	define( 'SERIE_SHAPE_FILLEDTRIANGLE', 681012 );
	define( 'SERIE_SHAPE_FILLEDSQUARE', 681013 );
	define( 'SERIE_SHAPE_FILLEDDIAMOND', 681017 );
	define( 'SERIE_SHAPE_CIRCLE', 681014 );
	define( 'SERIE_SHAPE_TRIANGLE', 681015 );
	define( 'SERIE_SHAPE_SQUARE', 681016 );
	define( 'SERIE_SHAPE_DIAMOND', 681018 );
	define( 'AXIS_X', 682001 );
	define( 'AXIS_Y', 682002 );
	define( 'ABSOLUTE_MIN', -10000000000000 );
	define( 'ABSOLUTE_MAX', 10000000000000 );
	define( 'VOID', 0.123456788999999997336054 );
	define( 'EURO_SYMBOL', utf8_encode( '&#8364;' ) );
?>