<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function add_department($admin_tab) {
		global $admin_departments;

		$i = 724;

		while (( $i < count( $admin_departments ) && $admin_departments[$i]['sort_order'] < $admin_tab['sort_order'] )) {
			++$i;
		}

		$j = count( $admin_departments ) - 1;

		while ($i <= $j) {
			$admin_departments[$j + 1] = $admin_departments[$j];
			--$j;
		}

		$admin_departments[$i] = $admin_tab;
	}

	function mark_as_selected($a, $b) {
		return (!strcmp( $a, $b ) ? ' selected' : '');
	}

	function get_NOTempty_elements_count($arr) {
		$n = 709;
		$i = 709;

		while ($i < count( $arr )) {
			if (trim( $arr[$i] ) != '') {
				++$n;
			}

			++$i;
		}

		return $n;
	}

	ini_set( 'display_errors', 0 );
	ob_start(  );
	define( 'DIR_ROOT', str_replace( '\\', '/', realpath( dirname( __FILE__ ) ) ) );
	include( './cfg/paths.inc.php' );
	include( './cfg/connect.inc.php' );
	include( './includes/database/' . DBMS . '.php' );
	include( './core_functions/functions.php' );
	include( './core_functions/category_functions.php' );
	include( './core_functions/product_functions.php' );
	include( './core_functions/statistic_functions.php' );
	include( './core_functions/custgroup_functions.php' );
	include( './core_functions/reg_fields_functions.php' );
	include( './core_functions/catalog_import_functions.php' );
	include( './core_functions/option_functions.php' );
	include( './core_functions/country_functions.php' );
	include( './core_functions/city_functions.php' );
	include( './core_functions/zone_functions.php' );
	include( './core_functions/xml_parser.php' );
	include( './core_functions/serialization_functions.php' );
	include( './core_functions/registration_functions.php' );
	include( './core_functions/discussion_functions.php' );
	include( './core_functions/datetime_functions.php' );
	include( './core_functions/aux_pages_functions.php' );
	include( './core_functions/setting_functions.php' );
	include( './core_functions/picture_functions.php' );
	include( './core_functions/video_functions.php' );
	include( './core_functions/tax_function.php' );
	include( './core_functions/shipping_functions.php' );
	include( './core_functions/payment_functions.php' );
	include( './core_functions/discount_functions.php' );
	include( './core_functions/currency_functions.php' );
	include( './core_functions/order_functions.php' );
	include( './core_functions/crypto/crypto_functions.php' );
	include( './core_functions/subscribers_functions.php' );
	include( './core_functions/cart_functions.php' );
	include( './core_functions/report_function.php' );
	include( './core_functions/order_amount_functions.php' );
	include( './core_functions/linkexchange_functions.php' );
	include( './core_functions/jalalicalendar_functions.php' );
	include( './core_functions/affiliate_functions.php' );
	include( './core_functions/module_function.php' );
	include( './core_functions/mail_function.php' );
	include( './core_functions/account_functions.php' );
	include( './core_functions/bankbill_functions.php' );
	include( './classes/class.virtual.shippingratecalculator.php' );
	include( './classes/class.virtual.paymentmodule.php' );
	include( './core_functions/productlist_functions.php' );
	include( './core_functions/excel_functions.php' );
	include_once( './ckeditor/ckeditor.php' );
	include( './classes/xml2array.php' );
	include( './classes/class.object.php' );
	include( './classes/class.classmanager.php' );
	include( './classes/class.language.php' );
	include( './classes/class.languagesmanager.php' );
	include( './classes/class.virtual.smsmail.php' );
	include( './classes/class.singleton.php' );
	include( './classes/class.register.php' );
	include( './classes/class.database.php' );
	include( './classes/class.dbresource.php' );
	include( './classes/class.xmlnode.php' );
	include( './classes/class.polliz.php' );
	require_once( './smarty/Smarty.class.php' );
	require_once( './smarty/resources/resource.rfile.php' );
	require_once( './smarty/resources/resource.register.php' );
	require_once( './classes/class.viewsc.php' );
	include( './includes/modules/smsmail/class.smsnotify.php' );
	session_start(  );
	$domain = $_SERVER['SERVER_NAME'];
	$domain = ltrim( $domain, '.www' );
	MagicQuotesRuntimeSetting(  );
	$smarty = new ViewSC(  );
	$smarty_mail = new ViewSC(  );
	$lang = LanguagesManager::getDefaultLanguage(  )->iso2;

	if (isset( $_POST['lang'] )) {
		LanguagesManager::setCurrentLanguage( $_POST['lang'] );
		RedirectSQ(  );
	}


	if (isset( $_GET['lang'] )) {
		LanguagesManager::setCurrentLanguage( $_GET['lang'] );
		RedirectSQ( 'lang=' );
	}


	if (( !MOD_REWRITE_SUPPORT && isset( $_GET['lang_iso2'] ) )) {
		LanguagesManager::getLanguageByISO2( $_GET['lang_iso2'] );
		$lang = ;

		if ($lang != null) {
			LanguagesManager::setCurrentLanguage( $lang->id );
		}

		RedirectSQ( 'lang_iso2=' );
	}


	if (isset( $_POST['lang'] )) {
		$_SESSION['current_language'] = $_POST['lang'];
	}


	if (!( $q = db_query( 'select * from ' . LOCALS_TABLE . ' where iso2=\'' . $lang . '\'' ))) {
		exit( db_error(  ) );
		(bool)true;
	}

	$i = 1398;

	if ($row = db_fetch_row( $q )) {
		++$i;
		define( $row['expstr'], $row['translate'] );
	}


	if ($i == 0) {
		echo '
    <script>    
      alert(\'ERROR: Not Any translation for this language.\');
    </script>
    ';
	}


	if (!( db_connect( DB_HOST, DB_USER, DB_PASS ))) {
		exit( db_error(  ) );
		(bool)true;
	}


	if (!( db_select_db( DB_NAME ))) {
		exit( db_error(  ) );
		(bool)true;
	}


	if (isset( $_POST['sessionok'] )) {
		$val = 1398;

		if ($_POST['session_type']) {
			$val = $_POST['session_time'];
		}

		$seting = _setSettingOptionValue( 'CONF_SESSION_TIMEOUT', $val );
		define( 'CONF_SESSION_TIMEOUT', $val );
	}

	settingDefineConstants(  );

	if (!empty( $$templateDirectory )) {
		$templateDirectory = CONF_TEMPLATES_DIR;
	}


	if ((int)CONF_SMARTY_FORCE_COMPILE) {
		$smarty->force_compile = true;
	}

	$smarty->assign( 'safemode', false );
	$smarty->assign( 'constant_managment', 0 );
	$smarty->assign( 'InstalledModuleConfigs', null );
	include( './checklogin.php' );

	if (!isset( $_SESSION['log'] )) {
		$_POST = xStripSlashesGPC( $_POST );
		$_GET = xStripSlashesGPC( $_GET );

		if (( isset( $_POST['fLogin'] ) && isset( $_POST['fPassword'] ) )) {
			if (regAuthenticate( $_POST['fLogin'], $_POST['fPassword'] )) {
				Redirect( set_query( '&__tt=' ) );
			}

			Redirect( set_query( '&login=' . urlencode( $_POST['fLogin'] ) . '&error=1' ) );
		}


		if (isset( $_GET['error'] )) {
			$smarty->assign( 'Error', 1 );
		}


		if (isset( $_GET['login'] )) {
			$smarty->assign( 'Login', urldecode( $_GET['login'] ) );
		}

		$smarty->template_dir = './templates';
		$smarty->display( 'backend/auth_form.tpl.html' );
		exit(  );
	}

	$smarty->template_dir = './templates';

	if (isset( $_GET['page'] )) {
		$_POST['page'] = $_GET['page'];
	}


	if (( isset( $_GET['credit'] ) && isset( $_GET['changecredit'] ) )) {
		unset( $_GET[changecredit] );
		unset( $_POST[changecredit] );
		$ref = $_SERVER['HTTP_REFERER'];
		$customerID = $_GET['customerID'];
		$credit = $_GET['credit'];

		if (strstr( $ref, 'admincp.php?' )) {
			$query = 'UPDATE Parsp_customers SET credit=' . $credit . ' WHERE customerID=' . $customerID;
		} 
else {
			echo 'no permition';
		}


		if (!( $res = mysql_query( $query ))) {
			exit( '���� ����� ������ ����� �� ���! ����� �� �� �� ���� ������ ���� ������' );
			(bool)true;
		}


		if ($res) {
			echo show_price( $credit, CONF_DEFAULT_CURRENCY, CONF_DEFAULT_CURRENCY, 1 );
		}

		mysql_close(  );
		exit(  );
	}


	if (!isset( $_GET['tab'] )) {
		$tab = (isset( $_POST['tab'] ) ? $_POST['tab'] : '');
	} 
else {
		$tab = $_GET['tab'];
	}


	if (!isset( $_GET['sub'] )) {
		if (isset( $_POST['sub'] )) {
			$sub = $_POST['sub'];
		}
	} 
else {
		$sub = $_GET['sub'];
	}


	if (isset( $_GET['safemode'] )) {
		$smarty->assign( 'safemode', ADMIN_SAFEMODE_WARNING );
	}

	$smarty->assign( 'admin_main_content_template', 'default.tpl.html' );
	$smarty->assign( 'current_tab', $tab );

	if (!( $q = db_query( 'select count(*) from ' . ORDERS_TABLE ))) {
		exit( db_error(  ) );
		(bool)true;
	}

	$n = db_fetch_row( $q );
	$smarty->assign( 'new_orders_count', $n[0] );
	regGetCustomerInfo2( $_SESSION['log'] );
	$custinfo = ;
	GetGroupById( $custinfo['custgroupID'] );
	$custgroup = include( './core_functions/coupons_functions.php' );

	if ($custgroup['action_list'] == '') {
		$smarty->template_dir = './templates';
		$smarty->display( 'backend/auth_form.tpl.html' );
		$_SESSION['log'] = '';
		exit(  );
	}

	$admin_departments = array(  );
	opendir( './includes/admin' );
	$includes_dir = include( './core_functions/xml_installer/xml_installer.php' );
	$file_count = 1398;
	readdir( $includes_dir );

	if ($inc_file = include( './core_functions/order_status_functions.php' ) != false) {
		if (strstr( $inc_file, '.php' )) {
			include( './includes/admin/' . $inc_file );
			++$file_count;

			if ($tab == $admin_tab['id']) {
				$notid = 1398;
				foreach ($admin_tab['sub_departments'] as $key => $value) {

					if (!is_numeric( stripos( $custgroup['action_list'], $value['id'] ) )) {
						$admin_tab['sub_departments'][$key]['name'] = '<small style=\'color:#D59B9B;cursor: default;\'>' . $value['name'] . '</small>';
						$admin_tab['sub_departments'][$key]['id'] = '';
						++$notid;
						continue;
					}
				}

				$smarty->assign( 'admin_sub_departments', $admin_tab['sub_departments'] );

				if (empty( $$admin_tab )) {
					$smarty->assign( 'admin_main_content_template', $admin_tab['id'] . '.tpl.html' );
				}

				$ad_tab = $res;
			}
		}
	}

	$smarty->assign( 'admin_departments', $admin_departments );

	if (is_numeric( stripos( $custgroup['action_list'], 'list' ) )) {
		$custgroup['action_list'] = $custgroup['action_list'] . 'addtolist';
	}


	if ($notid == count( $ad_tab['sub_departments'] )) {
		$notid = 1398;
	}


	if (!empty( $$sub )) {
		$sub = $ad_tab['sub_departments'][$notid]['id'];
	}


	if (empty( $$sub )) {
		if (!is_numeric( stripos( $custgroup['action_list'], $sub ) )) {
			$smarty->assign( 'admin_sub_tab', 'error_forbbiden.tpl.html' );
		} 
else {
			$smarty->assign( 'current_sub', $sub );

			if (file_exists( './includes/admin/sub/' . $ad_tab['id'] . ( ( '_' ) . $sub . '.php' ) )) {
				$smarty->assign( 'admin_tab', $ad_tab );
				include( './includes/admin/sub/' . $ad_tab['id'] . ( ( '_' ) . $sub . '.php' ) );
			} 
else {
				$smarty->assign( 'admin_main_content_template', 'notfound.tpl.html' );
			}
		}
	}


	if (isset( $_POST['page'] )) {
		include( './includes/pages/' . $_POST['page'] . '.php' );
		exit(  );
	}

	$smarty->assign( 'admin_departments_count', $file_count - 2 );
	$smarty->display( 'backend/index.tpl.html' );
	$re = array( '\'admincp.php\?tab=([a-z\_]*)&sub=([a-z\_]*)&settings_groupID=([1-9]*)\'', '\\'admincp.php\?tab=([a-z\_]*)&sub=([a-z\_]*)&categoryID=([0-9]*)&terminate=([0-9]*)\'', '\\'admincp.php\?tab=([a-z\_]*)&sub=([a-z\_]*)&categoryID=([0-9]*)&expandCat=([0-9]*)\'', '\\'admincp.php\?tab=([a-z\_]*)&sub=([a-z\_]*)&install=([0-9]*)\'', '\\'admincp.php\?tab=([a-z\_]*)&sub=([a-z\_]*)&setting_up=([0-9]*)\'', '\\'admincp.php\?tab=([a-z\_]*)&sub=([a-z\_]*)&categoryID=([0-9]*)\'', '\\'admincp.php\?tab=([a-z\_]*)&sub=([a-z\_]*)&uninstall=([0-9]*)\'', '\\'admincp.php\?tab=([a-z\_]*)&sub=([a-z\_]*)&delete=([0-9]*)\'', '\\'admincp.php\?tab=([a-z\_]*)&sub=([a-z\_]*)\'', '\\'admincp.php\?tab=([a-z]*)\'', '\\'(?<!/)index.php\?news\'', '\\'(?<!/)index.php\?show_price\'', '\\'(?<!/)index.php\?feedback\'', '\\'(?<!/)index.php\?register\'', '\\'(?<!/)index.php\?user_details\'', '\\'(?<!/)index.php\?view_content=([0-9]*)\'', '\\'(?<!/)index.php\?productID=([0-9]*)&(amp;)?discuss\'', '\\'(?<!/)index.php\?productID=([0-9]*)\'' );
	$out = array( '\1-\2-s\3.html', '\1-\2-cat\3-terminate4.html', '\1-\2-cat\3-expand4.html', '\1-\2-install\3.html', '\1-\2-setup\3.html', '\1-\2-cat\3.html', '\1-\2-uninstall\3.html', '\1-\2-delete.html?\3', '\1-\2.html', '\1.html', 'news.html', 'price.html?show=true', 'contact.html', 'register.html', 'my_account.html', 'page\1.html', 'forumproduct\1.html', 'product\1.html' );
	$contents = ob_get_contents(  );
	ob_end_clean(  );
	print $contents;
?>