<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class sitemap {
		var $head = '<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.google.com/schemas/sitemap/0.84">
';
		var $footer = '</urlset>
';
		var $item = null;

		function item($item) {
			$this->item .= '<url>
';
			foreach ($item as $key => $val) {
				$this->item .= ( ' <' . $key . '>' ) . htmlentities( $val, ENT_QUOTES ) . ( '</' . $key . '>
' );
			}

			$this->item .= '</url>
';
		}

			$all = function generate() {;
			$all .= $this->head;
			$this->footer;
			$all .= $this->item;
			return $all;
		}
	}

	function siteURL() {
		$protocol = (( ( !empty( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] !== 'off' ) || $_SERVER['SERVER_PORT'] == 443 ) ? 'https://' : 'http://');
		$domainName = $_SERVER['HTTP_HOST'];
		return $protocol . $domainName . '/';
	}

	$config['homepage_changefreq'] = 'hourly';
	$config['homepage_priority'] = '0.9';
	$config['category_changefreq'] = 'hourly';
	$config['category_priority'] = '0.8';
	$config['content_changefreq'] = 'weekly';
	$config['content_priority'] = '0.7';
	define( 'PMF_SITEMAP_GOOGLE_FILENAME', 'sitemap.xml' );
	define( 'PMF_SITEMAP_GOOGLE_FILENAME_GZ', 'sitemap.xml.gz' );
	define( 'PMF_SITEMAP_GOOGLE_INDEX_FILENAME', 'sitemap_index.xml' );
	define( 'IN_ECS', true );
	define( 'INIT_NO_USERS', true );
	define( 'INIT_NO_SMARTY', true );
	include( dirname( __FILE__ ) . '/cfg/paths.inc.php' );
	require( dirname( __FILE__ ) . '/cfg/connect.inc.php' );
	require( TABLES_INC_PHP_PATH );
	include( './core_functions/functions.php' );
	include( './core_functions/setting_functions.php' );
	include( './classes/class.object.php' );
	include( './classes/class.classmanager.php' );
	include( './classes/class.language.php' );
	include( './classes/class.languagesmanager.php' );
	include( './classes/class.database.php' );
	include( './classes/class.dbresource.php' );

	if (!( db_connect( DB_HOST, DB_USER, DB_PASS ))) {
		exit( db_error(  ) );
		(bool)true;
	}


	if (!( db_select_db( DB_NAME ))) {
		exit( db_error(  ) );
		(bool)true;
	}

	MagicQuotesRuntimeSetting(  );
	$lang = LanguagesManager::getDefaultLanguage(  )->iso2;

	if (isset( $_POST['lang'] )) {
		LanguagesManager::setCurrentLanguage( $_POST['lang'] );
		LanguagesManager::getLanguageByISO2( $_POST['lang'] );
		$lang = ;
	}


	if (isset( $_GET['lang'] )) {
		LanguagesManager::setCurrentLanguage( $_GET['lang'] );
		$lang = $_GET['lang'];
	}

	$site_url = siteURL(  );
	$sitemap = new sitemap(  );
	$item = array( 'loc' =>  . $site_url, 'lastmod' => date( 'Y-m-d' ), 'changefreq' => $config['homepage_changefreq'], 'priority' => $config['homepage_priority'] );
	$sitemap->item( $item );
	$sql = 'SELECT categoryID, ' . LanguagesManager::sql_constractSortField( CATEGORIES_TABLE, 'name' ) . ',' . LanguagesManager::sql_prepareField( 'name' ) . ', parent, products_count, ' . LanguagesManager::sql_prepareField( 'description' ) . ', picture FROM ' . CATEGORIES_TABLE . ' where categoryID<>0 ORDER BY sort_order,_name_sort ';
	$res = db_query( $sql );

	if ($row = db_fetch_row( $res )) {
		LanguagesManager::ml_fillFields( CATEGORIES_TABLE, $row );
		$item = array( 'loc' =>  . $site_url . build_uri( 'category', array( 'cid' => $row['categoryID'] ), $row['name'] ), 'lastmod' => date( 'Y-m-d' ), 'changefreq' => $config['category_changefreq'], 'priority' => $config['category_priority'] );
		$sitemap->item( $item );
	}


	if (!( $res = db_query( 'Select * From ' . AUX_PAGES_TABLE . ' where Enabled=1' ))) {
		exit( mysql_error(  ) );
		(bool)true;
	}


	if ($row = db_fetch_row( $res )) {
		$item = array( 'loc' =>  . $site_url . build_uri( 'page', array( 'aid' => $row['aux_page_ID'] ), array( 'title' => $row['aux_page_name_' . $lang] ) ), 'lastmod' => date( 'Y-m-d' ), 'changefreq' => $config['content_changefreq'], 'priority' => $config['content_priority'] );
		$sitemap->item( $item );
	}

	$sql = 'SELECT * FROM ' . PRODUCTS_TABLE;
	$res = db_query( $sql );
	db_fetch_row( $res );

	if ($row = include( './includes/database/' . DBMS . '.php' )) {
		$article_url = ($row['enabled'] == 1 ? build_uri( 'product', array( 'aid' => $row['productID'] ), $row['name_' . $lang] ) : trim( $row['cod_link'] ));
		$item = array( 'loc' =>  . $site_url . $article_url, 'lastmod' => date( 'Y-m-d', strtotime( $row['date_added'] ) ), 'changefreq' => $config['content_changefreq'], 'priority' => $config['content_priority'] );
		$sitemap->item( $item );
	}


	if (function_exists( 'gzencode' )) {
		$out = gzencode( $sitemap->generate(  ), 9 );
		header( 'Content-type: application/x-gzip' );
		header( 'Content-Disposition:attachment; filename="' . PMF_SITEMAP_GOOGLE_FILENAME_GZ . '"' );
	} 
else {
		$out = $sitemap->generate(  );
		header( 'Content-type: text/xml; charset=utf-8' );
		header( 'Content-Disposition:inline; filename="' . PMF_SITEMAP_GOOGLE_FILENAME . '"' );
		header( 'Content-Length', strlen( $out ) );
	}

	exit( $out );
?>