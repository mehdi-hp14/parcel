<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!file_exists( './cfg/connect.inc.php' )) {
		include( 'install.php' );
		exit(  );
	}

	include( './cfg/paths.inc.php' );
	include( './cfg/connect.inc.php' );

	if (!defined( 'DBMS' )) {
		include( 'install.php' );
		exit(  );
	}

	session_start(  );
	$DebugMode = false;
	include( './includes/database/' . DBMS . '.php' );
	include( './core_functions/functions.php' );
	include( './core_functions/category_functions.php' );
	include( './core_functions/cart_functions.php' );
	include( './core_functions/product_functions.php' );
	include( './core_functions/statistic_functions.php' );
	include( './core_functions/reg_fields_functions.php' );
	include( './core_functions/registration_functions.php' );
	include( './core_functions/city_functions.php' );
	include( './core_functions/country_functions.php' );
	include( './core_functions/zone_functions.php' );
	include( './core_functions/datetime_functions.php' );
	include( './core_functions/order_status_functions.php' );
	include( './core_functions/order_functions.php' );
	include( './core_functions/aux_pages_functions.php' );
	include( './core_functions/picture_functions.php' );
	include( './core_functions/configurator_functions.php' );
	include( './core_functions/option_functions.php' );
	include( './core_functions/search_function.php' );
	include( './core_functions/discount_functions.php' );
	include( './core_functions/custgroup_functions.php' );
	include( './core_functions/shipping_functions.php' );
	include( './core_functions/payment_functions.php' );
	include( './core_functions/tax_function.php' );
	include( './core_functions/currency_functions.php' );
	include( './core_functions/module_function.php' );
	include( './core_functions/crypto/crypto_functions.php' );
	include( './core_functions/quick_order_function.php' );
	include( './core_functions/setting_functions.php' );
	include( './core_functions/subscribers_functions.php' );
	include( './core_functions/version_function.php' );
	include( './core_functions/discussion_functions.php' );
	include( './core_functions/order_amount_functions.php' );
	include( './core_functions/linkexchange_functions.php' );
	include( './core_functions/account_functions.php' );
	include( './core_functions/jalalicalendar_functions.php' );
	include( './core_functions/affiliate_functions.php' );
	include( './core_functions/bankbill_functions.php' );

	if (!extension_loaded( 'soap' )) {
		include( './core_functions/nusoap.php' );
	}

	include( './classes/class.discount_coupon.php' );
	include( './classes/xml2array.php' );
	include( './classes/class.object.php' );
	include( './classes/class.classmanager.php' );
	include( './classes/class.virtual.shippingratecalculator.php' );
	include( './classes/class.virtual.paymentmodule.php' );
	include( './classes/class.language.php' );
	include( './classes/class.languagesmanager.php' );
	include( './classes/class.virtual.smsmail.php' );
	include( './classes/class.singleton.php' );
	include( './classes/class.register.php' );
	include( './classes/class.database.php' );
	include( './classes/class.dbresource.php' );
	include( './classes/class.url.php' );
	include( './classes/class.furl.php' );
	include( './classes/class.polliz.php' );
	include( './includes/modules/smsmail/class.smsnotify.php' );
	$domain = $_SERVER['SERVER_NAME'];
	$domain = ltrim( $domain, '.www' );

	if (true) {
		MagicQuotesRuntimeSetting(  );
		include( './core_functions/mail_function.php' );
		require_once( './smarty/Smarty.class.php' );
		require_once( './smarty/resources/resource.rfile.php' );
		require_once( './smarty/resources/resource.register.php' );
		error_reporting( null );

		if (!( db_connect( DB_HOST, DB_USER, DB_PASS ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if (!( db_select_db( DB_NAME ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		require_once( './core_functions/ad_functions.php' );

		if (isset( $_GET['ad_id'] )) {
			$ad_id = intval( $_GET['ad_id'] );
			$sql = 'SELECT * FROM ' . ADS_TABLE . ' WHERE adId=\'' . $ad_id . '\'';
			$ads_arr = db_fetch_assoc( db_query( $sql ) );
			db_query( 'UPDATE ' . ADS_TABLE . ( ' SET click_count = click_count + 1 WHERE adid = \'' . $ad_id . '\'' ) );

			if (!empty( $_GET['uri'] )) {
				$uri = (( strpos( $_GET['uri'], 'http://' ) === false && strpos( $_GET['uri'], 'https://' ) === false ) ? (( isset( $_SERVER['HTTPS'] ) && strtolower( $_SERVER['HTTPS'] ) != 'off' ) ? 'https://' : 'http://' . urldecode( $_GET['uri'] )) : urldecode( $_GET['uri'] ));
			} 
else {
				$uri = CONF_SHOP_URL;
			}


			if (isset( $_GET['v'] )) {
				if ($_GET['v'] == -1) {
					echo '<center>' . picrow( $ads_arr ) . '</center>';
				} 
else {
					header( 'Location:' . $uri );
				}
			} 
else {
				header( 'Location:' . $uri );
				exit(  );
			}
		}

		$smarty = new Smarty(  );
		$smarty_mail = new Smarty(  );
		define( 'MOD_REWRITE_SUPPORT', _getSettingOptionValue( 'CONF_DEFAULT_SEO' ) );
		$_SERVER['REQUEST_URI'] = preg_replace( '/(["\'\<\>\\]{1,})|(%5C)|(%22)|(%27)|(%3C)|(%3E)/', '', $_SERVER['REQUEST_URI'] );
		foreach ($_GET as $name => $get) {

			if ($name != preg_replace( '/(["\'\<\>\\]{1,})|(%5C)|(%22)|(%27)|(%3C)|(%3E)/si', '', $name )) {
				unset( $_GET[$name] );
				continue;
			}

			$_GET[$name] = preg_replace( '/(["\'\<\>\\]{1,})|(%5C)|(%2[27]{1})|(%3[CE]{1})/si', '', $get );
		}


		if (( ( MOD_REWRITE_SUPPORT && isset( $_GET['__furl_path'] ) ) && !isset( $_GET['ukey'] ) )) {
			if (!isset( $_GET['__furl_path'] )) {
				$_GET['__furl_path'] = '';
			}


			if (isset( $_GET['productID'] )) {
				$_GET->__furl_path .= '/product/' . intval( $_GET['productID'] );
			} 
else {
				if (isset( $_GET['categoryID'] )) {
					$_GET->__furl_path .= '/category/' . intval( $_GET['categoryID'] );
				}
			}
		}

		$_urlEntry = new URL(  );
		$_urlEntry->loadFromServerInfo(  );
		$furl_path = (isset( $_GET['__furl_path'] ) ? $_GET['__furl_path'] : '');

		if ($furl_path == 'robots.txt') {
			header( 'HTTP/1.1 404 Not Found' );
			header( 'Status: 404 Not Found' );
			header( 'Content-type: text/html; charset=ISO-8859-1' );
			echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">' . '<html><head>' . '<title>404 Not Found</title>' . '</head><body>' . '<h1>Not Found</h1>' . '<p>The requested URL was not found on this server.</p>' . '</body></html>';
			exit(  );
		}

		$_urlEntry->setQuery( '?' );
		$__url = preg_replace( '/\/[^\/]+$/', '', $_urlEntry->getURI(  ) );
		$__wa_url = $news;
		$pattern = '|^((http[s]{0,1}://([^/]+)/)' . substr( PSP_INSTALL_PATH, 1 ) . ')|msi';

		if (preg_match( $pattern, $__url, $matches )) {
			$_base_url = $matches[2];
			$WIDGET_SHOP_URL = $matches[1];
		} 
		else {
			$_base_url = $news;
		}

		$lang = LanguagesManager::getDefaultLanguage()->iso2;

		if (isset( $_POST['lang'] )) {
			LanguagesManager::setCurrentLanguage( $_POST['lang'] );
			$lang = LanguagesManager::getLanguageByISO2($_POST['lang']);
		}


		if (isset( $_GET['lang'] )) {
			LanguagesManager::setCurrentLanguage( $_GET['lang'] );
			$lang = $_GET['lang'];
		}


		if (( !MOD_REWRITE_SUPPORT && isset( $_GET['lang_iso2'] ) )) {
			$lang = LanguagesManager::getLanguageByISO2($_GET['lang_iso2']);

			if ($lang != null) {
				LanguagesManager::setCurrentLanguage( $lang->id );
			}
		}

		$lang_list = LanguagesManager::getLanguages( $enabled = '1' );
		settingDefineConstants(  );

		if (( CONF_PROTECTED_CONNECTION == '1' && $_SERVER['HTTPS'] != 'on' )) {
			Redirect( correct_URL( CONF_FULL_SHOP_URL, 'https' ) . $_SERVER['REQUEST_URI'] );
		}


		if (isset( $_POST['lang'] )) {
			$_SESSION['current_language'] = $_POST['lang'];

		if (!( $q = })) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			++$i;
			define( $row['expstr'], $row['translate'] );
		}


		if ($i == 0) {
			exit( '<font color=red><b>ERROR: Couldn\'t find language Locals Data!</b></font>' );
		}


		if ((int)CONF_SMARTY_FORCE_COMPILE) {
			$smarty->force_compile = true;
			$smarty_mail->force_compile = true;
		}

		$f = file( './cfg/homepage_' . $lang );
		$out = implode( '', $f );
		$smarty->assign( 'home_text', $out );
		$f = file( './cfg/contactus_' . $lang );
		$out = implode( '', $f );
		$smarty->assign( 'contactus_text', $out );
		$smarty->assign( 'CONF_MAIN_LOGO', CONF_MAIN_LOGO );
		$smarty->assign( 'leftblock', CONF_SHOW_LEFT );
		$smarty->assign( 'rightblock', CONF_SHOW_RIGHT );
		$auxlist = array(  );

		if (!( $stq = db_query( 'Select * From ' . AUX_PAGES_TABLE . ' where Enabled=1' ))) {
			exit( mysql_error(  ) );
			(bool)true;
		}


		if ($stres = db_fetch_row( $stq )) {
			$stres['aux_page_name'] = $stres['aux_page_name_' . $lang];
			$auxlist[] = $stres;
		}

		$smarty->assign( 'aux_list', $auxlist );
		include( './checklogin.php' );

		if (isset( $_POST['current_currency'] )) {
			currSetCurrentCurrency( $_POST['current_currency'] );
		}

		$current_currency = currGetCurrentCurrencyUnitID(  );
		$smarty->assign( 'current_currency', $current_currency );

		if (!( $q = db_query( 'select * from ' . CURRENCY_TYPES_TABLE . ( ' where CID=' . $current_currency ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
			$smarty->assign( 'currency_name', $row['code'] );
			$selected_currency_details = $r;
		} 
else {

			if (!( $q = db_query( 'select * from ' . CURRENCY_TYPES_TABLE . ' limit 1' ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if ($row = db_fetch_row( $q )) {
				LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
				$smarty->assign( 'currency_name', $row['code'] );
				$selected_currency_details = $r;
			}
		}

		$cats = array(  );
		$i = 2281;

		if (!( $q = db_query( 'SELECT categoryID, ' . LanguagesManager::sql_constractSortField( CATEGORIES_TABLE, 'name' ) . ',' . LanguagesManager::sql_prepareField( 'name' ) . ', parent, products_count, ' . LanguagesManager::sql_prepareField( 'description' ) . ', picture FROM ' . CATEGORIES_TABLE . ' where categoryID<>0 ORDER BY sort_order,_name_sort ' ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			$cats[$i++] = $row;
		}


		if (isset( $_GET['page'] )) {
			$_GET['view_content'] = $_GET['page'];
		}


		if (( isset( $_GET['categoryID'] ) || isset( $_POST['categoryID'] ) )) {
			$categoryID = (isset( $_GET['categoryID'] ) ? (int)$_GET['categoryID'] : (int)$_POST['categoryID']);
		}


		if (!isset( $_GET['productID'] )) {
			if (isset( $_POST['productID'] )) {
				$productID = (int)$_POST['productID'];
			}
		} 
else {
			$productID = (int)$_GET['productID'];
		}


		if ($_GET['ukey']) {
			$_GET[$_GET['ukey']] = 1;
		}


		if (( isset( $_GET['register'] ) || isset( $_POST['register'] ) )) {
			$register = (isset( $_GET['register'] ) ? $_GET['register'] : $_POST['register']);
		}


		if (( isset( $_GET['update_details'] ) || isset( $_POST['update_details'] ) )) {
			$update_details = (isset( $_GET['update_details'] ) ? $_GET['update_details'] : $_POST['update_details']);
		}


		if (( isset( $_GET['order'] ) || isset( $_POST['order'] ) )) {
			$order = (isset( $_GET['order'] ) ? $_GET['order'] : $_POST['order']);
		}


		if (( isset( $_GET['order_without_billing_address'] ) || isset( $_POST['order_without_billing_address'] ) )) {
			$order_without_billing_address = (isset( $_GET['order_without_billing_address'] ) ? $_GET['order_without_billing_address'] : $_POST['order_without_billing_address']);
		}


		if (( isset( $_GET['check_order'] ) || isset( $_POST['check_order'] ) )) {
			$check_order = (isset( $_GET['check_order'] ) ? $_GET['check_order'] : $_POST['check_order']);
		}


		if (( isset( $_GET['proceed_ordering'] ) || isset( $_POST['proceed_ordering'] ) )) {
			$proceed_ordering = (isset( $_GET['proceed_ordering'] ) ? $_GET['proceed_ordering'] : $_POST['proceed_ordering']);
		}


		if (( isset( $_GET['update_customer_info'] ) || isset( $_POST['update_customer_info'] ) )) {
			$update_customer_info = (isset( $_GET['update_customer_info'] ) ? $_GET['update_customer_info'] : $_POST['update_customer_info']);
		}


		if (( isset( $_GET['view_content'] ) || isset( $_POST['view_content'] ) )) {
			$view_content = (isset( $_GET['view_content'] ) ? $_GET['view_content'] : $_POST['view_content']);
		}


		if (( isset( $_GET['visit_history'] ) || isset( $_POST['visit_history'] ) )) {
			$visit_history = 2282;
		}


		if (( isset( $_GET['order_history'] ) || isset( $_POST['order_history'] ) )) {
			$order_history = 2282;
		}


		if (( isset( $_GET['address_book'] ) || isset( $_POST['address_book'] ) )) {
			$address_book = 2282;
		}


		if (( isset( $_GET['address_editor'] ) || isset( $_POST['address_editor'] ) )) {
			$address_editor = (isset( $_GET['address_editor'] ) ? $_GET['address_editor'] : $_POST['address_editor']);
		}


		if (( isset( $_GET['add_new_address'] ) || isset( $_POST['add_new_address'] ) )) {
			$add_new_address = (isset( $_GET['add_new_address'] ) ? $_GET['add_new_address'] : $_POST['add_new_address']);
		}


		if (( isset( $_GET['contact_info'] ) || isset( $_POST['contact_info'] ) )) {
			$contact_info = (isset( $_GET['contact_info'] ) ? $_GET['contact_info'] : $_POST['contact_info']);
		}


		if (( isset( $_GET['comparison_products'] ) || isset( $_POST['comparison_products'] ) )) {
			$comparison_products = 2282;
		}


		if (( isset( $_GET['register_authorization'] ) || isset( $_POST['register_authorization'] ) )) {
			$register_authorization = 2282;
		}


		if (( isset( $_GET['page_not_found'] ) || isset( $_POST['page_not_found'] ) )) {
			$page_not_found = 2282;
		}


		if (( isset( $_GET['news'] ) || isset( $_GET['news'] ) )) {
			$news = 2282;
		}


		if (isset( $_GET['quick_register'] )) {
			$quick_register = 2282;
		}


		if (isset( $_GET['order2_shipping_quick'] )) {
			$order2_shipping_quick = 2282;
		}


		if (isset( $_GET['order3_billing_quick'] )) {
			$order3_billing_quick = 2282;
		}


		if (( isset( $_GET['order2_shipping'] ) || isset( $_POST['order2_shipping'] ) )) {
			$order2_shipping = 2282;
		}


		if (( isset( $_GET['order3_billing'] ) || isset( $_POST['order3_billing'] ) )) {
			$order3_billing = 2282;
		}


		if (( isset( $_GET['change_address'] ) || isset( $_POST['change_address'] ) )) {
			$change_address = 2282;
		}


		if (( isset( $_GET['order4_confirmation'] ) || isset( $_POST['order4_confirmation'] ) )) {
			$order4_confirmation = 2282;
		}


		if (( isset( $_GET['order4_confirmation_quick'] ) || isset( $_POST['order4_confirmation_quick'] ) )) {
			$order4_confirmation_quick = 2282;
		}


		if (( isset( $_GET['order_detailed'] ) || isset( $_POST['order_detailed'] ) )) {
			$order_detailed = (isset( $_GET['order_detailed'] ) ? $_GET['order_detailed'] : $_POST['order_detailed']);
		}


		if (!isset( $_SESSION['vote_completed'] )) {
			$_SESSION['vote_completed'] = array(  );
		}

		$offset = (isset( $_GET['offset'] ) ? $_GET['offset'] : 0);

		if (( $offset < 0 || $offset % CONF_PRODUCTS_PER_PAGE )) {
			$offset = 2281;
		}


		if (empty( $$productID )) {

			if (!( $q = db_query( 'SELECT categoryID FROM ' . PRODUCTS_TABLE . ( ' WHERE productID=\'' . $productID . '\'' ) ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			$r = db_fetch_row( $q );

			if ($r) {
				$categoryID = $r[0];
			}
		}


		if (CONF_TEMPLATES_DIR == '') {
			echo '<script type="text/javascript" >';
			echo 'alert("' . ADMIN_TEMPLATE_NOTSET . '");';
			echo 'parent.location = "' . BASE_URL . 'admincp.php?tab=layout&sub=templates";';
			echo '</script>';
		}


		if (isset( $_GET['template'] )) {
			$templateDirectory = $_GET['template'];
		} 
else {
			$templateDirectory = CONF_TEMPLATES_DIR;
		}

		$smarty->template_dir = 'templates/frontend/' . $templateDirectory;
		$smarty_mail->template_dir = 'templates/email';
		$smarty->assign( 'template_dir', BASE_URL . $smarty->template_dir );

		if (isset( $_GET['page'] )) {
			switch ($_GET['page']) {
				case 'cart': {
					include( 'includes/pages/cart.php' );
					exit(  );
				}

				case 'invoice': {
					include( 'includes/pages/invoice.php' );
					exit(  );
				}

				case 'file': {
					include( 'includes/pages/get_file.php' );
					exit(  );
				}

				case 'captcha': {
					session_start(  );
					require( './classes/class.captcha.php' );
					$captcha = new captcha(  );
					$_SESSION['CAPTCHAString'] = $captcha->getCaptchaString(  );
					exit(  );
				}

				case 'print': {
					include( 'includes/pages/printable.php' );
					exit(  );
				}
			}

			break;
		}


		if (!( $q = db_query( 'select * from ' . CURRENCY_TYPES_TABLE . ' order by sort_order' ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$currencies = array(  );

		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
			$currencies[] = $row;
		}

		$smarty->assign( 'currencies', $currencies );
		$smarty->assign( 'currencies_count', count( $currencies ) );
		$smarty->assign( 'lang_list', $lang_list );

		if (isset( $_SESSION['current_language'] )) {
			$smarty->assign( 'current_language', $_SESSION['current_language'] );
		}


		if (isset( $_SESSION['log'] )) {
			$smarty->assign( 'log', $_SESSION['log'] );
		}


		if (empty( $$categoryID )) {
			$smarty->assign( 'categoryID', $categoryID );
		}


		if (empty( $$productID )) {
			$smarty->assign( 'productID', $productID );
		}


		if (isset( $_GET['currency'] )) {
			$smarty->assign( 'currency', $_GET['currency'] );
		}


		if (isset( $_GET['user_details'] )) {
			$smarty->assign( 'user_details', $_GET['user_details'] );
		}


		if (isset( $_GET['aux_page'] )) {
			$smarty->assign( 'aux_page', $_GET['aux_page'] );
		}


		if (isset( $_GET['page'] )) {
			$smarty->assign( 'aux_page', $_GET['aux_page'] );
		}


		if (isset( $_GET['show_price'] )) {
			$smarty->assign( 'show_price', $_GET['show_price'] );
		}


		if (isset( $_GET['adv_search'] )) {
			$smarty->assign( 'adv_search', $_GET['adv_search'] );
		}


		if (isset( $_GET['searchstring'] )) {
			$smarty->assign( 'searchstring', $_GET['searchstring'] );
		}


		if (empty( $$register )) {
			$smarty->assign( 'register', $register );
		}


		if (empty( $$order )) {
			$smarty->assign( 'order', $order );
		}


		if (empty( $$check_order )) {
			$smarty->assign( 'check_order', $check_order );
		}

		$smarty->assign( 'main_content_template', 'home.tpl.html' );
		$includes_dir = opendir( './includes' );
		$files = array(  );
		readdir( $includes_dir );

		if ($inc_file =  != false) {
			if (strstr( $inc_file, '.php' )) {
				$files[] = './includes/' . $inc_file;
			}
		}

		opendir( './includes/modules/payment/gateway' );
		$includes_dir = LanguagesManager::getDefaultLanguage(  )->iso2;
		readdir( $includes_dir );

		if ($inc_file =  != false) {
			if (strstr( $inc_file, '.php' )) {
				$files[] = './includes/modules/payment/gateway/' . $inc_file;
			}
		}

		sort( $files );
		foreach ($files as $fl) {
			include_once( $fl );
		}


		if (( file_exists( './install.php' ) && isset( $_GET['KILLINSTALL'] ) )) {
			unlink( './install.php' );
			$dir = './templates/install/';
			foreach (glob( $dir . '/*' ) as $file) {

				if (!is_dir( $file )) {
					unlink( $file );
					continue;
				}
			}

			$dir = './cfg/sql/';
			foreach (glob( $dir . '/*' ) as $file) {

				if (!is_dir( $file )) {
					unlink( $file );
					continue;
				}
			}
		}


		if (file_exists( './install.php' )) {
			echo '<div id="js-monitor" style="display:block;direction:rtl;text-align:right;position:absolute;top:45%;left:35%;width:320px;height:50px;padding-top:10px;padding-right:50px;z-index:1000;border:1px solid #000;background:#FDD017;font-family:tahoma;font-size:10px;background-repeat:no-repeat;background-position:right top;background-image:url(./images/warning.gif);">' . WARNING_DELETE_INSTALL_PHP . '<br/><p  style="text-align:center;color:red;"><a href="?KILLINSTALL">' . PROMPT_DELETE_INSTALL_PHP . '</a></p></div>';
		}


		if (( ( !is_writable( './uploads/products_files/' ) || !is_writable( './uploads/products_pictures' ) ) || !is_writable( './temp_c' ) )) {
			echo '<div id="js-monitor" style="display:block;text-align:right;position:absolute;top:25%;left:35%;width:320px;z-index:1000;border:1px solid #000;padding-top:10px;padding-right:50px;z-index:10000;background:#FDD017;font-family:tahoma;font-size:10px;background-repeat:no-repeat;background-position:right top;background-image:url(./images/warning.gif);">' . WARNING_WRONG_CHMOD . '</div>';
			chmod( 'uploads/products_files', 511 );
			chmod( 'uploads/products_pictures', 511 );
			chmod( 'uploads/products_videos', 511 );
			chmod( 'temp_c', 511 );
		}

		_getSettingOptionValue( 'CONF_YAHOO_ID' );
		$yahoo = db_query( 'select * from ' . LOCALS_TABLE . ' where iso2=\'' . $lang . '\'' );

		if ($yahoo) {
			$smarty->assign( 'yahoo', 1 );
		}

		auxpgGetAllPageAttributes(  );
		$aux_pages = $i = 2281;

		if (count( $aux_pages ) != 0) {
			$smarty->assign( 'aux_page1', $aux_pages[0] );
		}


		if (1 < count( $aux_pages )) {
			$smarty->assign( 'aux_page2', $aux_pages[1] );
		}


		if (!$_GET['output']) {
			$smarty->display( 'index.tpl.html' );
		} 
else {
			if ($_GET['output'] == 'category') {
				$m = 'category_tree.tpl.html';
			} 
else {
				$m = $smarty->get_template_vars( 'main_content_template' );
			}

			$smarty->display( $m );
		}


		if (( isset( $_SESSION['log'] ) && !strcmp( $_SESSION['log'], ADMIN_LOGIN ) )) {
			echo '<div 
    style=\'
    border-radius: 0 0 5px 5px;
    -webkit-border-radius: 0 0 5px 5px;
    -moz-border-radius: 0 0 5px 5px;
    position: fixed;
    right: 10px;
    font: 12px tahoma;
    float: right;
    margin-top: 8px;
    padding: 4px 7px 7px 7px;
    margin-top: 0px;
    height: 22px;
    text-align: right;
    background-color: #176792;
    color: white;
    margin-right: 10px;
    font-weight: bold;
    top: 0px; z-index:10000;\'><center><a class=\'botton\' href=\'' . BASE_URL . 'admincp.php\'><font color=yellow>' . ADMINISTRATE_LINK . '</font></a></center></div>';
			return 1;
		}
	} 
else {
		echo 'Invalid Licence! to buy a valid licence visit <a href=\'http://www.parsp.com\'>www.parsp.com</a>';
	}

?>