<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	include_once( './classes/class.image.php' );
	include( './cfg/connect.inc.php' );
	include( './includes/database/' . DBMS . '.php' );
	include( './core_functions/functions.php' );
	include( './core_functions/setting_functions.php' );

	if (!( db_connect( DB_HOST, DB_USER, DB_PASS ))) {
		exit( db_error(  ) );
		(bool)true;
	}


	if (!( db_select_db( DB_NAME ))) {
		exit( db_error(  ) );
		(bool)true;
	}


	if ($_GET['type'] == 'box') {
		$width = _getSettingOptionValue( 'CONF_HOMEBOXES_THUMBNAILSIZE_WIDTH' );
		$height = _getSettingOptionValue( 'CONF_HOMEBOXES_THUMBNAILSIZE_HEIGHT' );
	} 
else {
		if ($_GET['type'] == 'default') {
			$width = _getSettingOptionValue( 'CONF_DEFUALTPIC_WIDTH' );
			$height = _getSettingOptionValue( 'CONF_DEFUALTPIC_HEIGHT' );
		} 
else {
			if ($_GET['type'] == 'thumbnail') {
				$width = _getSettingOptionValue( 'CONF_THUMBNAILSIZE_WIDTH' );
				$height = _getSettingOptionValue( 'CONF_THUMBNAILSIZE_HEIGHT' );
			} 
else {
				if ($_GET['type'] == 'enlarged') {
					$width = _getSettingOptionValue( 'CONF_ENLARGED_WIDTH' );
					$height = _getSettingOptionValue( 'CONF_ENLARGED_HEIGHT' );
				} 
else {
					if ($_GET['type'] == 'special') {
						$width = _getSettingOptionValue( 'CONF_SPECIALPRODCUTS_WIDTH' );
						$height = _getSettingOptionValue( 'CONF_SPECIALPRODCUTS_HEIGHT' );
					} 
else {
						if ($_GET['type'] == 'admin') {
							$width = 871;
							$height = 863;
						} 
else {
							$width = 1041;
							$height = 991;
						}
					}
				}
			}
		}
	}


	if (( ( $_GET['imageurl'] && $_GET['type'] ) && $_GET['imageurl'] != 'noimage' )) {
		$imageurl = 'uploads/products_pictures/' . $_GET['imageurl'];
	} 
else {
		$imageurl = 'images/noimage.gif';
	}


	if ($imageurl == 'noimage') {
		$imageurl = 'images/noimage.gif';
	}

	$image = new cdggjcadai( $imageurl );
	$image->resize( $width, $height, RESIZE_TYPE_CROP );
	$image->render(  );
?>