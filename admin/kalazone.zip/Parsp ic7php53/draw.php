<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CLASS_PATH', './classes' );
	define( 'FONT_PATH', './style/fonts' );
	error_reporting( 1 );
	include( './cfg/connect.inc.php' );
	include( './includes/database/' . DBMS . '.php' );
	include( './core_functions/functions.php' );
	include( './classes/xml2array.php' );
	include( './classes/class.object.php' );
	include( './classes/class.classmanager.php' );
	include( './classes/class.virtual.shippingratecalculator.php' );
	include( './classes/class.virtual.paymentmodule.php' );
	include( './classes/class.language.php' );
	include( './classes/class.languagesmanager.php' );
	include( './classes/class.virtual.smsmail.php' );
	include( './classes/class.singleton.php' );
	include( './classes/class.register.php' );
	include( './classes/class.database.php' );
	include( './classes/class.dbresource.php' );
	include( './classes/class.polliz.php' );
	session_start(  );
	$domain = $_SERVER['SERVER_NAME'];
	$domain = ltrim( $domain, '.www' );
	MagicQuotesRuntimeSetting(  );
	$lang = LanguagesManager::getDefaultLanguage(  )->iso2;
	MagicQuotesRuntimeSetting(  );
	include( CLASS_PATH . '/class.pData.php' );
	include( CLASS_PATH . '/class.pDraw.php' );
	include( CLASS_PATH . '/class.pImage.php' );
	include( CLASS_PATH . '/class.pPie.php' );
	require_once( CLASS_PATH . '/bidi.php' );
	require_once( CLASS_PATH . '/unicode_data.php' );

	if ($_GET['cmd'] == 'polldata') {
		$MyData = new pData(  );
		$POLLIZ = new PollizAdmin(  );
		$pollData = $POLLIZ->getPoll( $_GET['pollId'] );

		if (is_array( $pollData )) {
			$pollVotes = $POLLIZ->getPollVotes( $_GET['pollId'] );
			foreach ($pollData['pollAnswers'] as $ansOrder => $ansData) {
				$votes = ($pollVotes[$ansData['id']] ? $pollVotes[$ansData['id']] : 0);
				$point[] = $votes;
				$ans[] = $ansData['answer'];
			}
		}

		$MyData->addPoints( $point, 'ScoreA' );
		$MyData->setSerieDescription( 'ScoreA', 'Application A' );
		$MyData->addPoints( $ans, 'Labels' );
		$MyData->setAbscissa( 'Labels' );
		$myPicture = new pImage( 300, 260, $MyData );

		if (( isset( $_GET['ImageMap'] ) || isset( $_POST['ImageMap'] ) )) {
			$myPicture->dumpImageMap( 'ImageMap3DPieChart', IMAGE_MAP_STORAGE_FILE, '3DPieChart', './temp_c' );
		}

		$myPicture->initialiseImageMap( 'ImageMap3DPieChart', IMAGE_MAP_STORAGE_FILE, '3DPieChart', './temp_c' );
		$Settings = array( 'R' => 170, 'G' => 183, 'B' => 87, 'Dash' => 1, 'DashR' => 190, 'DashG' => 203, 'DashB' => 107 );
		$myPicture->drawFilledRectangle( 0, 0, 300, 300, $Settings );
		$Settings = array( 'StartR' => 219, 'StartG' => 231, 'StartB' => 139, 'EndR' => 1, 'EndG' => 138, 'EndB' => 68, 'Alpha' => 50 );
		$myPicture->drawGradientArea( 0, 0, 300, 260, DIRECTION_VERTICAL, $Settings );
		$myPicture->drawRectangle( 0, 0, 299, 259, array( 'R' => 0, 'G' => 0, 'B' => 0 ) );
		$myPicture->setFontProperties( array( 'FontName' => FONT_PATH . '/DejaVuSans.ttf', 'FontSize' => 10, 'R' => 80, 'G' => 80, 'B' => 80 ) );
		$myPicture->drawGradientArea( 0, 0, 300, 20, DIRECTION_VERTICAL, array( 'StartR' => 0, 'StartG' => 0, 'StartB' => 0, 'EndR' => 50, 'EndG' => 50, 'EndB' => 50, 'Alpha' => 100 ) );
		$myPicture->drawRectangle( 0, 0, 299, 259, array( 'R' => 0, 'G' => 0, 'B' => 0 ) );
		$myPicture->drawText( 0, 8, 'نتیجه نظر سنجی', array( 'R' => 255, 'G' => 255, 'B' => 255, 'Align' => TEXT_ALIGN_CENTER ) );
		$Settings = array( 'RecordImageMap' => true );
		$PieChart = new pPie( $myPicture, $MyData, $Settings );
		$PieSettings = array( 'DrawLabels' => true, 'LabelStacked' => false, 'Border' => true, 'RecordImageMap' => true );
		$PieChart->draw3DPie( 150, 160, $PieSettings );
		$myPicture->setShadow( false );
		$PieChart->drawPieLegend( 15, 40, array( 'Alpha' => 20 ) );
		$myPicture->autoOutput( './temp_c/3DPieChart.png' );
	}


	if ($_GET['cmd'] == 'reprtdata') {
		include( './core_functions/jalalicalendar_functions.php' );
		include( './core_functions/datetime_functions.php' );
		include( './core_functions/setting_functions.php' );
		include( './core_functions/order_functions.php' );
		settingDefineConstants(  );
		$callBackParam['from_date'] = $_GET['fromdate'];
		$callBackParam['till_date'] = $_GET['tilldate'];
		$callBackParam['orderStatuses'] = explode( ',', $_GET['status'] );
		$salesdata = ordGetreports( $callBackParam );
		foreach ($salesdata as $key => $value) {
			$values[] = $value['order_amount'];
			$labels[] = $value['cur_date'];
			$counts[] = $value['order_count'];
		}

		$fromdate = TransformDATEToTemplate( $_GET['fromdate'] );
		$tilldate = TransformDATEToTemplate( $_GET['tilldate'] );
		$MyData = new pData(  );
		$MyData->addPoints( $values, 'میزان فروش' );
		$MyData->setAxisName( 0, 'میزان (مبلغ) فروش' );
		$MyData->addPoints( $labels, 'Labels' );
		$MyData->setSerieDescription( 'Labels', 'Months' );
		$MyData->setAbscissa( 'Labels' );
		$myPicture = new pImage( 700, 230, $MyData );
		$myPicture->Antialias = false;
		$Settings = array( 'R' => 245, 'G' => 245, 'B' => 245, 'Dash' => 1, 'DashR' => 265, 'DashG' => 265, 'DashB' => 265 );
		$myPicture->drawFilledRectangle( 0, 0, 700, 230, $Settings );
		$Settings = array( 'StartR' => 231, 'StartG' => 231, 'StartB' => 231, 'EndR' => 168, 'EndG' => 153, 'EndB' => 141, 'Alpha' => 50 );
		$myPicture->drawGradientArea( 0, 0, 700, 230, DIRECTION_VERTICAL, $Settings );
		$myPicture->drawRectangle( 0, 0, 699, 229, array( 'R' => 0, 'G' => 0, 'B' => 0 ) );
		$myPicture->setFontProperties( array( 'FontName' => FONT_PATH . '/DejaVuSans.ttf', 'FontSize' => 10, 'R' => 80, 'G' => 80, 'B' => 80 ) );
		$myPicture->drawText( 0, 8, 'نمودار میزان فروش از تاریخ ' . $fromdate . ' تا تاریخ ' . $tilldate . ' ', array( 'R' => 0, 'G' => 0, 'B' => 255, 'Align' => TEXT_ALIGN_CENTER ) );
		$myPicture->setGraphArea( 60, 40, 650, 200 );
		$scaleSettings = array( 'XMargin' => 10, 'YMargin' => 10, 'Floating' => true, 'GridR' => 255, 'GridG' => 255, 'GridB' => 255, 'DrawSubTicks' => true, 'CycleBackground' => true );
		$myPicture->drawScale( $scaleSettings );
		$myPicture->drawLegend( 540, 20, array( 'Style' => LEGEND_NOBORDER, 'Mode' => LEGEND_HORIZONTAL ) );
		$myPicture->Antialias = true;
		$MyData->setSerieDrawable( 'Probe 1', true );
		$myPicture->drawAreaChart(  );
		$myPicture->setShadow( true, array( 'X' => 1, 'Y' => 1, 'R' => 0, 'G' => 0, 'B' => 0, 'Alpha' => 10 ) );
		$myPicture->drawLineChart(  );
		$myPicture->drawPlotChart( array( 'PlotBorder' => true, 'PlotSize' => 3, 'BorderSize' => 1, 'Surrounding' => -60, 'BorderAlpha' => 80 ) );
		$myPicture->autoOutput( './temp_c/barChart.png' );
	}

?>