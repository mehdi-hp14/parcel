<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function sendEmail($mailTo, $mailSubject, $mailBody, $additional_headers = null, $sender = null) {
		if (CONF_PHPMAILER_ENABLED == 1) {
			require_once( 'phpmailer/class.phpmailer.php' );

			if (class_exists( 'phpmailer' )) {
				$objMail = new PHPMailer(  );

				if (( 0 < CONF_PHPMAILER_PORT && CONF_PHPMAILER_HOST != '' )) {
					$objMail->IsSMTP(  );
					$objMail->Host = CONF_PHPMAILER_HOST;
					$objMail->Port = CONF_PHPMAILER_PORT;
					$objMail->SMTPAuth = true;
					$objMail->Username = CONF_PHPMAILER_USERNAME;
					$objMail->Password = CONF_PHPMAILER_PASSWORD;
				}

				$objMail->CharSet = 'UTF-8';

				if (empty( $$sender )) {
					$objMail->From = preg_replace( '/\015\012/', '', $sender['email'] );
					$objMail->FromName = preg_replace( '/\015\012/', '', $sender['name'] );
				} 
else {
					$objMail->From = preg_replace( '/\015\012/', '', CONF_GENERAL_EMAIL );
					$objMail->FromName = preg_replace( '/\015\012/', '', CONF_GENERAL_EMAIL );
				}

				$objMail->Subject = $mailSubject;
				$objMail->MsgHTML( preg_replace( '/\015\012/', '
', $mailBody ) );
				$objMail->AddAddress( $mailTo );
				$objMail->IsHTML( true );
				$objMail->Send(  );
				return true;
			}
		} 
else {
			return mail( $mailTo, $mailSubject, $mailBody, $additional_headers );
		}

	}

?>