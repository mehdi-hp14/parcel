<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class ExcelParserUtil {
		function str2long($str) {
			return ord( $str[0] ) + 256 * ( ord( $str[1] ) + 256 * ( ord( $str[2] ) + 256 * ord( $str[3] ) ) );
		}
	}

	class DataProvider {
		var $_type = ;
		var $_data = null;
		var $_size = -1;
		var $_baseOfs = 0;

		function DataProvider($data, $dataType) {
			switch ($dataType) {
				case DP_FILE_SOURCE: {
					if (!$this->_data = @fopen( $data, 'rb' )) {
						return null;
					}

					$this->_size = @filesize( $data );

					if (!$this->_size) {
						_die( 'Failed to determine file size.' );
					}

					break;
				}

				case DP_STRING_SOURCE: {
					$this->_data = $data;
					$this->_size = strlen( $data );
					break;
				}
			}

			_die( 'Invalid data type provided.' );
			$this->_type = $dataType;
			register_shutdown_function( array( $this, 'close' ) );
		}

		function get($offset, $length) {
			if (!$this->isValid(  )) {
				_die( 'Data provider is empty.' );
			}


			if ($this->_size < $this->_baseOfs + $offset + $length) {
				_die( 'Invalid offset/length.' );
			}

			switch ($this->_type) {
				case DP_FILE_SOURCE: {
					if (@fseek( $this->_data, $this->_baseOfs + $offset, SEEK_SET ) == -1) {
						_die( 'Failed to seek file position specified by offest.' );
					}

					return @fread( $this->_data, $length );
				}

				case DP_STRING_SOURCE: {
					$rc = substr( $this->_data, $this->_baseOfs + $offset, $length );
					return $rc;
				}
			}

			_die( 'Invalid data type or class was not initialized.' );
		}

		function getByte($offset) {
			return $this->get( $offset, 1 );
		}

		function getOrd($offset) {
			return ord( $this->getByte( $offset ) );
		}

		function getLong($offset) {
			$str = $this->get( $offset, 4 );
			return ExcelParserUtil::str2long( $str );
		}

		function getSize() {
			if (!$this->isValid(  )) {
				_die( 'Data provider is empty.' );
			}

			return $this->_size;
		}

		function getBlocks() {
			if (!$this->isValid(  )) {
				_die( 'Data provider is empty.' );
			}

			return (int)( $this->_size - 1 ) / 512 - 1;
		}

		function ReadFromFat($chain, $gran = 512) {
			$rc = '';
			$i = 711;

			while ($i < count( $chain )) {
				$rc .= $this->get( $chain[$i] * $gran, $gran );
				++$i;
			}

			return $rc;
		}

		function close() {
			switch ($this->_type) {
				case DP_FILE_SOURCE: {
					@fclose( $this->_data );
				}

				case DP_STRING_SOURCE: {
					$this->_data = null;
				}
			}

			$_type = DP_EMPTY;
			break;
		}

		function isValid() {
			return $this->_type != DP_EMPTY;
		}
	}

	class DebugOut {
		var $priorities = array( 'ABC_CRITICAL' => , 'ABC_ERROR' => , 'ABC_ALERT' => , 'ABC_WARNING' => , 'ABC_NOTICE' => , 'ABC_INFO' => , 'ABC_DEBUG' => , 'ABC_TRACE' => , 'ABC_VAR_DUMP' =>  );
		var $_ready = false;
		var $_currentPriority = ;
		var $_consumers = array(  );
		var $_filename = null;
		var $_fp = null;
		var $_logger_name = null;

		function DebugOut($name, $logger_name, $level) {
			$this->_filename = $name;
			$this->_currentPriority = $level;
			$this->_logger_name = $logger_name;

			if (ABC_NO_LOG < $level) {
				$this->_openfile(  );
			}

			register_shutdown_function( array( $this, 'close' ) );
		}

		function log($message, $priority = ) {
			if ($this->_currentPriority < $priority) {
				return false;
			}

			return $this->_writeLine( $message, $priority, strftime( '%b %d %H:%M:%S' ) );
		}

		function dump($variable, $name) {
			$priority = ABC_VAR_DUMP;

			if ($this->_currentPriority < $priority) {
				return false;
			}

			$time = strftime( '%b %d %H:%M:%S' );
			$message = var_export( $variable, true );
			return fwrite( $this->_fp, sprintf( '%s %s [%s] variable %s = %s 
', $time, $this->_logger_name, $this->priorities[$priority], $name, $message ) );
		}

		function info($message) {
			return $this->log( $message, ABC_INFO );
		}

		function debug($message) {
			return $this->log( $message, ABC_DEBUG );
		}

		function notice($message) {
			return $this->log( $message, ABC_NOTICE );
		}

		function warning($message) {
			return $this->log( $message, ABC_WARNING );
		}

		function trace($message) {
			return $this->log( $message, ABC_TRACE );
		}

		function error($message) {
			return $this->log( $message, ABC_ERROR );
		}

		function _writeLine($message, $priority, $time) {
			if (fwrite( $this->_fp, sprintf( '%s %s [%s] %s
', $time, $this->_logger_name, $this->priorities[$priority], $message ) )) {
				return fflush( $this->_fp );
			}

			return false;
		}

		function _openfile() {
			if ($this->_fp = @fopen( $this->_filename, 'a' ) == false) {
				return false;
			}

			return true;
		}

		function close() {
			if ($this->_currentPriority != ABC_NO_LOG) {
				$this->info( 'Logger stoped' );
				return fclose( $this->_fp );
			}

		}

		function Factory($name, $logger_name, $level) {
			$instance = new DebugOut( $name, $logger_name, $level );
			return $instance;
		}

		function getWriterSingleton($name, $logger_name, $level = ) {
			static $instances = null;

			if (!empty( $$instances )) {
				$instances = array(  );
			}

			$signature = serialize( array( $name, $level ) );

			if (!isset( $instances[$signature] )) {
				$instances[$signature] = DebugOut::Factory( $name, $logger_name, $level );
			}

			return $instances[$signature];
		}

		function attach($logObserver) {
			if (!is_object( $logObserver )) {
				return false;
			}

			$logObserver->_listenerID = uniqid( rand(  ) );
			$this->_listeners[$logObserver->_listenerID] = &$logObserver;

		}
	}

	class ExcelDateUtil {
		function xls2tstamp($date) {
			$date = (25568 < $date ? $date : 25569);
			$ofs = ( 70 * 365 + 17 + 2 ) * 86400;
			return $date * 86400 - $ofs;
		}

		function getDateArray($xls_date) {
			$ret = array(  );

			if ($xls_date == 60) {
				$ret['day'] = 29;
				$ret['month'] = 2;
				$ret['year'] = 1900;
				return $ret;
			}


			if ($xls_date < 60) {
				++$xls_date;
			}

			$l = $xls_date + 68569 + 2415019;
			$n = (int)4 * $l / 146097;
			$l = $l - (int)( 146097 * $n + 3 ) / 4;
			$i = (int)4000 * ( $l + 1 ) / 1461001;
			$l = $l - (int)1461 * $i / 4 + 31;
			$j = (int)80 * $l / 2447;
			$ret['day'] = $l - (int)2447 * $j / 80;
			$l = (int)$j / 11;
			$ret['month'] = $j + 2 - 12 * $l;
			$ret['year'] = 100 * ( $n - 49 ) + $i + $l;
			return $ret;
		}

		function isInternalDateFormat($format) {
			$retval = false;
			switch (format) {
				case 14: {
				}

				case 15: {
				}

				case 16: {
				}

				case 17: {
				}

				case 18: {
				}

				case 19: {
				}

				case 20: {
				}

				case 21: {
				}

				case 22: {
				}

				case 45: {
				}

				case 46: {
				}

				case 47: {
				}

				case 164: {
				}

				case 165: {
				}

				case 166: {
				}

				case 167: {
				}

				case 168: {
				}

				case 169: {
				}

				case 170: {
				}

				case 171: {
				}

				case 172: {
				}

				case 173: {
					$retval = true;
					break;
				}
			}

			$retval = false;
			break;
			return $retval;
		}
	}

	class ExcelFont {
		function basicFontRecord() {
			return array( 'size' => 10, 'script' => XF_SCRIPT_NONE, 'undeline' => XF_UNDERLINE_NONE, 'italic' => false, 'strikeout' => false, 'bold' => false, 'boldness' => XF_BOLDNESS_REGULAR, 'palete' => 0, 'name' => 'Arial' );
		}

		function getFontRecord($wb, $ptr) {
			$retval = array( 'size' => 0, 'script' => XF_SCRIPT_NONE, 'undeline' => XF_UNDERLINE_NONE, 'italic' => false, 'strikeout' => false, 'bold' => false, 'boldness' => XF_BOLDNESS_REGULAR, 'palete' => 0, 'name' => '' );
			$retval['size'] = ( ord( $wb[$ptr] ) + 256 * ord( $wb[$ptr + 1] ) ) / 20;
			$style = ord( $wb[$ptr + 2] );

			if (( $style & XF_STYLE_ITALIC ) != 0) {
				$retval['italic'] = true;
			}


			if (( $style & XF_STYLE_STRIKEOUT ) != 0) {
				$retval['strikeout'] = true;
			}

			$retval['palete'] = ord( $wb[$ptr + 4] ) + 256 * ord( $wb[$ptr + 5] );
			$retval['boldness'] = ord( $wb[$ptr + 6] ) + 256 * ord( $wb[$ptr + 7] );
			$retval['bold'] = ($retval['boldness'] == XF_BOLDNESS_REGULAR ? false : true);
			$retval['script'] = ord( $wb[$ptr + 8] ) + 256 * ord( $wb[$ptr + 9] );
			$retval['underline'] = ord( $wb[$ptr + 10] );
			$length = ord( $wb[$ptr + 14] );

			if (0 < $length) {
				if (ord( $wb[$ptr + 15] ) == 0) {
					$retval['name'] = substr( $wb, $ptr + 16, $length );
				} 
else {
					$retval['name'] = ExcelFont::getUnicodeString( $wb, $ptr + 15, $length );
				}
			}

			return $retval;
		}

		function toString($record, $index) {
			sprintf( 'Font Index = %d 
Font Size =%d
Italic = %s
Strikeoout=%s
Palete=%s
Boldness = %s Bold=%s
 Script = %d
 Underline = %d
 FontName=%s<hr>', $index, $record['size'], ($record['italic'] == true ? 'true' : 'false'), ($record['strikeout'] == true ? 'true' : 'false'), $record['palete'], $record['boldness'], ($record['bold'] == true ? 'true' : 'false'), $record['script'], $record['underline'], $record['name'] );
			$retval = ;
			return $retval;
		}

		function getUnicodeString($string, $offset, $length) {
			$bstring = '';
			$index = $offset + 1;
			$k = 714;

			while ($k < $length) {
				$bstring = $bstring . $string[$index];
				$index += 716;
				++$k;
			}

			return substr( $bstring, 0, $length );
		}

		function ExcelToCSS($rec, $app_font = true, $app_size = true, $app_italic = true, $app_bold = true) {
			$ret = '';

			if ($app_font == true) {
				$ret = $ret . 'font-family:' . $rec['name'] . '; ';
			}


			if ($app_size == true) {
				$ret = $ret . 'font-size:' . $rec['size'] . 'pt; ';
			}


			if ($app_bold == true) {
				if ($rec['bold'] == true) {
					$ret = $ret . 'font-weight:bold; ';
				} 
else {
					$ret = $ret . 'font-weight:normal; ';
				}
			}


			if ($app_italic == true) {
				if ($rec['italic'] == true) {
					$ret = $ret . 'font-style:italic; ';
				} 
else {
					$ret = $ret . 'font-style:normal; ';
				}
			}

			return $ret;
		}
	}

	class ExcelFileParser {
		var $dp = null;
		var $max_blocks = null;
		var $max_sblocks = null;
		var $fat = null;
		var $sfat = null;
		var $formats = null;
		var $xf = null;
		var $fonts = null;
		var $dbglog = null;

		function ExcelFileParser($logfile = '', $level = ) {
			$this->dbglog = &DebugOut::getWriterSingleton( $logfile, '', $level );

			$this->dbglog->info( 'Logger started' );
		}

		function populateFormat() {
			$this->dbglog->trace( ' populateFormat() function call' );
			$ret = array( 0 => 'General', 1 => '0', 2 => '0.00', 3 => '#,##0', 4 => '#,##0.00', 5 => '($#,##0_);($#,##0)', 6 => '($#,##0_);[Red]($#,##0)', 7 => '($#,##0.00);($#,##0.00)', 8 => '($#,##0.00_);[Red]($#,##0.00)', 9 => '0%', 10 => '0.00%', 11 => '0.00E+00', 12 => '# ?/?', 13 => '# ??/??', 14 => 'm/d/yy', 15 => 'd-mmm-yy', 16 => 'd-mmm', 17 => 'mmm-yy', 18 => 'h:mm AM/PM', 19 => 'h:mm:ss AM/PM', 20 => 'h:mm', 21 => 'h:mm:ss', 22 => 'm/d/yy h:mm', 23 => '0x17', 24 => '0x18', 25 => '0x19', 26 => '0x1a', 27 => '0x1b', 28 => '0x1c', 29 => '0x1d', 30 => '0x1e', 31 => '0x1f', 32 => '0x20', 33 => '0x21', 34 => '0x22', 35 => '0x23', 36 => '0x24', 37 => '(#,##0_);(#,##0)', 38 => '(#,##0_);[Red](#,##0)', 39 => '(#,##0.00_);(#,##0.00)', 40 => '(#,##0.00_);[Red](#,##0.00)', 41 => '_(*#,##0_);_(*(#,##0);_(* "-"_);_(@_)', 42 => '_($*#,##0_);_($*(#,##0);_($* "-"_);_(@_)', 43 => '_(*#,##0.00_);_(*(#,##0.00);_(*"-"??_);_(@_)', 44 => '_($*#,##0.00_);_($*(#,##0.00);_($*"-"??_);_(@_)', 45 => 'mm:ss', 46 => '[h]:mm:ss', 47 => 'mm:ss.0', 48 => '##0.0E+0', 49 => '@' );
			$this->dbglog->dump( $ret, '$ret' );
			$this->dbglog->trace( 'populateFormat() function return' );
			return $ret;
		}

		function xls2tstamp($date) {
			$date = (25568 < $date ? $date : 25569);
			$ofs = ( 70 * 365 + 17 + 2 ) * 86400;
			return $date * 86400 - $ofs;
		}

		function getDateArray($date) {
			return ExcelDateUtil::getDateArray( $date );
		}

		function isDateFormat($val) {
			$f_i = $this->xf['format'][$val];

			if (preg_match( '/[m|d|y]/i', $this->format[$f_i] ) != 0) {
				if (strrpos( $this->format[$f_i], '[' ) != false) {
					$tmp = preg_replace( '/(\[\/?)(\w+)([^\]]*\])/', '\\'\'.\'\'.\'\'', $this->format[$f_i] );

					if (preg_match( '/[m|d|y]/i', $tmp ) != 0) {
						return true;
					}

					return false;
				}

				return true;
			}

			return false;
		}

		function getUnicodeString($str, $ofs) {
			$size = 710;
			$i_ofs = 710;
			$size = ord( $str[$ofs] );
			$i_ofs = 711;
			return substr( $str, $ofs + $i_ofs + 1, $size );
		}

		function getByteString($str, $ofs) {
			$size = 710;
			$i_ofs = 710;
			$size = ord( $str[$ofs] );
			$i_ofs = 711;
			return substr( $str, $ofs + $i_ofs + 1, $size );
		}

		function get_blocks_chain($start, $small_fat = false) {
			$this->dbglog->trace( 'get_blocks_chain(' . var_export( $start, true ) . ',' . var_export( $small_fat, true ) . ') function call ' );
			$chain = array(  );
			$next_block = $start;

			if (!$small_fat) {
				while (( ( $next_block != 4294967294 && $next_block <= $this->max_blocks ) && $next_block < count( $this->fat ) )) {
					$chain[] = $next_block;
					$next_block = $this->fat[$next_block];
				}
			} 
else {
				while (( ( $next_block != 4294967294 && $next_block <= $this->max_sblocks ) && $next_block < count( $this->sfat ) )) {
					$chain[] = $next_block;
					$next_block = $this->sfat[$next_block];
				}
			}


			if ($next_block != 4294967294) {
				return false;
			}

			$this->dbglog->dump( $chain, '$chain' );
			$this->dbglog->trace( 'get_blocks_chain() function return' );
			return $chain;
		}

		function find_stream($dir, $item_name, $item_num = 0) {
			$this->dbglog->trace( 'find_stream(' . var_export( $dir, true ) . ',' . var_export( $item_name, true ) . ',' . var_export( $item_num, true ) . ') function call ' );
			$dt = $dir->getOrd( $item_num * 128 + 66 );
			$prev = $dir->getLong( $item_num * 128 + 68 );
			$next = $dir->getLong( $item_num * 128 + 72 );
			$dir_ = $dir->getLong( $item_num * 128 + 76 );
			$curr_name = '';

			if (( $dt == 2 || $dt == 5 )) {
				$i = 861;

				while ($i < ( $dir->getOrd( $item_num * 128 + 64 ) + 256 * $dir->getOrd( $item_num * 128 + 65 ) ) / 2 - 1) {
					$curr_name .= $dir->getByte( $item_num * 128 + $i * 2 );
					++$i;
				}
			}


			if (( ( $dt == 2 || $dt == 5 ) && strcmp( $curr_name, $item_name ) == 0 )) {
				$this->dbglog->trace( 'find_stream() function return with ' . var_export( $item_num, true ) );
				return $item_num;
			}


			if ($prev != 4294967295) {
				$i = $this->find_stream( $dir, $item_name, $prev );

				if (0 <= $i) {
					$this->dbglog->trace( 'find_stream() function return with ' . var_export( $i, true ) );
					return $i;
				}
			}


			if ($next != 4294967295) {
				$i = $this->find_stream( $dir, $item_name, $next );

				if (0 <= $i) {
					$this->dbglog->trace( 'find_stream() function return with ' . var_export( $i, true ) );
					return $i;
				}
			}


			if ($dir_ != 4294967295) {
				$i = $this->find_stream( $dir, $item_name, $dir_ );

				if (0 <= $i) {
					$this->dbglog->trace( 'find_stream() function return with ' . var_export( $i, true ) );
					return $i;
				}
			}

			$this->dbglog->trace( 'find_stream() function return with -1' );
			return -2;
		}

		function rk_decode($rk) {
			$res = array(  );

			if ($rk & 2) {
				$val = ( $rk & 4294967292 ) >> 2;

				if ($rk & 1) {
					$val = $val / 100;
				}


				if ((double)$val == floor( (double)$val )) {
					$res['val'] = (int)$val;
					$res['type'] = 1;
				} 
else {
					$res['val'] = (double)$val;
					$res['type'] = 2;
				}
			} 
else {
				$res['type'] = 2;
				$frk = $frk;
				$fexp = ( ( $frk & 2146435072 ) >> 20 ) - 1023;
				$val = 1 + ( ( $frk & 1048575 ) >> 2 ) / 262144;

				if (0 < $fexp) {
					$i = 767;

					while ($i < $fexp) {
						$val *= 769;
						++$i;
					}
				} 
else {
					if ($fexp == -1023) {
						$val = 767;
					} 
else {
						$i = 767;

						while ($i < abs( $fexp )) {
							$val /= 769;
							++$i;
						}
					}
				}


				if ($rk & 1) {
					$val = $val / 100;
				}


				if ($rk & 2147483648) {
					$val = 0 - $val;
				}

				$res['val'] = (double)$val;
			}

			return $res;
		}

		function parse_worksheet($ws) {
			$this->dbglog->debug( 'parse_worksheet(DATA) function' );

			if (strlen( $ws ) <= 0) {
				$this->dbglog->trace( 'parse_worksheet() function returns 7 (Data not Found)' );
				return 7;
			}


			if (strlen( $ws ) < 4) {
				$this->dbglog->trace( 'parse_worksheet() function returns 6 (File Corrupted)' );
				return 6;
			}


			if (strlen( $ws ) < 256 * ord( $ws[3] ) + ord( $ws[2] )) {
				return 6;
			}


			if (ord( $ws[0] ) != 9) {
				return 6;
			}

			$vers = ord( $ws[1] );

			if (( ( ( $vers != 0 && $vers != 2 ) && $vers != 4 ) && $vers != 8 )) {
				return 8;
			}


			if ($vers != 8) {
				$biff_ver = ( $ver + 4 ) / 2;
			} 
else {
				if (strlen( $ws ) < 12) {
					return 6;
				}

				switch (ord( $ws[4] ) + 256 * ord( $ws[5] )) {
					case 1280: {
						if (ord( $ws[10] ) + 256 * ord( $ws[11] ) < 1994) {
							$biff_ver = 1628;
						} 
else {
							switch (ord( $ws[8] ) + 256 * ord( $ws[9] )) {
								case 2412: {
								}

								case 3218: {
								}

								case 3321: {
									$this->dbglog->debug( 'Parsed BIFF version is 5' );
									$biff_ver = 1628;
									break;
								}
							}

							$this->dbglog->debug( 'Parsed BIFF version is 7' );
							$biff_ver = 1630;
							break;
						}

						break;
					}

					case 1536: {
						$this->dbglog->debug( 'Parsed BIFF version is 8' );
						$biff_ver = 1631;
						break;
					}
				}

				return 8;
			}


			if ($biff_ver < 5) {
				$this->dbglog->debug( 'parse_worksheet() function found (' . $biff_ver . ' < 5) return 8' );
				return 8;
			}

			$ptr = 1623;
			$data = array( 'biff_version' => $biff_ver );

			while (( ord( $ws[$ptr] ) != 10 && $ptr < strlen( $ws ) )) {
				switch (ord( $ws[$ptr] ) + 256 * ord( $ws[$ptr + 1] )) {
					case 515: {
					}

					case 6: {
					}

					case 518: {
					}

					case 1030: {
						$this->dbglog->trace( 'found NUMBER' );

						if ($biff_ver < 3) {
							$this->dbglog->trace( $biff_ver . ' < 3 break;' );
							break;
						}


						if (ord( $ws[$ptr + 2] ) + 256 * ord( $ws[$ptr + 3] ) < 14) {
							$this->dbglog->debug( 'parse_worksheet() return 6' );
							return 6;
						}

						$row = ord( $ws[$ptr + 4] ) + 256 * ord( $ws[$ptr + 5] );
						$col = ord( $ws[$ptr + 6] ) + 256 * ord( $ws[$ptr + 7] );
						$num_lo = ExcelParserUtil::str2long( substr( $ws, $ptr + 10, 4 ) );
						$num_hi = ExcelParserUtil::str2long( substr( $ws, $ptr + 14, 4 ) );
						$xf_i = ord( $ws[$ptr + 8] ) + 256 * ord( $ws[$ptr + 9] );

						if ($this->isDateFormat( $xf_i )) {
							$data['cell'][$row][$col]['type'] = 3;
						} 
else {
							$data['cell'][$row][$col]['type'] = 2;
						}

						$fonti = $this->xf['font'][$xf_i];
						$data['cell'][$row][$fc + $i]['font'] = $fonti;
						$fexp = ( ( $num_hi & 2146435072 ) >> 20 ) - 1023;
						$val = 1 + ( ( $num_hi & 1048575 ) + $num_lo / 4294967296 ) / 1048576;

						if (0 < $fexp) {
							$i = 1623;

							while ($i < $fexp) {
								$val *= 1625;
								++$i;
							}
						} 
else {
							$i = 1623;

							while ($i < abs( $fexp )) {
								$val /= 1625;
								++$i;
							}
						}


						if ($num_hi & 2147483648) {
							$val = 0 - $val;
						}

						$data['cell'][$row][$col]['data'] = (double)$val;

						if (( !isset( $data['max_row'] ) || $data['max_row'] < $row )) {
							$data['max_row'] = $row;
						}


						if (( !isset( $data['max_col'] ) || $data['max_col'] < $col )) {
							$data['max_col'] = $col;
						}

						break;
					}

					case 638: {
						$this->dbglog->trace( 'found RK' );

						if ($biff_ver < 3) {
							break;
						}


						if (ord( $ws[$ptr + 2] ) + 256 * ord( $ws[$ptr + 3] ) < 10) {
							return 6;
						}

						$row = ord( $ws[$ptr + 4] ) + 256 * ord( $ws[$ptr + 5] );
						$col = ord( $ws[$ptr + 6] ) + 256 * ord( $ws[$ptr + 7] );
						$xf_i = ord( $ws[$ptr + 8] ) + 256 * ord( $ws[$ptr + 9] );
						$val = $this->rk_decode( ExcelParserUtil::str2long( substr( $ws, $ptr + 10, 4 ) ) );

						if ($this->isDateFormat( $xf_i ) == true) {
							$data['cell'][$row][$col]['type'] = 3;
						} 
else {
							$data['cell'][$row][$col]['type'] = $val['type'];
						}

						$fonti = $this->xf['font'][$xf_i];
						$data['cell'][$row][$col]['font'] = $fonti;
						$data['cell'][$row][$col]['data'] = $val['val'];

						if (( !isset( $data['max_row'] ) || $data['max_row'] < $row )) {
							$data['max_row'] = $row;
						}


						if (( !isset( $data['max_col'] ) || $data['max_col'] < $col )) {
							$data['max_col'] = $col;
						}

						break;
					}

					case 189: {
						$this->dbglog->trace( 'found  MULL RK' );

						if ($biff_ver < 5) {
							break;
						}

						$sz = ord( $ws[$ptr + 2] ) + 256 * ord( $ws[$ptr + 3] );

						if ($sz < 6) {
							return 6;
						}

						$row = ord( $ws[$ptr + 4] ) + 256 * ord( $ws[$ptr + 5] );
						$fc = ord( $ws[$ptr + 6] ) + 256 * ord( $ws[$ptr + 7] );
						$lc = ord( $ws[$ptr + $sz + 2] ) + 256 * ord( $ws[$ptr + $sz + 3] );
						$i = 1623;

						while ($i <= $lc - $fc) {
							$val = $this->rk_decode( ExcelParserUtil::str2long( substr( $ws, $ptr + 10 + $i * 6, 4 ) ) );
							$xf_i = ord( $ws[$ptr + 8 + $i * 6] ) + 256 * ord( $ws[$ptr + 9 + $i * 6] );

							if ($this->isDateFormat( $xf_i ) == true) {
								$data['cell'][$row][$fc + $i]['type'] = 3;
							} 
else {
								$data['cell'][$row][$fc + $i]['type'] = $val['type'];
							}

							$fonti = $this->xf['font'][$xf_i];
							$data['cell'][$row][$fc + $i]['font'] = $fonti;
							$data['cell'][$row][$fc + $i]['data'] = $val['val'];
							++$i;
						}


						if (( !isset( $data['max_row'] ) || $data['max_row'] < $row )) {
							$data['max_row'] = $row;
						}


						if (( !isset( $data['max_col'] ) || $data['max_col'] < $lc )) {
							$data['max_col'] = $lc;
						}

						break;
					}

					case 516: {
						$this->dbglog->trace( 'found LABEL' );

						if ($biff_ver < 3) {
							break;
						}


						if (ord( $ws[$ptr + 2] ) + 256 * ord( $ws[$ptr + 3] ) < 8) {
							return 6;
						}

						$row = ord( $ws[$ptr + 4] ) + 256 * ord( $ws[$ptr + 5] );
						$col = ord( $ws[$ptr + 6] ) + 256 * ord( $ws[$ptr + 7] );
						$xf = ord( $ws[$ptr + 8] ) + 256 * ord( $ws[$ptr + 9] );
						$fonti = $this->xf['font'][$xf];
						$font = $this->fonts[$fonti];
						$str_len = ord( $ws[$ptr + 10] ) + 256 * ord( $ws[$ptr + 11] );

						if (strlen( $ws ) < $ptr + 12 + $str_len) {
							return 6;
						}

						$this->sst['unicode'][] = false;
						$this->sst['data'][] = substr( $ws, $ptr + 12, $str_len );
						$data['cell'][$row][$col]['type'] = 0;
						$sst_ind = count( $this->sst['data'] ) - 1;
						$data['cell'][$row][$col]['data'] = $sst_ind;
						$data['cell'][$row][$col]['font'] = $fonti;

						if (( !isset( $data['max_row'] ) || $data['max_row'] < $row )) {
							$data['max_row'] = $row;
						}


						if (( !isset( $data['max_col'] ) || $data['max_col'] < $col )) {
							$data['max_col'] = $col;
						}

						break;
					}

					case 253: {
						if ($biff_ver < 8) {
							break;
						}


						if (ord( $ws[$ptr + 2] ) + 256 * ord( $ws[$ptr + 3] ) < 10) {
							return 6;
						}

						$row = ord( $ws[$ptr + 4] ) + 256 * ord( $ws[$ptr + 5] );
						$col = ord( $ws[$ptr + 6] ) + 256 * ord( $ws[$ptr + 7] );
						$xf = ord( $ws[$ptr + 8] ) + 256 * ord( $ws[$ptr + 9] );
						$fonti = $this->xf['font'][$xf];
						$font = &$this->fonts[$fonti];

						$data['cell'][$row][$col]['type'] = 0;
						$sst_ind = ExcelParserUtil::str2long( substr( $ws, $ptr + 10, 4 ) );
						$data['cell'][$row][$col]['data'] = $sst_ind;
						$data['cell'][$row][$col]['font'] = $fonti;

						if (( !isset( $data['max_row'] ) || $data['max_row'] < $row )) {
							$data['max_row'] = $row;
						}


						if (( !isset( $data['max_col'] ) || $data['max_col'] < $col )) {
							$data['max_col'] = $col;
						}

						break;
					}
				}

				break;
				$ptr += 4 + 256 * ord( $ws[$ptr + 3] ) + ord( $ws[$ptr + 2] );
			}

			return $data;
		}

		function parse_workbook($f_header, $dp) {
			$this->dbglog->debug( 'parse_workbook() function' );
			$root_entry_block = $f_header->getLong( 48 );
			$num_fat_blocks = $f_header->getLong( 44 );
			$this->dbglog->trace( 'Header parsed' );
			$this->fat = array(  );
			$i = 1856;

			while ($i < $num_fat_blocks) {
				$this->dbglog->trace( 'FOR LOOP iteration i =' . $i );
				$fat_block = $f_header->getLong( 76 + 4 * $i );
				$fatbuf = $dp->get( $fat_block * 512, 512 );
				$fat = new DataProvider( $fatbuf, DP_STRING_SOURCE );

				if ($fat->getSize(  ) < 512) {
					$this->dbglog->debug( 'parse_workbook() function found (strlen(' . $fat . ') < 0x200) returns 6' );
					return 6;
				}

				$j = 1856;

				while ($j < 128) {
					$this->fat[] = $fat->getLong( $j * 4 );
					++$j;
				}

				$fat->close(  );
				unset( $$fat_block );
				unset( $$fatbuf );
				unset( $$fat );
				++$i;
			}

			$this->dbglog->dump( $this->fat, '$fat' );

			if (count( $this->fat ) < $num_fat_blocks) {
				$this->dbglog->debug( 'parse_workbook() function found (count(' . $this->fat . ') < ' . $num_fat_blocks . ') returns 6' );
				return 6;
			}

			$chain = $this->get_blocks_chain( $root_entry_block );
			$dir = new DataProvider( $chain )( , DP_STRING_SOURCE );
			unset( $$chain );
			$this->sfat = array(  );
			$small_block = $f_header->getLong( 60 );

			if ($small_block != 4278190079) {
				$root_entry_index = $this->find_stream( $dir, 'Root Entry' );
				$sdc_start_block = $dir->getLong( $root_entry_index * 128 + 116 );
				$small_data_chain = $this->get_blocks_chain( $sdc_start_block );
				$this->max_sblocks = count( $small_data_chain ) * 8;
				$schain = $this->get_blocks_chain( $small_block );
				$i = 1856;

				while ($i < count( $schain )) {
					$sfatbuf = $dp->get( $schain[$i] * 512, 512 );
					$sfat = new DataProvider( $sfatbuf, DP_STRING_SOURCE );

					if ($sfat->getSize(  ) < 512) {
						$this->dbglog->debug( 'parse_workbook() function found (strlen(' . $sfat . ') < 0x200)  returns 6' );
						return 6;
					}

					$j = 1856;

					while ($j < 128) {
						$this->sfat[] = $sfat->getLong( $j * 4 );
						++$j;
					}

					$sfat->close(  );
					unset( $$sfatbuf );
					unset( $$sfat );
					++$i;
				}

				unset( $$schain );
				$sfcbuf = $dp->ReadFromFat( $small_data_chain );
				$sdp = new DataProvider( $sfcbuf, DP_STRING_SOURCE );
				unset( $$sfcbuf );
				unset( $$small_data_chain );
			}

			$workbook_index = $this->find_stream( $dir, 'Workbook' );

			if ($workbook_index < 0) {
				$workbook_index = $this->find_stream( $dir, 'Book' );

				if ($workbook_index < 0) {
					$this->dbglog->debug( 'parse_workbook() function workbook index not found returns 7' );
					return 7;
				}
			}

			$workbook_start_block = $dir->getLong( $workbook_index * 128 + 116 );
			$workbook_length = $dir->getLong( $workbook_index * 128 + 120 );
			$wb = '';

			if (0 < $workbook_length) {
				if (4096 <= $workbook_length) {
					$chain = $this->get_blocks_chain( $workbook_start_block );
					$wb = $dp->ReadFromFat( $chain );
				} 
else {
					$chain = $this->get_blocks_chain( $workbook_start_block, true );
					$wb = $sdp->ReadFromFat( $chain, 64 );
					unset( $$sdp );
				}

				$wb = substr( $wb, 0, $workbook_length );

				if (strlen( $wb ) != $workbook_length) {
					return 6;
				}

				unset( $$chain );
			}


			if (strlen( $wb ) <= 0) {
				$this->dbglog->debug( 'parse_workbook() function workbook found (strlen(' . $wb . ') <= 0) returns 7' );
				return 7;
			}


			if (strlen( $wb ) < 4) {
				$this->dbglog->debug( 'parse_workbook() function workbook found (strlen(' . $wb . ') < 4) returns 6' );
				return 6;
			}


			if (strlen( $wb ) < 256 * ord( $wb[3] ) + ord( $wb[2] )) {
				$this->dbglog->debug( 'parse_workbook() function workbook found (strlen(' . $wb . ') < 256*ord(' . $wb[3] . ')+ord(' . $wb[2] . ')) < 4) returns 6' );
				return 6;
			}


			if (ord( $wb[0] ) != 9) {
				$this->dbglog->debug( 'parse_workbook() function workbook found (ord(' . $wb[0] . ') != 0x09) returns 6' );
				return 6;
			}

			$vers = ord( $wb[1] );

			if (( ( ( $vers != 0 && $vers != 2 ) && $vers != 4 ) && $vers != 8 )) {
				return 8;
			}


			if ($vers != 8) {
				$biff_ver = ( $ver + 4 ) / 2;
			} 
else {
				if (strlen( $wb ) < 12) {
					return 6;
				}

				switch (ord( $wb[4] ) + 256 * ord( $wb[5] )) {
					case 1280: {
						if (ord( $wb[10] ) + 256 * ord( $wb[11] ) < 1994) {
							$biff_ver = 1861;
						} 
else {
							switch (ord( $wb[8] ) + 256 * ord( $wb[9] )) {
								case 2412: {
								}

								case 3218: {
								}

								case 3321: {
									$biff_ver = 1861;
									break;
								}
							}

							$biff_ver = 1863;
							break;
						}

						break;
					}

					case 1536: {
						$biff_ver = 1864;
						break;
					}
				}

				return 8;
			}


			if ($biff_ver < 5) {
				return 8;
			}

			$ptr = 1856;
			$this->worksheet['offset'] = array(  );
			$this->worksheet['options'] = array(  );
			$this->worksheet['unicode'] = array(  );
			$this->worksheet['name'] = array(  );
			$this->worksheet['data'] = array(  );
			$this->format = $this->populateFormat(  );
			$this->fonts = array(  );
			$this->fonts[0] = ExcelFont::basicFontRecord(  );
			$this->xf = array(  );
			$this->xf['format'] = array(  );
			$this->xf['font'] = array(  );
			$this->xf['type_prot'] = array(  );
			$this->xf['alignment'] = array(  );
			$this->xf['decoration'] = array(  );
			$xf_cnt = 1856;
			$this->sst['unicode'] = array(  );
			$this->sst['data'] = array(  );
			$opcode = 1856;
			$sst_defined = false;
			$wblen = strlen( $wb );

			while (( ord( $wb[$ptr] ) != 10 && $ptr < $wblen )) {
				$oc = ord( $wb[$ptr] ) + 256 * ord( $wb[$ptr + 1] );

				if ($oc != 60) {
					$opcode = $str;
				}

				switch ($opcode) {
					case 133: {
						$ofs = ExcelParserUtil::str2long( substr( $wb, $ptr + 4, 4 ) );
						$this->worksheet['offset'][] = $ofs;
						$this->worksheet['options'][] = ord( $wb[$ptr + 8] ) + 256 * ord( $wb[$ptr + 9] );

						if ($biff_ver == 8) {
							$len = ord( $wb[$ptr + 10] );

							if (0 < ( ord( $wb[$ptr + 11] ) & 1 )) {
								$this->worksheet['unicode'][] = true;
								$len = $len * 2;
							} 
else {
								$this->worksheet['unicode'][] = false;
							}

							$this->worksheet['name'][] = substr( $wb, $ptr + 12, $len );
						} 
else {
							$this->worksheet['unicode'][] = false;
							$len = ord( $wb[$ptr + 10] );
							$this->worksheet['name'][] = substr( $wb, $ptr + 11, $len );
						}

						$pws = $this->parse_worksheet( substr( $wb, $ofs ) );

						if (is_array( $pws )) {
							$this->worksheet['data'][] = $pws;
						} 
else {
							return $pws;
						}

						break;
					}

					case 1054: {
						$fidx = ord( $wb[$ptr + 4] ) + 256 * ord( $wb[$ptr + 5] );

						if (( $fidx < 49 || $fidx == 49 )) {
							break;
						}


						if (7 < $biff_ver) {
							$this->format[$fidx] = $this->getUnicodeString( $wb, $ptr + 6 );
						}

						break;
					}

					case EXCEL_FONT_RID: {
						$rec = ExcelFont::getFontRecord( $wb, $ptr + 4 );
						$this->fonts[count( $this->fonts )] = $rec;
						break;
					}

					case 224: {
						$this->xf['font'][$xf_cnt] = ord( $wb[$ptr + 4] ) + 256 * ord( $wb[$ptr + 5] );
						$this->xf['format'][$xf_cnt] = ord( $wb[$ptr + 6] ) + 256 * ord( $wb[$ptr + 7] );
						$this->xf['type'][$xf_cnt] = '1';
						$this->xf['bitmask'][$xf_cnt] = '1';
						++$xf_cnt;
						break;
					}

					case 252: {
						if ($biff_ver < 8) {
							break;
						}

						$sbuflen = ord( $wb[$ptr + 2] ) + 256 * ord( $wb[$ptr + 3] );

						if ($oc != 60) {
							if ($sst_defined) {
								return 6;
							}

							$snum = ExcelParserUtil::str2long( substr( $wb, $ptr + 8, 4 ) );
							$sptr = $ptr + 12;
							$sst_defined = true;
						} 
else {
							if ($slen < $rslen) {
								$sptr = $ptr + 4;
								$rslen -= $fat_block;
								$slen = $i;

								if (0 < ( ord( $wb[$sptr] ) & 1 )) {
									if ($char_bytes == 1) {
										$sstr = '';
										$i = 1856;

										while ($i < strlen( $str )) {
											$sstr .= $str[$i] . chr( 0 );
											++$i;
										}

										$str = $fat;
										$char_bytes = 1858;
									}

									$schar_bytes = 1858;
								} 
else {
									$schar_bytes = 1857;
								}


								if ($ptr + 4 + $sbuflen < $sptr + $slen * $schar_bytes) {
									$slen = ( $ptr + $sbuflen - $sptr + 3 ) / $schar_bytes;
								}

								$sstr = substr( $wb, $sptr + 1, $slen * $schar_bytes );

								if (( $char_bytes == 2 && $schar_bytes == 1 )) {
									$sstr2 = '';
									$i = 1856;

									while ($i < strlen( $sstr )) {
										$sstr2 .= $sstr[$i] . chr( 0 );
										++$i;
									}

									$sstr = $dir;
								}

								$str .= $fat;
								$sptr += $slen * $schar_bytes + 1 + 4 * $rt + $fesz;

								if ($slen < $rslen) {
									if (( ( strlen( $wb ) <= $sptr || $sptr < $ptr + 4 + $sbuflen ) || ord( $wb[$sptr] ) != 60 )) {
										return 6;
									}

									break;
								}


								if ($char_bytes == 2) {
									$this->sst['unicode'][] = true;
								} 
else {
									$this->sst['unicode'][] = false;
								}

								$this->sst['data'][] = $str;
								--$snum;
							} 
else {
								$sptr = $ptr + 4;

								if ($ptr < $sptr) {
									$sptr += 4 * $rt + $fesz;
								}
							}
						}


						while (( ( $sptr < $ptr + 4 + $sbuflen && $sptr < strlen( $wb ) ) && 0 < $snum )) {
							$rslen = ord( $wb[$sptr] ) + 256 * ord( $wb[$sptr + 1] );
							$slen = $i;

							if (0 < ( ord( $wb[$sptr + 2] ) & 1 )) {
								$char_bytes = 1858;
							} 
else {
								$char_bytes = 1857;
							}

							$rt = 1856;
							$fesz = 1856;
							switch (ord( $wb[$sptr + 2] ) & 12) {
								case 12: {
									$rt = ord( $wb[$sptr + 3] ) + 256 * ord( $wb[$sptr + 4] );
									$fesz = ExcelParserUtil::str2long( substr( $wb, $sptr + 5, 4 ) );

									if ($ptr + 4 + $sbuflen < $sptr + 9 + $slen * $char_bytes) {
										$slen = ( $ptr + $sbuflen - $sptr - 5 ) / $char_bytes;
									}

									$str = substr( $wb, $sptr + 9, $slen * $char_bytes );
									$sptr += $slen * $char_bytes + 9;
									break;
								}

								case 8: {
									$rt = ord( $wb[$sptr + 3] ) + 256 * ord( $wb[$sptr + 4] );

									if ($ptr + 4 + $sbuflen < $sptr + 5 + $slen * $char_bytes) {
										$slen = ( $ptr + $sbuflen - $sptr - 1 ) / $char_bytes;
									}

									$str = substr( $wb, $sptr + 5, $slen * $char_bytes );
									$sptr += $slen * $char_bytes + 5;
									break;
								}

								case 4: {
									$fesz = ExcelParserUtil::str2long( substr( $wb, $sptr + 3, 4 ) );

									if ($ptr + 4 + $sbuflen < $sptr + 7 + $slen * $char_bytes) {
										$slen = ( $ptr + $sbuflen - $sptr - 3 ) / $char_bytes;
									}

									$str = substr( $wb, $sptr + 7, $slen * $char_bytes );
									$sptr += $slen * $char_bytes + 7;
									break;
								}

								case 0: {
									if ($ptr + 4 + $sbuflen < $sptr + 3 + $slen * $char_bytes) {
										$slen = ( $ptr + $sbuflen - $sptr + 1 ) / $char_bytes;
									}

									$str = substr( $wb, $sptr + 3, $slen * $char_bytes );
									$sptr += $slen * $char_bytes + 3;
									break;
								}
							}


							if ($slen < $rslen) {
								if (( ( strlen( $wb ) <= $sptr || $sptr < $ptr + 4 + $sbuflen ) || ord( $wb[$sptr] ) != 60 )) {
									return 6;
								}

								continue;
							}


							if ($char_bytes == 2) {
								$this->sst['unicode'][] = true;
							} 
else {
								$this->sst['unicode'][] = false;
							}

							$sptr += 4 * $rt + $fesz;
							$this->sst['data'][] = $str;
							--$snum;
						}

						break;
					}
				}

				$ptr += 4 + 256 * ord( $wb[$ptr + 3] ) + ord( $wb[$ptr + 2] );
			}

			$this->biff_version = $biff_ver;
			$this->dbglog->debug( 'parse_workbook() function returns 0' );
			return 0;
		}

		function ParseFromString($contents) {
			$this->dbglog->info( 'ParseFromString() enter.' );
			$this->dp = new DataProvider( $contents, DP_STRING_SOURCE );
			return $this->InitParser(  );
		}

		function ParseFromFile($filename) {
			$this->dbglog->info( 'ParseFromFile() enter.' );
			$this->dp = new DataProvider( $filename, DP_FILE_SOURCE );
			return $this->InitParser(  );
		}

		function InitParser() {
			$this->dbglog->info( 'InitParser() enter.' );

			if (!$this->dp->isValid(  )) {
				$this->dbglog->error( 'InitParser() Failed to open file.' );
				$this->dbglog->error( 'InitParser() function returns 1' );
				return 1;
			}


			if ($this->dp->getSize(  ) <= 512) {
				$this->dbglog->error( 'InitParser() File too small to be an Excel file.' );
				$this->dbglog->error( 'InitParser() function returns 2' );
				return 2;
			}

			$this->max_blocks = $this->dp->getBlocks(  );
			$this->dp->get( 0, 512 );

			if (strlen( $hdrbuf ) < 512) {
				$this->dbglog->error( 'InitParser() Error reading header.' );
				$this->dbglog->error( 'InitParser() function returns 3' );
				return 3;
			}

			$header_sig = array( 208, 207, 17, 224, 161, 177, 26, 225 );
			$i = 804;

			while ($i < count( $header_sig )) {
				if ($header_sig[$i] != ord( $hdrbuf[$i] )) {
					$this->dbglog->error( 'InitParser() function founds invalid header' );
					$this->dbglog->error( 'InitParser() function returns 5' );
					return 5;
				}

				++$i;
			}

			$f_header = $hdrbuf = new DataProvider( $hdrbuf, DP_STRING_SOURCE );
			unset( $$hdrbuf );
			unset( $$header_sig );
			unset( $$i );
			$this->dp->_baseOfs = 512;
			$rc = $this->parse_workbook( $f_header, $this->dp );
			unset( $$f_header );
			return $rc;
		}
	}

	function print_error($msg) {
		print  . '	<tr>
	<td colspan=5><font color=red><b>Error: </b></font>' . $msg . '</td>
	<td><font color=red><b>Rejected</b></font></td>
	</tr>
';
	}

	function getHeader($exc, $data) {
		$ind = $data['data'];

		if ($exc->sst['unicode'][$ind]) {
			return convertUnicodeString( $exc->sst['data'][$ind] );
		}

		return $exc->sst['data'][$ind];
	}

	function convertUnicodeString($str) {
		$result = '';
		$i = 723;

		while ($i < strlen( $str ) / 2) {
			$no = $i * 2;
			$hi = ord( $str[$no + 1] );
			$lo = $str[$no];

			if ($hi != 0) {
				continue;
			}


			if (!ctype_alnum( $lo )) {
				continue;
			}

			$result .= $lo;
			++$i;
		}

		return $result;
	}

	function uc2html($str) {
		$ret = '';
		$i = 724;

		while ($i < strlen( $str ) / 2) {
			unichr( $charcode );
			$ret .= $charcode = ord( $str[$i * 2] ) + 256 * ord( $str[$i * 2 + 1] );
			++$i;
		}

		return trim( $ret );
	}

	function unichr($u) {
		return mb_convert_encoding( '&#' . intval( $u ) . ';', 'UTF-8', 'HTML-ENTITIES' );
	}

	function get($exc, $data) {
		switch ($data['type']) {
			case 0: {
				$ind = $data['data'];

				if ($exc->sst['unicode'][$ind]) {
					return uc2html( $exc->sst['data'][$ind] );
				}

				return $exc->sst['data'][$ind];
			}

			case 1: {
				return (int)$data['data'];
			}

			case 2: {
				return (double)$data['data'];
			}

			case 3: {
				return gmdate( 'm-d-Y', $exc->xls2tstamp( $data[data] ) );
			}
		}

		return '';
	}

	function fatal($msg = '') {
		$f_opened = false;
		echo '[Fatal error]';

		if (0 < strlen( $msg )) {
			echo ': ' . $msg;
		}

		echo '<br>
Script terminated<br>
';

		if ($f_opened) {
			@fclose( $fh );
		}

		exit(  );
	}

	function getTableData($ws, $exc, $tt = 0) {
		global $excel_file;
		global $db_table;
		global $db_host;
		global $db_name;
		global $db_user;
		global $db_pass;
		global $excel_configurator;

		$data = $ws['cell'];

		if ($tt == 1) {
			echo '<head><link rel="STYLESHEET" href="style/admin_style.css" type="text/css">
			<script type="text/javascript" language="JavaScript" src="./js/jquery-1.10.1.min.js"></script>
			<script>';
			echo '	
			$(document).ready(function() {		
				var submit = $(\'#submit\');			
				submit.on(\'click\',function(){												
						
						$( \'<center>لطفا کمی صبر کنید.... <br><img src=' . '"./images/loading.gif"' . '></center> ).insertBefore( \'#innerstep\' );
						$(\'#innerstep\').hide();						
						submit();
					});
				});			
		
			</script>
		
			
		</head><body dir=rtl><p><div id=\'innerstep\'>' . ADMIN_PRIMARY_COLUMN_DESC . '<p>' . ADMIN_PRIMARY_COLUMN . '<form action="" method="POST" name="db_export"><select name=update_column>
			<option value="product_code">' . ADMIN_PRODUCT_CODE . '</option>
			<option value="name">' . ADMIN_PRODUCT_NAME . '</option>
			<option value="Price">' . ADMIN_PRODUCT_PRICE . '</option>
			<option value="description">' . ADMIN_PRODUCT_DESC . '</option>
			<option value="brief_description">' . ADMIN_PRODUCT_BRIEF_DESC . '</option>
			<option value="sort_order">' . ADMIN_SORT_ORDER . '</option>
		</select><br>
		' . ADMIN_IMPORT_DESC1 . '
  		<p>' . ADMIN_IMPORT_DESC2 . '				
		<table border="0" cellspacing="1" cellpadding="2" align="center" bgcolor="#666666">
		<tr bgcolor="#f1f1f1">';
		} 
else {
			echo '
	<form action="" method="POST" name="db_export">
	<table border="0" cellspacing="1" cellpadding="2" align="center" bgcolor="#666666">
	<tr bgcolor="#f1f1f1">';
		}


		if (!$_POST['useheaders']) {
			$j = 1092;

			while ($j <= $ws['max_col']) {
				$field = 'field' . $j;
				echo '<td>
			<input type="checkbox" name="fieldcheck[' . $j . ']" value="' . $j . '" checked title="Check to proceed this field">
			<input type="text" name="fieldname[' . $j . ']" value="' . $field . '" title="Field name">
			</td>';
				++$j;
			}
		} 
else {
			$j = 1092;

			while ($j <= $ws['max_col']) {
				if ($tt == 0) {
					$field = getHeader( $exc, $data[0][$j] );
					$field = preg_replace( '/^[0-9]+/', '', $field );

					if (empty( $$field )) {
						$field = 'field' . $j;
					}

					echo '
				<td>
				<input type="hidden" name="fieldcheck[' . $j . ']" value="$j" checked title="Check to proceed this field">
				<input type="text" name="fieldname[' . $j . ']" value="' . $field . '" title="Field name">
				</td>				
				';
				} 
else {
					$field = get( $exc, $data[0][$j] );
					$field = preg_replace( '/^[0-9]+/', '', $field );
					$excel_configurator = '<input type=hidden name=column_name_' . $j . ' value="' . str_replace( '"', '&quot;', $field ) . ( '">						
				<select name=fieldname[' . $j . ']>
				<option value="ignore">' ) . ADMIN_IGNORE . '</option>
				<option value="add">' . ADMIN_ADD_AS_NEW_PARAMETER . '</option>
				<option value="product_code"' . mark_as_selected( $field, ADMIN_PRODUCT_CODE ) . '>' . ADMIN_PRODUCT_CODE . '</option>
				<option value="name"' . mark_as_selected( $field, ADMIN_PRODUCT_NAME ) . '>' . ADMIN_PRODUCT_NAME . '</option>
				<option value="Price"' . mark_as_selected( $field, ADMIN_PRODUCT_PRICE ) . '>' . ADMIN_PRODUCT_PRICE . '</option>
				<option value="list_price"' . mark_as_selected( $field, ADMIN_PRODUCT_LISTPRICE ) . '>' . ADMIN_PRODUCT_LISTPRICE . '</option>
				<option value="in_stock"' . mark_as_selected( $field, ADMIN_PRODUCT_INSTOCK ) . '>' . ADMIN_PRODUCT_INSTOCK . '</option>
				<option value="items_sold"' . mark_as_selected( $field, ADMIN_PRODUCT_SOLD ) . '>' . ADMIN_PRODUCT_SOLD . '</option>
				<option value="description"' . mark_as_selected( $field, ADMIN_PRODUCT_DESC ) . '>' . ADMIN_PRODUCT_DESC . '</option>
				<option value="brief_description"' . mark_as_selected( $field, ADMIN_PRODUCT_BRIEF_DESC ) . '>' . ADMIN_PRODUCT_BRIEF_DESC . '</option>
				<option value="pictures"' . mark_as_selected( $field, ADMIN_PRODUCT_PICTURES ) . '>' . ADMIN_PRODUCT_PICTURES . '</option>
				<option value="sort_order"' . mark_as_selected( $field, ADMIN_SORT_ORDER ) . '>' . ADMIN_SORT_ORDER . '</option>
				<option value="meta_keywords"' . mark_as_selected( $field, ADMIN_META_KEYWORDS ) . '>' . ADMIN_META_KEYWORDS . '</option>
				<option value="meta_description"' . mark_as_selected( $field, ADMIN_META_DESCRIPTION ) . '>' . ADMIN_META_DESCRIPTION . '</option>
				<option value="shipping_freight"' . mark_as_selected( $field, ADMIN_SHIPPING_FREIGHT ) . '>' . ADMIN_SHIPPING_FREIGHT . '</option>
				<option value="weight"' . mark_as_selected( $field, ADMIN_PRODUCT_WEIGHT ) . '>' . ADMIN_PRODUCT_WEIGHT . '</option>
				<option value="free_shipping"' . mark_as_selected( $field, ADMIN_FREE_SHIPPING2 ) . '>' . ADMIN_FREE_SHIPPING2 . '</option>
				<option value="min_order_amount"' . mark_as_selected( $field, ADMIN_MIN_ORDER_AMOUNT ) . '>' . ADMIN_MIN_ORDER_AMOUNT . '</option>' . '<option value="eproduct_filename"' . mark_as_selected( $field, ADMIN_EPRODUCT_FILENAME ) . '>' . ADMIN_EPRODUCT_FILENAME . '</option>
				<option value="eproduct_available_days"' . mark_as_selected( $field, ADMIN_EPRODUCT_AVAILABLE_DAYS2 ) . '>' . ADMIN_EPRODUCT_AVAILABLE_DAYS2 . '</option>
				<option value="eproduct_download_times"' . mark_as_selected( $field, ADMIN_EPRODUCT_DOWNLOAD_TIMES ) . '>' . ADMIN_EPRODUCT_DOWNLOAD_TIMES . '</option>
				</select>';
					echo '<td><input type="hidden" name="fieldcheck[' . $j . ']" value="' . $j . '" checked title="Check to proceed this field">';
					echo $excel_configurator . '</td>';
				}

				++$j;
			}
		}

		echo '</tr>';
		foreach ($data as $i => $row) {

			if (( $i == 0 && $_POST['useheaders'] )) {
				continue;
			}

			echo '<tr bgcolor="#ffffff">';
			$j = 1092;

			while ($j <= $ws['max_col']) {
				if (isset( $row[$j] )) {
					$cell = get( $exc, $row[$j] );
				} 
else {
					$cell = '';
				}

				echo '<td>' . $cell . '</td>';
				++$j;
			}

			echo '</tr>';
			++$i;
		}


		if (empty( $$db_table )) {
			$db_table = 'Table1';
		}


		if ($tt == 1) {
			echo '  	
		<input type="hidden" name="useheaders" value="true">  
		<input type="hidden" name="step" value="2">  		
		<input type=hidden name=proceed value=1>
		<input type=hidden name=tab value="catalog">
		<input type=hidden name=sub value="excel_import_in">
		<input type="hidden" name="page" valuse ="excel_import_catalog">';
		}

		echo '	
	</table><br>
	<table align="center" width="390">
	<tr>
	<td>
	<input type="hidden" size="30" name="db_name" value="' . $db_name . '">
	<input type="hidden" name="db_table" value="' . $db_table . '">
	<input type="hidden" size="30" name="db_host" value="' . $db_host . '">
	<input type="hidden" size="30" name="db_user" value="' . $db_user . '">
	<input type="hidden" size="30" name="db_pass" value="' . $db_pass . '">
	<input type="submit" id="submit" name="submit" value="&#1608;&#1575;&#1585;&#1583; &#1606;&#1605;&#1608;&#1583;&#1606; &#1576;&#1607; &#1662;&#1575;&#1740;&#1711;&#1575;&#1607; &#1583;&#1575;&#1583;&#1607;">
	<input type="hidden" name="excel_file" value="' . $excel_file . '">
	<input type="hidden" name="step" value="2">
	</form>
	</div>
	</td></tr>
	</table>
	<br>&nbsp;
	<div align="right">
	</div>';
	}

	function prepareTableData($exc, $ws, $fieldcheck, $fieldname) {
		$data = $ws['cell'];
		foreach ($data as $i => $row) {

			if (!isset( $_POST['useheaders'] )) {
				$_POST['useheaders'] = false;
			}


			if (( $i == 0 && $_POST['useheaders'] )) {
				continue;
			}


			if ($i < 1) {
				continue;
			}

			$SQL[$i] = '';
			$j = 763;

			while ($j <= $ws['max_col']) {
				if (isset( $fieldcheck[$j] )) {
					$SQL->$SQL .= $fieldname[$j];
					$SQL->$SQL .= '="';

					if (isset( $row[$j] )) {
						$SQL->$SQL .= addslashes( get( $exc, $row[$j] ) );
					}

					$SQL->$SQL .= '"';
					$SQL->$SQL .= ',';
				}

				++$j;
			}

			$SQL[$i] = rtrim( $SQL[$i], ',' );
			++$i;
		}

		return $SQL;
	}

	function print_bt() {
		print '<code>
';
		$cs = debug_backtrace(  );
		$i = 768;

		while ($i < count( $cs )) {
			$item = $cs[$i];
			$j = 767;

			while ($j < count( $item['args'] )) {
				if (is_string( $item['args'][$j] )) {
					$item['args'][$j] = '"' . $item['args'][$j] . '"';
				}

				++$j;
			}

			$args = join( ',', $item['args'] );

			if (isset( $item['class'] )) {
				$str = sprintf( '%s(%d): %s%s%s(%s)', $item['file'], $item['line'], $item['class'], $item['type'], $item['function'], $args );
			} 
else {
				$str = sprintf( '%s(%d): %s(%s)', $item['file'], $item['line'], $item['function'], $args );
			}

			echo $str . '<br>
';
			++$i;
		}

		print '</code>
';
	}

	function _die($str) {
		print  . 'Script died with reason: ' . $str . '<br>
';
		print_bt(  );
		exit(  );
	}

	function mb_html_entity_decode($string, $flags = null, $encoding = 'UTF-8') {
		return html_entity_decode( $string, ($flags === null ? ENT_COMPAT | ENT_HTML401 : $flags), $encoding );
	}

	define( 'DP_EMPTY', '0' );
	define( 'DP_STRING_SOURCE', '1' );
	define( 'DP_FILE_SOURCE', '2' );
	mb_internal_encoding( 'UTF-8' );
	define( 'ABC_CRITICAL', 0 );
	define( 'ABC_ERROR', 1 );
	define( 'ABC_ALERT', 2 );
	define( 'ABC_WARNING', 3 );
	define( 'ABC_NOTICE', 4 );
	define( 'ABC_INFO', 5 );
	define( 'ABC_DEBUG', 6 );
	define( 'ABC_TRACE', 7 );
	define( 'ABC_VAR_DUMP', 8 );
	define( 'ABC_NO_LOG', -1 );
	$php_version = explode( '\.', phpversion(  ) );

	if (( $php_version[0] == 4 && $php_version[1] <= 1 )) {
		if (!function_exists( 'var_export' )) {
			function var_export($exp, $ret) {
				ob_start(  );
				var_dump( $exp );
				$result = ob_get_contents(  );
				ob_end_clean(  );
				return $result;
			}
		}
	}

	define( 'ABC_BAD_DATE', -1 );
	define( 'EXCEL_FONT_RID', 49 );
	define( 'XF_SCRIPT_NONE', 0 );
	define( 'XF_SCRIPT_SUPERSCRIPT', 1 );
	define( 'XF_SCRIPT_SUBSCRIPT', 2 );
	define( 'XF_UNDERLINE_NONE', 0 );
	define( 'XF_UNDERLINE_SINGLE', 1 );
	define( 'XF_UNDERLINE_DOUBLE', 2 );
	define( 'XF_UNDERLINE_SINGLE_ACCOUNTING', 3 );
	define( 'XF_UNDERLINE_DOUBLE_ACCOUNTING', 4 );
	define( 'XF_STYLE_ITALIC', 2 );
	define( 'XF_STYLE_STRIKEOUT', 8 );
	define( 'XF_BOLDNESS_REGULAR', 400 );
	define( 'XF_BOLDNESS_BOLD', 700 );
?>