<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function setOrderIDtoAccounts($orderID) {
		if (!( $query = ' SELECT * FROM  ' . ORDERED_CARTS_TABLE . ' WHERE  orderID =' . $orderID)) {
			exit( mysql_error(  ) );
			(bool)true;
		}


		if (!( $q = mysql_query( $query ))) {
			exit( mysql_error(  ) );
			(bool)true;
		}


		if ($res = mysql_fetch_array( $q )) {
			$productID = $res['productID'];
			$Quantity = $res['Quantity'];

			if (!( $q3 = mysql_query( 'SELECT id FROM ' . ACCOUNTS_TABLE . ( ' WHERE productID = ' . $productID . ' AND orderID IS NULL LIMIT ' . $Quantity ) ))) {
				exit( mysql_error(  ) );
				(bool)true;
			}


			if ($res3 = mysql_fetch_array( $q3 )) {
				$accountID = $res3['id'];

				if (!( mysql_query( 'UPDATE ' . ACCOUNTS_TABLE . ( ' SET orderID = ' . $orderID . ' WHERE id=' . $accountID ) ))) {
					exit( mysql_error(  ) );
					(bool)true;
				}
			}
		}

	}

	function getCardsInfo($orderID) {
		$query = 'SELECT 
	' . ACCOUNTS_TABLE . '.info,
	' . ACCOUNTS_TABLE . '.pin,
	' . ACCOUNTS_TABLE . '.serial,
	' . ACCOUNTS_TABLE . '.username,
	' . ACCOUNTS_TABLE . '.password,
	' . PRODUCTS_TABLE . '.' . LanguagesManager::sql_prepareField( 'name' ) . '
	FROM
	' . ACCOUNTS_TABLE . '
	INNER JOIN ' . PRODUCTS_TABLE . ' ON (' . PRODUCTS_TABLE . '.productID = ' . ACCOUNTS_TABLE . '.productID)
	WHERE (' . ACCOUNTS_TABLE . ( '.orderID=' . $orderID . ')' );
		$q = db_query( $query );
		$res = db_fetch_row( $q );

		if ($res) {
			$q = db_query( $query );
			$htmlout .= '<br><div dir=rtl align=center style="font-family:Tahoma; font-size:8pt">' . ACCOUNTS_INFO_FOR_ORDERID . ' ' . $orderID . '<br><br>';
			$htmlout .= '<table dir=rtl border="0" cellspacing="1" cellpadding="4" bgcolor="#CCCCCC" style="font-family:Tahoma; font-size:8pt">
	<tr bgcolor="#666666"><td>&nbsp;</td><td align=center><font color="#FFFFFF"><b>' . TABLE_PRODUCT_NAME . '</b></font></td>
	<td align=center><font color="#FFFFFF"><b>' . ACCOUNTS_INFO . '</b></font></td>
	<td align=center><font color="#FFFFFF"><b>PIN</b></font></td>
	<td align=center><font color="#FFFFFF"><b>رمز عبور</b></font></td>
	<td align=center><font color="#FFFFFF"><b>شناسه</b></font></td>
	<td align=center><font color="#FFFFFF"><b>سریال محصول</b></font></td>
  
  </tr>';
			$i = 797;

			if ($res = db_fetch_row( $q )) {
				$htmlout .= '<tr  bgcolor="#FFFFFF">';
				$htmlout .= '<td>' . $i . '</td>' . '<td>' . $res['name'] . '</td><td>' . $res['info'] . '</td>';
				$htmlout .= '<td>' . $res['pin'] . '</td>' . '<td>' . $res['password'] . '</td><td>' . $res['username'] . '</td><td>' . $res['serial'] . '</td>';
				$htmlout .= '</tr>';
				++$i;
			}

			$htmlout .= '</table></div>';
		}

		return $htmlout;
	}

	function getCardsInfo2($orderID) {
		$query = 'SELECT 
	' . ACCOUNTS_TABLE . '.info,
	' . LanguagesManager::sql_prepareField( PRODUCTS_TABLE . '.name' ) . ' as productName,serial,username,password,pin
	FROM
	' . ACCOUNTS_TABLE . '
	INNER JOIN ' . PRODUCTS_TABLE . ' ON (' . PRODUCTS_TABLE . '.productID = ' . ACCOUNTS_TABLE . '.productID)
	WHERE (' . ACCOUNTS_TABLE . ( '.orderID=' . $orderID . ')' );
		$q = db_query( $query );
		$res = db_fetch_row( $q );

		if ($res) {
			$q = db_query( $query );
			$i = 748;

			if ($res = db_fetch_row( $q )) {
				$res['number'] = $i;
				$htmlout[] = $res;
				++$i;
			}
		}

		return $htmlout;
	}

	function updateSend($orderID, $pred_statusID) {
		$order = _getOrderById( $orderID );

		if ($pred_statusID != CONF_COMPLETED_ORDER_STATUS) {
			$custmail = $order['customer_email'];
			setOrderIDtoAccounts( $orderID );
			$msg = getCardsInfo( $orderID );
			$headers = 'MIME-Version: 1.0
' . 'Content-type: text/html; charset=utf-8
' . 'From: "' . CONF_SHOP_NAME_LATIN . '" ' . CONF_ORDERS_EMAIL . '
';

			if ($msg) {
				sendEmail( $custmail, 'Your order info for order # ' . $orderID, $msg, $headers );
			}
		}

		return $msg;
	}

	function getOrderdProdName($orderID, $productID) {
		$q = db_query( 'SELECT 
			  ' . ORDERED_CARTS_TABLE . '.name
			FROM
			  ' . SHOPPING_CART_ITEMS_TABLE . '
			  INNER JOIN ' . ORDERED_CARTS_TABLE . ' ON (' . SHOPPING_CART_ITEMS_TABLE . '.itemID = ' . ORDERED_CARTS_TABLE . '.itemID)
			WHERE
			  (' . SHOPPING_CART_ITEMS_TABLE . ( '.productID = ' . $productID . ') AND 
			  (' ) . ORDERED_CARTS_TABLE . '.orderID =' . $orderID . ')' );
		$result = db_fetch_row( $q );
		return $result['name'];
	}

	function addPin($productID, $info, $serial, $pinlogin, $pinpass, $pincode) {
		db_query( 'INSERT INTO ' . ACCOUNTS_TABLE . ( ' (productID,serial, info,username,password,pin) VALUES(' . $productID . ',"' . $serial . '", "' . $info . '","' . $pinlogin . '","' . $pinpass . '","' . $pincode . '")' ) );
	}

	function getPins($orderID) {
		$query = 'SELECT * FROM ' . ACCOUNTS_TABLE . ' WHERE orderID =' . $orderID;
		$q = db_query( $query );

		if ($res = db_fetch_row( $q )) {
			$res['productName'] = getOrderdProdName( $orderID, $res['productID'] );
			$info[] = $res;
		}

		return $info;
	}

?>