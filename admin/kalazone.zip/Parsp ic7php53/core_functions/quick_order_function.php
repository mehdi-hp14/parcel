<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

		$phone = function quickOrderContactInfoVerify() {;
		$_POST['first_name'];
		$first_name = $_POST['phone'];

		if (trim( $first_name ) == '') {
			return ERROR_INPUT_NAME;
		}

		$last_name = $_POST['last_name'];

		if (trim( $last_name ) == '') {
			return ERROR_INPUT_NAME;
		}

		$Email = $_POST['email'];

		if (trim( $Email ) == '') {
			return ERROR_INPUT_EMAIL;
		}


		if (!preg_match( '/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i', $Email )) {
			return ERROR_INPUT_EMAIL;
		}


		if (isset( $_POST['affiliationLogin'] )) {
			if (( !regIsRegister( $_POST['affiliationLogin'] ) && $_POST['affiliationLogin'] )) {
				return ERROR_WRONG_AFFILIATION;
			}
		}

		foreach ($_POST as $key => $val) {

			if (strstr( $key, 'additional_field_' )) {
				$id = (int)str_replace( 'additional_field_', '', $key );

				if (( GetIsRequiredRegField( $id ) && strlen( trim( $val ) ) == 0 )) {
					return FEEDBACK_ERROR_FILL_IN_FORM;
				}

				continue;
			}
		}

		return '';
	}

	function quickOrderReceiverAddressVerify() {
		$receiver_first_name = $_POST['receiver_first_name'];
		$_POST['receiver_last_name'];
		$countryID = $_POST['countryID'];

		if (isset( $_POST['state'] )) {
			$state = $_POST['state'];
		} 
else {
			$state = '';
		}

		$zip = $_POST['zip'];
		$city = $_POST['city'];
		$cityID = $_POST['cityID'];
		$address = $_POST['address'];
		$phone = $_POST['phone'];
		$mobile = $_POST['mobile'];

		if (isset( $_POST['zoneID'] )) {
			$zoneID = $_POST['zoneID'];
		} 
else {
			$zoneID = 748;
		}

		$error = $receiver_last_name = regVerifyAddress( $receiver_first_name, $receiver_last_name, $countryID, $zoneID, $state, $zip, $city, $cityID, $address, $phone, $mobile );
		return $error;
	}

	function quickOrderBillingAddressVerify() {
		if (isset( $_POST['billing_address_check'] )) {
			return quickOrderReceiverAddressVerify(  );
		}

		$billingCountryID = $payer_last_name = $payer_first_name = ;

		if (isset( $_POST['billingState'] )) {
			$billingState = $_POST['billingState'];
		} 
else {
			$billingState = '';
		}

		$billingZip = $_POST['billingZip'];
		$_POST['billingCity'];
		$billingCity = $_POST['payer_first_name'];
		$_POST['billingCityID'];
		$billingCityID = $_POST['payer_last_name'];
		$_POST['billingAddress'];
		$billingAddress = $_POST['billingCountryID'];

		if (isset( $_POST['billingZoneID'] )) {
			$billingZoneID = $_POST['billingZoneID'];
		} 
else {
			$billingZoneID = 745;
		}

		$error = regVerifyAddress( $payer_first_name, $payer_last_name, $billingCountryID, $billingZoneID, $billingState, $billingZip, $billingCity, $billingCityID, $billingAddress );
		return $error;
	}

	function quikOrderSetCustomerInfo() {
		$_SESSION['first_name'] = $_POST['first_name'];
		$_SESSION['last_name'] = $_POST['last_name'];
		$_SESSION['email'] = $_POST['email'];
		$_SESSION['affiliationLogin'] = $_POST['affiliationLogin'];
		$_SESSION['phone'] = $_POST['phone'];
		$_SESSION['mobile'] = $_POST['mobile'];
		foreach ($_POST as $key => $val) {

			if (( strstr( $key, 'additional_field_' ) && 0 < strlen( trim( $val ) ) )) {
				$_SESSION[$key] = $val;
				continue;
			}
		}

	}

	function quickOrderSetReceiverAddress() {
		$_SESSION['receiver_first_name'] = $_POST['receiver_first_name'];
		$_SESSION['receiver_last_name'] = $_POST['receiver_last_name'];
		$_SESSION['receiver_countryID'] = $_POST['countryID'];
		$_SESSION['receiver_state'] = $_POST['state'];
		$_SESSION['receiver_zoneID'] = $_POST['zoneID'];
		$_SESSION['receiver_zip'] = $_POST['zip'];

		if (isset( $_POST['cityID'] )) {
			$_POST['city'] = ctGetSingleCityById( $_POST['cityID'] );
			$_POST['city'] = $_POST['city']['city_name_' . LanguagesManager::getDefaultLanguage(  )->iso2];
		}

		$_SESSION['receiver_cityID'] = $_POST['cityID'];
		$_SESSION['receiver_city'] = $_POST['city'];
		$_SESSION['receiver_address'] = $_POST['address'];
		$_SESSION['phone'] = $_POST['phone'];
		$_SESSION['mobile'] = $_POST['mobile'];
	}

	function quickOrderSetBillingAddress() {
		if (!isset( $_POST['billing_address_check'] )) {
			$_SESSION['billing_first_name'] = $_POST['payer_first_name'];
			$_SESSION['billing_last_name'] = $_POST['payer_last_name'];
			$_SESSION['billing_countryID'] = $_POST['billingCountryID'];
			$_SESSION['billing_state'] = $_POST['billingState'];

			if (isset( $_POST['billingCityID'] )) {
				$_POST['billingCity'] = ctGetSingleCityById( $_POST['billingCityID'] );
				$_POST['billingCity'] = $_POST['city']['city_name_' . LanguagesManager::getDefaultLanguage(  )->iso2];
			}

			$_SESSION['billing_city'] = $_POST['billingCity'];
			$_SESSION['billing_zoneID'] = $_POST['billingZoneID'];
			$_SESSION['billing_zip'] = $_POST['billingZip'];
			$_SESSION['billing_address'] = $_POST['billingAddress'];
			return null;
		}

		$_SESSION['billing_first_name'] = $_POST['receiver_first_name'];
		$_SESSION['billing_last_name'] = $_POST['receiver_last_name'];
		$_SESSION['billing_countryID'] = $_POST['countryID'];
		$_SESSION['billing_state'] = $_POST['state'];
		$_SESSION['billing_zoneID'] = $_POST['zoneID'];
		$_SESSION['billing_zip'] = $_POST['zip'];
		$_SESSION['billing_city'] = $_POST['city'];
		$_SESSION['billing_address'] = $_POST['address'];
	}

	function quickOrderGetReceiverAddressStr() {
		if (( !isset( $_SESSION['receiver_countryID'] ) || !isset( $_SESSION['receiver_first_name'] ) )) {
			return '';
		}

		$country = cnGetCountryById( $_SESSION['receiver_countryID'] );
		$country = $country['country_name'];

		if (trim( $_SESSION['receiver_state'] ) == '') {
			$zone = znGetSingleZoneById( $_SESSION['receiver_zoneID'] );
			$zone = $zone['zone_name'];
		} 
else {
			$zone = trim( $_SESSION['receiver_state'] );
		}

		$strAddress = xHtmlSpecialChars( $_SESSION['receiver_first_name'] ) . ' ' . xHtmlSpecialChars( $_SESSION['receiver_last_name'] );

		if (0 < strlen( $_SESSION['receiver_address'] )) {
			$strAddress .= '<br>' . xHtmlSpecialChars( $_SESSION['receiver_address'] );
		}


		if (0 < strlen( $_SESSION['receiver_city'] )) {
			$strAddress .= '<br>' . xHtmlSpecialChars( $_SESSION['receiver_city'] );
		}


		if (0 < strlen( $zone )) {
			$strAddress .= ' ' . xHtmlSpecialChars( $zone );
		}


		if (0 < strlen( $_SESSION['receiver_zip'] )) {
			$strAddress .= ' ' . xHtmlSpecialChars( $_SESSION['receiver_zip'] );
		}


		if (0 < strlen( $country )) {
			$strAddress .= '<br>' . $country;
		}

		return $strAddress;
	}

	function quickOrderGetBillingAddressStr() {
		if (( !isset( $_SESSION['billing_countryID'] ) || !isset( $_SESSION['billing_first_name'] ) )) {
			return '';
		}

		$country = cnGetCountryById( $_SESSION['billing_countryID'] );
		$country = $country['country_name'];

		if (trim( $_SESSION['billing_state'] ) == '') {
			$zone = znGetSingleZoneById( $_SESSION['billing_zoneID'] );
			$zone = $zone['zone_name'];
		} 
else {
			$zone = trim( $_SESSION['billing_state'] );
		}

		$strAddress = xHtmlSpecialChars( $_SESSION['billing_first_name'] ) . ' ' . xHtmlSpecialChars( $_SESSION['billing_last_name'] );

		if (0 < strlen( $_SESSION['billing_address'] )) {
			$strAddress .= '<br>' . xHtmlSpecialChars( $_SESSION['billing_address'] );
		}


		if (0 < strlen( $_SESSION['billing_city'] )) {
			$strAddress .= '<br>' . xHtmlSpecialChars( $_SESSION['billing_city'] );
		}


		if (0 < strlen( $zone )) {
			$strAddress .= ' ' . xHtmlSpecialChars( $zone );
		}


		if (0 < strlen( $_SESSION['billing_zip'] )) {
			$strAddress .= ' ' . xHtmlSpecialChars( $_SESSION['billing_zip'] );
		}


		if (0 < strlen( $country )) {
			$strAddress .= '<br>' . $country;
		}

		$strAddress .= '<br>' . $_SESSION['phone'] . '-' . $_SESSION['mobile'];
		return $strAddress;
	}

?>