<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function ctGetCityByName($zoneID, $city_name) {
		$city = db_phquery_fetch( DBRFETCH_ASSOC, 'SELECT * FROM ?#CITY_TABLE WHERE zoneID=? AND city_name_fa=?', $zoneID, $city_name );
		LanguagesManager::ml_fillFields( CITY_TABLE, $city );
		return $city;
	}

	function CityBelongsToCountry($cityID, $countryiso2) {
		$q = db_query( 'select count(*) from ' . CITY_TABLE . ( ' where country_iso_2=\'' . $countryiso2 . '\'' ) );
		$row = db_fetch_row( $q );

		if ($row[0] != 0) {
			if (trim( $cityID ) == (bool)(int)$cityID) {
				$q = db_query( 'select count(*) from ' . CITY_TABLE . ( ' where country_iso_2=\'' . $countryiso2 . '\' AND cityID=' . $cityID ) );
				$row = db_fetch_row( $q );
				return $row[0] != 0;
			}

			return false;
		}

		return true;
	}

	function ctGetCitys($countryiso2 = null, $zone_code = null) {
		static $citys = array(  );
		static $inited = false;

		$data = array(  );

		if ($countryiso2) {
			if (!isset( $citys[$countryiso2] )) {
				$sql = 'SELECT *, ' . LanguagesManager::sql_prepareField( 'city_name' ) . ' AS city_name FROM ?#CITY_TABLE WHERE country_iso_2="?" and zoneID=?';
				$q = db_phquery( $sql, $countryiso2, $zone_code );

				if ($row = db_fetch_assoc( $q )) {
					LanguagesManager::ml_fillFields( CITY_TABLE, $row );

					if (isset( $citys[$row['zone_code']] )) {
						if (!is_array( $citys[$row['zone_code']] )) {
							$citys[$row['zone_code']] = array(  );
						}
					}

					$citys[$row['zone_code']][] = $row;
				}
			}


			if (isset( $citys[$zone_code] )) {
				$data = $citys[$zone_code];
			} 
else {
				$data = array(  );
			}
		} 
else {
			if (!$inited) {
				$sql = 'SELECT *, ' . LanguagesManager::sql_prepareField( 'city_name' ) . ' AS city_name FROM ?#CITY_TABLE where country_iso_2=\'?\' ORDER BY city_name';
				$q = db_phquery( $sql, $countryiso2 );

				if ($row = db_fetch_assoc( $q )) {
					LanguagesManager::ml_fillFields( CITY_TABLE, $row );

					if (!is_array( $citys[$row['zone_code']] )) {
						$citys[$row['zone_code']] = array(  );
					}

					$citys[$row['zone_code']][] = $row;
				}

				$inited = true;
			}

			foreach ($citys as $city) {
				$data += $q;
			}
		}

		return $data;
	}

	function ctGetCitysById($countryiso2, $zoneID) {
		if (( ( ( is_null( $countryiso2 ) || $countryiso2 == '' ) || is_null( $zoneID ) ) || $zoneID == '' )) {
			$countryiso2 = 'NULL';
		}

		return db_phquery_fetch( DBRFETCH_ROW_ALL, 'SELECT *, ' . LanguagesManager::sql_prepareField( 'city_name' ) . ' AS city_name FROM ?#CITY_TABLE WHERE country_iso_2=? and zoneID=? ORDER BY city_name', $countryiso2, $zoneID );
	}

	function ctGetCitysByZoneId($zoneID) {
		if (( is_null( $zoneID ) || $zoneID == '' )) {
			$zoneID = 'NULL';
		}

		return db_phquery_fetch( DBRFETCH_ROW_ALL, 'SELECT *, ' . LanguagesManager::sql_prepareField( 'city_name' ) . ' AS city_name FROM ?#CITY_TABLE WHERE zoneID=? ORDER BY city_name', $zoneID );
	}

	function ctGetSingleCityById($cityID) {
		if (( is_null( $cityID ) || $cityID == '' )) {
			$cityID = 'NULL';
		}

		$city = db_phquery_fetch( DBRFETCH_ROW, 'SELECT *, ' . LanguagesManager::sql_prepareField( 'city_name' ) . ' AS city_name FROM ?#CITY_TABLE WHERE cityID=?', $cityID );
		LanguagesManager::ml_fillFields( CITY_TABLE, $city );
		return $city;
	}

	function ctDeleteCity($cityID) {
		$tax_classes = taxGetTaxClasses(  );
		db_query( 'update ' . CUSTOMER_ADDRESSES_TABLE . ' set cityID=NULL where cityID=\'' . $cityID . '\'' );
		db_query( 'delete from ' . CITY_TABLE . ' where cityID=\'' . $cityID . '\'' );
	}

	function ctUpdateCity($cityID, $cityval, $countryiso2, $zoneID, $zone_code) {
		$sql = '
		UPDATE ?#CITY_TABLE SET ' . LanguagesManager::sql_prepareFieldUpdate( 'city_name', $cityval ) . ',city_code=?,city_codeim=?,zone_code=?,zoneID=? WHERE cityID=? and country_iso_2=?';
		db_phquery( $sql, $cityval['city_code'], $cityval['city_codeim'], $zone_code, $zoneID, $cityID, $countryiso2 );
	}

	function ctAddCity($city_name, $countryiso2, $zoneID, $zone_code) {
		$name_inj = LanguagesManager::sql_prepareFieldInsert( 'city_name', $city_name );
		$sql = 'INSERT ?#CITY_TABLE (' . $name_inj['fields'] . ', city_code,city_codeim, country_iso_2,zoneID,zone_code) 
  VALUES(' . $name_inj['values'] . ',?,?,?,?,?)';
		db_phquery( $sql, $city_name['city_code'], $city_name['city_codeim'], $countryiso2, $zoneID, $zone_code );
		return db_insert_id(  );
	}

?>