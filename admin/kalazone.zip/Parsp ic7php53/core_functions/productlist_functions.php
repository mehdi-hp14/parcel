<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function productlistadd($prdl) {
		$res = productlist_checkInfo( $prdl );

		if ($res) {
			return $res;
		}

		$res = loadproductlistById( $prdl['list_id'] );

		if ($res) {
			return ADMIN_PRODUCTLIST_CODE_EXIST;
		}

		db_query( 'insert into ' . TBL_PRODUCT_LIST . ' ( list_id,list_name,orderbtn,postbtn )  ' . ' values( \'' . $prdl['list_id'] . '\',\'' . $prdl['list_name'] . '\',\'' . $prdl['orderbtn'] . '\' ,\'' . $prdl['postbtn'] . '\' ) ' );
	}

	function productlistupdate($prdl) {
		$res = productlist_checkInfo( $prdl );

		if ($res) {
			return $res;
		}

		db_query( 'UPDATE ' . TBL_PRODUCT_LIST . ' SET list_name=\'' . $prdl['list_name'] . '\',orderbtn=\'' . $prdl['orderbtn'] . '\',postbtn=\'' . $prdl['postbtn'] . '\'' . ' where list_id=\'' . $prdl['list_id'] . '\'' );
	}

	function productlistdelete($prdid) {
		db_query( 'DELETE FROM ' . TBL_PRODUCT_LIST . ' where list_id=\'' . $prdid . '\'' );
	}

	function stc_deleteProductFromLists($productID) {
		db_phquery( 'DELETE FROM ?#TBL_PRODUCT_LIST_ITEM WHERE productID=?', $productID );
	}

	function stc_getLists() {
		db_query( 'SELECT pl.*, COUNT(pli.list_id) as products_num FROM ' . TBL_PRODUCT_LIST . ' pl LEFT JOIN ' . TBL_PRODUCT_LIST_ITEM . ' pli ON pl.list_id=pli.list_id GROUP BY pl.list_id ORDER BY `list_id` ASC' );

		if ($stres = $dbres = db_fetch_row( $dbres )) {
			$prodct_list[] = $stres;
		}

		return $prodct_list;
	}

		$dbres = function productlist_getlists($productid) {;
		db_fetch_row( $dbres );

		if ($stres = db_query( 'SELECT pl.*, COUNT(pli.list_id) as products_num FROM ' . TBL_PRODUCT_LIST . ' pl LEFT JOIN ' . TBL_PRODUCT_LIST_ITEM . ( ' pli ON pl.list_id=pli.list_id where pli.productID=' . $productid . ' GROUP BY pl.list_id  ORDER BY `list_id` ASC' ) )) {
			$prodct_list[] = $stres['list_name'];
		}

		return $prodct_list;
	}

		$dbres = function productlist_getlistsid($productid) {;
		db_fetch_row( $dbres );

		if ($stres = db_query( 'SELECT pl.*, COUNT(pli.list_id) as products_num FROM ' . TBL_PRODUCT_LIST . ' pl LEFT JOIN ' . TBL_PRODUCT_LIST_ITEM . ( ' pli ON pl.list_id=pli.list_id where pli.productID=' . $productid . ' GROUP BY pl.list_id  ORDER BY `list_id` ASC' ) )) {
			$prodct_list[] = $stres['list_id'];
		}

		return $prodct_list;
	}

	function productlist_checkInfo($prdl) {
		$id = strtolower( $prdl['list_id'] );

		if (!preg_match( '/^[a-z0-9]+$/u', $id )) {
			return ADMIN_STRING_INVALID;
		}

	}

	function delete() {
		$dbq = 'DELETE FROM ?#TBL_PRODUCT_LIST_ITEM WHERE list_id=?';
		db_phquery( $dbq, $this->id );
		parent::delete(  );
	}

	function addProducttolist($productID, $list_id) {
		if (!intval( $productID )) {
			return null;
		}

		$dbq = 'SELECT 1 FROM ?#TBL_PRODUCT_LIST_ITEM WHERE list_id=? AND productID=?';

		if (db_phquery_fetch( DBRFETCH_FIRST, $dbq, $list_id, $productID )) {
			return null;
		}

		$dbq = 'INSERT ?#TBL_PRODUCT_LIST_ITEM (list_id, productID) VALUES(?,?)';
		db_phquery( $dbq, $list_id, $productID );
	}

	function loadproductlistById($id) {
		$dbq = db_query( 'SELECT * FROM ' . TBL_PRODUCT_LIST . ' WHERE list_id=\'' . $id . '\'' );
		return mysql_fetch_assoc( $dbq['resource'] );
	}

	function getProductsbyproductlistid($enabled = null, $list_id) {
		$dbq = '
			SELECT t1.*, t3.thumbnail FROM ?#PRODUCTS_TABLE t1 LEFT JOIN ?#TBL_PRODUCT_LIST_ITEM t2 ON t1.productID=t2.productID
			LEFT JOIN ?#PRODUCT_PICTURES t3 ON t1.default_picture=t3.photoID
			WHERE' . (is_null( $enabled ) ? '' : ' t1.enabled=' . intval( $enabled ) . ' AND t1.categoryID != 1 AND') . ' t2.list_id=? ORDER BY t2.priority ASC
		';
		$dbres = db_phquery( $dbq, $list_id );
		$products = array(  );

		if ($row = db_fetch_assoc( $dbres )) {
			LanguagesManager::ml_fillFields( PRODUCTS_TABLE, $row );

			if (( !$row['thumbnail'] || !file_exists( DIR_PRODUCTS_PICTURES . '/' . $row['thumbnail'] ) )) {
				unset( $row[thumbnail] );
			}

			$row['price_str'] = show_price( $row['Price'] );
			$products[] = $row;
		}

		return $products;
	}

	function deleteProductfromlist($productID, $list_id) {
		db_phquery( 'DELETE FROM ?#TBL_PRODUCT_LIST_ITEM WHERE list_id=? AND productID=?', $list_id, $productID );
	}

?>