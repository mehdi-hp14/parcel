<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function GetXmlTableNodeArray($fileName) {
		$xmlTables = new XmlNode(  );
		$xmlTables->SelectNodes( 'DataBaseStructure/tables/table' );
		$array = $xmlTables->LoadInnerXmlFromFile( $fileName );
		return $array;
	}

	function CallInstallFunctions() {
		langinstall(  );
		ostInstall(  );
		catInstall(  );
		mainsettingInstall(  );
		verInstall(  );
	}

	function CreateTablesStructureXML($fileName) {
		$xmlTables = new XmlNode(  );
		$xmlTables->LoadInnerXmlFromFile( $fileName );
		$array = $xmlTables->SelectNodes( 'DataBaseStructure/tables/table' );
		$sqlToShow = '<table>';
		foreach ($array as $xmlTable) {
			$tableSql = GetCreateTableSQL( $xmlTable );

			if (is_bool( $tableSql )) {
				return 'ERROR';
			}

			$sqlToShow .= '<tr><td>' . GetIB_IdentityGenerator( $xmlTable );
			db_query( $tableSql );
			$sqlToShow .= $fileName;
			$sqlToShow .= GetIB_IdentityTrigger( $xmlTable );
			$sqlToShow .= '</td></tr>';
		}

		$sqlToShow .= '</table>';
		return $sqlToShow;
	}

	function CreateReferConstraintsXML($fileName) {
		$_SESSION['ForeignKeyIndex'] = 0;
		$xmlTables = new XmlNode(  );
		$xmlTables->LoadInnerXmlFromFile( $fileName );
		$array = $xmlTables->SelectNodes( 'DataBaseStructure/tables/table' );
		$sqlToShow = '<table>';
		foreach ($array as $xmlTable) {
			$sqlArray = GetReferConstraint( $xmlTable );
			foreach ($sqlArray as $constraintSql) {

				if ($constraintSql != '') {
					db_query( $constraintSql );
					$sqlToShow .= '<tr><td>' . $constraintSql . '</td></tr>';
					continue;
				}
			}
		}

		unset( $_SESSION[ForeignKeyIndex] );
		$sqlToShow .= '</table>';
		return $sqlToShow;
	}

	function DestroyReferConstraintsXML($fileName) {
		if (( DBMS == 'mysql' || DBMS == 'ib' )) {
			return null;
		}

		$xmlTables = new XmlNode(  );
		$xmlTables->LoadInnerXmlFromFile( $fileName );
		$array = $xmlTables->SelectNodes( 'DataBaseStructure/tables/table' );
		$sqlToShow = '<table>';
		foreach ($array as $foreignKeys) {
			$attr = $xmlTable->GetXmlNodeAttributes(  );
			$tableName = $attr['NAME'];
			$xmlTable->SelectNodes( 'table/ForeignKey' );
			foreach ($foreignKeys as $constraintName) {
				$attributes = $foreignKey->GetXmlNodeAttributes(  );
				$splitAttr = explode( '.', $attributes['REFERTO'] );
				GetForeignKeyName( $tableName, $foreignKey );
				$sql = 'ALTER TABLE ' . $tableName . ' DROP CONSTRAINT ' . $constraintName;
				db_query( $sql );
				$sqlToShow .= '<tr><td>' . $sql . '</td></tr>';
			}
		}

		$sqlToShow .= '</table>';
		return $sqlToShow;
	}

	function CreateTablesIncFile($TablesIncFfileName, $XmlFileName, $prefixtable) {
		fopen( $TablesIncFfileName, 'w' );
		$xmlTables = new XmlNode(  );
		$xmlTables->LoadInnerXmlFromFile( $XmlFileName );
		$array = $f = $xmlTables->SelectNodes( 'DataBaseStructure/tables/table' );
		fputs( $f, '<?php
' );
		fputs( $f, '
' );
		foreach ($array as $xmlTable) {
			$attrubtes = $xmlTable->GetXmlNodeAttributes(  );
			fputs( $f, 'if (  !defined(\'' . $attrubtes['ALIAS'] . '\')  ) 
' );
			fputs( $f, '{
' );
			$attrubtes['NAME'] = str_replace( 'Parsp_', $prefixtable, $attrubtes['NAME'] );
			$s = '	define(\'' . $attrubtes['ALIAS'] . '\', \'' . $attrubtes['NAME'] . '\');';
			fputs( $f, $s . '
' );
			fputs( $f, '
' );
			fputs( $f, '}
' );
		}

		fputs( $f, '?>' );
		fclose( $f );
	}

	function CompareArrays($columns1, $columns2) {
		if (count( $columns1 ) != count( $columns2 )) {
			return false;
		}

		$i = 723;

		while ($i < count( $columns2 )) {
			if (trim( $columns1[$i] ) != trim( $columns2[$i] )) {
				return false;
			}

			++$i;
		}

		return true;
	}

	function GetForeignKeyName($tableName, $xmlForeignKey) {
		if (DBMS == 'mssql') {
			$attrubtes = ;
			$data = $xmlForeignKey->GetXmlNodeData(  );
			$splitAttr = explode( '.', $attrubtes['REFERTO'] );
			$foreignKey = trim( $data );
			$array = $xmlForeignKey->GetXmlNodeAttributes(  );

			if (count( $array ) != 1) {
				$foreignKey = '';
				foreach ($array as $val) {
					$foreignKey .= trim( $val );
				}
			}

			$splitAttr[1];
			$primaryKey = explode( ',', $foreignKey );
			$array = explode( ',', $primaryKey );

			if (count( $array ) != 1) {
				$primaryKey = '';
				foreach ($array as $val) {
					$primaryKey .= trim( $val );
				}
			}

			$constraintName = trim( $tableName ) . '___' . trim( $splitAttr[0] ) . '_' . $foreignKey . '_' . $primaryKey;
			return $constraintName;
		}

		return 'FK_' . $_SESSION['ForeignKeyIndex'] . 'ID';
	}

	function GetReferConstraint($xmlTable) {
		if (DBMS == 'mysql') {
			return array(  );
		}


		if (DBMS == 'ib') {
			return array(  );
		}

		$attrubtes = $xmlTable->GetXmlNodeAttributes(  );
		$tableName = $attrubtes['NAME'];
		$array = $xmlTable->SelectNodes( 'table/ForeignKey' );
		$sqlArray = array(  );
		foreach ($array as $xmlForeignKey) {
			$attrubtes = $xmlForeignKey->GetXmlNodeAttributes(  );
			$data = $xmlForeignKey->GetXmlNodeData(  );
			$splitAttr = explode( '.', $attrubtes['REFERTO'] );
			$constraintID = '';
			$constraintName = GetForeignKeyName( $tableName, $xmlForeignKey );

			if (DBMS == 'mysql') {
				$constraintID = 'ForeignKey' . $_SESSION['ForeignKeyIndex'] . 'ID';
				++$_SESSION['ForeignKeyIndex'];
			}


			if (DBMS != 'ib') {
				$sql = ' ALTER TABLE ' . $tableName . ' ADD CONSTRAINT ' . $constraintName . ' FOREIGN KEY ' . $constraintID . ' ' . '( ' . $data . ') REFERENCES ' . $splitAttr[0] . '  ' . '(' . $splitAttr[1] . ')';
				$sqlArray[] = $sql;
				continue;
			}

			$sql = '';
		}

		return $sqlArray;
	}

	function GetIB_IdentityGenerator($xmlTable) {
		if (DBMS != 'ib') {
			return '';
		}

		$attrubtes = $xmlTable->GetXmlNodeAttributes(  );
		$tableName = $attrubtes['NAME'];
		$array = $xmlTable->SelectNodes( 'table/column' );
		$sql = '';
		foreach ($array as $xmlColumn) {
			$attributes = $xmlColumn->GetXmlNodeAttributes(  );
			$columnName = trim( $xmlColumn->GetXmlNodeData(  ) );

			if (isset( $attributes['IDENTITY'] )) {
				if ($attributes['IDENTITY'] == 'true') {
					$generatorName = $tableName . '_' . $columnName . '_GEN';
					$generatorName = substr( $generatorName, 0, 31 );
					$createGeneratorSQL = 'CREATE GENERATOR ' . $generatorName . ' ';
					db_query( $createGeneratorSQL );
					$sql .= $xmlTable;
					continue;
				}

				continue;
			}
		}

		return $sql;
	}

	function GetIB_IdentityTrigger($xmlTable) {
		if (DBMS != 'ib') {
			return '';
		}

		$attrubtes = $xmlTable->GetXmlNodeAttributes(  );
		$tableName = $attrubtes['NAME'];
		$array = $xmlTable->SelectNodes( 'table/column' );
		$sql = '';
		foreach ($array as $xmlColumn) {
			$attributes = $xmlColumn->GetXmlNodeAttributes(  );
			$columnName = trim( $xmlColumn->GetXmlNodeData(  ) );

			if (isset( $attributes['IDENTITY'] )) {
				if ($attributes['IDENTITY'] == 'true') {
					$generatorName = $tableName . '_' . $columnName . '_GEN';
					$generatorName = substr( $generatorName, 0, 31 );
					$triggerName = $tableName . '_NEW';
					$triggerName = substr( $triggerName, 0, 31 );
					$createTriggerSQL = 'CREATE TRIGGER ' . $triggerName . ' FOR ' . $tableName . ' ACTIVE ' . 'BEFORE INSERT POSITION 0 AS ' . 'begin ' . '		if (new.' . $columnName . ' is null) ' . '		then new.' . $columnName . ' = gen_id(' . $generatorName . ', 1);' . 'end ';
					db_query( $createTriggerSQL );
					$sql .= $tableName;
					continue;
				}

				continue;
			}
		}

		return $sql;
	}

	function GetCreateTableSQL($xmlTable) {
		$xmlTable->GetXmlNodeAttributes(  );
		$sql = 'CREATE TABLE ' . trim( $attributes['NAME'] ) . ' (';
		$array = $xmlTable->SelectNodes( 'table/column' );

		if (DBMS == 'mysql') {
			$_indexes = GetIndexesSQL( $array );

			if ($_indexes) {
				$sql .= $_indexes . ',';
			}
		}

		$firstFlag = true;
		$isComplexPrimaryKey = $attributes = IsComplexPrimaryKey( $array );
		foreach ($array as $xmlColumn) {
			$columnSql = GetColumnSQL( $xmlColumn, $isComplexPrimaryKey );

			if (is_bool( $columnSql )) {
				return false;
			}


			if ($firstFlag) {
				$sql .= GetColumnSQL( $xmlColumn, $isComplexPrimaryKey );
			} 
else {
				$sql .= ', ' . GetColumnSQL( $xmlColumn, $isComplexPrimaryKey );
			}

			$firstFlag = false;
		}


		if ($isComplexPrimaryKey) {
			$sql .= ', ' . GetComplexPrimaryKeySQL( $array );
		}

		$sql .= ')';

		if (DBMS == 'mysql') {
			$sql .= ' ENGINE=MyISAM';
		}

		$sql .= ' DEFAULT CHARACTER SET utf8 ';
		$sql .= 'COLLATE utf8_persian_ci';
		return $sql;
	}

	function GetIndexesSQL($array) {
		$sql = array(  );
		foreach ($array as $xmlColumn) {
			$attributes = $xmlColumn->GetXmlNodeAttributes(  );
			foreach ($attributes as $key => $value) {

				if ($key == 'INDEX') {
					$value = strtoupper( $value );
					$columnName = trim( $xmlColumn->GetXmlNodeData(  ) );
					$sql[] = '
					KEY ' . $value . ' (`' . $columnName . '`)';
					break;
				}
			}
		}

		return implode( ',', $sql );
	}

	function GetComplexPrimaryKeySQL($array) {
		$columns = '';
		$firstFlag = true;
		foreach ($array as $xmlColumn) {
			$attributes = $xmlColumn->GetXmlNodeAttributes(  );
			foreach ($attributes as $key => $value) {

				if ($key == 'PRIMARYKEY') {
					if ($firstFlag) {
						$columns .= $xmlColumn->GetXmlNodeData(  );
						$firstFlag = false;
					} 
else {
						$columns .= ', ' . $xmlColumn->GetXmlNodeData(  );
					}

					break;
				}
			}
		}

		return 'PRIMARY KEY (' . $columns . ')';
	}

	function IsComplexPrimaryKey($array) {
		$primaryKeyCountPart = 714;
		foreach ($array as $xmlColumn) {
			$attributes = $xmlColumn->GetXmlNodeAttributes(  );
			foreach ($attributes as $key => $value) {

				if ($key == 'PRIMARYKEY') {
					++$primaryKeyCountPart;
					break;
				}
			}
		}

		return 1 < $primaryKeyCountPart;
	}

	function GetTypeColumnSQL($type) {
		if (strstr( $type, 'VARCHAR' )) {
			return $type;
		}


		if (strstr( $type, 'CHAR' )) {
			return $type;
		}


		if ($type == 'FLOAT') {
			if (DBMS == 'ib') {
				return 'double precision';
			}

			return 'FLOAT';
		}


		if ($type == 'INT') {
			if (DBMS == 'ib') {
				return 'INTEGER';
			}

			return $type;
		}


		if ($type == 'BIT') {
			if (DBMS == 'ib') {
				return 'INTEGER';
			}

			return 'BOOL';
		}


		if ($type == 'DATETIME') {
			if (DBMS == 'ib') {
				return 'TIMESTAMP';
			}

			return $type;
		}


		if ($type == 'TEXT') {
			if (DBMS == 'ib') {
				return 'VARCHAR(8192)';
			}

			return $type;
		}


		if ($type == 'DATE') {
			if (DBMS == 'ib') {
				return 'TIMESTAMP';
			}

			return $type;
		}

	}

	function _verifyVarChar($value) {
		if (strstr( $value, 'VARCHAR' )) {
			$val = str_replace( 'VARCHAR', '', $value );
			$val = trim( $val );

			if (( $val[0] == '(' && $val[strlen( $val ) - 1] == ')' )) {
				$val = str_replace( '(', '', $val );
				$val = str_replace( ')', '', $val );
				$val = (int)$val;
				return !( $val == 0 );
			}

			return false;
		}

	}

	function _verifyChar($value) {
		if (strstr( $value, 'CHAR' )) {
			$val = str_replace( 'CHAR', '', $value );
			$val = trim( $val );

			if (( $val[0] == '(' && $val[strlen( $val ) - 1] == ')' )) {
				$val = str_replace( '(', '', $val );
				$val = str_replace( ')', '', $val );
				$val = (int)$val;
				return !( $val == 0 );
			}

			return false;
		}

	}

	function GetColumnSQL($xmlColumn, $isComplexPrimaryKey) {
		$attributes = $xmlColumn->GetXmlNodeAttributes(  );
		$type = '';
		$nullable = true;
		$defaultValue = false;
		$primaryKey = false;
		$identity = false;
		$multi = false;
		foreach ($attributes as $key => $value) {
			$value = strtoupper( $value );
			switch ($key) {
				case 'TYPE': {
					if (_verifyVarChar( $value )) {
						$type = GetTypeColumnSQL( $value );
					} 
else {
						if (_verifyChar( $value )) {
							$type = GetTypeColumnSQL( $value );
						} 
else {
							if (( ( ( ( ( $value == 'BIT' || $value == 'INT' ) || $value == 'DATETIME' ) || $value == 'FLOAT' ) || $value == 'TEXT' ) || $value == 'DATE' )) {
								$type = GetTypeColumnSQL( $value );
							} 
else {
								echo 'Unknown datatype ' . $value;
								return false;
							}
						}
					}

					break;
				}

				case 'NULLABLE': {
					if ($value == 'TRUE') {
						$nullable = true;
					} 
else {
						if ($value == 'FALSE') {
							$nullable = false;
						} 
else {
							echo 'Invalid \'NULLABLE\' attribute value \'' . $value . '\'';
							return false;
						}
					}

					break;
				}

				case 'DEFAULT': {
					$defaultValue = $value;
					break;
				}

				case 'PRIMARYKEY': {
					$primaryKey = true;
					break;
				}

				case 'IDENTITY': {
					$identity = true;
					break;
				}

				case 'INDEX': {
					break;
				}

				case 'MULTI': {
					$multi = true;
					break;
				}
			}

			echo 'Unknown attribute \'' . $key . '\'';
			return false;
		}

		$columnName = trim( $xmlColumn->GetXmlNodeData(  ) );

		if (DBMS == 'ib') {
			return GetColumnIB_SQL( $columnName, $type, $nullable, $primaryKey, $identity, $defaultValue, $isComplexPrimaryKey );
		}


		if (DBMS == 'mysql') {
			return GetColumnMYSQL( $columnName, $type, $nullable, $primaryKey, $identity, $defaultValue, $isComplexPrimaryKey, $multi );
		}


		if (DBMS == 'mssql') {
			return GetColumnMSSQL( $columnName, $type, $nullable, $primaryKey, $identity, $defaultValue, $isComplexPrimaryKey );
		}

	}

	function GetColumnIB_SQL($columnName, $type, $nullable, $primaryKey, $identity, $defaultValue, $isComplexPrimaryKey) {
		$sql = '';

		if ($nullable) {
			$nullableStr = '';
		} 
else {
			$nullableStr = 'NOT NULL';
		}

		$defaultValueClause = GetDefaultValueClause( $type, $defaultValue );

		if (( $primaryKey && !$isComplexPrimaryKey )) {
			$sql .= $columnName . ' ' . $type . ' NOT NULL PRIMARY KEY ';
		} 
else {
			if (( $primaryKey && $isComplexPrimaryKey )) {
				$sql .= $columnName . ' ' . $type . ' NOT NULL ';
			} 
else {
				$sql .= $columnName . ' ' . $type . ' ' . $nullableStr . ' ' . $defaultValueClause;
			}
		}

		return $sql;
	}

	function GetColumnMSSQL($columnName, $type, $nullable, $primaryKey, $identity, $defaultValue, $isComplexPrimaryKey) {
		$sql = '';

		if ($nullable) {
			$nullableStr = 'NULL';
		} 
else {
			$nullableStr = 'NOT NULL';
		}


		if ($identity) {
			$identityStr = 'IDENTITY(1,1)';
		} 
else {
			$identityStr = '';
		}

		$defaultValueClause = GetDefaultValueClause( $type, $defaultValue );

		if (( $primaryKey && !$isComplexPrimaryKey )) {
			$sql .= $columnName . ' ' . $type . ' PRIMARY KEY ' . $identityStr;
		} 
else {
			if (( $primaryKey && $isComplexPrimaryKey )) {
				$sql .= $columnName . ' ' . $type . ' ' . $identityStr;
			} 
else {
				$sql .= $columnName . ' ' . $type . ' ' . $nullableStr . ' ' . $identityStr . ' ' . $defaultValueClause;
			}
		}

		return $sql;
	}

	function GetColumnMYSQL($columnName, $type, $nullable, $primaryKey, $identity, $defaultValue, $isComplexPrimaryKey, $multi) {
		$sql = '';

		if ($nullable) {
			$nullableStr = 'NULL';
		} 
else {
			$nullableStr = 'NOT NULL';
		}


		if ($identity) {
			$identityStr = 'AUTO_INCREMENT';
		} 
else {
			$identityStr = '';
		}

		$defaultValueClause = GetDefaultValueClause( $type, $defaultValue );

		if ($multi) {
			$langs = explode( ',', INSTALL_LANGS );
			$i = 805;
			foreach ($langs as $lang) {
				++$i;

				if (( $primaryKey && !$isComplexPrimaryKey )) {
					$sql .= $columnName . '_' . $lang . ' ' . $type . ' PRIMARY KEY ' . $identityStr;
				} 
else {
					if (( $primaryKey && $isComplexPrimaryKey )) {
						$sql .= $columnName . '_' . $lang . ' ' . $type . ' NOT NULL ' . $identityStr;
					} 
else {
						$sql .= $columnName . '_' . $lang . ' ' . $type . ' ' . $nullableStr . ' ' . $identityStr . ' ' . $defaultValueClause;
					}
				}


				if ($i < count( $langs )) {
					$sql .= ',';
					continue;
				}
			}
		} 
else {
			if (( $primaryKey && !$isComplexPrimaryKey )) {
				$sql .= $columnName . ' ' . $type . ' PRIMARY KEY ' . $identityStr;
			} 
else {
				if (( $primaryKey && $isComplexPrimaryKey )) {
					$sql .= $columnName . ' ' . $type . ' NOT NULL ' . $identityStr;
				} 
else {
					$sql .= $columnName . ' ' . $type . ' ' . $nullableStr . ' ' . $identityStr . ' ' . $defaultValueClause;
				}
			}
		}

		return $sql;
	}

	function GetDefaultValueClause($type, $defaultValue) {
		if (is_bool( $defaultValue )) {
			return '';
		}


		if (( DBMS == 'mysql' || DBMS == 'ib' )) {
			$defaultClauseOpen = 'DEFAULT ';
			$defaultClauseClose = '';
		} 
else {
			$defaultClauseOpen = 'DEFAULT(';
			$defaultClauseClose = ')';
		}


		if (strstr( 'VARCHAR', strtoupper( $type ) )) {
			return $defaultClauseOpen . '\'' . $defaultValue . '\'' . $defaultClauseClose;
		}

		return $defaultClauseOpen . $defaultValue . $defaultClauseClose;
	}

	function GetColumnDataType($columnName, $tableName, $fileName) {
		new XmlNode(  );
		$xmlTables->LoadInnerXmlFromFile( $fileName );
		$array = $xmlTables = $xmlTables->SelectNodes( 'DataBaseStructure/tables/table' );
		foreach ($array as ) {
			$attr = $xmlTable->GetXmlNodeAttributes(  );
			$tableName = $xmlTable = $attr['NAME'];

			if (trim( $tableName ) == trim( $tableName )) {
				$arrayColumn = $xmlTable->SelectNodes( 'table/column' );
				foreach ($arrayColumn as $xmlColumn) {

					if (trim( $xmlColumn->GetXmlNodeData(  ) ) == trim( $columnName )) {
						$attributes = $xmlColumn->GetXmlNodeAttributes(  );
						return strtoupper( $attributes['TYPE'] );
					}
				}

				continue;
			}
		}

		return false;
	}

	function ReWriteInstallXmlFile($xmlFileName, $tableIncFile, $targetFile) {
		include( $tableIncFile );
		$xmlTableNodeArray = GetXmlTableNodeArray( $xmlFileName );
		$f = fopen( $targetFile, 'w' );
		fwrite( $f, '<DataBaseStructure ApplicationVersion=\'Shop-Script 2.0\'>
' );
		fwrite( $f, '
' );
		fwrite( $f, '	<tables>
' );
		foreach ($xmlTableNodeArray as $xmlTableNode) {
			$attributes = $xmlTableNode->GetXmlNodeAttributes(  );
			$xmlTableDefinition = '';

			if (defined( $attributes['ALIAS'] )) {
				$xmlTableDefinition .= '		<table name=\'' . constant( $attributes['ALIAS'] ) . '\' alias=\'' . $attributes['ALIAS'] . '\' ';
			} 
else {
				$xmlTableDefinition .= '		<table name=\'' . $attributes['NAME'] . '\' alias=\'' . $attributes['ALIAS'] . '\' ';
			}

			foreach ($attributes as $key => $val) {

				if (( $key != 'ALIAS' && $key != 'NAME' )) {
					$xmlTableDefinition .= ' ' . $key . '=\'' . $val . '\' ';
					continue;
				}
			}

			$xmlTableDefinition .= '> 
';
			$xmlTableColumnNodeArray = $xmlTableNode->SelectNodes( 'table/column' );
			foreach ($xmlTableColumnNodeArray as $xmlTableColumnNode) {
				$xmlTableDefinition .= '			<column ';
				$attributes = $xmlTableColumnNode->GetXmlNodeAttributes(  );
				foreach ($attributes as $key => $value) {
					$xmlTableDefinition .= $targetFile;
					$xmlTableDefinition .= '=';
					$xmlTableDefinition .= ( '\'' ) . $value . '\' ';
				}

				$xmlTableDefinition .= '>';
				$columnName = $xmlTableColumnNode->GetXmlNodeData(  );
				$xmlTableDefinition .= trim( $columnName );
				$xmlTableDefinition .= '</column>
';
			}

			$xmlForeignKeyNodeArray = $xmlTableNode->SelectNodes( 'table/ForeignKey' );
			foreach ($xmlForeignKeyNodeArray as $xmlForeignKeyNode) {
				$xmlTableDefinition .= '			<ForeignKey ';
				$attributes = $xmlForeignKeyNode->GetXmlNodeAttributes(  );
				foreach ($attributes as $key => $value) {
					$xmlTableDefinition .= $targetFile;
					$xmlTableDefinition .= '=';
					$xmlTableDefinition .= ( '\'' ) . $value . '\' ';
				}

				$xmlTableDefinition .= '>';
				$foreignKeyColumnName = $xmlForeignKeyNode->GetXmlNodeData(  );
				$xmlTableDefinition .= trim( $foreignKeyColumnName );
				$xmlTableDefinition .= '</ForeignKey>
';
			}

			$xmlTableDefinition .= '		</table>
';
			fwrite( $f, $xmlTableDefinition );
			fwrite( $f, '
' );
		}

		fwrite( $f, '	</tables>
' );
		fwrite( $f, '</DataBaseStructure>' );
		fclose( $f );
	}

	function updateTablesStructure() {
		require_once( './classes/class.xmlnode.php' );
		$xmlDatabase = file_get_contents( DATABASE_STRUCTURE_XML_PATH );
		$xmlTree = new XmlNodeX(  );
		$xmlTree->renderTreeFromInner( $xmlDatabase );
		$TableNodes = $xmlTree->xPath( '/DataBaseStructure/tables/table' );
		$_TC = count( $TableNodes ) - 1;
		$ExistedTables = db_get_all_tables(  );

		while (0 <= $_TC) {
			$TableNode = &$TableNodes[$_TC];

			if (!defined( $TableNode->getAttribute( 'alias' ) )) {
				define( $TableNode->getAttribute( 'alias' ), $TableNode->getAttribute( 'name' ) );
			}

			$TableName = constant( $TableNode->getAttribute( 'alias' ) );
			$Columns = db_getColumns( $TableName );
			$ColumnNodes = $TableNode->xPath( '/table/column' );
			$_j = count( $ColumnNodes ) - 1;

			while (0 <= $_j) {
				if (!isset( $Columns[strtolower( $ColumnNodes[$_j]->getData(  ) )] )) {
					$Nullable = ( is_null( $ColumnNodes[$_j]->getAttribute( 'NULLABLE' ) ) || strtolower( $ColumnNodes[$_j]->getAttribute( 'NULLABLE' ) != 'false' ) );
					db_add_column( $TableName, $ColumnNodes[$_j]->getData(  ), $ColumnNodes[$_j]->getAttribute( 'TYPE' ), $ColumnNodes[$_j]->getAttribute( 'DEFAULT' ), $Nullable );
				}

				--$_j;
			}

			--$_TC;
		}

	}

?>