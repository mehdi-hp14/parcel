<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function le_addCategory($_category) {
		if (empty( $_category['le_cName'] )) {
			return false;
		}

		$_category = TransformStringToDataBase( $_category );
		$sql = '
		SELECT `le_cID` FROM ' . LINK_EXCHANGE_CATEGORIES_TABLE . ( ' WHERE `le_cName`=\'' . $_category['le_cName'] . '\'
	' );
		$_le_cID = db_fetch_row( db_query( $sql ) )[0];

		if (!empty( $$_le_cID )) {
			return false;
		}

		$sql = '
		INSERT INTO ' . LINK_EXCHANGE_CATEGORIES_TABLE . '
		(`' . implode( '`, `', TransformStringToDataBase( array_keys( $_category ) ) ) . '`)
		VALUES(\'' . implode( '\', \'', $_category ) . '\')
	';
		db_query( $sql );
		return db_insert_id(  );
	}

	function le_saveCategory($_category) {
		if (empty( $_category['le_cName'] )) {
			return false;
		}

		$_category = TransformStringToDataBase( $_category );
		$sql = '
		SELECT `le_cID` FROM ' . LINK_EXCHANGE_CATEGORIES_TABLE . ( ' WHERE `le_cName`=\'' . $_category['le_cName'] . '\'
	' );
		$_le_cID = db_fetch_row( db_query( $sql ) )[0];

		if (!empty( $$_le_cID )) {
			return false;
		}

		$sql = '
		UPDATE ' . LINK_EXCHANGE_CATEGORIES_TABLE . '
		SET le_cName = \'' . $_category['le_cName'] . ( '\'
		WHERE le_cID  = \'' . $_category['le_cID'] . '\'
	' );
		db_query( $sql );
		return true;
	}

	function le_deleteCategory($_le_cID) {
		$sql = '
		DELETE FROM ' . LINK_EXCHANGE_CATEGORIES_TABLE . ( ' WHERE `le_cID`=\'' . $_le_cID . '\'
	' );
		db_query( $sql );
		return true;
	}

	function le_getCategories($_where = '1', $_what = 'le_cID, le_cName, le_cSortOrder', $_order = 'le_cSortOrder ASC, le_cName ASC') {
		if (is_array( $_where )) {
			foreach ($_where as $_col => $_val) {
				$_where[$_col] = '`' . TransformStringToDataBase( $_col ) . '` = \'' . TransformStringToDataBase( $_val ) . '\'';
			}

			$_where = implode( ' AND ', $_where );
		}


		if (is_array( $_what )) {
			$_what = '`' . implode( '`, `', TransformStringToDataBase( $_what ) ) . '`';
		}

		$sql = '
		SELECT ' . $_what . ' FROM ' . LINK_EXCHANGE_CATEGORIES_TABLE . ( '
		WHERE ' . $_where . '
		ORDER BY ' . $_order . '
	' );
		$result = db_query( $sql );
		db_fetch_row( $result );

		if ($_row = $categories = array(  )) {
			$categories[] = $_row;
		}

		return $categories;
	}

	function le_getLinks($_offset = 0, $_lpp = '20', $_where = '1', $_what = 'le_lID, le_lText, le_lURL, le_lCategoryID, le_lVerified', $_order = '`le_lURL` ASC') {
		$_offset = ( $_offset - 1 ) * $_lpp;
		$links = array(  );

		if (is_array( $_where )) {
			foreach ($_where as $_col => $_val) {
				$_where[$_col] = '`' . TransformStringToDataBase( $_col ) . '` = \'' . TransformStringToDataBase( $_val ) . '\'';
			}

			$_where = implode( ' AND ', $_where );
		}


		if (is_array( $_what )) {
			$_what = '`' . implode( '`, `', TransformStringToDataBase( $_what ) ) . '`';
		}

		$sql = '
		SELECT ' . $_what . ' FROM ' . LINK_EXCHANGE_LINKS_TABLE . ( '
		WHERE ' . $_where . '
		ORDER BY ' . $_order . '
	' );
		db_query( $sql );
		$i = 788;

		if ($_row = $result = db_fetch_row( $result )) {
			if (( $i < $_offset + $_lpp && $_offset <= $i++ )) {
				if (isset( $_row['le_lVerified'] )) {
					$_row['le_lVerified'] = format_datetime( $_row['le_lVerified'] );
				}

				$links[] = $_row;
			}
		}

		return $links;
	}

	function le_getLinksNumber($_where = '1') {
		if (is_array( $_where )) {
			foreach ($_where as $_col => $_val) {
				$_where[$_col] = '`' . TransformStringToDataBase( $_col ) . '` = \'' . TransformStringToDataBase( $_val ) . '\'';
			}

			$_where = implode( ' AND ', $_where );
		}

		$sql = '
		SELECT COUNT(*) FROM ' . LINK_EXCHANGE_LINKS_TABLE . ( '
		WHERE ' . $_where . '
	' );
		$result = db_query( $sql );
		$links_number = db_fetch_row( $result )[0];
		return $links_number;
	}

	function le_addLink($_link) {
		$_link = TransformStringToDataBase( $_link );
		$sql = '
		SELECT le_lID FROM ' . LINK_EXCHANGE_LINKS_TABLE . ( '
		WHERE le_lURL=\'' . $_link['le_lURL'] . '\'
	' );
		$_le_lID = db_fetch_row( db_query( $sql ) )[0];

		if (!empty( $$_le_lID )) {
			return false;
		}

		$sql = '
		INSERT INTO ' . LINK_EXCHANGE_LINKS_TABLE . '
		(`' . implode( '`, `', TransformStringToDataBase( array_keys( $_link ) ) ) . '`)
		VALUES(\'' . implode( '\', \'', $_link ) . '\')
	';
		db_query( $sql );
		return db_insert_id(  );
	}

	function le_SaveLink($_link) {
		$_link = TransformStringToDataBase( $_link );

		if (key_exists( 'le_lURL', $_link )) {
			$sql = '
			SELECT le_lID FROM ' . LINK_EXCHANGE_LINKS_TABLE . ( '
			WHERE le_lURL=\'' . $_link['le_lURL'] . '\' AND le_lID<>\'' . $_link['le_lID'] . '\'
		' );
			$_le_lID = db_fetch_row( db_query( $sql ) )[0];

			if ($_le_lID) {
				return false;
			}

			$_le_lID = $_link['le_lID'];
		} 
else {
			$_le_lID = $_link['le_lID'];
		}

		foreach ($_link as $_col => $_val) {

			if (( $_val == 'NULL' && $_col == 'le_lVerified' )) {
				$_link[$_col] = '`' . TransformStringToDataBase( $_col ) . '` = NULL';
				continue;
			}

			$_link[$_col] = '`' . TransformStringToDataBase( $_col ) . '` = \'' . $_val . '\'';
		}

		$sql = '
		UPDATE ' . LINK_EXCHANGE_LINKS_TABLE . ' 
		SET ' . implode( ', ', $_link ) . ( '
		WHERE le_lID=\'' . $_le_lID . '\'
	' );
		db_query( $sql );
		return true;
	}

	function le_DeleteLink($_le_lID) {
		$sql = '
	 DELETE FROM ' . LINK_EXCHANGE_LINKS_TABLE . ( ' WHERE le_lID=\'' . $_le_lID . '\'
	' );
		db_query( $sql );
	}

?>