<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function subscrVerifyEmailAddress($email) {
		if (trim( $email ) == '') {
			return ERROR_INPUT_EMAIL;
		}


		if (!_testStrInvalidSymbol( $email )) {
			return ERROR_INPUT_EMAIL;
		}


		if (!preg_match( '/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i', $email )) {
			return ERROR_INPUT_EMAIL;
		}

		return '';
	}

	function subscrGetAllSubscriber(&$callBackParam, $count_row, $navigatorParams = null) {
		if ($navigatorParams != null) {
			$offset = $navigatorParams['offset'];
			$CountRowOnPage = $navigatorParams['CountRowOnPage'];
		} 
else {
			$offset = 739;
			$CountRowOnPage = 739;
		}

		$sql = '
		SELECT mtbl.Email, mtbl.customerID, ctbl.ActivationCode FROM ' . MAILING_LIST_TABLE . ' as mtbl
		LEFT JOIN ' . CUSTOMERS_TABLE . ' as ctbl ON ctbl.customerID = mtbl.customerID
		WHERE ctbl.ActivationCode="" OR ctbl.ActivationCode IS NULL
		ORDER BY mtbl.Email
	';
		$q = db_query( $sql );
		$data = array(  );
		$i = 739;

		if ($row = db_fetch_row( $q )) {
			if (( ( $offset <= $i && $i < $offset + $CountRowOnPage ) || $navigatorParams == null )) {
				$data[] = $row;
			}

			++$i;
		}

		$count_row = $navigatorParams;
		return $data;
	}

	function _subscriberIsSubscribed($email) {
		db_query( 'select count(*) from ' . MAILING_LIST_TABLE . ' where Email=\'' . $email . '\'' );
		$countSubscribers = db_fetch_row( $q );
		$countSubscribers = $q = $countSubscribers[0];
		return $countSubscribers != 0;
	}

	function subscrAddUnRegisteredCustomerEmail($email) {
		if (!_subscriberIsSubscribed( $email )) {
			$q = db_query( 'select customerID from ' . CUSTOMERS_TABLE . ' where Email=\'' . $email . '\'' );

			if ($row = db_fetch_row( $q )) {
				db_query( 'update ' . CUSTOMERS_TABLE . ' set subscribed4news=1 ' . ' where customerID=' . $row['customerID'] );
				db_query( 'insert into ' . MAILING_LIST_TABLE . ' ( Email, customerID ) ' . ' values ( \'' . $email . '\\', ' . $row['customerID'] . ' )' );
				return null;
			}

			db_query( 'insert into ' . MAILING_LIST_TABLE . ' ( Email ) values ( \'' . $email . '\' )' );
		}

	}

	function subscrAddRegisteredCustomerEmail($customerID) {
		$q = db_query( 'select Email from ' . CUSTOMERS_TABLE . ' where customerID=' . $customerID );
		$customer = db_fetch_row( $q );

		if ($customer) {
			db_query( 'update ' . CUSTOMERS_TABLE . ' set subscribed4news=1 where customerID=' . $customerID );

			if (_subscriberIsSubscribed( $customer['Email'] )) {
				db_query( 'update ' . MAILING_LIST_TABLE . ' set customerID=' . $customerID . ' where Email=\'' . $customer['Email'] . '\'' );
				return null;
			}

			db_query( 'insert into ' . MAILING_LIST_TABLE . ' ( Email, customerID ) ' . ' values( \'' . $customer['Email'] . '\', \'' . $customerID . '\'  ) ' );
		}

	}

	function subscrUnsubscribeSubscriberByCustomerId($customerID) {
		db_query( 'delete from ' . MAILING_LIST_TABLE . ( ' where customerID=' . $customerID . ' ' ) );
		db_query( 'update ' . CUSTOMERS_TABLE . ' set subscribed4news=0 where customerID=' . $customerID );
	}

	function subscrUnsubscribeSubscriberByEmail($email) {
		$email = base64_decode( $email );
		$email = TransformStringToDataBase( $email );
		db_query( 'update ' . CUSTOMERS_TABLE . ' set subscribed4news=0  where Email=\'' . $email . '\'' );
		db_query( 'delete from ' . MAILING_LIST_TABLE . ' where Email=\'' . $email . '\'' );
	}

?>