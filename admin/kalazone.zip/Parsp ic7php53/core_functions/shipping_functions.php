<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function shDeleteShippingMethod($SID) {
		db_query( 'delete from ' . SHIPPING_METHODS_TABLE . ( ' where SID=' . $SID ) );
	}

	function shGetShippingMethodsByModule($shippingModule) {
		$moduleID = $shippingModule->get_id(  );

		if (strlen( $moduleID ) == 0) {
			return array(  );
		}

		$moduleID = (int)$moduleID;
		$q = db_query( 'select *,' . LanguagesManager::sql_prepareField( 'Name' ) . ' as name,' . LanguagesManager::sql_constractSortField( SHIPPING_METHODS_TABLE, 'Name' ) . ',' . LanguagesManager::sql_constractSortField( SHIPPING_METHODS_TABLE, 'description' ) . ' from ' . SHIPPING_METHODS_TABLE . ' where module_id=' . $moduleID );
		$data = array(  );

		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( SHIPPING_METHODS_TABLE, $row );
			$data[] = $row;
		}

		return $data;
	}

	function shGetShippingMethodById($shippingMethodID) {
		db_query( 'select *,' . LanguagesManager::sql_prepareField( 'Name' ) . ' as Name,' . LanguagesManager::sql_constractSortField( SHIPPING_METHODS_TABLE, 'Name' ) . ',' . LanguagesManager::sql_constractSortField( SHIPPING_METHODS_TABLE, 'description' ) . ' from ' . SHIPPING_METHODS_TABLE . ( ' where SID=' . $shippingMethodID . ' ' ) );
		$q = $shippingMethodID = (int)$shippingMethodID;

		if ($row = db_fetch_row( $q )) {
			$row['Name'] = TransformDataBaseStringToText( $row['Name'] );
			$row['description'] = TransformDataBaseStringToText( $row['description'] );
			$row['email_comments_text'] = TransformDataBaseStringToText( $row['email_comments_text'] );
		}

		return $row;
	}

	function shGetAllShippingMethods($enabledOnly = false) {
		$whereClause = '';

		if ($enabledOnly) {
			$whereClause = ' where Enabled=1 ';
		}


		if (!( $q = db_query( 'select *,' . LanguagesManager::sql_constractSortField( SHIPPING_METHODS_TABLE, 'Name' ) . ',' . LanguagesManager::sql_constractSortField( SHIPPING_METHODS_TABLE, 'description' ) . ' from ' . SHIPPING_METHODS_TABLE . ' ' . $whereClause . ' order by sort_order' ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$data = array(  );

		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( SHIPPING_METHODS_TABLE, $row );
			$data[] = $row;
		}

		return $data;
	}

	function shGetInstalledShippingModules() {
		$moduleFiles = GetFilesInDirectory( './includes/modules/shipping', 'php' );
		$shipping_modules = array(  );
		foreach ($moduleFiles as $fileName) {
			$className = GetClassName( $fileName );

			if (!$className) {
				continue;
			}

			eval( '$shipping_module = new ' . $className . '();' );

			if ($shipping_module->is_installed(  )) {
				$shipping_modules[] = $shipping_module;
				continue;
			}
		}

		return $shipping_modules;
	}

	function shAddShippingMethod($val, $Enabled, $sort_order, $module_id, $thumbnail_logo) {
		$name_inj = LanguagesManager::sql_prepareFieldInsert( 'name', $val );
		LanguagesManager::sql_prepareFieldInsert( 'description', $val );
		$desc_inj = foreach ($val as );
		$emai_inj = LanguagesManager::sql_prepareFieldInsert( 'email_comments_text', $val );
		$sort_order = (int)$sort_order;
		db_query( 'insert into ' . SHIPPING_METHODS_TABLE . ' ( ' . $name_inj['fields'] . ',' . $desc_inj['fields'] . ',' . $emai_inj['fields'] . ', Enabled, module_id, sort_order ,thumbnail_logo ) ' . ' values ' . ' ( ' . $name_inj['values'] . ',' . $desc_inj['values'] . ',' . $emai_inj['values'] . ( ', ' . $Enabled . ', ' . $module_id . ', ' . $sort_order . ',\'' . $thumbnail_logo . '\' )' ) );
		return db_insert_id(  );
	}

	function shUpdateShippingMethod($SID, $value, $Enabled, $sort_order, $module_id, $thumbnail_logo) {
		$module_id = (int)$module_id;
		$sort_order = (int)$sort_order;
		db_query( 'update ' . SHIPPING_METHODS_TABLE . ' set  ' . LanguagesManager::sql_prepareFieldUpdate( 'name', $value ) . ',' . LanguagesManager::sql_prepareFieldUpdate( 'description', $value ) . ',' . LanguagesManager::sql_prepareFieldUpdate( 'email_comments_text', $value ) . ',' . ( ' Enabled=\'' . $Enabled . '\', module_id=' . $module_id . ', sort_order=' . $sort_order . ' , thumbnail_logo=\'' . $thumbnail_logo . '\' ' ) . ( ' where SID=' . $SID ) );
	}

	function shShippingMethodIsExist($shippingMethodID) {
		db_query( 'select count(*) from ' . SHIPPING_METHODS_TABLE . ' where SID=' . $shippingMethodID . ' AND Enabled=1' );
		$count = db_fetch_row( $q_count );
		$count = $q_count = $count[0];
		return $count != 0;
	}

?>