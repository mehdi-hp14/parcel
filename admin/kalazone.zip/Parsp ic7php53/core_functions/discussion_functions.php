<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function discGetAllDiscussion(&$callBackParam, $count_row, $navigatorParams = null) {
		$orderClause = '';

		if (isset( $callBackParam['sort'] )) {
			$orderClause = ' order by ' . $callBackParam['sort'];

			if (isset( $callBackParam['direction'] )) {
				if ($callBackParam['direction'] == 'ASC') {
					$orderClause .= ' ASC ';
				} 
else {
					$orderClause .= ' DESC ';
				}
			}
		}

		$filter = '';

		if (isset( $callBackParam['productID'] )) {
			if ($callBackParam['productID'] != 0) {
				$filter = ' AND ' . PRODUCTS_TABLE . '.productID=' . $callBackParam['productID'];
			}
		}

		db_query( 'select DID, Author, Body, add_time, Topic, ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS product_name from ' . DISCUSSIONS_TABLE . ', ' . PRODUCTS_TABLE . ' where ' . DISCUSSIONS_TABLE . '.productID=' . PRODUCTS_TABLE . '.productID ' . $filter . ' ' . $orderClause );
		$q = $data = array(  );

		if ($navigatorParams != null) {
			$offset = $navigatorParams['offset'];
			$CountRowOnPage = $navigatorParams['CountRowOnPage'];
		} 
else {
			$offset = 802;
			$CountRowOnPage = 802;
		}

		$i = 802;

		if ($row = db_fetch_row( $q )) {
			if (( ( $offset <= $i && $i < $offset + $CountRowOnPage ) || $navigatorParams == null )) {
				$row['Author'] = TransformDataBaseStringToText( $row['Author'] );
				$row['Body'] = TransformDataBaseStringToText( $row['Body'] );
				$row['Topic'] = TransformDataBaseStringToText( $row['Topic'] );
				$row['add_time'] = format_datetime( $row['add_time'] );
				$data[] = $row;
			}

			++$i;
		}

		$count_row = $data;
		return $data;
	}

	function discGetAllDiscussedProducts() {
		$q = db_query( 'select ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS product_name, ' . PRODUCTS_TABLE . '.productID AS productID from ' . DISCUSSIONS_TABLE . ', ' . PRODUCTS_TABLE . ' where ' . DISCUSSIONS_TABLE . '.productID=' . PRODUCTS_TABLE . '.productID ' . ' group by ' . PRODUCTS_TABLE . '.productID, product_name order by product_name' );
		$data = array(  );

		if ($row = db_fetch_row( $q )) {
			$data[] = $row;
		}

		return $data;
	}

		$q = function discGetDiscussion($DID) {;
		db_fetch_row( $q );
		$row = db_query( 'select DID, Author, Body, add_time, Topic, ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS product_name, ' . ' ' . PRODUCTS_TABLE . '.productID AS productID from ' . DISCUSSIONS_TABLE . ', ' . PRODUCTS_TABLE . ' where ' . DISCUSSIONS_TABLE . '.productID=' . PRODUCTS_TABLE . ( '.productID AND DID=' . $DID ) );
		$row['add_time'] = format_datetime( $row['add_time'] );
		return $row;
	}

	function discAddDiscussion($productID, $Author, $Topic, $Body) {
		$Author = TransformStringToDataBase( $Author );
		$Topic = TransformStringToDataBase( $Topic );
		$Body = TransformStringToDataBase( $Body );
		db_query( 'insert into ' . DISCUSSIONS_TABLE . '(productID, Author, Body, add_time, Topic)  ' . ( 'values( ' . $productID . ', \'' . $Author . '\', \'' . $Body . '\', \'' ) . get_current_time(  ) . ( '\', \'' . $Topic . '\' )' ) );
	}

	function discDeleteDiscusion($DID) {
		db_query( 'delete from ' . DISCUSSIONS_TABLE . ' where DID=' . $DID );
	}

?>