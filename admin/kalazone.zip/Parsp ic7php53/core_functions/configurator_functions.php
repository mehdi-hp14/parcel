<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function cfgGetOptions() {
		$options = db_query( 'SELECT optionID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS name FROM ' . PRODUCT_OPTIONS_TABLE );
		$data = array(  );

		if ($option_row = db_fetch_row( $options )) {
			$data[] = $option_row;
		}

		return $data;
	}

	function cfgGetProductOptionValue($productID) {
		$data = array(  );
		$options = db_query( 'SELECT *, ' . LanguagesManager::sql_constractSortField( PRODUCT_OPTIONS_TABLE, 'name' ) . ' FROM ' . PRODUCT_OPTIONS_TABLE . ' ORDER BY sort_order, ' . LanguagesManager::sql_getSortField( PRODUCT_OPTIONS_TABLE, 'name' ) );

		if ($option_row = db_fetch_row( $options )) {
			$optionID = $option_row['optionID'];
			$item = array(  );
			LanguagesManager::ml_fillFields( PRODUCT_OPTIONS_TABLE, $option_row );
			$item['option_row'] = $option_row;
			$item['option_value'] = array( 'option_value' => null, 'option_type' => 0, 'option_show_times' => 1 );
			$item['value_count'] = 0;

			if (isset( $value_counts[$optionID] )) {
				$item['value_count'] = $value_counts[$optionID];
			}

			$data[$optionID] = $item;
		}

		$sql = 'SELECT COUNT(*) AS \'cnt\', ps.`optionID`  FROM `?#PRODUCTS_OPTIONS_SET_TABLE` ps,`?#PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE` pv  WHERE  ps.optionid=pv.optionid and ps.variantID= pv.variantID and `productID`=? GROUP BY `optionID`';
		$res = db_phquery( $sql, $productID );

		if ($row = db_fetch_assoc( $res )) {
			$optionID = $row['optionID'];

			if (isset( $data[$optionID] )) {
				$data[$optionID]['value_count'] = $row['cnt'];
			}
		}

		$sql = 'SELECT * FROM `?#PRODUCT_OPTIONS_VALUES_TABLE` WHERE `productID`=?';
		$res = db_phquery( $sql, $productID );

		if ($row = db_fetch_assoc( $res )) {
			$optionID = $row['optionID'];

			if (isset( $data[$optionID] )) {
				LanguagesManager::ml_fillFields( PRODUCT_OPTIONS_VALUES_TABLE, $row );
				$data[$optionID]['option_value'] = $row;
			}
		}

		return $data;
	}

	function cfgSet_N_VALUES_OptionType($productID, $optionID) {
		$q = db_query( 'select count(*) from ' . PRODUCT_OPTIONS_VALUES_TABLE . ( ' where optionID=' . $optionID . ' AND productID=' . $productID ) );
		$count = db_fetch_row( $q );
		$count = $count[0];

		if ($count == 0) {
			db_query( 'insert into ' . PRODUCT_OPTIONS_VALUES_TABLE . ' ( optionID, productID, ' . LanguagesManager::sql_prepareField( 'option_value' ) . ', option_type, option_show_times ) ' . ( ' values( ' . $optionID . ', ' . $productID . ', \'\', 2, 1 ) ' ) );
			return null;
		}

		db_query( 'update ' . PRODUCT_OPTIONS_VALUES_TABLE . ' set option_type=1 ' . ( ' where productID=' . $productID . ' AND optionID=' . $optionID ) );
	}

	function cfgUpdateOptionValue($productID, $updatedValues) {
		foreach ($updatedValues as $key => $value) {

			if (( $updatedValues[$key]['option_radio_type'] == 'UN_DEFINED' || $updatedValues[$key]['option_radio_type'] == 'ANY_VALUE' )) {
				$option_type = 780;
			} 
else {
				$option_type = 781;
			}


			if ($updatedValues[$key]['option_radio_type'] == 'UN_DEFINED') {
				$option_value = null;
			} 
else {
				$option_value = $updatedValues[$key];
			}

			$where_clause = ' WHERE optionID=\'' . xEscapeSQLstring( $key ) . '\' AND productID=\'' . xEscapeSQLstring( $productID ) . '\'';
			$q = db_query( 'select count(*) from ' . PRODUCT_OPTIONS_VALUES_TABLE . ' ' . $where_clause );
			$r = db_fetch_row( $q );

			if ($r[0] == 1) {
				$dbq = '
				UPDATE ?#PRODUCT_OPTIONS_VALUES_TABLE
				SET ' . LanguagesManager::sql_prepareFieldUpdate( 'option_value', $option_value ) . ', option_type=? ' . $where_clause . '
			';
				db_phquery( $dbq, $option_type );
				continue;
			}

			$dbq_inj = LanguagesManager::sql_prepareFieldInsert( 'option_value', $option_value );
			$dbq = '
				INSERT ?#PRODUCT_OPTIONS_VALUES_TABLE (optionID, productID, ' . $dbq_inj['fields'] . ', option_type)
				VALUES(?, ?, ' . $dbq_inj['values'] . ', ?)
			';
			db_phquery( $dbq, $key, $productID, $option_type );
		}

	}

	function UpdateConfiguriableProductOption($optionID, $productID, $option_show_times, $variantID_default, $setting) {
		$where_clause = ' where optionID=\'' . $optionID . '\' AND ' . ' productID=\'' . $productID . '\'';
		$q = db_query( 'select count(*) from ' . PRODUCT_OPTIONS_VALUES_TABLE . $where_clause );
		$r = db_fetch_row( $q );

		if ($r[0] != 0) {
			db_query( 'update ' . PRODUCT_OPTIONS_VALUES_TABLE . ' set ' . LanguagesManager::sql_prepareFieldUpdate( 'option_value', $r ) . ', ' . ' option_show_times=\'' . $option_show_times . '\\', ' . ' variantID=' . $variantID_default . ' ' . $where_clause );
		} 
else {
			db_query( 'insert into ' . PRODUCT_OPTIONS_VALUES_TABLE . '(optionID, productID, option_type, ' . 'option_show_times, variantID) ' . 'values(\'' . $optionID . '\', \'' . $productID . '\', 0, \'' . $option_show_times . '\',  ' . $variantID_default . '  )' );
		}

		$q1 = db_query( 'select variantID from ' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . ' where optionID=\'' . $optionID . '\'' );
		$if_only = false;

		if ($r1 = db_fetch_row( $q1 )) {
			$key = $r1['variantID'];
			$where_clause = ' where productID=\'' . $productID . '\' AND optionID=\'' . $optionID . '\' AND variantID=\'' . $key . '\'';

			if (!isset( $setting[$key]['switchOn'] )) {
				db_query( 'delete from ' . PRODUCTS_OPTIONS_SET_TABLE . $where_clause );
			}

			$q = db_query( 'select count(*) from ' . PRODUCTS_OPTIONS_SET_TABLE . $where_clause );
			$r = db_fetch_row( $q );

			if ($r[0] != 0) {
				db_query( 'update ' . PRODUCTS_OPTIONS_SET_TABLE . ' set price_surplus=\'' . (double)$setting[$key]['price_surplus'] . '\'' . $where_clause );
				$if_only = true;
			}

			db_query( 'insert into ' . PRODUCTS_OPTIONS_SET_TABLE . '(productID, optionID, variantID, price_surplus)' . 'values( \'' . $productID . '\', \'' . $optionID . '\', \'' . $key . '\', \'' . (double)$setting[$key]['price_surplus'] . '\' )' );
			$if_only = true;
		}


		if (!$if_only) {
			db_query( 'update ' . PRODUCT_OPTIONS_VALUES_TABLE . ' set option_show_times=0 where optionID=\'' . $optionID . '\' AND ' . ' productID=\'' . $productID . '\'' );
		}

	}

?>