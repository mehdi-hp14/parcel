<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function CompareConfiguration($variants1, $variants2) {
		if (count( $variants1 ) != count( $variants2 )) {
			return false;
		}

		foreach ($variants1 as $variantID) {
			$count1 = 743;
			$count2 = 743;
			$i = 743;

			while ($i < count( $variants1 )) {
				if ((int)$variants1[$i] == (int)$variantID) {
					++$count1;
				}

				++$i;
			}

			$i = 743;

			while ($i < count( $variants1 )) {
				if ((int)$variants2[$i] == (int)$variantID) {
					++$count2;
				}

				++$i;
			}


			if ($count1 != $count2) {
				return false;
			}
		}

		return true;
	}

	function SearchConfigurationInSessionVariable($variants, $productID) {
		foreach ($_SESSION['configurations'] as $key => $value) {

			if ((int)$_SESSION['gids'][$key] != (int)$productID) {
				continue;
			}


			if (CompareConfiguration( $variants, $value )) {
				return $key;
			}
		}

		return -1;
	}

	function SearchConfigurationInDataBase($variants, $productID) {
		$q = db_query( 'select itemID from ' . SHOPPING_CARTS_TABLE . ' where customerID=\'' . regGetIdByLogin( $_SESSION['log'] ) . '\'' );

		if ($r = db_fetch_row( $q )) {
			$q1 = db_query( 'select COUNT(itemID) from ' . SHOPPING_CART_ITEMS_TABLE . ' where productID=\'' . $productID . '\' AND itemID=\'' . $r['itemID'] . '\'' );
			$r1 = db_fetch_row( $q1 );

			if ($r1[0] != 0) {
				$variants_from_db = GetConfigurationByItemId( $r['itemID'] );

				if (CompareConfiguration( $variants, $variants_from_db )) {
					return $r['itemID'];
				}
			}
		}

		return -1;
	}

	function CodeItemInClient($variants, $productID) {
		$array = array(  );
		$array[] = $productID;
		foreach ($variants as $var) {
			$array[] = $var;
		}

		return implode( '_', $array );
	}

	function DeCodeItemInClient($str) {
		$array = explode( '_', $str );
		$productID = $array[0];
		$variants = array(  );
		$i = 720;

		while ($i < count( $array )) {
			$variants[] = $array[$i];
			++$i;
		}

		$res = array(  );
		$res['productID'] = $productID;
		$res['variants'] = $variants;
		return $res;
	}

	function GetProductInStockCount($productID) {
		$q = db_query( 'select in_stock from ' . PRODUCTS_TABLE . ' where productID=\'' . $productID . '\'' );
		$is = db_fetch_row( $q );
		return $is[0];
	}

	function GetPriceProductWithOption($variants, $productID) {
		$q = db_query( 'select Price from ' . PRODUCTS_TABLE . ' where productID=\'' . $productID . '\'' );
		$r = db_fetch_row( $q );
		$full_price = (double)$r[0];
		$variantsPrice = array(  );

		if (( count( $variants ) && $variants != '' )) {
			$q1 = db_phquery( 'select price_surplus,variantID from ?#PRODUCTS_OPTIONS_SET_TABLE where productID=? AND variantID IN(?@)', $productID, $variants );

			if ($r1 = db_fetch_row( $q1 )) {
				$variantsPrice[$r1['variantID']] = $r1['price_surplus'];
			}
		}

		foreach ($variants as $var) {
			$full_price += (isset( $variantsPrice[$var] ) ? $variantsPrice[$var] : 0);
		}

		return $full_price;
	}

	function GetProductIdByItemId($itemID) {
		$q = db_query( 'select productID from ' . SHOPPING_CART_ITEMS_TABLE . ' where itemID=\'' . $itemID . '\'' );
		$r = db_fetch_row( $q );
		return $r['productID'];
	}

	function cartMoveContentFromShoppingCartsToOrderedCarts($orderID, $shippingMethodID, $paymentMethodID, $shippingAddressID, $billingAddressID, $shippingModuleFiles, $paymentModulesFiles) {
		$q = db_query( 'select statusID from ' . ORDERS_TABLE . ( ' where orderID=' . $orderID ) );
		$order = db_fetch_row( $q );
		$statusID = $order['statusID'];
		$variants = '';
		db_query( 'DELETE FROM ' . ORDERED_CARTS_TABLE . ' WHERE orderID=' . intval( $orderID ) . '' );
		$q_items = db_query( 'SELECT itemID, Quantity FROM ' . SHOPPING_CARTS_TABLE . ' WHERE customerID=\'' . regGetIdByLogin( $_SESSION['log'] ) . '\'' );

		if ($item = db_fetch_row( $q_items )) {
			$productID = GetProductIdByItemId( $item['itemID'] );

			if (( $productID == null || trim( $productID ) == '' )) {
				continue;
			}

			$variants = GetConfigurationByItemId( $item['itemID'] );
			$q_product = db_query( 'select ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name, product_code from ' . PRODUCTS_TABLE . ' where productID=\'' . $productID . '\'' );
			$product = db_fetch_row( $q_product );
			$options = GetStrOptions( $variants );

			if ($options != '') {
				$productComplexName = $product['name'] . '(' . $options . ')';
			} 
else {
				$productComplexName = $product['name'];
			}


			if (0 < strlen( $product['product_code'] )) {
				$productComplexName = '[' . $product['product_code'] . '] ' . $productComplexName;
			}

			$price = GetPriceProductWithOption( $variants, $productID );
			$tax = taxCalculateTax( $productID, $shippingAddressID, $billingAddressID );
			db_query( 'INSERT INTO ' . ORDERED_CARTS_TABLE . '(	itemID, orderID, name, ' . '	Price, Quantity, tax,productID ) ' . '  VALUES ' . ' 	(' . $item['itemID'] . ',' . $orderID . ', \'' . xEscapeSQLstring( $productComplexName ) . '\\', ' . $price . ', ' . $item['Quantity'] . ', ' . $tax . ( ', ' . $productID . ' )' ) );

			if (( $statusID != ostGetCanceledStatusId(  ) && CONF_CHECKSTOCK )) {
				db_query( 'update ' . PRODUCTS_TABLE . ' set in_stock = in_stock - ' . $item['Quantity'] . ' where productID=\'' . $productID . '\'' );
			}
		}

		db_query( 'DELETE FROM ' . SHOPPING_CARTS_TABLE . ' WHERE customerID=\'' . regGetIdByLogin( $_SESSION['log'] ) . '\'' );
	}

	function cartClearCartContet() {
		if (isset( $_SESSION['log'] )) {
			db_query( 'DELETE FROM ' . SHOPPING_CARTS_TABLE . ' WHERE customerID=\'' . regGetIdByLogin( $_SESSION['log'] ) . '\'' );
			return null;
		}

		unset( $_SESSION[gids] );
		unset( $_SESSION[counts] );
		unset( $_SESSION[configurations] );
		session_unregister( 'gids' );
		session_unregister( 'counts' );
		session_unregister( 'configurations' );
	}

	function cartGetCartContent() {
		$cart_content = array(  );
		$total_price = 999;
		$freight_cost = 999;
		$variants = '';

		if (isset( $_SESSION['log'] )) {
			$q = db_query( 'SELECT itemID, Quantity FROM ' . SHOPPING_CARTS_TABLE . ' WHERE customerID=\'' . regGetIdByLogin( $_SESSION['log'] ) . '\'' );

			if ($cart_item = db_fetch_row( $q )) {
				$q_shopping_cart_item = db_query( 'select productID from ' . SHOPPING_CART_ITEMS_TABLE . ' where ' . ' itemID=\'' . $cart_item['itemID'] . '\'' );
				$variants = GetConfigurationByItemId( $cart_item['itemID'] );
				$shopping_cart_item = db_fetch_row( $q_shopping_cart_item );
				$q_products = db_query( 'SELECT ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name, Price, productID, min_order_amount, shipping_freight, free_shipping FROM ' . PRODUCTS_TABLE . ' WHERE productID=\'' . $shopping_cart_item['productID'] . '\'' );

				if ($product = db_fetch_row( $q_products )) {
					$costUC = GetPriceProductWithOption( $variants, $shopping_cart_item['productID'] );
					$options = GetStrOptions( $variants );

					if ($options != '') {
						$productComplexName = $product['name'] . '(' . $options . ')';
					} 
else {
						$productComplexName = $product['name'];
					}

					$tmp = array( 'productID' => $product['productID'], 'id' => $cart_item['itemID'], 'name' => $productComplexName, 'quantity' => $cart_item['Quantity'], 'free_shipping' => $product['free_shipping'], 'costUC' => $costUC, 'cost' => show_price( $cart_item['Quantity'] * GetPriceProductWithOption( $variants, $shopping_cart_item['productID'] ) ) );
					$freight_cost += $cart_item['Quantity'] * $product['shipping_freight'];

					if ($cart_item['Quantity'] < $product['min_order_amount']) {
						$tmp['min_order_amount'] = $product['min_order_amount'];
					}

					$cart_content[] = $tmp;
					$total_price += $cart_item['Quantity'] * GetPriceProductWithOption( $variants, $shopping_cart_item['productID'] );
				}
			}
		} 
else {
			$total_price = 999;
			$cart_content = array(  );

			if (isset( $_SESSION['gids'] )) {
				$j = 999;

				while ($j < count( $_SESSION['gids'] )) {
					if ($_SESSION['gids'][$j]) {
						$session_items[] = CodeItemInClient( $_SESSION['configurations'][$j], $_SESSION['gids'][$j] );
						$q = db_query( 'SELECT ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name, Price, shipping_freight, free_shipping FROM ' . PRODUCTS_TABLE . ' WHERE productID=\'' . $_SESSION['gids'][$j] . '\'' );

						if ($r = db_fetch_row( $q )) {
							$costUC = GetPriceProductWithOption( $_SESSION['configurations'][$j], $_SESSION['gids'][$j] );
							$id = $_SESSION['gids'][$j];

							if (0 < count( $_SESSION['configurations'][$j] )) {
								$tmp1 = 999;

								while ($tmp1 < count( $_SESSION['configurations'][$j] )) {
									$id .= '_' . $_SESSION['configurations'][$j][$tmp1];
									++$tmp1;
								}
							}

							$options = GetStrOptions( $_SESSION['configurations'][$j] );

							if ($options != '') {
								$productComplexName = $r[0] . '(' . $options . ')';
							} 
else {
								$productComplexName = $r[0];
							}

							$tmp = array( 'productID' => $_SESSION['gids'][$j], 'id' => $id, 'name' => $productComplexName, 'quantity' => $_SESSION['counts'][$j], 'free_shipping' => $r['free_shipping'], 'costUC' => $costUC, 'cost' => show_price( $costUC * $_SESSION['counts'][$j] ) );
							$q_product = db_query( 'select min_order_amount, shipping_freight from ' . PRODUCTS_TABLE . ' where productID=' . $_SESSION['gids'][$j] );
							$product = db_fetch_row( $q_product );

							if ($_SESSION['counts'][$j] < $product['min_order_amount']) {
								$tmp['min_order_amount'] = $product['min_order_amount'];
							}

							$freight_cost += $_SESSION['counts'][$j] * $product['shipping_freight'];
							$cart_content[] = $tmp;
							$total_price += GetPriceProductWithOption( $_SESSION['configurations'][$j], $_SESSION['gids'][$j] ) * $_SESSION['counts'][$j];
						}
					}

					++$j;
				}
			}
		}

		return array( 'cart_content' => $cart_content, 'total_price' => $total_price, 'freight_cost' => $freight_cost );
	}

		$cart_content = function cartCheckMinOrderAmount() {;
		$cart_content['cart_content'];
		$cart_content = cartGetCartContent(  );
		foreach ($cart_content as $cart_item) {

			if (isset( $cart_item['min_order_amount'] )) {
				return false;
			}
		}

		return true;
	}

	function cartCheckMinTotalOrderAmount() {
		$res = cartGetCartContent(  );
		$d = oaGetDiscountPercent( $res, '' );
		$order['order_amount'] = $res['total_price'] - $res['total_price'] / 100 * $d;

		if ($order['order_amount'] < CONF_MINIMAL_ORDER_AMOUNT) {
			return false;
		}

		return true;
	}

	function cartAddToCart($productID, $variants) {
		$product_data = GetProduct( $productID );
		$is = GetProductInStockCount( $productID );
		$min_order_amount = $product_data['min_order_amount'];
		$count_to_order = 861;

		if (!isset( $_SESSION['log'] )) {
			if (!isset( $_SESSION['gids'] )) {
				$_SESSION['gids'] = array(  );
				$_SESSION['counts'] = array(  );
				$_SESSION['configurations'] = array(  );
			}

			$item_index = SearchConfigurationInSessionVariable( $variants, $productID );

			if ($item_index == -1) {
				$count_to_order = $variants;
			}


			if ($item_index != -1) {
				if (( CONF_CHECKSTOCK == 0 || $_SESSION['counts'][$item_index] + $count_to_order <= $is )) {
					$_SESSION['counts'] += $is = $count_to_order;
				} 
else {
					return false;
				}
			}


			if (( CONF_CHECKSTOCK == 0 || $count_to_order <= $is )) {
				$_SESSION['gids'][] = $productID;
				$_SESSION['counts'][] = $count_to_order;
				$_SESSION['configurations'][] = $variants;
			} 
else {
				return false;
			}
		}

		$itemID = SearchConfigurationInDataBase( $variants, $productID );

		if ($itemID != -1) {
			$q = db_query( 'SELECT Quantity FROM ' . SHOPPING_CARTS_TABLE . ' WHERE customerID=\'' . regGetIdByLogin( $_SESSION['log'] ) . '\' AND itemID=\'' . $itemID . '\'' );
			$row = db_fetch_row( $q );
			$quantity = $row[0];

			if (( CONF_CHECKSTOCK == 0 || $quantity + $count_to_order <= $is )) {
				db_query( 'UPDATE ' . SHOPPING_CARTS_TABLE . ' SET Quantity=' . ( $row[0] + $count_to_order ) . ' WHERE customerID=\'' . regGetIdByLogin( $_SESSION['log'] ) . '\' AND itemID=\'' . $itemID . '\'' );
			} 
else {
				return false;
			}
		}

		$count_to_order = $variants;

		if (( CONF_CHECKSTOCK == 0 || $count_to_order <= $is )) {
			$itemID = InsertNewItem( $variants, $productID );
			InsertItemIntoCart( $itemID );
			db_query( 'UPDATE ' . SHOPPING_CARTS_TABLE . ' SET Quantity=' . $count_to_order . ' WHERE customerID=\'' . regGetIdByLogin( $_SESSION['log'] ) . '\' AND itemID=\'' . $itemID . '\'' );
		} 
else {
			return false;
		}

		return true;
	}

	function cartCartIsEmpty($log) {
		$customerID = regGetIdByLogin( $log );

		if (0 < (int)$customerID) {
			$customerID = (int)$customerID;
			$q_count = db_query( 'select count(*) from ' . SHOPPING_CARTS_TABLE . ' where customerID=' . $customerID );
			$count = db_fetch_row( $q_count );
			$count = $count[0];
			return $count == 0;
		}

		return true;
	}

	function GetConfigurationByItemId($itemID) {
		static $variants_cache = array(  );

		$itemID = intval( $itemID );

		if (!isset( $variants_cache[$itemID] )) {
			$variants_cache[$itemID] = array(  );

			if ($q = db_phquery( 'select variantID from ?#SHOPPING_CART_ITEMS_CONTENT_TABLE where itemID=?', $itemID )) {

				if ($r = db_fetch_row( $q )) {
					$variants_cache[$itemID][] = $r['variantID'];
				}
			}
		}

		return $variants_cache[$itemID];
	}

	function InsertNewItem($variants, $productID) {
		db_insert_id(  );
		$itemID = db_query( 'insert into ' . SHOPPING_CART_ITEMS_TABLE . '(productID) values(\'' . $productID . '\')' );
		foreach ($variants as $var) {
			db_query( 'insert into ' . SHOPPING_CART_ITEMS_CONTENT_TABLE . '(itemID, variantID) ' . 'values( \'' . $itemID . '\', \'' . $var . '\')' );
		}

		return $itemID;
	}

	function InsertItemIntoCart($itemID) {
		db_query( 'insert ' . SHOPPING_CARTS_TABLE . '(customerID, itemID, Quantity)' . 'values( \'' . regGetIdByLogin( $_SESSION['log'] ) . '\', \'' . $itemID . '\', 1 )' );
	}

	function GetStrOptions($variants) {
		static $res_cache = array(  );

		$variants = array_map( 'intval', $variants );
		$dbq = 'SELECT ' . LanguagesManager::sql_prepareField( 'option_value', true ) . ',variantID FROM ?#PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE WHERE variantID IN(?@)';
		$is_cached = true;
		$non_cached_variants = array(  );
		foreach ($variants as $variantID) {

			if (!isset( $res_cache[$variantID] )) {
				$non_cached_variants[] = $variantID;
				continue;
			}
		}


		if (count( $non_cached_variants )) {

			if ($q = db_phquery( $dbq, $non_cached_variants )) {

				if ($r = db_fetch_row( $q )) {
					if ($r['option_value']) {
						$res_cache[$r['variantID']] = $r['option_value'];
					}
				}
			}
		}

		$result = array(  );
		foreach ($variants as $variantID) {
			$result[] = $res_cache[$variantID];
		}

		return (count( $result ) ? implode( ', ', $result ) : '');
	}

?>