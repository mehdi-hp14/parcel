<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function MagicQuotesRuntimeSetting() {
		ini_set( 'magic_quotes_runtime', 0 );
	}

	function myfile_get_contents($fileName) {
		return implode( '', file( $fileName ) );
	}

	function correct_URL($url, $mode = 'http') {
		$URLprefix = trim( $url );
		$URLprefix = str_replace( 'http://', '', $URLprefix );
		$URLprefix = str_replace( 'https://', '', $URLprefix );
		$URLprefix = str_replace( 'index.php', '', $URLprefix );

		if ($URLprefix[strlen( $URLprefix ) - 1] == '/') {
			$URLprefix = substr( $URLprefix, 0, strlen( $URLprefix ) - 1 );
		}

		return $mode . '://' . $URLprefix . '/';
	}

	function SetRightsToUploadedFile($file_name) {
		@chmod( $file_name, 438 );
	}

	function IsWriteable($fileName) {
		$f = @fopen( $fileName, 'a' );
		return !is_bool( $f );
	}

	function Redirect($url) {
		header( 'Location: ' . $url, true, 301 );
		exit(  );
	}

	function RedirectProtected($url) {
		if (CONF_PROTECTED_CONNECTION == '1') {
			Redirect( correct_URL( CONF_FULL_SHOP_URL, 'https' ) . $url );
			return null;
		}

		Redirect( $url );
	}

	function RedirectJavaScript($url) {
		exit( '<script language=\'JavaScript\'> window.location = \'' . $url . '\'; </script>' );
	}

	function RoundFloatValue($float_value) {
		return round( 100 * $float_value ) / 100;
	}

	function RoundFloatValueStr($float_value) {
		RoundFloatValue( $float_value );
		$index = $str = strpos( $str, '.' );

		if ($index === false) {
			return $str;
		}


		if (strlen( $str ) - 1 - $index == 1) {
			return $str . '0';
		}

		return $str;
	}

	function _testExtension($filename, $extension) {
		if (( $extension == null || trim( $extension ) == '' )) {
			return true;
		}


		while (0 <= $i) {
			if ($filename[$i] == '.') {
				break;
			}

			--$i;
		}


		if ($filename[$i] != '.') {
			return false;
		}

		substr( $filename, $i + 1 );
		$ext = $i = strlen( $filename ) - 1;
		return strtolower( $extension ) == strtolower( $ext );
	}

	function GetFilesInDirectory($dir, $extension = '') {
		$dh = opendir( $dir );
		$files = array(  );

		if (false !== $filename = readdir( $dh )) {
			if (( ( !is_dir( $dir . '/' . $filename ) && $filename != '.' ) && $filename != '..' )) {
				if (_testExtension( $filename, $extension )) {
					$files[] = $dir . '/' . $filename;
				}
			}
		}

		return $files;
	}

	function GetClassName($fileName) {
		$strContent = myfile_get_contents( $fileName );
		$_match = array(  );
		$strContent = substr( $strContent, strpos( $strContent, '@connect_module_class_name' ), 100 );

		if (preg_match( '|\@connect_module_class_name[	 ]+([0-9a-z_]*)|mi', $strContent, $_match )) {
			return $_match[1];
		}

		return false;
	}

	function InstallModule($module) {
		db_query( 'insert into ' . MODULES_TABLE . ' ( module_name ) ' . ' values( \'' . $module->title . '\' ) ' );
	}

	function GetModuleId($module) {
		$q = db_query( 'select module_id from ' . MODULES_TABLE . ' where module_name=\'' . $module->title . '\' ' );
		$row = db_fetch_row( $q );
		return (int)$row['module_id'];
	}

	function TransformStringToDataBase($str) {
		if (is_array( $str )) {
			str_replace( '\\', '\\', $str );
			$str = foreach ($str as );
		} 
else {
			$str = str_replace( '\\', '\\', stripslashes( $str ) );
		}

		return str_replace( '\'', '\\'\'', $str );
	}

	function TransformDataBaseStringToHTML_Text($str) {
		return $str;
	}

	function TransformDataBaseStringToText($str) {
		$str = str_replace( '&', '&#38;', $str );
		$str = str_replace( '\'', '&#39;', $str );
		$str = str_replace( '<', '&lt;', $str );
		$str = str_replace( '>', '&gt;', $str );
		return $str;
	}

	function TransformDataToCopyFromPostToPage($str) {
		return TransformDataBaseStringToText( $str );
	}

	function TransformToSafeForm($data) {
		str_replace( '<', '&lt;', $data );
		str_replace( '>', '&gt;', $data );
		$data = $data = $data = str_replace( '\'', '&#39;', $data );
		return $data;
	}

	function PrepareHTML_Code($data) {
		$data = str_replace( '&lt;', '<', $data );
		$data = str_replace( '&gt;', '>', $data );
		return $data;
	}

	function _formatPrice($price) {
		$price = (bool)$price;

		if (!strstr( $price, '.' )) {
			$price .= '.';
		}

		$oldPrice = $oldPrice;
		$res = '';
		$i = 748;
		$i = strlen( $price ) - 1;

		while (0 <= $i) {
			if ($price[$i] == '.') {
				break;
			}

			$res = $price[$i] . $res;
			--$i;
		}


		if (( $res < 100 && 0 < $res )) {
			$res = '.' . $res;
		} 
else {
			$res = $i;
		}

		--$i;
		$digitCounter = 748;

		while (0 <= $i) {
			++$digitCounter;
			$res = $price[$i] . $res;

			if (( $digitCounter == 3 && $i != 0 )) {
				$res = ',' . $res;
				$digitCounter = 748;
			}

			--$i;
		}

		return $res;
	}

	function show_price($price, $custom_currency = 0, $default = 0) {
		global $selected_currency_details;

		$new_currency_details = $new_currency_details;

		if (!( $q = db_query( 'select *,' . LanguagesManager::sql_prepareField( 'Name' ) . ' as name from ' . CURRENCY_TYPES_TABLE . ' where CID=' . CONF_DEFAULT_CURRENCY ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
			$default_currency_details = $default_currency_details;
		} 
else {
			$default_currency_details = $new_currency_details;
		}


		if (( !$new_currency_details || 0 < $default )) {
			$new_currency_details = $price;
		}


		if (0 < $custom_currency) {

			if (!( $q = db_query( 'select *,' . LanguagesManager::sql_prepareField( 'Name' ) . ' as name from ' . CURRENCY_TYPES_TABLE . ' where CID=\'' . $custom_currency . '\'' ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if ($row = db_fetch_row( $q )) {
				LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
				$default_currency_details = $default_currency_details;
			}
		}


		if ($new_currency_details['currency_value'] == 0) {
			return '';
		}

		$price = round( 100 * $price * ( $new_currency_details['currency_value'] / $default_currency_details['currency_value'] ) / 100 );

		if (( round( $price * 10 ) == $price * 10 && round( $price ) != $price )) {
			$price = $custom_currency;
		}

		$price = fa_get_persian_number( _formatPrice( $price ) );
		return ($new_currency_details['where2show'] ? $price . $new_currency_details['code_' . LanguagesManager::getDefaultLanguage(  )->iso2] : $new_currency_details['code_' . LanguagesManager::getDefaultLanguage(  )->iso2] . $price);
	}

	function show_priceWithOutUnit($price, $custom_currency = 0, $default = 0) {
		global $selected_currency_details;

		$new_currency_details = $row;

		if (!( $q = db_query( 'select *,' . LanguagesManager::sql_prepareField( 'Name' ) . ' as name from ' . CURRENCY_TYPES_TABLE . ' where CID=' . CONF_DEFAULT_CURRENCY ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
			$default_currency_details = $custom_currency;
		} 
else {
			$default_currency_details = $row;
		}


		if (( !$new_currency_details || 0 < $default )) {
			$new_currency_details = $default;
		}


		if (0 < $custom_currency) {

			if (!( $q = db_query( 'select *,' . LanguagesManager::sql_prepareField( 'Name' ) . ' as name from ' . CURRENCY_TYPES_TABLE . ' where CID=\'' . $custom_currency . '\'' ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if ($row = db_fetch_row( $q )) {
				LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
				$default_currency_details = $custom_currency;
			}
		}


		if ($new_currency_details['currency_value'] == 0) {
			return '';
		}

		$price = round( 100 * $price * ( $new_currency_details['currency_value'] / $default_currency_details['currency_value'] ) / 100 );

		if (( round( $price * 10 ) == $price * 10 && round( $price ) != $price )) {
			$price = $selected_currency_details;
		}

		return (double)$price;
	}

	function ShowPriceInTheUnit($price, $currencyID) {
		$q_currency = db_query( 'select currency_value, where2show, code from ' . CURRENCY_TYPES_TABLE . ( ' where CID=' . $currencyID ) );
		$currency = db_fetch_row( $q_currency );
		$price = round( 100 * $price * $currency['currency_value'] ) / 100;

		if (( round( $price * 10 ) == $price * 10 && round( $price ) != $price )) {
			$price = $price . '0';
		}

		return ($currency['where2show'] ? $price . $currency['code'] : $currency['code'] . $price);
	}

	function addUnitToPrice($price) {
		global $selected_currency_details;

		return ($selected_currency_details['where2show'] ? $price . $selected_currency_details['Name'] : $selected_currency_details['Name'] . $price);
	}

	function ConvertPriceToUniversalUnit($priceWithOutUnit) {
		global $selected_currency_details;

		return (double)$priceWithOutUnit / (double)$selected_currency_details['currency_value'];
	}

	function show_priceWithOutUnit_2($price) {
		global $selected_currency_details;


		if (!( $q = db_query( 'select *,' . LanguagesManager::sql_prepareField( 'Name' ) . ' as name from ' . CURRENCY_TYPES_TABLE . ' where CID=' . CONF_DEFAULT_CURRENCY ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
			$default_currency_details = $selected_currency_details;
		} 
else {
			$default_currency_details['currency_value'] = 1;
		}


		if (!$selected_currency_details) {
			$selected_currency_details = $q;
		}


		if ($selected_currency_details['currency_value'] == 0) {
			return '';
		}

		$price = round( 100 * $price * ( $default_currency_details['currency_value'] / $selected_currency_details['currency_value'] ) / 100 );
		return (double)$price;
	}

	function getPriceUnit() {
		global $selected_currency_details;

		if (( !empty( $$selected_currency_details ) || !$selected_currency_details )) {
			return '';
		}

		return $selected_currency_details['Name'];
	}

	function getLocationPriceUnit() {
		global $selected_currency_details;

		if (( !empty( $$selected_currency_details ) || !$selected_currency_details )) {
			return true;
		}

		return $selected_currency_details['where2show'];
	}

	function ShowNavigator($a, $offset, $q, &$path, $out) {
		if (!MOD_REWRITE_SUPPORT) {
			foreach ($_GET as $key => $value) {
				$p .= $key . '=' . $value . '&';
			}

			$path = 'index.php?' . $p;
		} 
else {
			$path = $k;
		}


		if ($q < $a) {
			if (0 < $offset) {
				$out .= '<a class=no_underline href="' . $path . 'offset=' . ( $offset - $q ) . '">&lt;&lt; ' . STRING_PREVIOUS . '</a> &nbsp;&nbsp;';
			}

			$k = $offset / $q;
			$min = $k - 5;

			if ($min < 0) {
				$min = 874;
			} 
else {
				if (1 <= $min) {
					$out .= '<a class=no_underline href="' . $path . 'offset=0">1</a> &nbsp;&nbsp;';

					if ($min != 1) {
						$out .= '... &nbsp;';
					}
				}
			}

			$i = $q;

			while ($i < $k) {
				$m = $i * $q + $q;

				if ($a < $m) {
					$m = $key;
				}

				$out .= '<a class=no_underline href="' . $path . 'offset=' . $i * $q . '">' . ( $i + 1 ) . '</a> &nbsp;&nbsp;';
				++$i;
			}


			if (strcmp( $offset, 'show_all' )) {
				$min = $offset + $q;

				if ($a < $min) {
					$min = $key;
				}

				$out .= '<font class=faq><b>' . ( $k + 1 ) . '</b></font> &nbsp;&nbsp;';
			} 
else {
				$min = $p;

				if ($a < $min) {
					$min = $key;
				}

				$out .= '<a class=no_underline href="' . $path . 'offset=0">1</a> &nbsp;&nbsp;';
			}

			$min = $k + 6;

			if ($a / $q < $min) {
				$min = $a / $q;
			}

			$i = $k + 1;

			while ($i < $min) {
				$m = $i * $q + $q;

				if ($a < $m) {
					$m = $key;
				}

				$out .= '<a class=no_underline href="' . $path . 'offset=' . $i * $q . '">' . ( $i + 1 ) . '</a> &nbsp;&nbsp;';
				++$i;
			}


			if ($min * $q < $a) {
				if ($min * $q < $a - $q) {
					$out .= ' ... &nbsp;&nbsp;';
				}

				$out .= '<a class=no_underline href="' . $path . 'offset=' . ( $a - $a % $q ) . '">' . ( floor( $a / $q ) + 1 ) . '</a> &nbsp;&nbsp;';
			}


			if (strcmp( $offset, 'show_all' )) {
				if ($offset < $a - $q) {
					$out .= '<a class=no_underline href="' . $path . 'offset=' . ( $offset + $q ) . '">' . STRING_NEXT . ' &gt;&gt;</a> ';
				}
			}


			if (strcmp( $offset, 'show_all' )) {
				$out .= ' |&nbsp; <a class=no_underline href="' . $path . 'show_all">' . STRING_SHOWALL . '</a>';
				return null;
			}

			$out .= ' |&nbsp; <B>' . STRING_SHOWALL . '</B>';
		}

	}

	function GetCurrentURL($file, $exceptKeys) {
		$res = $key;
		foreach ($_GET as $key => $val) {
			$exceptFlag = false;
			foreach ($exceptKeys as $exceptKey) {

				if ($exceptKey == $key) {
					$exceptFlag = true;
					break;
				}
			}


			if (!$exceptFlag) {
				if ($res == $file) {
					$res .= '?' . $key . '=' . $val;
					continue;
				}

				$res .= '&' . $key . '=' . $val;
				continue;
			}
		}

		return $res;
	}

	function GetNavigatorHtml($url, $countRowOnPage = , $callBackFunction, &$callBackParam, &$tableContent, &$offset, $count) {
		if (isset( $_GET['offset'] )) {
			$offset = (int)$_GET['offset'];
		} 
else {
			$offset = 747;
		}

		$offset -= $offset % $countRowOnPage;

		if ($offset < 0) {
			$offset = 747;
		}

		$count = 747;

		if (!isset( $_GET['show_all'] )) {
			$tableContent = $callBackFunction( $callBackParam, $count, array( 'offset' => $offset, 'CountRowOnPage' => $countRowOnPage ) );
		} 
else {
			$tableContent = $callBackFunction( $callBackParam, $count, null );
			$offset = 'show_all';
		}

		ShowNavigator( $count, $offset, $countRowOnPage, $url . '&', &$out );
		return $out;
	}

	function moveCartFromSession2DB() {
		if (( isset( $_SESSION['gids'] ) && isset( $_SESSION['log'] ) )) {
			regGetIdByLogin( $_SESSION['log'] );
			$q = db_query( 'select itemID from ' . SHOPPING_CARTS_TABLE . ' where customerID=' . $customerID );
			$items = array(  );

			if ($item = $customerID = db_fetch_row( $q )) {
				$items[] = $item['itemID'];
			}

			foreach ($_SESSION['gids'] as $key => $productID) {

				if ($productID == 0) {
					continue;
				}

				$itemID = null;
				$j = 879;

				while ($j < count( $items )) {
					$q = db_query( 'select count(*) from ' . SHOPPING_CART_ITEMS_TABLE . ' where productID=' . $productID . ' AND ' . ' itemID=' . $items[$j] );
					$count = db_fetch_row( $q );
					$count = $count[0];

					if ($count != 0) {
						$configurationFromSession = $_SESSION['configurations'][$key];
						$configurationFromDB = GetConfigurationByItemId( $items[$j] );

						if (CompareConfiguration( $configurationFromSession, $configurationFromDB )) {
							$itemID = $items[$j];
							break;
						}

						$itemID = $items[$j];
					}

					++$j;
				}


				if ($itemID == null) {
					if (!( db_query( 'insert into ' . SHOPPING_CART_ITEMS_TABLE . ' (productID) values(\'' . $productID . '\')
' ))) {
						exit( db_error(  ) );
						(bool)true;
					}

					$itemID = db_insert_id(  );
					foreach ($_SESSION['configurations'][$key] as $var) {

						if (!( db_query( 'insert into ' . SHOPPING_CART_ITEMS_CONTENT_TABLE . ' ( itemID, variantID ) ' . ' values( \'' . $itemID . '\', \'' . $var . '\' )
' ))) {
							exit( db_error(  ) );
							(bool)true;
						}
					}


					if (!( db_query( 'insert ' . SHOPPING_CARTS_TABLE . '(customerID, itemID, Quantity)' . 'values( \'' . $customerID . '\', \'' . $itemID . '\', \'' . $_SESSION['counts'][$key] . '\' )
' ))) {
						exit( db_error(  ) );
						(bool)true;
					}

					continue;
				}


				if (!( db_query( 'update ' . SHOPPING_CARTS_TABLE . ' set Quantity=Quantity + ' . $_SESSION['counts'][$key] . ' ' . ' where customerID=' . $customerID . ' and itemID=' . $itemID . '
' ))) {
					exit( db_error(  ) );
					(bool)true;
				}
			}

			unset( $_SESSION[gids] );
			unset( $_SESSION[counts] );
			unset( $_SESSION[configurations] );
		}

	}

	function validate_search_string($s) {
		str_replace( '%', '', $s );
		str_replace( '_', '', $s );
		stripslashes( $s );
		$s = $s = $s = $s = str_replace( '\'', '\\'', $s );
		return $s;
	}

	function string_encode($s) {
		$result = base64_encode( $s );
		return $result;
	}

	function string_decode($s) {
		$result = base64_decode( $s );
		return $result;
	}

	function ScanPostVariableWithId($varnames) {
		$data = array(  );
		foreach ($varnames as $name) {
			foreach ($_POST as $key => $value) {

				if (strstr( $key, $name . '_' )) {
					$key = str_replace( $name . '_', '', $key );
					$data[$key][$name] = $value;
					continue;
				}
			}
		}

		return $data;
	}

	function ScanGetVariableWithId($varnames) {
		$data = array(  );
		foreach ($varnames as $name) {
			foreach ($_GET as $key => $value) {

				if (strstr( $key, $name . '_' )) {
					$key = str_replace( $name . '_', '', $key );
					$data[$key][$name] = $value;
					continue;
				}
			}
		}

		return $data;
	}

	function value($variable) {
		if (!empty( $$variable )) {
			return 'undefined';
		}

		$res = '';

		if (is_null( $variable )) {
			$res .= 'NULL';
		} 
else {
			if (is_array( $variable )) {
				$res .= '<b>array</b>';
				$res .= '<ul>';
				foreach ($variable as $key => $value) {
					$res .= '<li>';
					$res .= '[ ' . value( $key ) . ' ]=' . value( $value );
					$res .= '</li>';
				}

				$res .= '</ul>';
			} 
else {
				if (is_int( $variable )) {
					$res .= '<b>integer</b>
';
					$res .= (bool)$variable;
				} 
else {
					if (is_bool( $variable )) {
						$res .= '<b>bool</b>
';

						if ($variable) {
							$res .= '<i>True</i>';
						} 
else {
							$res .= '<i>False</i>';
						}
					} 
else {
						if (is_string( $variable )) {
							$res .= '<b>string</b>
';
							$res .= '\'' . (bool)$variable . '\'';
						} 
else {
							if (is_float( $variable )) {
								$res .= '<b>float</b>
';
								$res .= (bool)$variable;
							}
						}
					}
				}
			}
		}

		return $res;
	}

	function debug($variable) {
		if (!empty( $$variable )) {
			echo 'undefined';
			return null;
		}

		echo value( $variable ) . '<br>';
	}

	function set_query($_vars, $_request = '', $_store = false) {
		if (!$_request) {
			global $_SERVER;

			$_request = $_SERVER['REQUEST_URI'];
		}

		$_anchor = '';
		$_anchor = @explode( '#', $_request )[1];
		[0];
		$_request = ;

		if (strpos( $_vars, '#' ) !== false) {
			$_anchor = @explode( '#', $_vars )[1];
			[0];
			$_vars = ;
		}


		if (( !$_vars && !$_anchor )) {
			return preg_replace( '|\?.*$|', '', $_request ) . ($_anchor ? '#' . $_anchor : '');
		}


		if (( !$_vars && $_anchor )) {
			return $_request . '#' . $_anchor;
		}

		$_rvars = array(  );
		$tr_vars = explode( '&', (strpos( $_request, '?' ) !== false ? preg_replace( '|.*\?|', '', $_request ) : '') );
		foreach ($tr_vars as $_var) {
			$_t = explode( '=', $_var );

			if ($_t[0]) {
				$_rvars[$_t[0]] = $_t[1];
				continue;
			}
		}

		$tr_vars = explode( '&', preg_replace( array( '|^\&|', '|^\?|' ), '', $_vars ) );
		foreach ($tr_vars as $_var) {
			$_t = explode( '=', $_var );

			if (!$_t[1]) {
				unset( $_rvars[$_t[0]] );
				continue;
			}

			$_rvars[$_t[0]] = $_t[1];
		}

		$tr_vars = array(  );
		foreach ($_rvars as $_var => $_val) {
			$tr_vars[] = ( $_var . '=' ) . $_val;
		}


		if ($_store) {
			global $_SERVER;

			$_request = $_SERVER['REQUEST_URI'];
			$_SERVER['REQUEST_URI'] = preg_replace( '|\?.*$|', '', $_request ) . (count( $tr_vars ) ? '?' . implode( '&', $tr_vars ) : '') . ($_anchor ? '#' . $_anchor : '');
			return $_SERVER['REQUEST_URI'];
		}

		return preg_replace( '|\?.*$|', '', $_request ) . (count( $tr_vars ) ? '?' . implode( '&', $tr_vars ) : '') . ($_anchor ? '#' . $_anchor : '');
	}

	function getListerRange($_pagenumber, $_totalpages, $_lister_num = 20) {
		if ($_pagenumber <= 0) {
			return array( 'start' => 1, 'end' => 1 );
		}

		$lister_start = $_pagenumber - floor( $_lister_num / 2 );
		$lister_start = ($lister_start + $_lister_num <= $_totalpages ? $lister_start : $_totalpages - $_lister_num + 1);
		$lister_start = (0 < $lister_start ? $lister_start : 1);
		$lister_end = $lister_start + $_lister_num - 1;
		$lister_end = ($lister_end <= $_totalpages ? $lister_end : $_totalpages);
		return array( 'start' => $lister_start, 'end' => $lister_end );
	}

	function html_spchars($_data) {
		if (is_array( $_data )) {
			foreach ($_data as $_ind => $_val) {
				$_data[$_ind] = html_spchars( $_val );
			}

			return $_data;
		}

		return htmlspecialchars( $_data, ENT_QUOTES );
	}

	function xStripSlashesGPC($_data) {
		if (!get_magic_quotes_gpc(  )) {
			return $_data;
		}


		if (is_array( $_data )) {
			foreach ($_data as $_ind => $_val) {
				$_data[$_ind] = xStripSlashesGPC( $_val );
			}

			return $_data;
		}

		return stripslashes( $_data );
	}

	function TransformTemplateToDATE($_date, $_template = '') {
		if (!$_template) {
			$_template = CONF_DATE_FORMAT;
		}


		if (stripos( strrev( $_template ), 'ilalaj' )) {
			substr( $_date, strpos( $_template, 'DD' ), 2 );
			substr( $_date, strpos( $_template, 'MM' ), 2 );
			$month = $_template = 'YYYY-MM-DD';
			$year = $day = substr( $_date, strpos( $_template, 'YYYY' ), 4 );
			return gregorian( $year, $month, $day );
		}

		substr( $_date, strpos( $_template, 'DD' ), 2 );
		$month = substr( $_date, strpos( $_template, 'MM' ), 2 );
		$year = $day = substr( $_date, strpos( $_template, 'YYYY' ), 4 );
		return ( ( ( $year . '-' ) . $month . '-' ) . $day . ' ' );
	}

	function TransformDATEToTemplate($_date, $_template = '') {
		if (!$_template) {
			$_template = CONF_DATE_FORMAT;
		}

		preg_match( '|(\d{4})-(\d{2})-(\d{2})|', $_date, $mathes );
		unset( $mathes[0] );

		if (stripos( strrev( $_template ), 'ilalaj' )) {
			return jdate( 'Y/m/d', strtotime( $_date ) );
		}

		return str_replace( array( 'YYYY', 'MM', 'DD' ), $mathes, $_template );
	}

	function isTemplateDate($_date, $_template = '') {
		if (!$_template) {
			$_template = CONF_DATE_FORMAT;
		}


		if (stripos( strrev( $_template ), 'ilalaj' )) {
			$expd = explode( '/', $_date, 3 );
			return !jcheckdate( $expd[0], $expd[1], $expd[2] );
		}

		$ok = ( strlen( $_date ) == strlen( $_template ) && preg_replace( '|\d{2}|', '', $_date ) == str_replace( array( 'MM', 'DD', 'YYYY' ), '', $_template ) );
		$ok = ( ( $ok && substr( $_date, strpos( $_template, 'DD' ), 2 ) < 32 ) && substr( $_date, strpos( $_template, 'MM' ), 2 ) < 13 );
		return $ok;
	}

	function xMailTxt($_Email, $_Subject, $_TemplateName, $_AssignArray = array(  )) {
		if (!$_Email) {
			return 0;
		}

		$mailSmarty = new Smarty(  );
		foreach ($_AssignArray as $_var => $_val) {
			$mailSmarty->assign( $_var, $_val );
		}

		$_t = $mailSmarty->fetch( 'email/' . $_TemplateName );
		$msg = '<table cellpadding="0" cellspacing="0" style="width: 657px;" align="center" dir="rtl" style="font-family:Tahoma; font-size:8pt">
		  <tr><td>' . $_t . '</td></tr></table>';
		$headers = 'MIME-Version: 1.0
' . 'Content-type: text/html; charset=utf-8
' . 'From: "' . CONF_SHOP_NAME_LATIN . '" ' . CONF_ORDERS_EMAIL . '
';

		if ($msg) {
			$_Subject = '=?UTF-8?B?' . base64_encode( $_Subject ) . '?=';
			$result = sendEmail( $_Email, $_Subject, $msg, $headers );
		}

	}

	function xNl2Br($_Data, $_Key = array(  )) {
		if (!is_array( $_Data )) {
			return nl2br( $_Data );
		}


		if (!is_array( $_Key )) {
			$_Key = array( $_Key );
		}

		foreach ($_Data as $__Key => $__Data) {

			if (( count( $_Key ) && !is_array( $__Data ) )) {
				if (in_array( $__Key, $_Key )) {
					$_Data[$__Key] = xNl2Br( $__Data, $_Key );
					continue;
				}

				continue;
			}

			$_Data[$__Key] = xNl2Br( $__Data, $_Key );
		}

		return $_Data;
	}

	function xStripSlashesHTMLspecialChars($_Data) {
		return html_spchars( xStripSlashesGPC( $_Data ) );
	}

	function xStrReplace($_Search, $_Replace, $_Data, $_Key = array(  )) {
		if (!is_array( $_Data )) {
			return str_replace( $_Search, $_Replace, $_Data );
		}


		if (!is_array( $_Key )) {
			$_Key = array( $_Key );
		}

		foreach ($_Data as $__Key => $__Data) {

			if (( count( $_Key ) && !is_array( $__Data ) )) {
				if (in_array( $__Key, $_Key )) {
					$_Data[$__Key] = xStrReplace( $_Search, $_Replace, $__Data, $_Key );
					continue;
				}

				continue;
			}

			$_Data[$__Key] = xStrReplace( $_Search, $_Replace, $__Data, $_Key );
		}

		return $_Data;
	}

	function xHtmlSpecialChars($_Data, $_Params = array(  ), $_Key = array(  )) {
		if (!is_array( $_Data )) {
			return htmlspecialchars( $_Data, ENT_QUOTES );
		}


		if (!is_array( $_Key )) {
			$_Key = array( $_Key );
		}

		foreach ($_Data as $__Key => $__Data) {

			if (( count( $_Key ) && !is_array( $__Data ) )) {
				if (in_array( $__Key, $_Key )) {
					$_Data[$__Key] = xHtmlSpecialChars( $__Data, $_Params, $_Key );
					continue;
				}

				continue;
			}

			$_Data[$__Key] = xHtmlSpecialChars( $__Data, $_Params, $_Key );
		}

		return $_Data;
	}

	function xEscapeSQLstring($_Data, $_Params = array(  ), $_Key = array(  )) {
		if (!is_array( $_Data )) {
			return mysql_escape_string( $_Data );
		}


		if (!is_array( $_Key )) {
			$_Key = array( $_Key );
		}

		foreach ($_Data as $__Key => $__Data) {

			if (( count( $_Key ) && !is_array( $__Data ) )) {
				if (in_array( $__Key, $_Key )) {
					$_Data[$__Key] = xEscapeSQLstring( $__Data, $_Params, $_Key );
					continue;
				}

				continue;
			}

			$_Data[$__Key] = xEscapeSQLstring( $__Data, $_Params, $_Key );
		}

		return $_Data;
	}

	function xSaveData($_ID, $_Data, $_TimeControl = 0) {
		if (!isset( $_SESSION['_xSAVE_DATA'] )) {
			$_SESSION['_xSAVE_DATA'] = array(  );
		}


		if (intval( $_TimeControl )) {
			$_SESSION['_xSAVE_DATA'][$_ID] = array( $_ID . '_DATA' => $_Data, $_ID . '_TIME_CTRL' => array( 'timetag' => time(  ), 'timelimit' => $_TimeControl ) );
			return null;
		}

		$_SESSION['_xSAVE_DATA'][$_ID] = $_Data;
	}

	function xPopData($_ID) {
		if (!isset( $_SESSION['_xSAVE_DATA'][$_ID] )) {
			return null;
		}


		if (is_array( $_SESSION['_xSAVE_DATA'][$_ID] )) {
			if (isset( $_SESSION['_xSAVE_DATA'][$_ID][$_ID . '_TIME_CTRL'] )) {
				if ($_SESSION['_xSAVE_DATA'][$_ID][$_ID . '_TIME_CTRL']['timetag'] + $_SESSION['_xSAVE_DATA'][$_ID][$_ID . '_TIME_CTRL']['timelimit'] < time(  )) {
					return null;
				}

				$Return = $_SESSION['_xSAVE_DATA'][$_ID][$_ID . '_DATA'];
				unset( $_SESSION['_xSAVE_DATA'][$_ID] );
				return $Return;
			}
		}

		$Return = $_SESSION['_xSAVE_DATA'][$_ID];
		unset( $_SESSION['_xSAVE_DATA'][$_ID] );
		return $Return;
	}

	function xDataExists($_ID) {
		if (!isset( $_SESSION['_xSAVE_DATA'][$_ID] )) {
			return 0;
		}


		if (is_array( $_SESSION['_xSAVE_DATA'][$_ID] )) {
			if (isset( $_SESSION['_xSAVE_DATA'][$_ID][$_ID . '_TIME_CTRL'] )) {
				if (time(  ) <= $_SESSION['_xSAVE_DATA'][$_ID][$_ID . '_TIME_CTRL']['timetag'] + $_SESSION['_xSAVE_DATA'][$_ID][$_ID . '_TIME_CTRL']['timelimit']) {
					return 1;
				}

				return 0;
			}

			return 1;
		}

		return 1;
	}

	function xGetData($_ID) {
		if (!isset( $_SESSION['_xSAVE_DATA'][$_ID] )) {
			return null;
		}


		if (is_array( $_SESSION['_xSAVE_DATA'][$_ID] )) {
			if (isset( $_SESSION['_xSAVE_DATA'][$_ID][$_ID . '_TIME_CTRL'] )) {
				if ($_SESSION['_xSAVE_DATA'][$_ID][$_ID . '_TIME_CTRL']['timetag'] + $_SESSION['_xSAVE_DATA'][$_ID][$_ID . '_TIME_CTRL']['timelimit'] < time(  )) {
					return null;
				}

				$Return = $_SESSION['_xSAVE_DATA'][$_ID][$_ID . '_DATA'];
				return $Return;
			}
		}

		$Return = $_SESSION['_xSAVE_DATA'][$_ID];
		return $Return;
	}

	function isWindows() {
		if (isset( $_SERVER['WINDIR'] )) {
			return true;
		}

		return false;
	}

	function generateRndCode($_RndLength, $_RndCodes = 'qwertyuiopasdfghjklzxcvbnm0123456789') {
		$l_name = '';
		$top = strlen( $_RndCodes ) - 1;
		srand( (double)microtime(  ) * 1000000 );
		$j = 719;

		while ($j < $_RndLength) {
			$l_name .= $_RndCodes[rand( 0, $top )];
			++$j;
		}

		return $l_name;
	}

	function hashish($input) {
		md5( $input );
		$result = ;
		return $result;
	}

	function getUcreditByLogin($login) {
		$q = db_query( 'SELECT credit from ' . CUSTOMERS_TABLE . ' WHERE Login = \'' . $login . '\'' );
		$res = db_fetch_row( $q );
		return $res['credit'];
	}

	function getUcreditByID($customerID) {
		$q = db_query( 'SELECT credit from ' . CUSTOMERS_TABLE . ' WHERE customerID = ' . $customerID );
		$res = db_fetch_row( $q );
		return $res['credit'];
	}

	function updateUserCreditByLogin($login, $newCredit) {
		db_query( 'UPDATE ' . CUSTOMERS_TABLE . ( ' SET credit=' . $newCredit . ' WHERE Login= \'' ) . $login . '\'' );
	}

	function fa_get_persian_number($number, $do_format = false) {
		$num_covmap = array( '0' => chr( 219 ) . chr( 176 ), chr( 219 ) . chr( 177 ), chr( 219 ) . chr( 178 ), chr( 219 ) . chr( 179 ), chr( 219 ) . chr( 180 ), chr( 219 ) . chr( 181 ), chr( 219 ) . chr( 182 ), chr( 219 ) . chr( 183 ), chr( 219 ) . chr( 184 ), chr( 219 ) . chr( 185 ) );
		$th_separator = chr( 217 ) . chr( 172 );

		if ($do_format) {
			$number = number_format( $number );
		}

		$number = strtr( $number, $num_covmap );

		if ($do_format) {
			$number = str_replace( ',', $th_separator, $number );
		}

		return $number;
	}

	function mail2utf8($text) {
		$text = ;
		$text = wordwrap( $text, 25, '
', false );
		implode( '
 ', $text );
		$text = explode( '
', $text );
		return $text;
	}

	function checkPath($_path, $dont_check_path = '.') {
		if (file_exists( $_path )) {
			return true;
		}

		realpath( $dont_check_path );
		str_replace( '\\', '/', $_path );
		explode( '/', $_path );
		$fldNum = $explFolders = $_path = $dont_check_path = count( $explFolders );
		$wer = 752;

		while ($wer < $fldNum) {
			$tPath = '';
			$qwe = 752;

			while ($qwe <= $wer) {
				$tPath .= $explFolders[$qwe] . '/';
				++$qwe;
			}


			if (( $dont_check_path && strpos( $dont_check_path, $tPath ) === 0 )) {
				continue;
			}


			if (( !file_exists( $tPath ) && $tPath )) {
				mkdir( $tPath );
			}

			++$wer;
		}

		return true;
	}

	function rand_name($_length = 4) {
		$rand_simb = 'qwertyuiopasdfghjklzxcvbnm0123456789';
		$l_name = '';
		$top = strlen( $rand_simb ) - 1;
		srand( (double)microtime(  ) * 1000000 );
		$j = 718;

		while ($j < $_length) {
			$l_name .= $rand_simb[rand( 0, $top )];
			++$j;
		}

		return $l_name;
	}

	function getUnicFile($_length = 4, $_tpl = '%s', $_path = './') {
		$fname = $_tpl;
		$limit = 715;

		do {
			$fname = sprintf( $_tpl, rand_name( $_length ) );
		}while (!( ( file_exists( $_path . $fname ) && 300 < $limit++ )));

		return $fname;
	}

	function translate($string) {
		global $LocalizationStrings;

		if (( empty( $$LocalizationStrings ) && is_array( $LocalizationStrings ) )) {
			return (isset( $LocalizationStrings[$string] ) ? $LocalizationStrings[$string] : $string);
		}

		return $string;
	}

	function scanArrayKeysForID($a, $varnames) {
		if (!is_array( $varnames )) {
			$varnames = array( $varnames );
		}

		$data = array(  );
		foreach ($varnames as $name) {
			foreach ($a as $value) {

				if (preg_match( '/^(' . $name . ')_/', $key, $kp )) {
					$key = preg_replace( '/^' . $name . '_/', '', $key );
					$data[$key][$kp[1]] = $value;
					continue;
				}
			}
		}

		return $data;
	}

	function irenderURL($_vars = '', $_request = '', $_store = false, $furl = null, $external = false) {
		$RenderedURL = '';

		if (!$_request) {
			$_request = $_SERVER['REQUEST_URI'];
			$GetVars = $_GET;
		}


		if (!MOD_REWRITE_SUPPORT) {
			if (( strpos( $_request, 'index.php' ) === false && !$external )) {
				if (strpos( $_request, '?' )) {
					$_request = str_replace( '?', 'index.php?', $_request );
				} 
else {
					$_request = 'index.php?' . $_request;
				}
			}


			if (preg_match( '/^\?categoryID=(\d+)\&category_slug=[a-z0-9_]+$/i', $_vars, $matches )) {
				$_vars = '?categoryID=' . $matches[1];
			}


			if (preg_match( '/^\?ukey=product\&productID=(\d+)\&product_slug=[a-z0-9_\-]+$/i', $_vars, $matches )) {
				$_vars = '?productID=' . $matches[1];
			}
		}

		$anchor = (preg_match( '@(#[^#]*)$@', $_request, $sp ) ? $sp[1] : '');
		$anchor = (preg_match( '@(#[^#]*)$@', $_vars, $sp ) ? $sp[1] : $anchor);

		if (strpos( $_vars, '?' ) !== false) {
			$Mode = URLRENDMODE_RESET;
			$_vars = substr( $_vars, 1, strlen( $_vars ) - 1 ) . '&lang_iso2=';
		} 
else {
			$Mode = URLRENDMODE_MODIFY;
		}


		if (strpos( $_vars, '&' ) === 0) {
			$_vars = substr( $_vars, 1, strlen( $_vars ) - 1 );
		}

		$ReceivedTokens = array(  );
		$r_TokenStrs = explode( '&', $_vars );
		$widgets_token = false;
		foreach ($r_TokenStrs as $TokenStr) {
			$r_Token = explode( '=', $TokenStr, 2 );

			if ($r_Token[0] == 'widgets') {
				$widgets_token = true;
			}


			if ($r_Token[0] == 'store_mode') {
				$mode_token = true;
			}


			if (( isset( $r_Token[1] ) && strlen( $r_Token[1] ) )) {
				$ReceivedTokens[$r_Token[0]] = $r_Token[1];

				if ($Mode == URLRENDMODE_MODIFY) {
					$GetVars[$r_Token[0]] = $r_Token[1];
					continue;
				}

				continue;
			}

			switch ($Mode) {
				case URLRENDMODE_MODIFY: {
					if (isset( $GetVars[$r_Token[0]] )) {
						unset( $GetVars[$r_Token[0]] );
					}

					break;
				}

				case URLRENDMODE_RESET: {
					if (( ( isset( $GetVars[$r_Token[0]] ) && $r_Token[0] != 'product_slug' ) && $r_Token[0] != 'category_slug' )) {
						$ReceivedTokens[$r_Token[0]] = $GetVars[$r_Token[0]];
					}

					break;
					break;
				}
			}
		}
	}

	function langinstall() {
		$langs = explode( ',', INSTALL_LANGS );
		$plangs = explode( ',', INSTALL_PROPS );
		$i = 746;
		foreach ($langs as $lang) {
			$pcheck = explode( ';', $plangs[$i] );
			$dbq = 'INSERT ' . LANGUAGE_TABLE . ' (`name`,`thumbnail`, `enabled`, `priority`, `iso2`, `direction`,`isdefault`)
					VALUES(\'' . $pcheck[0] . '\',\'' . $pcheck[2] . '\' ,' . $pcheck[1] . ' ,' . $pcheck[4] . ' ,\'' . $pcheck[3] . '\' ,' . $pcheck[5] . ' ,' . $pcheck[6] . ')';
			$DBRes = db_query( $dbq );
			++$i;
		}

	}

	function mainsettingInstall() {
		$setting_Groups = explode( ',', INSTALL_SETTING_GROUPS );
		$i = 727;
		foreach ($setting_Groups as $s_group) {
			$pcheck = explode( ';', $s_group );
			$dbq = 'INSERT ' . SETTINGS_GROUPS_TABLE . ' (settings_groupID, settings_group_name, sort_order)
					VALUES(' . $pcheck[0] . ',\'' . $pcheck[1] . '\' ,' . $pcheck[2] . ' )';
			$DBRes = db_query( $dbq );
			++$i;
		}

	}

	function is_image($file) {
		if (!preg_match( '/\.(jpg|jpeg|jpe|gif|pcx|bmp|png)$/i', $file, $r )) {
			return false;
		}

		return $r[1];
	}

	function renderURL($_vars = '', $_request = '', $_store = false, $furl = null, $external = false) {
		$RenderedURL = '';

		if (!MOD_REWRITE_SUPPORT) {
			if (trim( $_request ) == '') {
				$_request = $_SERVER['REQUEST_URI'];
				$GetVars = $_GET;
				$GetVars = renderGetVars( $_request );
			}


			if (( strpos( $_request, 'index.php' ) === false && !$external )) {
				if (strpos( $_request, '?' )) {
					$_request = str_replace( '?', 'index.php?', $_request );
				} 
else {
					$_request .= 'index.php';
				}
			}


			if (preg_match( '/^\?categoryID=(\d+)\&category_slug=[a-z0-9_]+$/i', $_vars, $matches )) {
				$_vars = '?categoryID=' . $matches[1];
			}


			if (preg_match( '/^\?ukey=product\&productID=(\d+)\&product_slug=[a-z0-9_\-]+$/i', $_vars, $matches )) {
				$_vars = '?productID=' . $matches[1];
			}
		}


		if ($_request == '') {
			$tempPath1 = explode( '/', str_replace( '\\', '/', dirname( $_SERVER['SCRIPT_FILENAME'] ) ) );
			$tempPath2 = explode( '/', substr( ABSPATH, 0, -1 ) );
			$tempPath3 = explode( '/', str_replace( '\\', '/', dirname( $_SERVER['PHP_SELF'] ) ) );
			$i = count( $tempPath2 );

			while ($i < count( $tempPath1 )) {
				array_pop( $tempPath3 );
				++$i;
			}

			$urladdr = $_SERVER['HTTP_HOST'] . implode( '/', $tempPath3 );

			if ($urladdr[strlen( $urladdr ) - 1] == '/') {
				$_request = (( isset( $_SERVER['HTTPS'] ) && strtolower( $_SERVER['HTTPS'] ) != 'off' ) ? 'https://' : 'http://') . $urladdr;
			} 
else {
				$_request = (( isset( $_SERVER['HTTPS'] ) && strtolower( $_SERVER['HTTPS'] ) != 'off' ) ? 'https://' : 'http://') . $urladdr . '/';
			}
		}

		$anchor = (preg_match( '@(#[^#]*)$@', $_request, $sp ) ? $sp[1] : '');
		$anchor = (preg_match( '@(#[^#]*)$@', $_vars, $sp ) ? $sp[1] : $anchor);

		if (strpos( $_vars, '?' ) !== false) {
			$Mode = URLRENDMODE_RESET;
			$_vars = substr( $_vars, 1, strlen( $_vars ) - 1 ) . '&lang_iso2=';
		} 
else {
			$Mode = URLRENDMODE_MODIFY;
		}


		if (strpos( $_vars, '&' ) === 0) {
			$_vars = substr( $_vars, 1, strlen( $_vars ) - 1 );
		}

		$ReceivedTokens = array(  );
		$r_TokenStrs = explode( '&', $_vars );
		$widgets_token = false;
		foreach ($r_TokenStrs as $TokenStr) {
			$r_Token = explode( '=', $TokenStr, 2 );

			if ($r_Token[0] == 'store_mode') {
				$mode_token = true;
			}


			if (( isset( $r_Token[1] ) && strlen( $r_Token[1] ) )) {
				$ReceivedTokens[$r_Token[0]] = $r_Token[1];

				if ($Mode == URLRENDMODE_MODIFY) {
					$GetVars[$r_Token[0]] = $r_Token[1];
					continue;
				}

				continue;
			}

			switch ($Mode) {
				case URLRENDMODE_MODIFY: {
					if (isset( $GetVars[$r_Token[0]] )) {
						unset( $GetVars[$r_Token[0]] );
					}

					break;
				}

				case URLRENDMODE_RESET: {
					if (( ( isset( $GetVars[$r_Token[0]] ) && $r_Token[0] != 'product_slug' ) && $r_Token[0] != 'category_slug' )) {
						$ReceivedTokens[$r_Token[0]] = $GetVars[$r_Token[0]];
					}

					break;
					break;
				}
			}
		}
	}

	function renderGetVars($URL) {
		$GetVars = array(  );
		$parsedURL = parse_url( $URL );

		if (( isset( $parsedURL['query'] ) && $parsedURL['query'] )) {
			$r_TokenStrs = explode( '&', $parsedURL['query'] );
			foreach ($r_TokenStrs as $TokenStr) {
				$r_Token = explode( '=', $TokenStr, 2 );

				if (isset( $r_Token[1] )) {
					$GetVars[$r_Token[0]] = $r_Token[1];
					continue;
				}
			}
		}

		return $GetVars;
	}

	function xHtmlSetQuery($_vars = '', $_request = '', $_store = false) {
		return xHtmlSpecialChars( renderURL( $_vars, $_request, $_store ) );
	}

	function build_uri($app, $params, $append = '', $page = 0, $keywords = '', $size = 0) {
		static $rewrite = null;

		if ($rewrite === null) {
			$rewrite = _getSettingOptionValue( 'rewrite' );
		}

		$args = array( 'cid' => 0, 'gid' => 0, 'bid' => 0, 'acid' => 0, 'aid' => 0, 'sid' => 0, 'gbid' => 0, 'auid' => 0, 'title' => '', 'sort' => '', 'order' => '' );
		extract( array_merge( $args, $params ) );
		$uri = '';
		switch ($app) {
			case 'category': {
				if (empty( $$cid )) {
					return false;
				}


				if ($rewrite) {
					$uri = 'category-' . $cid;

					if (empty( $$bid )) {
						$uri .= '-b' . $bid;
					}


					if (empty( $$price_min )) {
						$uri .= '-min' . $price_min;
					}


					if (empty( $$price_max )) {
						$uri .= '-max' . $price_max;
					}


					if (empty( $$filter_attr )) {
						$uri .= '-attr' . $filter_attr;
					}


					if (!empty( $$page )) {
						$uri .= '-' . $page;
					}


					if (!empty( $$sort )) {
						$uri .= '-' . $sort;
					}


					if (!empty( $$order )) {
						$uri .= '-' . $order;
					}
				} 
else {
					$uri = '?categoryID=' . $cid;

					if (!empty( $$bid )) {
						$uri .= '&amp;brand=' . $bid;
					}


					if (empty( $$price_min )) {
						$uri .= '&amp;price_min=' . $price_min;
					}


					if (empty( $$price_max )) {
						$uri .= '&amp;price_max=' . $price_max;
					}


					if (!empty( $$filter_attr )) {
						$uri .= '&amp;filter_attr=' . $filter_attr;
					}


					if (!empty( $$page )) {
						$uri .= '&amp;page=' . $page;
					}


					if (!empty( $$sort )) {
						$uri .= '&amp;sort=' . $sort;
					}


					if (!empty( $$order )) {
						$uri .= '&amp;order=' . $order;
					}
				}

				break;
			}

			case 'goods': {
				if (empty( $$gid )) {
					return false;
				}

				$uri = ($rewrite ? 'goods-' . $gid : 'goods.php?id=' . $gid);
				break;
			}

			case 'brand': {
				if (empty( $$bid )) {
					return false;
				}


				if ($rewrite) {
					$uri = 'brand-' . $bid;

					if (empty( $$cid )) {
						$uri .= '-c' . $cid;
					}


					if (!empty( $$page )) {
						$uri .= '-' . $page;
					}


					if (!empty( $$sort )) {
						$uri .= '-' . $sort;
					}


					if (!empty( $$order )) {
						$uri .= '-' . $order;
					}
				} 
else {
					$uri = 'brand.php?id=' . $bid;

					if (!empty( $$cid )) {
						$uri .= '&amp;cat=' . $cid;
					}


					if (!empty( $$page )) {
						$uri .= '&amp;page=' . $page;
					}


					if (!empty( $$sort )) {
						$uri .= '&amp;sort=' . $sort;
					}


					if (!empty( $$order )) {
						$uri .= '&amp;order=' . $order;
					}
				}

				break;
			}

			case 'article_cat': {
				if (empty( $$acid )) {
					return false;
				}


				if ($rewrite) {
					$uri = 'article_cat-' . $acid;

					if (!empty( $$page )) {
						$uri .= '-' . $page;
					}


					if (!empty( $$sort )) {
						$uri .= '-' . $sort;
					}


					if (!empty( $$order )) {
						$uri .= '-' . $order;
					}


					if (!empty( $$keywords )) {
						$uri .= '-' . $keywords;
					}
				} 
else {
					$uri = 'article_cat.php?id=' . $acid;

					if (!empty( $$page )) {
						$uri .= '&amp;page=' . $page;
					}


					if (!empty( $$sort )) {
						$uri .= '&amp;sort=' . $sort;
					}


					if (!empty( $$order )) {
						$uri .= '&amp;order=' . $order;
					}


					if (!empty( $$keywords )) {
						$uri .= '&amp;keywords=' . $keywords;
					}
				}

				break;
			}

			case 'page': {
				if (empty( $$aid )) {
					return false;
				}

				$uri = ($rewrite ? '/page/' . $aid . '/' . $title . '/' : 'index.php?page=' . $aid . '&view_slug=' . $title);
				break;
			}

			case 'product': {
				if (empty( $$aid )) {
					return false;
				}

				$uri = ($rewrite ? ( ( '/product/' . $aid . '/' ) . $title . '/' ) : 'index.php?productID=' . $aid);
				break;
			}

			case 'auction': {
				if (empty( $$auid )) {
					return false;
				}

				$uri = ($rewrite ? 'auction-' . $auid : 'auction.php?act=view&amp;id=' . $auid);
				break;
			}

			case 'snatch': {
				if (empty( $$sid )) {
					return false;
				}

				$uri = ($rewrite ? 'snatch-' . $sid : 'snatch.php?id=' . $sid);
				break;
			}

			case 'search': {
				break;
			}

			case 'exchange': {
				if ($rewrite) {
					$uri = 'exchange-' . $cid;

					if (empty( $$price_min )) {
						$uri .= '-min' . $price_min;
					}


					if (empty( $$price_max )) {
						$uri .= '-max' . $price_max;
					}


					if (!empty( $$page )) {
						$uri .= '-' . $page;
					}


					if (!empty( $$sort )) {
						$uri .= '-' . $sort;
					}


					if (!empty( $$order )) {
						$uri .= '-' . $order;
					}
				} 
else {
					$uri = 'exchange.php?cat_id=' . $cid;

					if (empty( $$price_min )) {
						$uri .= '&amp;integral_min=' . $price_min;
					}


					if (empty( $$price_max )) {
						$uri .= '&amp;integral_max=' . $price_max;
					}


					if (!empty( $$page )) {
						$uri .= '&amp;page=' . $page;
					}


					if (!empty( $$sort )) {
						$uri .= '&amp;sort=' . $sort;
					}


					if (!empty( $$order )) {
						$uri .= '&amp;order=' . $order;
					}
				}

				break;
			}

			case 'exchange_goods': {
				if (empty( $$gid )) {
					return false;
				}

				$uri = ($rewrite ? 'exchange-id' . $gid : 'exchange.php?id=' . $gid . '&amp;act=view');
				break;
			}
		}

		return false;
	}

	function page_and_size($filter) {
		if (( isset( $_REQUEST['page_size'] ) && 0 < intval( $_REQUEST['page_size'] ) )) {
			$filter['page_size'] = intval( $_REQUEST['page_size'] );
		} 
else {
			if (( isset( $_COOKIE['ECSCP']['page_size'] ) && 0 < intval( $_COOKIE['ECSCP']['page_size'] ) )) {
				$filter['page_size'] = intval( $_COOKIE['ECSCP']['page_size'] );
			} 
else {
				$filter['page_size'] = 15;
			}
		}

		$filter['page'] = (( empty( $_REQUEST['page'] ) || intval( $_REQUEST['page'] ) <= 0 ) ? 1 : intval( $_REQUEST['page'] ));
		$filter['page_count'] = (( !empty( $filter['record_count'] ) && 0 < $filter['record_count'] ) ? ceil( $filter['record_count'] / $filter['page_size'] ) : 1);

		if ($filter['page_count'] < $filter['page']) {
			$filter['page'] = $filter['page_count'];
		}

		$filter['start'] = ( $filter['page'] - 1 ) * $filter['page_size'];
		return $filter;
	}

	function selectLimit($sql, $num, $start = 0) {
		if ($start == 0) {
			$sql .= ' LIMIT ' . $num;
		} 
else {
			$sql .= ' LIMIT ' . $start . ', ' . $num;
		}

		return db_query( $sql );
	}

	function sort_flag($filter) {
		$flag['tag'] = 'sort_' . preg_replace( '/^.*\./', '', $filter['sort_by'] );
		$flag['img'] = '<img src="images/' . ($filter['sort_order'] == 'DESC' ? 'sort_desc.gif' : 'sort_asc.gif') . '"/>';
		return $flag;
	}

	function check_file_type($filename, $realname = '', $limit_ext_types = '') {
		if ($realname) {
			$extname = strtolower( substr( $realname, strrpos( $realname, '.' ) + 1 ) );
		} 
else {
			$extname = strtolower( substr( $filename, strrpos( $filename, '.' ) + 1 ) );
		}


		if (( $limit_ext_types && stristr( $limit_ext_types, '|' . $extname . '|' ) === false )) {
			return '';
		}

		$str = $format = '';
		$file = @fopen( $filename, 'rb' );

		if ($file) {
			$str = @fread( $file, 1024 );
			@fclose( $file );
		} 
else {
			if (stristr( $filename, ROOT_PATH ) === false) {
				if (( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( ( $extname == 'jpg' || $extname == 'jpeg' ) || $extname == 'gif' ) || $extname == 'png' ) || $extname == 'doc' ) || $extname == 'xls' ) || $extname == 'txt' ) || $extname == 'zip' ) || $extname == 'rar' ) || $extname == 'ppt' ) || $extname == 'pdf' ) || $extname == 'rm' ) || $extname == 'mid' ) || $extname == 'wav' ) || $extname == 'bmp' ) || $extname == 'swf' ) || $extname == 'chm' ) || $extname == 'sql' ) || $extname == 'cert' ) || $extname == 'pptx' ) || $extname == 'xlsx' ) || $extname == 'docx' )) {
					$format = $str;
				}
			} 
else {
				return '';
			}
		}


		if (( $format == '' && 2 <= strlen( $str ) )) {
			if (( substr( $str, 0, 4 ) == 'MThd' && $extname != 'txt' )) {
				$format = 'mid';
			} 
else {
				if (( substr( $str, 0, 4 ) == 'RIFF' && $extname == 'wav' )) {
					$format = 'wav';
				} 
else {
					if (substr( $str, 0, 3 ) == '���') {
						$format = 'jpg';
					} 
else {
						if (( substr( $str, 0, 4 ) == 'GIF8' && $extname != 'txt' )) {
							$format = 'gif';
						} 
else {
							if (substr( $str, 0, 8 ) == '�PNG

') {
								$format = 'png';
							} 
else {
								if (( substr( $str, 0, 2 ) == 'BM' && $extname != 'txt' )) {
									$format = 'bmp';
								} 
else {
									if (( ( substr( $str, 0, 3 ) == 'CWS' || substr( $str, 0, 3 ) == 'FWS' ) && $extname != 'txt' )) {
										$format = 'swf';
									} 
else {
										if (substr( $str, 0, 4 ) == '���') {
											if (( substr( $str, 512, 4 ) == '��' || $extname == 'doc' )) {
												$format = 'doc';
											} 
else {
												if (( substr( $str, 512, 2 ) == '	' || $extname == 'xls' )) {
													$format = 'xls';
												} 
else {
													if (( substr( $str, 512, 4 ) == '����' || $extname == 'ppt' )) {
														$format = 'ppt';
													}
												}
											}
										} 
else {
											if (substr( $str, 0, 4 ) == 'PK') {
												if (( substr( $str, 512, 4 ) == '��' || $extname == 'docx' )) {
													$format = 'docx';
												} 
else {
													if (( substr( $str, 512, 2 ) == '	' || $extname == 'xlsx' )) {
														$format = 'xlsx';
													} 
else {
														if (( substr( $str, 512, 4 ) == '����' || $extname == 'pptx' )) {
															$format = 'pptx';
														} 
else {
															$format = 'zip';
														}
													}
												}
											} 
else {
												if (( substr( $str, 0, 4 ) == 'Rar!' && $extname != 'txt' )) {
													$format = 'rar';
												} 
else {
													if (substr( $str, 0, 4 ) == '%PDF') {
														$format = 'pdf';
													} 
else {
														if (substr( $str, 0, 3 ) == '0�
') {
															$format = 'cert';
														} 
else {
															if (( substr( $str, 0, 4 ) == 'ITSF' && $extname != 'txt' )) {
																$format = 'chm';
															} 
else {
																if (substr( $str, 0, 4 ) == '.RMF') {
																	$format = 'rm';
																} 
else {
																	if ($extname == 'sql') {
																		$format = 'sql';
																	} 
else {
																		if ($extname == 'txt') {
																			$format = 'txt';
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}


		if (( $limit_ext_types && stristr( $limit_ext_types, '|' . $format . '|' ) === false )) {
			$format = '';
		}

		return $format;
	}

	function func_enabled($func) {
		$disabled = explode( ',', ini_get( 'disable_functions' ) );
		foreach ($disabled as $disableFunction) {
			$is_disabled[] = trim( $disableFunction );
		}


		if (in_array( $func, $is_disabled )) {
			$it_is_disabled['m'] = $func . '() has been disabled for security reasons in php.ini';
			$it_is_disabled['s'] = 0;
		} 
else {
			$it_is_disabled['m'] = $func . '() is allow to use';
			$it_is_disabled['s'] = 1;
		}

		return $it_is_disabled;
	}

	function get_system_info() {
		$_LANG['php_os'] = 'سیستم عامل';
		$_LANG['php_ver'] = 'نسخه PHP';
		$_LANG['support'] = 'پشتیبانی می شود';
		$_LANG['not_support'] = 'پشتیبانی نمی کند';
		$_LANG['does_support_mysql'] = 'پایگاه mysql';
		$_LANG['gd_version'] = 'نسخه GD';
		$_LANG['jpg'] = 'تصاویر jpg';
		$_LANG['png'] = 'تصاویر ‍Png';
		$_LANG['gif'] = 'تصاویر Gif';
		$_LANG['safe_mode'] = 'حالت امن';
		$_LANG['safe_mode_off'] = 'خاموش';
		$_LANG['safe_mode_on'] = 'روشن';
		$system_info = array(  );
		$system_info[] = array( $_LANG['php_os'], PHP_OS );
		$system_info[] = array( $_LANG['php_ver'], PHP_VERSION );
		$mysql_enabled = $_LANG['support'];
		$system_info[] = array( $_LANG['does_support_mysql'], $mysql_enabled );
		$gd_ver = get_gd_version(  );
		$gd_ver = (empty( $$gd_ver ) ? $_LANG['not_support'] : $gd_ver);

		if (0 < $gd_ver) {
			if (( '4.3' <= PHP_VERSION && function_exists( 'gd_info' ) )) {
				$gd_info = gd_info(  );
				$gif_enabled = ($gd_info['GIF Create Support'] === true ? $_LANG['support'] : $_LANG['not_support']);
				$png_enabled = ($gd_info['PNG Support'] === true ? $_LANG['support'] : $_LANG['not_support']);
			} 
else {
				if (function_exists( 'imagetypes' )) {
					$jpeg_enabled = (0 < ( imagetypes(  ) & IMG_JPG ) ? $_LANG['support'] : $_LANG['not_support']);
					$gif_enabled = (0 < ( imagetypes(  ) & IMG_GIF ) ? $_LANG['support'] : $_LANG['not_support']);
					$png_enabled = (0 < ( imagetypes(  ) & IMG_PNG ) ? $_LANG['support'] : $_LANG['not_support']);
				} 
else {
					$jpeg_enabled = $_LANG['not_support'];
					$gif_enabled = $_LANG['not_support'];
					$png_enabled = $_LANG['not_support'];
				}
			}
		} 
else {
			$jpeg_enabled = $_LANG['not_support'];
			$gif_enabled = $_LANG['not_support'];
			$png_enabled = $_LANG['not_support'];
		}

		$system_info[] = array( $_LANG['gd_version'], $gd_ver );
		$system_info[] = array( $_LANG['gif'], $gif_enabled );
		$system_info[] = array( $_LANG['png'], $png_enabled );
		$safe_mode = (ini_get( 'safe_mode' ) == '1' ? $_LANG['safe_mode_on'] : $_LANG['safe_mode_off']);
		$system_info[] = array( $_LANG['safe_mode'], $safe_mode );
		return $system_info;
	}

	function get_gd_version() {
		include_once( './includes/cls_image.php' );
		return cls_image::gd_version(  );
	}

	function zip_extract($file, $extractPath) {
		new ZipArchive(  );
		$res = $zip = $zip->open( $file );

		if ($res === true) {
			$zip->extractTo( $extractPath );
			$zip->close(  );
			return true;
		}

		return false;
	}

	function Zip($source, $destination, $include_dir = false, $comment = '') {
		if (( !extension_loaded( 'zip' ) || !file_exists( $source ) )) {
			return false;
		}


		if (file_exists( $destination )) {
			unlink( $destination );
		}

		$zip = new ZipArchive(  );

		if (!$zip->open( $destination, CREATE )) {
			return false;
		}

		$source = str_replace( '\\', '/', realpath( $source ) );

		if (is_dir( $source ) === true) {
			$files = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $source ), SELF_FIRST );

			if ($include_dir) {
				$arr = explode( '/', $source );
				$maindir = $arr[count( $arr ) - 1];
				$source = '';
				$i = 886;

				while ($i < count( $arr ) - 1) {
					$source .= '/' . $arr[$i];
					++$i;
				}

				$source = substr( $source, 1 );
				$zip->addEmptyDir( $maindir );
			}

			foreach ($files as $file) {
				$file = str_replace( '\\', '/', $file );

				if (in_array( substr( $file, strrpos( $file, '/' ) + 1 ), array( '.', '..' ) )) {
					continue;
				}

				$file = realpath( $file );
				$file = str_replace( '\\', '/', $file );

				if (is_dir( $file ) === true) {
					$zip->addEmptyDir( str_replace( $source . '/', '', $file . '/' ) );
					continue;
				}


				if (is_file( $file ) === true) {
					$zip->addFromString( str_replace( $source . '/', '', $file ), file_get_contents( $file ) );
					continue;
				}
			}
		} 
else {
			if (is_file( $source ) === true) {
				$zip->addFromString( basename( $source ), file_get_contents( $source ) );
			}
		}

		$zip->addFromString( 'readme.txt', 'Template Downloaded From Iranian Web Design - Parsp.com ' );
		$zip->setArchiveComment( $comment );
		return $zip->close(  );
	}

	function destroy($dir) {
		$mydir = opendir( $dir );

		if (false !== $file = readdir( $mydir )) {
			if (( $file != '.' && $file != '..' )) {
				chmod( $dir . $file, 511 );

				if (is_dir( $dir . $file )) {
					chdir( '.' );
					destroy( $dir . $file . '/' );

					if (!( rmdir( $dir . $file ))) {
						exit( 'couldn\'t delete ' . $dir . $file . '<br />' );
						(bool)true;
					}
				}


				if (!( unlink( $dir . $file ))) {
					exit( 'couldn\'t delete ' . $dir . $file . '<br />' );
					(bool)true;
				}
			}
		}

		closedir( $mydir );
	}

	define( 'URLRENDMODE_MODIFY', 1 );
	define( 'URLRENDMODE_RESET', 2 );

	if (!isset( $_SERVER['REQUEST_URI'] )) {
		$req = $_SERVER['PHP_SELF'];

		if (( isset( $_SERVER['QUERY_STRING'] ) && 0 < strlen( $_SERVER['QUERY_STRING'] ) )) {
			$req .= '?' . $_SERVER['QUERY_STRING'];
		}

		$_SERVER['REQUEST_URI'] = $GLOBALS['REQUEST_URI'] = $req;
	}

	define( 'ABSPATH', str_replace( '\\', '/', dirname( __FILE__ ) ) . '/' );
	$tempPath1 = explode( '/', str_replace( '\\', '/', dirname( $_SERVER['SCRIPT_FILENAME'] ) ) );
	$tempPath2 = explode( '/', substr( ABSPATH, 0, -1 ) );
	$tempPath3 = explode( '/', str_replace( '\\', '/', dirname( $_SERVER['PHP_SELF'] ) ) );
	$i = count( $tempPath2 );

	while ($i < count( $tempPath1 )) {
		array_pop( $tempPath3 );
		++$i;
	}

	$urladdr = $_SERVER['HTTP_HOST'] . implode( '/', $tempPath3 );

	if ($urladdr[strlen( $urladdr ) - 1] == '/') {
		define( 'BASE_URL', (( isset( $_SERVER['HTTPS'] ) && strtolower( $_SERVER['HTTPS'] ) != 'off' ) ? 'https://' : 'http://') . $urladdr );
	} 
else {
		define( 'BASE_URL', (( isset( $_SERVER['HTTPS'] ) && strtolower( $_SERVER['HTTPS'] ) != 'off' ) ? 'https://' : 'http://') . $urladdr . '/' );
	}

	unset( $$tempPath1 );
	unset( $$tempPath2 );
	unset( $$tempPath3 );
	unset( $$urladdr );
	define( 'PATH_DELIMITER', (isWindows(  ) ? ';' : ':') );
?>