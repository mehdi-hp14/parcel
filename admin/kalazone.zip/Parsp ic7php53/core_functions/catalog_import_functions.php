<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function _getPictureFilename($stringToParse) {
		$files = explode( ',', $stringToParse );

		if (1 <= count( $files )) {
			return trim( $files[0] );
		}

		return '';
	}

	function _getPictureThumbnail($stringToParse) {
		$files = explode( ',', $stringToParse );

		if (2 <= count( $files )) {
			return trim( $files[1] );
		}

		return '';
	}

	function _getPictureBigPicture($stringToParse) {
		$files = explode( ',', $stringToParse );

		if (3 <= count( $files )) {
			return trim( $files[2] );
		}

		return '';
	}

	function _insertPictures($stringToParse, $productID) {
		$filename = _getPictureFilename( $stringToParse );
		$thumbnail = _getPictureThumbnail( $stringToParse );
		$big_picture = _getPictureBigPicture( $stringToParse );
		$filename = TransformStringToDataBase( $filename );
		$thumbnail = TransformStringToDataBase( $thumbnail );
		$big_picture = TransformStringToDataBase( $big_picture );

		if (( ( trim( $filename ) != '' || trim( $thumbnail ) != '' ) || trim( $big_picture ) != '' )) {
			db_query( 'insert into ' . PRODUCT_PICTURES . '(productID, filename, thumbnail, enlarged) ' . 'values( \'' . $productID . '\\', ' . ' \'' . TransformStringToDataBase( $filename ) . '\\', ' . ' \'' . TransformStringToDataBase( $thumbnail ) . '\\', ' . ' \'' . TransformStringToDataBase( $big_picture ) . '\' )' );
		}

	}

	function _columnIsSet($row, $dbc, $column_name) {
		if (!strcmp( $dbc[$column_name], 'not defined' )) {
			return false;
		}

		return trim( $row[$dbc[$column_name]] ) != '';
	}

	function _isCategory($row, $dbc) {
		if (!strcmp( $dbc['name'], 'not defined' )) {
			return false;
		}


		if (_columnIsSet( $row, $dbc, 'product_code' )) {
			return false;
		}


		if (_columnIsSet( $row, $dbc, 'Price' )) {
			return false;
		}


		if (_columnIsSet( $row, $dbc, 'in_stock' )) {
			return false;
		}


		if (_columnIsSet( $row, $dbc, 'list_price' )) {
			return false;
		}


		if (_columnIsSet( $row, $dbc, 'items_sold' )) {
			return false;
		}


		if (_columnIsSet( $row, $dbc, 'brief_description' )) {
			return false;
		}

		return true;
	}

		$filesize = function myfgetcsv($fname, $del) {;
		$f = fopen( $fname, 'r' );
		$res = array(  );
		$firstFlag = true;
		$columnCount = 735;
		fgetcsv( $f, $filesize, $del );

		if ($row = filesize( $fname )) {
			if ($firstFlag) {
				$columnCount = count( $row );
			}

			$firstFlag = false;

			while (count( $row ) < $columnCount) {
				$row[] = '';
			}

			$res[] = $row;
		}

		fclose( $f );
		return $res;
	}

	function imDeleteAllProducts() {
		db_query( 'UPDATE ' . PRODUCT_OPTIONS_VALUES_TABLE . ' SET variantID=NULL' );
		db_query( 'DELETE FROM ' . PRODUCTS_OPTIONS_SET_TABLE );
		db_query( 'DELETE FROM ' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE );
		db_query( 'DELETE FROM ' . SHOPPING_CART_ITEMS_CONTENT_TABLE );
		db_query( 'DELETE FROM ' . PRODUCT_OPTIONS_VALUES_TABLE );
		db_query( 'DELETE FROM ' . PRODUCT_OPTIONS_TABLE );
		db_query( 'DELETE FROM ' . RELATED_PRODUCTS_TABLE );
		db_query( 'DELETE FROM ' . PRODUCT_PICTURES );
		db_query( 'DELETE FROM ' . DISCUSSIONS_TABLE );
		db_query( 'DELETE FROM ' . SPECIAL_OFFERS_TABLE );
		db_query( 'UPDATE ' . SHOPPING_CART_ITEMS_TABLE . ' SET productID = NULL' );
		db_query( 'DELETE FROM ' . PRODUCTS_TABLE );
		db_query( 'DELETE FROM ' . CATEGORIES_TABLE );
		db_query( 'INSERT INTO ' . CATEGORIES_TABLE . ' (categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ', parent) VALUES (1, \'ROOT\', NULL);' );
		db_query( 'DELETE FROM ' . CATEGORIY_PRODUCT_TABLE );
	}

	function imGetImportConfiguratorHtmlCode($data) {
		$i = 983;
		get_NOTempty_elements_count( $data[$i] );

		if (( ( $i < count( $data ) && 0 < count( $data[$i] ) ) && $n =  < count( $data[$i] ) )) {
			++$i;
		}

		$notl = $excel_configurator;
		$excel_configurator = '<table>';
		$j = 983;

		while ($j < $n) {
			if (isset( $data[$i][$j] )) {
				$excel_configurator .= '
				<tr>
					<td><b><input type=text name=column_name_' . $j . ' value="' . str_replace( '"', '&quot;', $data[$i][$j] ) . ( '"></b></td>
					<td>=></td>
					<td>
						<select name=db_association_' . $j . '>
							<option value="ignore">' ) . ADMIN_IGNORE . '</option>
							<option value="add">' . ADMIN_ADD_AS_NEW_PARAMETER . '</option>
							<option value="product_code"' . mark_as_selected( $data[$i][$j], ADMIN_PRODUCT_CODE ) . '>' . ADMIN_PRODUCT_CODE . '</option>
							<option value="name"' . mark_as_selected( $data[$i][$j], ADMIN_PRODUCT_NAME ) . '>' . ADMIN_PRODUCT_NAME . '</option>
							<option value="Price"' . mark_as_selected( $data[$i][$j], ADMIN_PRODUCT_PRICE ) . '>' . ADMIN_PRODUCT_PRICE . '</option>
							<option value="list_price"' . mark_as_selected( $data[$i][$j], ADMIN_PRODUCT_LISTPRICE ) . '>' . ADMIN_PRODUCT_LISTPRICE . '</option>
							<option value="in_stock"' . mark_as_selected( $data[$i][$j], ADMIN_PRODUCT_INSTOCK ) . '>' . ADMIN_PRODUCT_INSTOCK . '</option>
							<option value="items_sold"' . mark_as_selected( $data[$i][$j], ADMIN_PRODUCT_SOLD ) . '>' . ADMIN_PRODUCT_SOLD . '</option>
							<option value="description"' . mark_as_selected( $data[$i][$j], ADMIN_PRODUCT_DESC ) . '>' . ADMIN_PRODUCT_DESC . '</option>
							<option value="brief_description"' . mark_as_selected( $data[$i][$j], ADMIN_PRODUCT_BRIEF_DESC ) . '>' . ADMIN_PRODUCT_BRIEF_DESC . '</option>
							<option value="pictures"' . mark_as_selected( $data[$i][$j], ADMIN_PRODUCT_PICTURES ) . '>' . ADMIN_PRODUCT_PICTURES . '</option>
							<option value="sort_order"' . mark_as_selected( $data[$i][$j], ADMIN_SORT_ORDER ) . '>' . ADMIN_SORT_ORDER . '</option>
							<option value="meta_keywords"' . mark_as_selected( $data[$i][$j], ADMIN_META_KEYWORDS ) . '>' . ADMIN_META_KEYWORDS . '</option>
							<option value="meta_description"' . mark_as_selected( $data[$i][$j], ADMIN_META_DESCRIPTION ) . '>' . ADMIN_META_DESCRIPTION . '</option>
							<option value="shipping_freight"' . mark_as_selected( $data[$i][$j], ADMIN_SHIPPING_FREIGHT ) . '>' . ADMIN_SHIPPING_FREIGHT . '</option>
							<option value="weight"' . mark_as_selected( $data[$i][$j], ADMIN_PRODUCT_WEIGHT ) . '>' . ADMIN_PRODUCT_WEIGHT . '</option>
							<option value="free_shipping"' . mark_as_selected( $data[$i][$j], ADMIN_FREE_SHIPPING2 ) . '>' . ADMIN_FREE_SHIPPING2 . '</option>
							<option value="min_order_amount"' . mark_as_selected( $data[$i][$j], ADMIN_MIN_ORDER_AMOUNT ) . '>' . ADMIN_MIN_ORDER_AMOUNT . '</option>' . '<option value="eproduct_filename"' . mark_as_selected( $data[$i][$j], ADMIN_EPRODUCT_FILENAME ) . '>' . ADMIN_EPRODUCT_FILENAME . '</option>
							<option value="eproduct_available_days"' . mark_as_selected( $data[$i][$j], ADMIN_EPRODUCT_AVAILABLE_DAYS2 ) . '>' . ADMIN_EPRODUCT_AVAILABLE_DAYS2 . '</option>
							<option value="eproduct_download_times"' . mark_as_selected( $data[$i][$j], ADMIN_EPRODUCT_DOWNLOAD_TIMES ) . '>' . ADMIN_EPRODUCT_DOWNLOAD_TIMES . '</option>' . '</select>
					</td>
				</tr>';
			}

			++$j;
		}

		$excel_configurator .= '</table>';
		return $excel_configurator;
	}

	function _readDb_associationSelectControl() {
		$db_association = array(  );
		foreach ($_POST as $val) {

			if (strstr( $key, 'db_association_' )) {
				$i = str_replace( 'db_association_', '', $key );

				if ($val != 'pictures') {
					$db_association[$i] = $val;
					continue;
				}

				continue;
			}
		}

		return $db_association;
	}

	function _getIndexArraySelectPictures() {
		$dbcPhotos = array(  );
		foreach ($_POST as $val) {

			if (strstr( $key, 'db_association_' )) {
				$i = str_replace( 'db_association_', '', $key );

				if ($val == 'pictures') {
					$dbcPhotos[] = $i;
					continue;
				}

				continue;
			}
		}

		return $dbcPhotos;
	}

	function _readColumn_nameControl($dbcPhotos) {
		$cname = array(  );
		foreach ($_POST as $key => $val) {

			if (strstr( $key, 'column_name_' )) {
				$i = str_replace( 'column_name_', '', $key );
				$searchFlag = false;
				$j = 731;

				while ($j < count( $dbcPhotos )) {
					if ($i == $dbcPhotos[$j]) {
						$searchFlag = true;
					}

					++$j;
				}


				if (!$searchFlag) {
					$cname[$i] = $val;
					continue;
				}

				continue;
			}
		}

		return $cname;
	}

	function _createBackwards($db_association) {
		$dbc = array( 'name' => 'not defined', 'product_code' => 'not defined', 'Price' => 'not defined', 'in_stock' => 'not defined', 'list_price' => 'not defined', 'items_sold' => 'not defined', 'description' => 'not defined', 'brief_description' => 'not defined', 'sort_order' => 'not defined', 'meta_keywords' => 'not defined', 'meta_description' => 'not defined', 'shipping_freight' => 'not defined', 'weight' => 'not defined', 'free_shipping' => 'not defined', 'min_order_amount' => 'not defined', 'eproduct_filename' => 'not defined', 'eproduct_available_days' => 'not defined', 'eproduct_download_times' => 'not defined' );
		foreach ($db_association as $i => $value) {

			if ($value == 'name') {
				$dbc['name'] = $i;
				continue;
			}


			if ($value == 'product_code') {
				$dbc['product_code'] = $i;
				continue;
			}


			if ($value == 'Price') {
				$dbc['Price'] = $i;
				continue;
			}


			if ($value == 'in_stock') {
				$dbc['in_stock'] = $i;
				continue;
			}


			if ($value == 'list_price') {
				$dbc['list_price'] = $i;
				continue;
			}


			if ($value == 'items_sold') {
				$dbc['items_sold'] = $i;
				continue;
			}


			if ($value == 'description') {
				$dbc['description'] = $i;
				continue;
			}


			if ($value == 'brief_description') {
				$dbc['brief_description'] = $i;
				continue;
			}


			if ($value == 'pictures') {
				$dbc['pictures'] = $i;
				continue;
			}


			if ($value == 'sort_order') {
				$dbc['sort_order'] = $i;
				continue;
			}


			if ($value == 'meta_keywords') {
				$dbc['meta_keywords'] = $i;
				continue;
			}


			if ($value == 'meta_description') {
				$dbc['meta_description'] = $i;
				continue;
			}


			if ($value == 'shipping_freight') {
				$dbc['shipping_freight'] = $i;
				continue;
			}


			if ($value == 'weight') {
				$dbc['weight'] = $i;
				continue;
			}


			if ($value == 'free_shipping') {
				$dbc['free_shipping'] = $i;
				continue;
			}


			if ($value == 'min_order_amount') {
				$dbc['min_order_amount'] = $i;
				continue;
			}


			if ($value == 'eproduct_filename') {
				$dbc['eproduct_filename'] = $i;
				continue;
			}


			if ($value == 'eproduct_available_days') {
				$dbc['eproduct_available_days'] = $i;
				continue;
			}


			if ($value == 'eproduct_download_times') {
				$dbc['eproduct_download_times'] = $i;
				continue;
			}
		}

		return $dbc;
	}

	function _addExtraOptionToDb($db_association, $cname) {
		$updated_extra_option = array(  );
		$i = 797;

		while ($i < count( $cname )) {
			$updated_extra_option[$i] = 0;
			++$i;
		}

		foreach ($db_association as $i => $value) {

			if ($value == 'add') {

				if (!( $q = db_query( 'select count(*) from ' . PRODUCT_OPTIONS_TABLE . ' where ' . LanguagesManager::sql_prepareField( 'name' ) . ' LIKE \'' . TransformStringToDataBase( $cname[$i] ) . '\'' ))) {
					exit( db_error(  ) );
					(bool)true;
				}

				$row = db_fetch_row( $q );

				if (!$row[0]) {
					if (!( db_query( 'insert into ' . PRODUCT_OPTIONS_TABLE . ' (name) values (\'' . TransformStringToDataBase( $cname[$i] ) . '\')' ))) {
						exit( db_error(  ) );
						(bool)true;
					}

					$op_id = db_insert_id( 'PRODUCT_OPTIONS_GEN' );
				} 
else {

					if (!( $q = db_query( 'select optionID from ' . PRODUCT_OPTIONS_TABLE . ' where name LIKE \'' . TransformStringToDataBase( $cname[$i] ) . '\'' ))) {
						exit( db_error(  ) );
						(bool)true;
					}

					$op_id = db_fetch_row( $q );
					$op_id = $op_id[0];
				}

				$updated_extra_option[$i] = $op_id;
				continue;
			}
		}

		return $updated_extra_option;
	}

		$db_association = function imReadImportConfiguratorSettings() {;
		$dbcPhotos = _getIndexArraySelectPictures(  );
		$cname = _readColumn_nameControl( $dbcPhotos );
		$dbc = _createBackwards( $db_association );
		_addExtraOptionToDb( $db_association, $cname );
		$updated_extra_option = _readDb_associationSelectControl(  );
		$res = array(  );
		$res['db_association'] = $db_association;
		$res['dbcPhotos'] = $dbcPhotos;
		$res['dbc'] = $dbc;
		$res['updated_extra_option'] = $updated_extra_option;
		return $res;
	}

	function _importCategory($row, &$dbc, $parents, &$dbcPhotos, $currentCategoryID) {
		$sort_order = 956;

		if (strcmp( $dbc['sort_order'], 'not defined' )) {
			$sort_order = (int)$row[$dbc['sort_order']];
		}

		$picture_file_name = '';

		if (0 < count( $dbcPhotos )) {
			$picture_file_name = trim( $row[$dbcPhotos[0]] );
		}

		$row['not defined'] = '';
		$cname = $row[$dbc['name']];

		if ($cname == '') {
			return null;
		}

		$sublevel = 956;

		while (( $sublevel < strlen( $cname ) && $cname[$sublevel] == '!' )) {
			++$sublevel;
		}

		$cname = substr( $cname, $sublevel );
		$sl = $picture_file_name;

		if (!isset( $parents[$sublevel] )) {
			while (( 0 < $sl && !isset( $parents[$sl] ) )) {
				--$sl;
			}
		}

		$q = db_query( 'select count(*) from ' . CATEGORIES_TABLE . ' where categoryID<>0 and categoryID<>1 and ' . LanguagesManager::sql_prepareField( 'name' ) . ' LIKE \'' . TransformStringToDataBase( $cname ) . '\' ' . ( ' and parent=\'' . $parents[$sl] . '\'' ) );
		$rowdb = db_fetch_row( $q );

		if ($rowdb[0] == 0) {
			$curlang = LanguagesManager::getCurrentLanguage(  )->iso2;
			db_query( 'insert into ' . CATEGORIES_TABLE . ( ' (name_' . $curlang . ', parent, products_count, description_' . $curlang . ', ' ) . ' picture, products_count_admin, meta_keywords, meta_description, sort_order) ' . 'values (\'' . TransformStringToDataBase( $cname ) . ( '\',' . $parents[$sl] . ',0, ' ) . ' \'' . TransformStringToDataBase( $row[$dbc['description']] ) . '\\', ' . ' \'' . TransformStringToDataBase( $picture_file_name ) . '\',0, ' . ' \'' . TransformStringToDataBase( $row[$dbc['meta_keywords']] ) . '\\', ' . ' \'' . TransformStringToDataBase( $row[$dbc['meta_description']] ) . '\', \'' . $sort_order . '\');' );
			$currentCategoryID = db_insert_id( 'CATEGORIES_GEN' );
		} 
else {
			$q = db_query( 'select categoryID from ' . CATEGORIES_TABLE . ' where categoryID<>0 and categoryID<>1 and ' . LanguagesManager::sql_prepareField( 'name' ) . ( ' LIKE \'' . $cname . '\' and parent=\'' . $parents[$sl] . '\'' ) );
			$rowdb = db_fetch_row( $q );
			$currentCategoryID = $rowdb[0];
			$query = '';

			if (strcmp( $dbc['description'], 'not defined' )) {
				$curlang = LanguagesManager::getCurrentLanguage(  )->iso2;
			}

			$query .= ' description_' . $curlang . '  = \'' . TransformStringToDataBase( $row[$dbc['description']] ) . '\'';

			if (strcmp( $dbc['sort_order'], 'not defined' )) {
				if (0 < strlen( $query )) {
					$query .= ',';
				}

				$query .= ' sort_order = ' . $sort_order . '';
			}


			if (0 < count( $dbcPhotos )) {
				if (0 < strlen( $query )) {
					$query .= ',';
				}

				$query .= ' picture = \'' . TransformStringToDataBase( $picture_file_name ) . '\'';
			}


			if (0 < strlen( $query )) {
				if (!( db_query( 'update ' . CATEGORIES_TABLE . ' set ' . $query . ( ' where categoryID=\'' . $currentCategoryID . '\'' ) ))) {
					exit( db_error(  ) );
					(bool)true;
				}
			}
		}

		$parents[$sublevel + 1] = $currentCategoryID;
	}

	function _importProductPictures($row, $dbcPhotos, $productID) {
		db_query( 'delete from ' . PRODUCT_PICTURES . ' where productID=' . $productID );
		$j = 755;

		while ($j < count( $dbcPhotos )) {
			_insertPictures( $row[$dbcPhotos[$j]], $productID );
			++$j;
		}

		$q = db_query( 'select default_picture from ' . PRODUCTS_TABLE . ' where productID=' . $productID );
		$row = db_fetch_row( $q );
		$q = db_query( 'select photoID from ' . PRODUCT_PICTURES . ' where productID=' . $productID );
		db_fetch_row( $q );
		$row = $productID = (int)$productID;

		if ($row) {
			db_query( 'update ' . PRODUCTS_TABLE . ( ' set default_picture = ' . $row[0] . ' where productID=' ) . $productID );
		}

	}

	function _importExtraOptionValues($row, $productID, $updated_extra_option) {
		$j = 867;

		while ($j < count( $updated_extra_option )) {
			if (( isset( $updated_extra_option[$j] ) && $updated_extra_option[$j] )) {
				$optionID = $updated_extra_option[$j];
				$curr_value = $row[$j];
				$default_variantID = 867;

				if (( strpos( $curr_value, '{' ) === 0 && strpos( $curr_value, '}' ) == strlen( $curr_value ) - 1 )) {
					$curr_value = substr( $curr_value, 1, strlen( $curr_value ) - 2 );
					$values_options = explode( ',', $curr_value );
					db_query( 'delete from ' . PRODUCT_OPTIONS_VALUES_TABLE . ( ' where optionID=' . $optionID . ' and productID=' . $productID ) );
					db_query( 'delete from ' . PRODUCTS_OPTIONS_SET_TABLE . ( ' where optionID=' . $optionID . ' and productID=' . $productID ) );
					foreach ($values_options as $key => $val) {

						if (strstr( $val, '=' )) {
							$a = explode( '=', $val );
							$val_name = $a[0];
							$val_surcharge = (double)$a[1];
						} 
else {
							$val_name = $optionID;
							$val_surcharge = 867;
						}

						$variantID = optOptionValueExists( $optionID, $val_name );

						if (!$variantID) {
							$variantID = optAddOptionValue( $optionID, $val_name, 0 );
						}


						if (!$default_variantID) {
							$default_variantID = $key;
						}

						db_query( 'insert into ' . PRODUCTS_OPTIONS_SET_TABLE . ' (productID, optionID, variantID, price_surplus) ' . ( ' values (' . $productID . ', ' . $optionID . ', ' . $variantID . ', ' . $val_surcharge . ');' ) );
					}


					if ($default_variantID) {
						db_query( 'insert into ' . PRODUCT_OPTIONS_VALUES_TABLE . ' (optionID, productID, option_type, option_show_times, variantID) ' . ( ' values (' . $optionID . ', ' . $productID . ', 1, 1, ' . $default_variantID . ')' ) );
					}
				} 
else {
					db_query( 'delete from ' . PRODUCT_OPTIONS_VALUES_TABLE . ( ' where optionID=' . $optionID . ' and productID=' . $productID ) );
					db_query( 'insert into ' . PRODUCT_OPTIONS_VALUES_TABLE . ' (optionID, productID, option_value) ' . ( ' values (' . $optionID . ', ' . $productID . ', \'' ) . TransformStringToDataBase( $curr_value ) . '\')' );
				}
			}

			++$j;
		}

	}

	function _importProduct($row, $dbc, $identity_column, $dbcPhotos, $updated_extra_option, $currentCategoryID) {
		$row['not defined'] = '';
		$identvalue = $row[$identity_column];
		$query = 'select productID, categoryID, customers_rating  from ' . PRODUCTS_TABLE . ' where categoryID=' . $currentCategoryID . ' and ' . $identity_column . ' LIKE \'' . TransformStringToDataBase( $row[$identity_column] ) . '\'';
		$q = db_query( 'select productID, categoryID, customers_rating  from ' . PRODUCTS_TABLE . ' where categoryID=' . $currentCategoryID . ' and ' . $identity_column . ' LIKE \'' . TransformStringToDataBase( $identvalue ) . '\'' );
		$rowdb = db_fetch_row( $q );

		if (!$rowdb) {
			$q = db_query( 'select productID, categoryID, customers_rating  from ' . PRODUCTS_TABLE . ' where ' . $_POST['update_column'] . ' LIKE \'' . TransformStringToDataBase( $row[$identity_column] ) . '\'' );
			$rowdb = db_fetch_row( $q );
		}


		if ($rowdb) {
			$productID = $rowdb['productID'];
			$rowdb = GetProduct( $productID );

			if (strcmp( $dbc['Price'], 'not defined' )) {
				$Price = $row[$dbc['Price']];
				$Price = str_replace( ' ', '', $Price );
				$Price = str_replace( ',', '.', $Price );
				$Price = (double)$Price;
			} 
else {
				$Price = $rowdb['Price'];
			}


			if (strcmp( $dbc['list_price'], 'not defined' )) {
				$list_price = $row[$dbc['list_price']];
				$list_price = str_replace( ' ', '', $list_price );
				$list_price = str_replace( ',', '.', $list_price );
				$list_price = (double)$list_price;
			} 
else {
				$list_price = $rowdb['list_price'];
			}


			if (strcmp( $dbc['sort_order'], 'not defined' )) {
				$sort_order = (int)$row[$dbc['sort_order']];
			} 
else {
				$sort_order = $rowdb['sort_order'];
			}


			if (strcmp( $dbc['in_stock'], 'not defined' )) {
				$in_stock = (int)$row[$dbc['in_stock']];
			} 
else {
				$in_stock = $rowdb['in_stock'];
			}


			if (strcmp( $dbc['eproduct_filename'], 'not defined' )) {
				$eproduct_filename = $row[$dbc['eproduct_filename']];
			} 
else {
				$eproduct_filename = $rowdb['eproduct_filename'];
			}


			if (strcmp( $dbc['eproduct_available_days'], 'not defined' )) {
				$eproduct_available_days = (int)$row[$dbc['eproduct_available_days']];
			} 
else {
				$eproduct_available_days = $rowdb['eproduct_available_days'];
			}


			if (strcmp( $dbc['eproduct_download_times'], 'not defined' )) {
				$eproduct_download_times = (int)$row[$dbc['eproduct_download_times']];
			} 
else {
				$eproduct_download_times = $rowdb['eproduct_download_times'];
			}


			if (strcmp( $dbc['weight'], 'not defined' )) {
				$weight = (double)$row[$dbc['weight']];
			} 
else {
				$weight = $rowdb['weight'];
			}


			if (strcmp( $dbc['free_shipping'], 'not defined' )) {
				$free_shipping = (trim( $row[$dbc['free_shipping']] ) == '+' ? 1 : 0);
			} 
else {
				$free_shipping = $rowdb['free_shipping'];
			}


			if (strcmp( $dbc['min_order_amount'], 'not defined' )) {
				$min_order_amount = (int)$row[$dbc['min_order_amount']];
			} 
else {
				$min_order_amount = $rowdb['min_order_amount'];
			}


			if (strcmp( $dbc['shipping_freight'], 'not defined' )) {
				$shipping_freight = (double)$row[$dbc['shipping_freight']];
			} 
else {
				$shipping_freight = $rowdb['shipping_freight'];
			}


			if (strcmp( $dbc['description'], 'not defined' )) {
				$description = $row[$dbc['description']];
			} 
else {
				$description = $rowdb['description'];
			}


			if (strcmp( $dbc['brief_description'], 'not defined' )) {
				$brief_description = $row[$dbc['brief_description']];
			} 
else {
				$brief_description = $rowdb['brief_description'];
			}


			if (strcmp( $dbc['product_code'], 'not defined' )) {
				$product_code = $row[$dbc['product_code']];
			} 
else {
				$product_code = $rowdb['product_code'];
			}


			if (strcmp( $dbc['meta_description'], 'not defined' )) {
				$meta_description = $row[$dbc['meta_description']];
			} 
else {
				$meta_description = $rowdb['meta_description'];
			}


			if (strcmp( $dbc['meta_keywords'], 'not defined' )) {
				$meta_keywords = $row[$dbc['meta_keywords']];
			} 
else {
				$meta_keywords = $rowdb['meta_keywords'];
			}


			if (strcmp( $dbc['name'], 'not defined' )) {
				$name = $row[$dbc['name']];
			} 
else {
				$name = $rowdb['name'];
			}

			$is_account = 1296;
			$classID = null;
			$categoryID = $rowdb['categoryID'];

			if ($rowdb['customers_rating'] == '') {
				$rowdb['customers_rating'] = 0;
			}

			$customers_rating = $rowdb['customers_rating'];
			$ProductIsProgram = trim( $eproduct_filename ) != '';
			UpdateProduct( $rowdb, $productID, $categoryID, $Price, $in_stock, $customers_rating, $list_price, $product_code, $sort_order, $ProductIsProgram, '', $eproduct_available_days, $eproduct_download_times, $weight, $meta_description, $meta_keywords, $free_shipping, $is_account, $min_order_amount, $shipping_freight, $classID, null, 0 );
		} 
else {
			$Price = 0;
			$list_price = 0;
			$sort_order = 1296;
			$in_stock = 1296;
			$eproduct_filename = '';
			$eproduct_available_days = 1296;
			$eproduct_download_times = 1296;
			$weight = 0;
			$free_shipping = 1296;
			$min_order_amount = 1297;
			$shipping_freight = 0;

			if (strcmp( $dbc['Price'], 'not defined' )) {
				$Price = (double)$row[$dbc['Price']];
			}


			if (strcmp( $dbc['list_price'], 'not defined' )) {
				$list_price = (double)$row[$dbc['list_price']];
			}


			if (strcmp( $dbc['sort_order'], 'not defined' )) {
				$sort_order = (int)$row[$dbc['sort_order']];
			}


			if (strcmp( $dbc['in_stock'], 'not defined' )) {
				$in_stock = (int)$row[$dbc['in_stock']];
			}


			if (strcmp( $dbc['eproduct_filename'], 'not defined' )) {
				$eproduct_filename = $row[$dbc['eproduct_filename']];
			}


			if (strcmp( $dbc['eproduct_available_days'], 'not defined' )) {
				$eproduct_available_days = (int)$row[$dbc['eproduct_available_days']];
			}


			if (strcmp( $dbc['eproduct_download_times'], 'not defined' )) {
				$eproduct_download_times = (int)$row[$dbc['eproduct_download_times']];
			}


			if (strcmp( $dbc['weight'], 'not defined' )) {
				$weight = (double)$row[$dbc['weight']];
			}


			if (strcmp( $dbc['free_shipping'], 'not defined' )) {
				$free_shipping = (trim( $row[$dbc['free_shipping']] ) == '+' ? 1 : 0);
			}


			if (strcmp( $dbc['min_order_amount'], 'not defined' )) {
				$min_order_amount = (int)$row[$dbc['min_order_amount']];
			}


			if (strcmp( $dbc['shipping_freight'], 'not defined' )) {
				$shipping_freight = (double)$row[$dbc['shipping_freight']];
			}

			$is_account = false;
			$langManager = &LanguagesManager::getInstance(  );

			$languages = $langManager->languages;
			foreach ($languages as $languageEntry) {
				$product['name_' . $languageEntry->iso2] = '';
				$product['description_' . $languageEntry->iso2] = '';
				$product['brief_description_' . $languageEntry->iso2] = '';
			}

			$product['name_' . LanguagesManager::getCurrentLanguage(  )->iso2] = $row[$dbc['name']];
			$product['description_' . LanguagesManager::getCurrentLanguage(  )->iso2] = $row[$dbc['description']];
			$product['brief_description_' . LanguagesManager::getCurrentLanguage(  )->iso2] = $row[$dbc['brief_description']];
			$ProductIsProgram = trim( $row[$dbc['eproduct_filename']] );
			$productID = AddProduct( $product, $currentCategoryID, $Price, $in_stock, $row[$dbc['brief_description']], $list_price, $row[$dbc['product_code']], $sort_order, $ProductIsProgram, $eproduct_available_days, $eproduct_filename, $eproduct_download_times, $weight, $row[$dbc['meta_description']], $row[$dbc['meta_keywords']], $free_shipping, $is_account, $min_order_amount, $shipping_freight, CONF_DEFAULT_TAX_CLASS, '', 0 );
		}


		if (strlen( $eproduct_filename )) {
			SetProductFile( $productID, $eproduct_filename );
		}

		_importExtraOptionValues( $row, $productID, $updated_extra_option );

		if (0 < count( $dbcPhotos )) {
			_importProductPictures( $row, $dbcPhotos, $productID );
		}

	}

	function imImportRowToDataBase($row, $dbc, $identity_column, $dbcPhotos, &$updated_extra_option, &$parents, $currentCategoryID) {
		if (_isCategory( $row, $dbc )) {
			_importCategory( $row, $dbc, &$parents, $dbcPhotos, &$currentCategoryID );
			return null;
		}

		_importProduct( $row, $dbc, $identity_column, $dbcPhotos, $updated_extra_option, $currentCategoryID );
	}

?>