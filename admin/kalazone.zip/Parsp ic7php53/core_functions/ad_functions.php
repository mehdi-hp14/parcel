<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function move_upload_file($file_name, $target_name = '') {
		if (function_exists( 'move_uploaded_file' )) {
			if (move_uploaded_file( $file_name, $target_name )) {
				@chmod( $target_name, 493 );
				return true;
			}


			if (copy( $file_name, $target_name )) {
				@chmod( $target_name, 493 );
				return true;
			}
		} 
else {
			if (copy( $file_name, $target_name )) {
				@chmod( $target_name, 493 );
				return true;
			}
		}

		return false;
	}

	function move_file($upload, $target) {
		if (( isset( $upload['error'] ) && 0 < $upload['error'] )) {
			return false;
		}


		if (!move_upload_file( $upload['tmp_name'], $target )) {
			return false;
		}

		return true;
	}

	function check_img_type($img_type) {
		return ( ( ( ( $img_type == 'image/pjpeg' || $img_type == 'image/x-png' ) || $img_type == 'image/png' ) || $img_type == 'image/gif' ) || $img_type == 'image/jpeg' );
	}

	function get_filetype($path) {
		$pos = strrpos( $path, '.' );

		if ($pos !== false) {
			return substr( $path, $pos );
		}

		return '';
	}

	function random_filename() {
		$str = '';
		$i = 709;

		while ($i < 9) {
			$str .= mt_rand( 0, 9 );
			++$i;
		}

		return time(  ) - date( 'Z' ) . $str;
	}

	function unique_name($dir) {
		$filename = '';

		while (empty( $$filename )) {
			$filename = random_filename(  );

			if (( ( file_exists( $dir . $filename . '.jpg' ) || file_exists( $dir . $filename . '.gif' ) ) || file_exists( $dir . $filename . '.png' ) )) {
				$filename = '';
				continue;
			}
		}

		return $filename;
	}

	function make_dir($folder) {
		$reval = false;

		if (!file_exists( $folder )) {
			@umask( 0 );
			preg_match_all( '/([^\/]*)\/?/i', $folder, $atmp );
			$base = ($atmp[0][0] == '/' ? '/' : '');
			foreach ($atmp[1] as $val) {

				if ('' != $val) {
					$base .= $atmp;

					if (( '..' == $val || '.' == $val )) {
						$base .= '/';
						continue;
					}
				}

				continue;
				$base .= '/';

				if (!file_exists( $base )) {
					if (@mkdir( @rtrim( $base, '/' ), 511 )) {
						@chmod( $base, 511 );
						$reval = true;
						continue;
					}

					continue;
				}
			}
		} 
else {
			$reval = is_dir( $folder );
		}

		clearstatcache(  );
		return $reval;
	}

	function upload_flash($upload, $dir = '', $img_name = '') {
		if (empty( $$dir )) {
			$dir = date( 'Ym' );
			$dir = './' . $dir . '/';
		} 
else {
			$dir = './' . $dir . '/';

			if ($img_name) {
				$img_name = $dir . $img_name;
			}
		}


		if (!file_exists( $dir )) {
			if (!make_dir( $dir )) {
				$this->error_msg = sprintf( $GLOBALS['_LANG']['directory_readonly'], $dir );
				$this->error_no = ERR_DIRECTORY_READONLY;
				return false;
			}
		}


		if (empty( $$img_name )) {
			$img_name = unique_name( $dir );
			$img_name = $dir . $img_name . '.' . get_filetype( $upload['name'] );
		}


		if ($upload['type'] != 'application/x-shockwave-flash') {
			$this->error_msg = $GLOBALS['_LANG']['invalid_upload_image_type'];
			$this->error_no = ERR_INVALID_IMAGE_TYPE;
			return false;
		}

		$allow_file_types = '|SWF|';

		if (!check_file_type( $upload['tmp_name'], $img_name, $allow_file_types )) {
			$error_msg = $GLOBALS['_LANG']['invalid_upload_image_type'];
			$error_no = ERR_INVALID_IMAGE_TYPE;
			return false;
		}


		if (move_file( $upload, $img_name )) {
			return $img_name;
		}

		$error_msg = sprintf( $GLOBALS['_LANG']['upload_failure'], $upload['name'] );
		$error_no = ERR_UPLOAD_FAILURE;
		return false;
	}

	function upload_image($upload, $dir = '', $img_name = '') {
		if (empty( $$dir )) {
			$dir = date( 'Ym' );
			$dir = './' . $dir . '/';
		} 
else {
			$dir = './' . $dir . '/';

			if ($img_name) {
				$img_name = $dir . $img_name;
			}
		}


		if (!file_exists( $dir )) {
			if (!make_dir( $dir )) {
				$this->error_msg = sprintf( $GLOBALS['_LANG']['directory_readonly'], $dir );
				$this->error_no = ERR_DIRECTORY_READONLY;
				return false;
			}
		}


		if (empty( $$img_name )) {
			$img_name = unique_name( $dir );
			$img_name = $dir . $img_name . '.' . get_filetype( $upload['name'] );
		}


		if (!check_img_type( $upload['type'] )) {
			$this->error_msg = $GLOBALS['_LANG']['invalid_upload_image_type'];
			$this->error_no = ERR_INVALID_IMAGE_TYPE;
			return false;
		}

		$allow_file_types = '|GIF|JPG|JEPG|PNG|BMP|SWF|';

		if (!check_file_type( $upload['tmp_name'], $img_name, $allow_file_types )) {
			$error_msg = $GLOBALS['_LANG']['invalid_upload_image_type'];
			$error_no = ERR_INVALID_IMAGE_TYPE;
			return false;
		}


		if (move_file( $upload, $img_name )) {
			return $img_name;
		}

		$error_msg = sprintf( $GLOBALS['_LANG']['upload_failure'], $upload['name'] );
		$error_no = ERR_UPLOAD_FAILURE;
		return false;
	}

	function get_adslist($incategory) {
		$pid = (!empty( $_REQUEST['pid'] ) ? intval( $_REQUEST['pid'] ) : 0);
		$filter = array(  );
		$filter['sort_by'] = (empty( $_REQUEST['sort_by'] ) ? 'ad.ad_name' : trim( $_REQUEST['sort_by'] ));
		$filter['sort_order'] = (empty( $_REQUEST['sort_order'] ) ? 'DESC' : trim( $_REQUEST['sort_order'] ));
		$where = 'WHERE 1 ';

		if (0 < $pid) {
			$where .= ' AND ad.position_name = \'' . $pid . '\' ';
		}


		if ($incategory) {
			$where .= ' AND ad.ad_place = \'1\' ';
		} 
else {
			$where .= ' AND ad.ad_place = \'0\' ';
		}

		$sql = 'SELECT COUNT(*) FROM ' . ADS_TABLE . ' AS ad ' . $where;
		$filter['record_count'] = db_fetch_assoc( db_query( $sql ) );
		$filter['record_count'] = $filter['record_count'][0];
		$filter = page_and_size( $filter );
		$arr = array(  );
		$sql = 'SELECT * ' . 'FROM ' . ADS_TABLE . ( ' AS ad ' . $where . ' ' ) . 'ORDER by ' . $filter['sort_by'] . ' ' . $filter['sort_order'];
		$res = selectLimit( $sql, $filter['page_size'], $filter['start'] );

		if ($rows = db_fetch_row( $res )) {
			$rows['type'] = ($rows['media_type'] == 0 ? STRING_PICTURE : '');
			$rows->type .= ($rows['media_type'] == 1 ? 'Flash' : '');
			$rows->type .= ($rows['media_type'] == 2 ? 'Html' : '');
			$rows->type .= ($rows['media_type'] == 3 ? STRING_TEXT : '');
			$rows->type .= ($rows['media_type'] == 4 ? 'Code' : '');

			if ($rows['start_time'] != '') {
				$rows['start_time'] = TransformDATEToTemplate( date( 'Y-m-d', $rows['start_time'] ) );
			} 
else {
				$rows['start_time'] = '';
			}


			if ($rows['end_time'] != 0) {
				$rows['end_time'] = TransformDATEToTemplate( date( 'Y-m-d', $rows['end_time'] ) );
			} 
else {
				$rows['end_time'] = STRING_UNLIMITED;
			}

			$rows['piclink'] = picrow( $rows, '25px', '25px' );
			$rows['pichtml'] = picrow( $rows );
			$rows['condstring'] = '';
			$cods = explode( ',', $rows['ad_condition'] );
			foreach ($cods as $cod) {
				$cod = str_replace( ',', '', $cod );
				$icat = catGetCategoryById( $cod );
				$catname = $icat['name'];
				$rows['condstring'] = $rows['condstring'] . $catname . '<br>';
			}

			$arr[] = $rows;
		}

		return array( 'ads' => $arr, 'filter' => $filter, 'page_count' => $filter['page_count'], 'record_count' => $filter['record_count'] );
	}

	function ad_edit($smarty, $ad_id) {
		$sql = 'SELECT * FROM ' . ADS_TABLE . ' WHERE adId=\'' . intval( $ad_id ) . '\'';
		$ads_arr = db_fetch_assoc( db_query( $sql ) );
		$ads_arr['ad_name'] = $ads_arr['ad_name'];

		if (intval( $ads_arr['start_time'] ) != 0) {
			$ads_arr['start_time'] = TransformDATEToTemplate( $ads_arr['start_time'] );
		} 
else {
			$ads_arr['start_time'] = '';
		}


		if (intval( $ads_arr['end_time'] ) != 0) {
			$ads_arr['end_time'] = TransformDATEToTemplate( $ads_arr['end_time'] );
		} 
else {
			$ads_arr['end_time'] = '';
		}


		if ($ads_arr['media_type'] == '0') {
			if (( strpos( $ads_arr['ad_code'], 'http://' ) === false && strpos( $ads_arr['ad_code'], 'https://' ) === false )) {
				$src = './uploads/afficheimg/' . $ads_arr['ad_code'];
				$smarty->assign( 'img_src', $src );
			} 
else {
				$src = $ads_arr['ad_code'];
				$smarty->assign( 'url_src', $src );
			}
		}


		if ($ads_arr['media_type'] == '1') {
			if (( strpos( $ads_arr['ad_code'], 'http://' ) === false && strpos( $ads_arr['ad_code'], 'https://' ) === false )) {
				$src = './uploads/afficheimg/' . $ads_arr['ad_code'];
				$smarty->assign( 'flash_url', $src );
			} 
else {
				$src = $ads_arr['ad_code'];
				$smarty->assign( 'flash_url', $src );
			}

			$smarty->assign( 'src', $src );
		}


		if ($ads_arr['media_type'] == '3') {
			$smarty->assign( 'url_src', $ads_arr['ad_link'] );
		}


		if ($ads_arr['media_type'] == 0) {
			$smarty->assign( 'media_type', $_LANG['ad_img'] );
		} 
else {
			if ($ads_arr['media_type'] == 1) {
				$smarty->assign( 'media_type', $_LANG['ad_flash'] );
			} 
else {
				if ($ads_arr['media_type'] == 2) {
					$smarty->assign( 'media_type', $_LANG['ad_html'] );
				} 
else {
					if ($ads_arr['media_type'] == 3) {
						$smarty->assign( 'media_type', $_LANG['ad_text'] );
					} 
else {
						if ($ads_arr['media_type'] == 4) {
							$smarty->assign( 'media_type', $_LANG['ad_code'] );
						}
					}
				}
			}
		}

		$smarty->assign( 'today', jdate( 'Y/m/d' ) );
		$smarty->assign( 'form_act', 'update' );
		$smarty->assign( 'action', 'edit' );
		$smarty->assign( 'ads', $ads_arr );
	}

	function picrow($row, $height, $weight) {
		$onclick = 'onclick="TINY.box.show({id:\'ibox\',addp:\'\',iframe:\'index.php?v=-1&ad_id=' . $row['adId'] . '&amp;uri=' . urlencode( $row['ad_link'] ) . '\',width:700,height:500,opacity:90,animante:1,close:1,mask:1,boxid:\'frameless\',fixed:0,closejs:function(){closeJS()}})"';
		switch ($row['media_type']) {
			case 0: {
				$src = (( strpos( $row['ad_code'], 'http://' ) === false && strpos( $row['ad_code'], 'https://' ) === false ) ? './uploads/afficheimg/' . $row['ad_code'] : $row['ad_code']);
				$ads[] = '<a ' . $onclick . ( ' >
                <img src=\'' . $src . '\' ' ) . (empty( $$width ) ? ' width="' . $width . '"' : '') . ' ' . (empty( $$height ) ? ' height="' . $height . '"' : '') . 'border=\'0\' /></a>';
				break;
			}

			case 1: {
				$src = (( strpos( $row['ad_code'], 'http://' ) === false && strpos( $row['ad_code'], 'https://' ) === false ) ? './uploads/afficheimg/' . $row['ad_code'] : $row['ad_code']);
				$ads[] = '<a ' . $onclick . ' >
                          <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" ' . 'codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0"  ' . (empty( $$width ) ? ' width="' . $width . '"' : '') . ' ' . (empty( $$height ) ? ' height="' . $height . '"' : '') . ( '>
                           <param name=\'movie\' value=\'' . $src . '\'>
                           <param name=\'quality\' value=\'high\'>
                           <embed src=\'' . $src . '\' quality=\'high\'
                           pluginspage=\'http://www.macromedia.com/go/getflashplayer\'
                           type=\'application/x-shockwave-flash\' ' ) . (empty( $$width ) ? ' width="' . $width . '"' : '') . ' ' . (empty( $$height ) ? ' height="' . $height . '"' : '') . '></embed>
                         </object>
                         </a>';
				break;
			}

			case 2: {
				$ads[] = $row['ad_code'];
				break;
			}

			case 3: {
				$ads[] = '<a href=\'index.php?adid=' . $row['adid'] . '&amp;uri=' . urlencode( $row['ad_link'] ) . '\'
                target=\'_blank\'>' . htmlspecialchars( $row['ad_code'] ) . '</a>';
				break;
			}

			case 4: {
				$ads[] = eval( $row['ad_code'] );
				break;
			}

			case 5: {
				$ads[] = '<div id="flash_adv">
        <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cabversion=6,0,0,0" ' . (empty( $$width ) ? ' width="' . $width . '"' : '') . ' ' . (empty( $$height ) ? ' height="' . $height . '"' : '') . '>
        <param name="movie" value="' . $flash_src . '"><param name="quality" value="high">
        <param name="wmode" value="opaque">        
        <embed src="data/flashdata/dynfocus/dynfocus.swf" 
        quality="high" ' . (empty( $$width ) ? ' width="' . $width . '"' : '') . ' ' . (empty( $$height ) ? ' height="' . $height . '"' : '') . ' allowscriptaccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="transparent">
        </object></div>';
			}

			case 6: {
				$ads[] = '<div id="flash_cycle">
        <object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cabversion=6,0,0,0" width="484" height="200">
        <param name="movie" value="data/flashdata/dynfocus/dynfocus.swf">
        <param name="quality" value="high"><param name="wmode" value="opaque"><param name="FlashVars" value="pics=data/afficheimg/20081027angsif.jpg|data/afficheimg/20081027wdwd.jpg|data/afficheimg/20081027xuorxj.jpg&amp;links=http%3A//www.ecshop.com|http%3A//www.wdwd.com|http%3A//help.ecshop.com/index.php%3Fdoc-view-108.htm&amp;texts=ECShop|WDWD|ECShop&amp;pic_width=484&amp;pic_height=200&amp;show_text=1&amp;txtcolor=000000&amp;bgcolor=DDDDDD&amp;button_pos=4&amp;stop_time=3000">
        <embed src="data/flashdata/dynfocus/dynfocus.swf" flashvars="pics=data/afficheimg/20081027angsif.jpg|data/afficheimg/20081027wdwd.jpg|data/afficheimg/20081027xuorxj.jpg&amp;links=http%3A//www.ecshop.com|http%3A//www.wdwd.com|http%3A//help.ecshop.com/index.php%3Fdoc-view-108.htm&amp;texts=ECShop|WDWD|ECShop&amp;pic_width=484&amp;pic_height=200&amp;show_text=1&amp;txtcolor=000000&amp;bgcolor=DDDDDD&amp;button_pos=4&amp;stop_time=3000" quality="high" width="484" height="200" allowscriptaccess="sameDomain" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="transparent">
        </object></div>';
			}
		}

		return $ads[0];
	}

?>