<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_SESSION['log'] )) {
		if (0 < CONF_SESSION_TIMEOUT) {
			if ($_SESSION['timeout'] + CONF_SESSION_TIMEOUT * 60 < time(  )) {
				unset( $_SESSION[log] );
				unset( $_SESSION[pass] );
				unset( $_SESSION[timeout] );
				echo '<script>
   if (window.toolbar.visible == false)
   {
    alert(\'' . ADMIN_SESSION_EXPIRED . STRING_COUPON_EXPIRED . '\');
    window.close();
   }
   </script>';
				echo '<script type="text/javascript">
            if (parent.location!="") 
                {
                  alert("' . ADMIN_SESSION_EXPIRED . STRING_COUPON_EXPIRED . '");
                  parent.location="admincp.php";
                }                                                                    
           </script>';
			}
		}


		if (!( $q = db_query( 'SELECT cust_password FROM ' . CUSTOMERS_TABLE . ' WHERE Login=\'' . $_SESSION['log'] . '\'' ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$row = db_fetch_row( $q );

		if (( ( !$row || !isset( $_SESSION['pass'] ) ) || strcmp( $row[0], $_SESSION['pass'] ) )) {
			unset( $_SESSION[log] );
			unset( $_SESSION[pass] );
		}
	}

?>