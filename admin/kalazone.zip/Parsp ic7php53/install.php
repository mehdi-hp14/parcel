<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function _testWriteable() {
		if (!IsWriteable( DATABASE_STRUCTURE_XML_PATH )) {
			return STRING_COULDNT_REWRITE_FILE . ' ' . DATABASE_STRUCTURE_XML_PATH;
		}


		if (!IsWriteable( TABLES_INC_PHP_PATH )) {
			return STRING_COULDNT_REWRITE_FILE . ' ' . TABLES_INC_PHP_PATH;
		}


		if (!IsWriteable( CONNECT_INC_PHP_PATH )) {
			return STRING_COULDNT_REWRITE_FILE . ' ' . CONNECT_INC_PHP_PATH;
		}


		if (file_exists( RESULT_XML_PATH )) {
			if (!IsWriteable( RESULT_XML_PATH )) {
				return STRING_COULDNT_REWRITE_FILE . ' ' . RESULT_XML_PATH;
			}
		}

		return '';
	}

	function _createConnectInc() {
		$error = '';

		if (!is_writable( './cfg/connect.inc.php' )) {
			$error = 'Couldn\'t rewrite file cfg/connect.inc.php.';
		} 
else {
			$f = fopen( './cfg/connect.inc.php', 'w' );
			$s = '<?php
' . '//database connection settings
' . 'define(\'LICENCE\', \'' . trim( $_POST['lisenceCode'] ) . '\');
	// Licence code 
' . 'define(\'DBMS\', \'' . $_SESSION['dbms'] . '\');
	// database system
' . 'define(\'DB_HOST\', \'' . $_SESSION['databaseHost'] . '\');
	// database host
' . 'define(\'DB_USER\', \'' . $_SESSION['databaseUsername'] . '\');
	// username
' . 'define(\'DB_PASS\', \'' . $_SESSION['databasePassword'] . '\');
	// password
' . 'define(\'DB_NAME\', \'' . $_SESSION['databaseName'] . '\');
	// database name
' . 'define(\'ADMIN_LOGIN\', \'' . $_POST['adminLogin'] . '\');
	
 define(\'DBTABLE_PREFIX\',\'Parsp_\');
	
 define(\'MYSQL_CHARSET\',\'utf8\');	
	
 define(\'DIR_TPLS\',\'./templates/\');
	
 define(\'DIR_COMPILEDTEMPLATES\',\'./temp_c/\');
	
 define(\'DIR_SMARTY_CACHE\',\'./temp_c/\'); 
	// administrator\'s login
' . '
' . '// include table name file
' . 'include(\'./cfg/tables.inc.php\');
	
' . '?>';
			fputs( $f, $s );
			fclose( $f );
		}

		return $error;
	}

	function _reWriteInstallXmlFile() {
		ReWriteInstallXmlFile( DATABASE_STRUCTURE_XML_PATH, $_SESSION['tableFileName'], RESULT_XML_PATH );
		unlink( DATABASE_STRUCTURE_XML_PATH );
		rename( RESULT_XML_PATH, DATABASE_STRUCTURE_XML_PATH );
	}

	function _installNewDataBase() {
		$tables = db_get_all_ss_tables( DATABASE_STRUCTURE_XML_PATH );
		foreach ($tables as $tableName) {
			db_delete_table( $tableName );
		}

		CreateTablesIncFile( './cfg/tables.inc.php', DATABASE_STRUCTURE_XML_PATH, 'Parsp_' );
		$error = _createConnectInc(  );

		if ($error != '') {
			exit( '<center><font color=red>' . $error . '</font></center>' );
		}

		include( './cfg/connect.inc.php' );
		$showdbtable = CreateTablesStructureXML( DATABASE_STRUCTURE_XML_PATH );
		serImportWithConstantNameReplacing( './cfg/sql/setting_constants.sql', true );
		_setNewOrderStatus(  );
		_setCompletedStatus(  );

		if (isset( $_POST['generalDataCheckbox'] )) {
			serImportWithConstantNameReplacing( './cfg/sql/localization.sql' );
			_setDefaultCurrency(  );
			serImportWithConstantNameReplacing( './cfg/sql/customer_groups.sql' );
			_setCustGroupByDefault(  );
			serImportWithConstantNameReplacing( './cfg/sql/shipping_payments.sql' );
			serImportWithConstantNameReplacing( './cfg/sql/fa.sql' );
			_setPaymentShippingMethod(  );
			_initializeAuxPages(  );
		}


		if (isset( $_POST['exampleDataCheckbox'] )) {
			serImportWithConstantNameReplacing( './cfg/sql/demo_database.sql' );
		}

		$sql = CreateReferConstraintsXML( DATABASE_STRUCTURE_XML_PATH );
		settingDefineConstants(  );
		regRegisterAdmin( $_POST['adminLogin'], $_POST['adminPassword'] );
		regAuthenticate( $_POST['adminLogin'], $_POST['adminPassword'] );
		_sendByMail(  );
	}

	function _unsetDataBaseSessionVariables() {
		unset( $_SESSION[dbms] );
		unset( $_SESSION[databaseHost] );
		unset( $_SESSION[databaseUsername] );
		unset( $_SESSION[databasePassword] );
		unset( $_SESSION[databaseName] );
	}

	function _sendByMail() {
	}

	function _setDefaultCurrency() {
		_setSettingOptionValue( 'CONF_DEFAULT_CURRENCY', 1 );
	}

	function _setNewOrderStatus() {
		_setSettingOptionValue( 'CONF_NEW_ORDER_STATUS', 2 );
	}

	function _setCompletedStatus() {
		_setSettingOptionValue( 'CONF_COMPLETED_ORDER_STATUS', 5 );
	}

	function _setCustGroupByDefault() {
		_setSettingOptionValue( 'CONF_DEFAULT_CUSTOMER_GROUP', 2 );
	}

	function _setPaymentShippingMethod() {
		payResetPaymentShippingMethods( 1 );
		paySetPaymentShippingMethod( 1, 1 );
		paySetPaymentShippingMethod( 1, 2 );
		paySetPaymentShippingMethod( 1, 3 );
		paySetPaymentShippingMethod( 1, 4 );
		paySetPaymentShippingMethod( 1, 5 );
		payResetPaymentShippingMethods( 2 );
		paySetPaymentShippingMethod( 2, 1 );
		paySetPaymentShippingMethod( 2, 2 );
		paySetPaymentShippingMethod( 2, 3 );
		paySetPaymentShippingMethod( 2, 4 );
		paySetPaymentShippingMethod( 2, 5 );
		payResetPaymentShippingMethods( 3 );
		paySetPaymentShippingMethod( 3, 1 );
		paySetPaymentShippingMethod( 3, 2 );
		paySetPaymentShippingMethod( 3, 3 );
		paySetPaymentShippingMethod( 3, 4 );
		paySetPaymentShippingMethod( 3, 5 );
		payResetPaymentShippingMethods( 4 );
		paySetPaymentShippingMethod( 4, 1 );
		paySetPaymentShippingMethod( 4, 2 );
		paySetPaymentShippingMethod( 4, 3 );
		paySetPaymentShippingMethod( 4, 4 );
		paySetPaymentShippingMethod( 4, 5 );
		payResetPaymentShippingMethods( 5 );
		paySetPaymentShippingMethod( 5, 1 );
		paySetPaymentShippingMethod( 5, 2 );
		paySetPaymentShippingMethod( 5, 3 );
		paySetPaymentShippingMethod( 5, 4 );
		paySetPaymentShippingMethod( 5, 5 );
	}

	function _initializeAuxPages() {
		$aux_page['aux_page_text_fa'] = '<h1>درباره ما</h1>همین ....';
		$aux_page['aux_page_text_en'] = '<h1>About us</h1>its me ....';
		$aux_page['aux_page_name_fa'] = 'درباره ما';
		$aux_page['aux_page_name_en'] = 'About us';
		$aux_page['meta_keywords_fa'] = '';
		$aux_page['meta_keywords_en'] = '';
		$auxpf = '';
		$auxpv = '';
		foreach ($aux_page as $key => $value) {
			$auxpf .= $key . ',';
			$auxpv .= ( '\'' ) . $value . '\',';
		}

		$qry = 'insert into ' . AUX_PAGES_TABLE . ' ( ' . $auxpf . 'enabled,aux_page_text_type )  ' . ' values( ' . $auxpv . '1,1 ) ';
		db_query( $qry );
	}

	function check_dirs_priv($checking_dirs) {
		$_LANG = array(  );
		$_LANG['can_write'] = 'قابل نوشتن';
		$_LANG['cannt_write'] = 'غیرقابل نوشتن';
		$_LANG['not_exists'] = 'وجود ندارد';
		$msgs = array( 'result' => 'OK', 'detail' => array(  ) );
		foreach ($checking_dirs as $dir) {

			if (!file_exists( './' . $dir )) {
				$msgs['result'] = 'ERROR';
				$msgs['detail'][] = array( $dir, $_LANG['not_exists'], 0 );
				continue;
			}


			if (file_mode_info( './' . $dir ) < 2) {
				$msgs['result'] = 'ERROR';
				$msgs['detail'][] = array( $dir, $_LANG['cannt_write'], 0 );
				continue;
			}

			$msgs['detail'][] = array( $dir, $_LANG['can_write'], 1 );
		}

		return $msgs;
	}

	function file_mode_info($file_path) {
		if (!file_exists( $file_path )) {
			return false;
		}

		$mark = 872;

		if (strtoupper( substr( PHP_OS, 0, 3 ) ) == 'WIN') {
			$test_file = $file_path . '/cf_test.txt';

			if (is_dir( $file_path )) {
				$dir = @opendir( $file_path );

				if ($dir === false) {
					return $mark;
				}


				if (@readdir( $dir ) !== false) {
					$mark ^= 873;
				}

				@closedir( $dir );
				$fp = @fopen( $test_file, 'wb' );

				if ($fp === false) {
					return $mark;
				}


				if (@fwrite( $fp, 'directory access testing.' ) !== false) {
					$mark ^= 874;
				}

				@fclose( $fp );
				@unlink( $test_file );
				$fp = @fopen( $test_file, 'ab+' );

				if ($fp === false) {
					return $mark;
				}


				if (@fwrite( $fp, 'modify test.
' ) !== false) {
					$mark ^= 876;
				}

				@fclose( $fp );

				if (@rename( $test_file, $test_file ) !== false) {
					$mark ^= 880;
				}

				@unlink( $test_file );
			} 
else {
				if (is_file( $file_path )) {
					$fp = @fopen( $file_path, 'rb' );

					if ($fp) {
						$mark ^= 873;
					}

					@fclose( $fp );
					$fp = @fopen( $file_path, 'ab+' );

					if (( $fp && @fwrite( $fp, '' ) !== false )) {
						$mark ^= 878;
					}

					@fclose( $fp );

					if (@rename( $test_file, $test_file ) !== false) {
						$mark ^= 880;
					}
				}
			}
		} 
else {
			if (@is_readable( $file_path )) {
				$mark ^= 873;
			}


			if (@is_writable( $file_path )) {
				$mark ^= 886;
			}
		}

		return $mark;
	}

	define( 'INSTALL_LANGS', 'fa,en' );
	define( 'INSTALL_PROPS', 'فارسی;1;images/flags/fa.gif;fa;1;0;1,English;0;images/flags/en.gif;en;2;0;0' );
	define( 'CAT_ROOT_DIFF', 'ROOT,ریشه' );
	define( 'INSTALL_SETTING_GROUPS', '2;تنظیمات کلی;1,3; شکل ظاهری; 2,4; کاتالوگ; 3,5; مشتریان; 4,6; سبد خرید و سفارشات; 5,7; تنظیمات تصویر; 6,8;  بلوکها; 7,9;پست الکترونیک;8' );
	define( 'INSTALL_CONSTANTS', '' );
	define( 'INSTALL_ORDER_STATUSES', 'انصراف داده شده;Canceled;5,معلق;Pending;0,فیش بانکی ثبت شده;Charged;1,ارسال شده;Sent;2,تکمیل شده;Paid & Deliverd;3,تایید شده;Processing;4' );
	include( './core_functions/functions.php' );
	include( './core_functions/xml_parser.php' );
	include( './core_functions/xml_installer/xml_installer.php' );
	include( './core_functions/serialization_functions.php' );
	include( './core_functions/order_status_functions.php' );
	include( './core_functions/setting_functions.php' );
	include( './core_functions/category_functions.php' );
	include( './core_functions/registration_functions.php' );
	include( './core_functions/statistic_functions.php' );
	include( './core_functions/datetime_functions.php' );
	include( './core_functions/aux_pages_functions.php' );
	include( './core_functions/crypto/crypto_functions.php' );
	include( './classes/class.classmanager.php' );
	include( './classes/class.object.php' );
	include( './classes/class.dbresource.php' );
	include( './classes/class.database.php' );
	include( './classes/class.language.php' );
	include( './classes/class.languagesmanager.php' );
	include( './core_functions/payment_functions.php' );
	include( './cfg/paths.inc.php' );
	include( './core_functions/version_function.php' );
	include( './smarty/Smarty.class.php' );

	if (!file_exists( './temp_c' )) {
		mkdir( 'temp_c' );
	}


	if (!file_exists( './uploads' )) {
		mkdir( 'uploads' );
	}


	if (!file_exists( './uploads/logos' )) {
		mkdir( './uploads/logos/' );
	}


	if (!file_exists( './uploads/products_files' )) {
		mkdir( './uploads/products_files/' );
	}


	if (!file_exists( './uploads/products_videos/' )) {
		mkdir( './uploads/products_videos/' );
	}


	if (!file_exists( './uploads/products_pictures/' )) {
		mkdir( './uploads/products_pictures/' );
	}

	$smarty = new Smarty(  );
	$checking_dirs = array( 'temp_c', 'uploads', 'cfg/sql/', 'cfg/connect.inc.php' );
	session_start(  );
	@set_time_limit( 0 );
	MagicQuotesRuntimeSetting(  );
	$smarty->template_dir = './templates/install/';

	if (isset( $_GET['install_is_completed'] )) {
		$smarty->display( 'successful_install.tpl.html' );
	} 
else {
		if (!isset( $_GET['license'] )) {
			if (!isset( $_GET['step'] )) {
				$_GET['step'] = 1;
			}


			if (( ( $_GET['step'] != 1 && $_GET['step'] != 2 ) && $_GET['step'] != 3 )) {
				$_GET['step'] = 1;
			}

			switch ($_GET['step']) {
				case 1: {
					$smarty->display( 'step1.tpl.html' );
					break;
				}

				case 2: {
					$error = _testWriteable(  );
					$check_dir = check_dirs_priv( $checking_dirs );
					$smarty->assign( 'dir_checking', $check_dir['detail'] );
					$sysinf = get_system_info(  );
					$smarty->assign( 'system_info', $sysinf );
					_testWriteable(  );

					if ($error =  != '') {
						$smarty->assign( 'file_is_not_writeable', $error );
					} 
else {
						if (isset( $_GET['nextstep'] )) {
							$smarty->assign( 'databaseHost', $_POST['_databaseHost'] );
							$smarty->assign( 'databaseUsername', $_POST['_databaseUsername'] );
							$smarty->assign( 'databasePassword', $_POST['_databasePassword'] );
							$smarty->assign( 'databaseName', $_POST['_databaseName'] );
							$smarty->assign( 'dbms', $_POST['_dbms'] );

							if (!file_exists( './includes/database/' . $_POST['_dbms'] . '.php' )) {
								exit( 'Couldn\'t find database functions file (includes/database/' . $_POST['_dbms'] . '.php)
                 <br>
                 Please reupload iwd to your server.' );
							} 
else {
								include( './includes/database/' . $_POST['_dbms'] . '.php' );
							}

							$res = db_connect( $_POST['_databaseHost'], $_POST['_databaseUsername'], $_POST['_databasePassword'] );

							if (is_bool( $res )) {
								$smarty->assign( 'errorCode', 1 );
								$smarty->display( 'step2.tpl.html' );
								exit(  );
							}

							$res = db_select_db( $_POST['_databaseName'] );

							if (!$res) {
								$smarty->assign( 'errorCode', 2 );
								$smarty->display( 'step2.tpl.html' );
								exit(  );
							}

							$_SESSION['dbms'] = $_POST['_dbms'];
							$_SESSION['databaseHost'] = $_POST['_databaseHost'];
							$_SESSION['databaseUsername'] = $_POST['_databaseUsername'];
							$_SESSION['databasePassword'] = $_POST['_databasePassword'];
							$_SESSION['databaseName'] = $_POST['_databaseName'];

							if (( isset( $_FILES['tableFileName'] ) && isset( $_FILES['tableFileName']['name'] ) )) {
								if (trim( $_FILES['tableFileName']['name'] ) != '') {
									$file_name = str_replace( ' ', '_', $_FILES['tableFileName']['name'] );
									move_uploaded_file( $_FILES['tableFileName']['tmp_name'], './temp_c/' . $file_name );
									SetRightsToUploadedFile( './temp_c/' . $file_name );
									$_SESSION['tableFileName'] = './temp_c/' . $file_name;
								}
							}


							if (!isset( $_GET['upgrade'] )) {
								RedirectJavaScript( 'install.php?step=3' );
							} 
else {
								RedirectJavaScript( 'install.php?step=3&upgrade=' . $_GET['upgrade'] );
							}
						}


						if (isset( $_GET['upgrade'] )) {
							$smarty->assign( 'upgrade', $_GET['upgrade'] );
						}
					}

					$smarty->display( 'step2.tpl.html' );
					break;
				}

				case 3: {
					if (!isset( $_SESSION['dbms'] )) {
						Redirect( 'install.php' );
					}


					if (!file_exists( './includes/database/' . $_SESSION['dbms'] . '.php' )) {
						Redirect( 'install.php' );
					}

					include( './includes/database/' . $_SESSION['dbms'] . '.php' );
					db_connect( $_SESSION['databaseHost'], $_SESSION['databaseUsername'], $_SESSION['databasePassword'] );
					db_select_db( $_SESSION['databaseName'] );

					if (!isset( $_GET['upgrade'] )) {
						$tables = db_get_all_ss_tables( DATABASE_STRUCTURE_XML_PATH );
						$smarty->assign( 'tables', $tables );

						if (isset( $_POST['install'] )) {
							_installNewDataBase(  );
							CallInstallFunctions(  );
							_unsetDataBaseSessionVariables(  );
							Redirect( 'install.php?install_is_completed' );
						}
					} 
else {
						if (isset( $_POST['install'] )) {
							if (isset( $_SESSION['tableFileName'] )) {
								_reWriteInstallXmlFile(  );
							}

							CallInstallFunctions(  );
							_upgradeOldDataBase(  );
							_unsetDataBaseSessionVariables(  );
							Redirect( 'install.php?install_is_completed' );
						}
					}


					if (isset( $_GET['upgrade'] )) {
						$smarty->assign( 'upgrade', $_GET['upgrade'] );
					}

					$smarty->display( 'step3.tpl.html' );
				}
			}
		} 
else {
			$smarty->display( 'license.html' );
		}
	}

	echo '
';
?>