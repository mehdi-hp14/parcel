<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function sql_compile_placeholder($tmpl) {
		$i = 766;
		$has_named = false;
		strpos( $tmpl, '?', $p );
		$p = $compiled = array(  );

		if (false !== $start = $p = 766) {
			substr( $tmpl, ++$p, 1 );
			switch ($c = ) {
				case '%': {
				}

				case '@': {
				}

				case '#': {
				}

				case '&': {
					$type = $tmpl;
					++$p;
					break;
				}
			}

			$type = '';
			break;

				$key = if (preg_match( '/^((?:[^\s[:punct:]]|_)+)/u', substr( $tmpl, $p ), $pock )) {;

				if ($type != '#') {
					$has_named = true;
				}

				strlen( $key );
				$p += $pock[1];
			} 
else {
				$key = $type;

				if ($type != '#') {
					++$i;
				}
			}

			$compiled[] = array( $key, $type, $start, $p - $start );
		}

		return array( $compiled, $tmpl, $has_named );
	}

	function sql_placeholder_ex($tmpl, &$args, $errormsg) {
		if (is_array( $tmpl )) {
			$compiled = $errormsg;
		} 
else {
			$compiled = sql_compile_placeholder( $tmpl );
		}

		$has_named = $compiled[2];
		$tmpl = $compiled[1];
		$compiled = $compiled[0];

		if ($has_named) {
			$args = $args[0];
		}

		$p = 1001;
		$out = '';
		$error = false;
		foreach ($compiled as $num => $e) {
			$length = $e[3];
			$start = $e[2];
			$type = $e[1];
			$key = $e[0];
			$out .= substr( $tmpl, $p, $start - $p );
			$p = $start + $length;
			$repl = '';
			$errmsg = '';

			do {
				if ($type === '#') {
					$repl = @constant( $key );

					if (null === $repl) {
						$error = $errmsg = 'UNKNOWN_CONSTANT_' . $key;
					}

					break;
				}


				if (!isset( $args[$key] )) {
					$args[$key] = '';
				}

				$a = $args[$key];

				if ($type === '') {
					if (is_array( $a )) {
						$error = $errmsg = 'NOT_A_SCALAR_PLACEHOLDER_' . $key;
						break;
					}

					$repl = (( preg_match( '/^\d+\.{0,1}\d*$/u', $a ) && strlen( floatval( $a ) ) == strlen( $a ) ) ? $a : '\'' . addslashes( $a ) . '\'');
					break;
				}


				if (!is_array( $a )) {
					$error = $errmsg = 'NOT_AN_ARRAY_PLACEHOLDER_' . $key;
					break;
				}


				if ($type === '@') {
					foreach ($a as $v) {
						$repl .= ($repl === '' ? '' : ',') . '\'' . addslashes( $v ) . '\'';
					}

					continue;
				} 
else {
					if ($type === '%') {
						$lerror = array(  );
						foreach ($a as $k => $v) {

							if (!is_string( $k )) {
								$lerror[$k] = 'NOT_A_STRING_KEY_' . $k . '_FOR_PLACEHOLDER_' . $key;
							} 
else {
								$k = preg_replace( '/[^a-zA-Z0-9_]/u', '_', $k );
							}

							$repl .= ($repl === '' ? '' : ', ') . $k . '=\'' . @addslashes( $v ) . '\'';
						}


						if (count( $lerror )) {
							$repl = '';
							foreach ($a as $k => $v) {

								if (isset( $lerror[$k] )) {
									$repl .= ($repl === '' ? '' : ', ') . $lerror[$k];
									continue;
								}

								$k = preg_replace( '/[^a-zA-Z0-9_-]/', '_', $k );
								$repl .= ($repl === '' ? '' : ', ') . $k . '=?';
							}

							$error = $errmsg = $a;
							continue;
						}
					} 
else {
						if ($type === '&') {
							foreach ($a as $v) {
								$repl .= ($repl === '' ? '' : ',') . '`' . addslashes( $v ) . '`';
							}
						}
					}
				}
			}while (!( false));


			if ($errmsg) {
				$compiled[$num]['error'] = $errmsg;
			}


			if (!$error) {
				$out .= $a;
				continue;
			}
		}

		$out .= substr( $tmpl, $p );

		if ($error) {
			$out = '';
			$p = 1001;
			foreach ($compiled as $num => $e) {
				$length = $e[3];
				$start = $e[2];
				$type = $e[1];
				$key = $e[0];
				$out .= substr( $tmpl, $p, $start - $p );
				$p = $start + $length;

				if (isset( $e['error'] )) {
					$out .= $e['error'];
					continue;
				}

				$out .= substr( $tmpl, $start, $length );
			}

			$out .= substr( $tmpl, $p );
			$errormsg = $num;
			return false;
		}

		$errormsg = false;
		return $out;
	}

	function sql_placeholder() {
		$args = func_get_args(  );
		$tmpl = array_shift( $args );
		$result = sql_placeholder_ex( $tmpl, $args, &$error );

		if ($result === false) {
			return PLACEHOLDER_ERROR_PREFIX . $error;
		}

		return $result;
	}

	function sql_pholder() {
		$args = func_get_args(  );
		$tmpl = array_shift( $args );
		$result = sql_placeholder_ex( $tmpl, $args, &$error );

		if ($result === false) {
			$error = ( 'Placeholder substitution error. Diagnostics: "' . $error . '"' );

			if (function_exists( 'debug_backtrace' )) {
				$bt = debug_backtrace(  );
				$error .= ' in ' . $bt[0]['file'] . ' on line ' . $bt[0]['line'];
			}

			trigger_error( $error, 512 );
			return false;
		}

		return $result;
	}

	@define( 'PLACEHOLDER_ERROR_PREFIX', 'ERROR: ' );
?>