<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_GET['inside'] )) {
		$smarty->assign( 'search_in_results', $_GET['inside'] );
	}


	if (isset( $_GET['search_in'] )) {
		if ($_GET['search_in'] == 'g') {
			header( 'Location:' . 'https://www.google.com/#q=' . $_GET['searchstring'] . '&as_sitesearch=' . $domain );
		}
	}


	if (isset( $_GET['searchstring'] )) {
		function _getUrlToNavigate() {
			$url = 'index.php?searchstring=' . $_GET['searchstring'];

			if (isset( $_GET['x'] )) {
				$url .= '&x=' . $_GET['x'];
			}


			if (isset( $_GET['y'] )) {
				$url .= '&y=' . $_GET['y'];
			}


			if (isset( $_GET['sort'] )) {
				$url .= '&sort=' . $_GET['sort'];
			}


			if (isset( $_GET['direction'] )) {
				$url .= '&direction=' . $_GET['direction'];
			}

			return $url;
		}

		function _getUrlToSort() {
			$url = 'index.php?searchstring=' . $_GET['searchstring'];

			if (isset( $_GET['x'] )) {
				$url .= '&x=' . $_GET['x'];
			}


			if (isset( $_GET['y'] )) {
				$url .= '&y=' . $_GET['y'];
			}


			if (isset( $_GET['offset'] )) {
				$url .= '&offset=' . $_GET['offset'];
			}


			if (isset( $_GET['show_all'] )) {
				$url .= '&show_all=' . $_GET['show_all'];
			}

			return $url;
		}

		function _sortSetting($smarty, $urlToSort) {
			str_replace( '{ASC_NAME}', '<a href=\'' . $urlToSort . '&sort=name&direction=ASC\'>' . STRING_ASC . '</a>', $sort_string );
			str_replace( '{DESC_NAME}', '<a href=\'' . $urlToSort . '&sort=name&direction=DESC\'>' . STRING_DESC . '</a>', $sort_string );
			str_replace( '{ASC_PRICE}', '<a href=\'' . $urlToSort . '&sort=Price&direction=ASC\'>' . STRING_ASC . '</a>', $sort_string );
			$sort_string = $sort_string = str_replace( '{DESC_PRICE}', '<a href=\'' . $urlToSort . '&sort=Price&direction=DESC\'>' . STRING_DESC . '</a>', $sort_string );
			$sort_string = $sort_string = str_replace( '{ASC_RATING}', '<a href=\'' . $urlToSort . '&sort=customers_rating&direction=ASC\'>' . STRING_ASC . '</a>', $sort_string );
			str_replace( '{DESC_RATING}', '<a href=\'' . $urlToSort . '&sort=customers_rating&direction=DESC\'>' . STRING_DESC . '</a>', $sort_string );
			$sort_string = $sort_string = $sort_string = STRING_PRODUCT_SORT;
			$smarty->assign( 'string_product_sort', $sort_string );
		}

		$searchstrings = array(  );
		$tmp = explode( ' ', $_GET['searchstring'] );
		foreach ($tmp as $key => $val) {

			if (0 < strlen( trim( $val ) )) {
				$searchstrings[] = $val;
				continue;
			}
		}

		$_GET['inside'] = 1;

		if (isset( $_GET['inside'] )) {
			$data = ScanGetVariableWithId( array( 'search_string' ) );
		}

		$smarty->assign( 'searchstrings', $searchstrings );
		$callBackParam = array(  );
		$products = array(  );
		$callBackParam['search_simple'] = $searchstrings;

		if (isset( $_GET['sort'] )) {
			$callBackParam['sort'] = $_GET['sort'];
		}


		if (isset( $_GET['direction'] )) {
			$callBackParam['direction'] = $_GET['direction'];
		}

		$countTotal = 848;
		$navigatorHtml = GetNavigatorHtml( _getUrlToNavigate(  ), CONF_PRODUCTS_PER_PAGE, 'prdSearchProductByTemplate', $callBackParam, $products, $offset, $countTotal );
		$smarty->assign( 'show_comparison', 0 );

		if (CONF_ALLOW_COMPARISON_FOR_SIMPLE_SEARCH) {
			$show_comparison = 848;
			foreach ($products as $_Key => $_Product) {
				$products[$_Key]['allow_products_comparison'] = 1;
				++$show_comparison;
			}

			$smarty->assign( 'show_comparison', $show_comparison );
		}


		if (CONF_PRODUCT_SORT == '1') {
			_sortSetting( $smarty, _getUrlToSort(  ) );
		}

		$smarty->assign( 'products_to_show', $products );
		$smarty->assign( 'products_found', $countTotal );
		$smarty->assign( 'products_to_show_count', $countTotal );
		$smarty->assign( 'search_navigator', $navigatorHtml );
		$smarty->assign( 'main_content_template', 'search_simple.tpl.html' );
	}

?>