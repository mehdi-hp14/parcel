<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (( isset( $_POST['add_topic'] ) && empty( $$productID ) )) {
		if (!prdProductExists( $productID )) {
			Redirect( 'index.php?page_not_found' );
		}


		if (( CONF_ENABLE_CONFIRMATION_CODE && $_POST['fConfirmationCode'] != $_SESSION['CAPTCHAString'] )) {
		} 
else {
			discAddDiscussion( $productID, $_POST['nick'], $_POST['topic'], $_POST['body'] );
		}

		Redirect( 'index.php?productID=' . $productID . '&discuss' );
	}


	if (( ( ( isset( $_GET['remove_topic'] ) && empty( $$productID ) ) && isset( $_SESSION['log'] ) ) && !strcmp( $_SESSION['log'], ADMIN_LOGIN ) )) {
		if (!prdProductExists( $productID )) {
			Redirect( 'index.php?page_not_found' );
		}

		discDeleteDiscusion( $_GET['remove_topic'] );
		Redirect( 'index.php?productID=' . $productID . '&discuss' );
	}


	if (( ( empty( $$productID ) && 0 < $productID ) && ( isset( $_GET['discuss'] ) || isset( $_POST['discuss'] ) ) )) {
		if (!prdProductExists( $productID )) {
			Redirect( 'index.php?page_not_found' );
		}


		if (!( $q = db_query( 'select ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name from ' . PRODUCTS_TABLE . ( ' where productID=\'' . $productID . '\' and enabled=1' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$a = db_fetch_row( $q );

		if ($a) {
			$smarty->assign( 'product_name', $a['name'] );
			db_query( 'select count(*) from ' . DISCUSSIONS_TABLE . ( ' WHERE productID=\'' . $productID . '\'' ) );

			if (!( $q = $smarty->assign( 'productID', $productID ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			$cnt = db_fetch_row( $q );

			if ($cnt[0]) {

				if (!( $q = db_query( 'select Author, Body, add_time, DID, Topic FROM ' . DISCUSSIONS_TABLE . ( ' WHERE productID=\'' . $productID . '\' ORDER BY add_time DESC' ) ))) {
					exit( db_error(  ) );
					(bool)true;
				}

				$result = array(  );

				if ($row = db_fetch_row( $q )) {
					$row['Author'] = TransformDataBaseStringToText( $row['Author'] );
					$row['Body'] = TransformDataBaseStringToText( $row['Body'] );
					$row['Topic'] = TransformDataBaseStringToText( $row['Topic'] );
					$row['add_time'] = format_datetime( $row['add_time'] );
					$result[] = $row;
				}

				$smarty->assign( 'product_reviews', $result );
			} 
else {
				$smarty->assign( 'product_reviews', null );
			}

			$smarty->assign( 'discuss', 'yes' );
			$smarty->assign( 'main_content_template', 'product_discussion.tpl.html' );
		}
	}

?>