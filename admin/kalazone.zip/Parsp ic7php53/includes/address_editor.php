<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (( ( empty( $$address_editor ) || empty( $$add_new_address ) ) && isset( $_SESSION['log'] ) )) {
		$_POST = xStripSlashesGPC( $_POST );
		$errorCode = '';
		$countryID = CONF_DEFAULT_COUNTRY;

		if (!isset( $_POST['zoneID'] )) {
			$_POST['zoneID'] = 0;
		}


		if (!isset( $_POST['state'] )) {
			$_POST['state'] = '';
		}


		if (empty( $$add_new_address )) {
			$smarty->assign( 'add_new_address', 1 );
		}


		if (empty( $$address_editor )) {
			$smarty->assign( 'address_editor', $address_editor );
		}


		if (isset( $_POST['save'] )) {
			$first_name = $_POST['first_name'];
			$last_name = $_POST['last_name'];
			$countryID = $_POST['countryID'];
			$zoneID = $_POST['zoneID'];
			$state = $_POST['state'];
			$zip = $_POST['zip'];
			$city = $_POST['city'];
			$cityID = $_POST['cityID'];
			$address = $_POST['address'];
			$phone = $_POST['phone'];
			$mobile = $_POST['mobile'];
			$error = regVerifyAddress( $first_name, $last_name, $countryID, $zoneID, $state, $zip, $city, $cityID, $address, $phone, $mobile );

			if ($error == '') {
				unset( $$error );
			} 
else {
				$smarty->assign( 'error', $error );
			}


			if (!empty( $$error )) {
				if (empty( $$add_new_address )) {
					regAddAddress( $first_name, $last_name, $countryID, $zoneID, $state, $zip, $city, $cityID, $address, $_SESSION['log'], $errorCode, $country_iso_2 );
					header( 'Location: index.php?address_book' );
				} 
else {
					if (empty( $$address_editor )) {
						regUpdateAddress( $address_editor, $first_name, $last_name, $countryID, $zoneID, $state, $zip, $city, $cityID, $address, $errorCode );
						header( 'Location: index.php?address_book' );
					}
				}
			}
		}


		if (isset( $_POST['first_name'] )) {
			$smarty->assign( 'first_name', $_POST['first_name'] );
			$smarty->assign( 'last_name', $_POST['last_name'] );
			$smarty->assign( 'countryID', $_POST['countryID'] );
			$smarty->assign( 'zoneID', $_POST['zoneID'] );
			$smarty->assign( 'state', $_POST['state'] );
			$smarty->assign( 'zip', $_POST['zip'] );
			$smarty->assign( 'city', $_POST['city'] );
			$smarty->assign( 'address', $_POST['address'] );
			$smarty->assign( 'phone', $_POST['phone'] );
			$smarty->assign( 'mobile', $_POST['mobile'] );
			$zoneID = $_POST['zoneID'];
			$cityID = $_POST['cityID'];
			$country_iso_2 = cnGetCountryById( $_POST['countryID'] );
			$country_iso_2 = $country_iso_2['country_iso_2'];
			$cities = ctGetCitysById( $country_iso_2, $_POST['zoneID'] );
			$zones = znGetZonesById( $country_iso_2 );
			$smarty->assign( 'zones', $zones );
			$smarty->assign( 'cities', $cities );
		} 
else {
			if (empty( $$address_editor )) {
				$address_editor = (int)$address_editor;

				if (!isset( $_SESSION['log'] )) {
					Redirect( 'index.php?page_not_found' );
				}

				$address = regGetAddressByLogin( $address_editor, $_SESSION['log'] );

				if ($address === false) {
					Redirect( 'index.php?page_not_found' );
				} 
else {
					$smarty->assign( 'first_name', $address['first_name'] );
					$smarty->assign( 'last_name', $address['last_name'] );
					$smarty->assign( 'countryID', $address['countryID'] );
					$smarty->assign( 'country_iso_2', $address['country_iso_2'] );
					$smarty->assign( 'cityID', $address['cityID'] );
					$smarty->assign( 'zoneID', $address['zoneID'] );
					$smarty->assign( 'state', $address['state'] );
					$smarty->assign( 'zip', $address['zip'] );
					$smarty->assign( 'city', $address['city'] );
					$smarty->assign( 'address', $address['address'] );
					$smarty->assign( 'phone', $address['phone'] );
					$smarty->assign( 'mobile', $address['mobile'] );
					$zoneID = $address['zoneID'];
					$cityID = $address['cityID'];
					$country_iso_2 = cnGetCountryById( $address['countryID'] );
					$country_iso_2 = $country_iso_2['country_iso_2'];
					$cities = ctGetCitysById( $country_iso_2, $address['zoneID'] );
					$zones = znGetZonesById( $country_iso_2 );
					$smarty->assign( 'cities', $cities );
					$smarty->assign( 'zones', $zones );
				}
			}
		}


		if (( empty( $$zones ) && !empty( $$zoneID ) )) {
			$smarty->assign( 'select_zone_statement', ERROR_ZONE_DOES_NOT_CONTAIN_TO_COUNTRY );
		}


		if (( empty( $$cities ) && !empty( $$cityID ) )) {
			$smarty->assign( 'select_city_statement', ERROR_CITY_DOES_NOT_CONTAIN_TO_COUNTRY );
		}

		$callBackParam = null;
		$count_row = 1082;
		$smarty->assign( 'countries', cnGetCountries( $callBackParam, $count_row ) );
		$smarty->assign( 'main_content_template', 'address_editor.tpl.html' );
	}

?>