<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_GET['logout'] )) {
		unset( $_SESSION[log] );
		unset( $_SESSION[pass] );
		RedirectJavaScript( 'index.php' );
	} 
else {
		if (CONF_SHOW_USERCREDIT == 1) {
			if (isset( $_SESSION['log'] )) {
				$userCredit = getUcreditByLogin( $_SESSION['log'] );
				$smarty->assign( 'userCredit', show_price( $userCredit, CONF_DEFAULT_CURRENCY, 1 ) );
			}
		}
	}


	if (( isset( $_POST['enter'] ) && !isset( $_SESSION['log'] ) )) {
		if (regAuthenticate( $_POST['user_login'], $_POST['user_pw'] )) {
			if (!isset( $_POST['order'] )) {
				if (!strcmp( $_SESSION['log'], ADMIN_LOGIN )) {
					Redirect( 'admincp.php' );
				} 
else {
					Redirect( 'index.php?user_details' );
				}
			}
		} 
else {
			$wrongLoginOrPw = 947;
		}
	}


	if (isset( $_POST['forgotpw'] )) {
		$smarty->assign( 'forgotpw', xStripSlashesHTMLspecialChars( $_POST['forgotpw'] ) );
		$res = regSendPasswordToUser( $_POST['forgotpw'], $smarty_mail );

		if ($res) {
			$smarty->assign( 'login_was_found', 1 );
		} 
else {
			$smarty->assign( 'login_wasnt_found', 1 );
		}

		$show_password_form = 947;
	}


	if (( ( isset( $_GET['logging'] ) || empty( $$show_password_form ) ) || empty( $$wrongLoginOrPw ) )) {
		if (empty( $$wrongLoginOrPw )) {
			$smarty->assign( 'wrongLoginOrPw', 1 );
		}

		$smarty->assign( 'main_content_template', 'password.tpl.html' );
	}


	if (isset( $_GET['remindpass'] )) {
		$g = explode( '__', $_GET['uid'] );
		$check = checkforremind( base64_decode( $g[0] ), base64_decode( $g[1] ) );

		if ($check != false) {
			if (isset( $_POST['uid'] )) {
				if ($_POST['new_password'] == $_POST['renew_password']) {
					$new_pass = $_POST['new_password'];
					regGetCustomerInfo2( $check );
					$CustomerInfo = ;

					if (is_array( $CustomerInfo )) {
						$sql = '
      				    UPDATE `' . CUSTOMERS_TABLE . '`
      				    SET  cust_password="' . cryptPasswordCrypt( $new_pass ) . '"
      				    WHERE Login="' . xEscapeSQLstring( $check ) . '"';

						if (!( $q = db_query( $sql ))) {
							exit( db_error(  ) );
							(bool)true;
						}


						if (regAuthenticate( $check, $new_pass )) {
							$smarty->assign( 'MessageBlock', STRING_CHANGE_PASSWORD_CHANGED );

							if (!isset( $_POST['order'] )) {
								if (!strcmp( $_SESSION['log'], ADMIN_LOGIN )) {
									Redirect( 'admincp.php' );
									return 1;
								}

								Redirect( 'index.php?user_details' );
								return 1;
							}
						}
					}
				} 
else {
					$smarty->assign( 'MessageBlock', ERROR_WRONG_PASSWORD_CONFIRMATION );
					$smarty->assign( 'login', $check );
					$smarty->assign( 'uid', $_GET['uid'] );
					$smarty->assign( 'main_content_template', 'remindpassword.tpl.html' );
					return 1;
				}
			}

			$smarty->assign( 'login', $check );
			$smarty->assign( 'uid', $_GET['uid'] );
			$smarty->assign( 'main_content_template', 'remindpassword.tpl.html' );
		}
	}

?>