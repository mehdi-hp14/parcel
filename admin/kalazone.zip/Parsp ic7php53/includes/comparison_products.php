<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (empty( $$comparison_products )) {
		$hiddenValue = '';

		if (isset( $_POST['ComparisonHidden1'] )) {
			$hiddenValue = $_POST['ComparisonHidden1'];
		}


		if (isset( $_POST['ComparisonHidden2'] )) {
			$hiddenValue = $_POST['ComparisonHidden2'];
		}

		$hiddenValue = trim( $hiddenValue );
		$productIDArray = explode( ' ', $hiddenValue );
		$showProductCategoryPath = true;
		$products = array(  );

		if (count( $productIDArray )) {
			$sql = '
			SELECT productID,' . LanguagesManager::sql_constractSortField( PRODUCTS_TABLE, 'name' ) . ' FROM ' . PRODUCTS_TABLE . ' WHERE productID IN ("' . implode( '","', $productIDArray ) . '")
			ORDER BY sort_order ASC ,_name_sort ASC
		';
			$Result = db_query( $sql );
			$productIDArray = array(  );

			if ($_Row = db_fetch_row( $Result )) {
				$productIDArray[] = $_Row[0];
			}
		}

		foreach ($productIDArray as $_productID) {
			$product = GetProduct( $_productID );

			if ($product) {
				if (( empty( $$_tCategory ) && $showProductCategoryPath )) {
					if ($_tCategory != $product['categoryID']) {
						$showProductCategoryPath = false;
					}
				}

				$_tCategory = $product['categoryID'];
				$product['thumbnail'] = GetThumbnail( $_productID );
				$product['saveWithUnit'] = show_price( $product['list_price'] - $product['Price'] );

				if ($product['list_price'] != 0) {
					$product['savePercent'] = ceil( ( $product['list_price'] - $product['Price'] ) / $product['list_price'] * 100 );
				}

				$product['list_priceWithUnit'] = show_price( $product['list_price'] );
				$product['PriceWithUnit'] = show_price( $product['Price'] );
				$products[] = $product;
				continue;
			}
		}

		$options = cfgGetOptions(  );
		$definedOptions = array(  );
		foreach ($options as $option) {
			$optionIsDefined = false;
			foreach ($products as $product) {
				foreach ($product['option_values'] as $optionValue) {

					if ($optionValue['optionID'] == $option['optionID']) {
						if (( ( $optionValue['option_type'] == 0 && $optionValue['value'] != '' ) || $optionValue['option_type'] == 1 )) {
							$optionIsDefined = true;
							break;
						}

						continue;
					}
				}
			}


			if ($optionIsDefined) {
				$definedOptions[] = $option['optionID'];
				continue;
			}
		}

		$sql = '
		SELECT optionID,' . LanguagesManager::sql_constractSortField( PRODUCT_OPTIONS_TABLE, 'name' ) . ',' . LanguagesManager::sql_prepareField( 'name' ) . ' as name FROM ' . PRODUCT_OPTIONS_TABLE . ' 
		WHERE optionID IN("' . implode( '", "', $definedOptions ) . '")
		ORDER BY sort_order ASC,_name_sort
	';
		$definedOptions = array(  );
		$Result = db_query( $sql );

		if ($_Row = db_fetch_row( $Result )) {
			$definedOptions[] = $_Row;
		}

		$optionIndex = 1043;
		foreach ($definedOptions as $option) {
			$productIndex = 1043;
			foreach ($products as $product) {
				$existFlag = false;
				foreach ($product['option_values'] as $optionValue) {

					if ($optionValue['optionID'] == $option['optionID']) {
						if (( $optionValue['option_type'] == 0 && $optionValue['value'] != '' )) {
							$value = $optionValue['value'];
						} 
else {
							if ($optionValue['option_type'] == 1) {
								$value = '';
								$extra = GetExtraParametrs( $product['productID'] );
								foreach ($extra as $item) {

									if (( ( ( $item['option_type'] == 1 && $item['optionID'] == $optionValue['optionID'] ) && isset( $item['values_to_select'] ) ) && 0 < count( $item['values_to_select'] ) )) {
										foreach ($item['values_to_select'] as $value_to_select) {

											if ($value != '') {
												$value .= ' / ' . $value_to_select['option_valueWithOutPrice'];
												continue;
											}

											$value .= $value_to_select['option_valueWithOutPrice'];
										}

										continue;
									}
								}
							} 
else {
								$value = STRING_VALUE_IS_UNDEFINED;
							}
						}

						$products[$productIndex][$optionIndex] = $value;
						$existFlag = true;
						break;
					}
				}


				if (!$existFlag) {
					$products[$productIndex][$optionIndex] = STRING_VALUE_IS_UNDEFINED;
				}

				++$productIndex;
			}

			++$optionIndex;
		}


		if (( 0 < count( $products ) && $showProductCategoryPath )) {
			$smarty->assign( 'product_category_path', catCalculatePathToCategory( $products[0]['categoryID'] ) );
			$category = catGetCategoryById( $products[0]['categoryID'] );

			if ($category) {
				$smarty->assign( 'category_description', $category['description'] );
			}
		}

		$smarty->assign( 'definedOptions', $definedOptions );
		$smarty->assign( 'products', $products );
		$smarty->assign( 'products_count', count( $products ) );
		$smarty->assign( 'main_content_template', 'comparison_products.tpl.html' );
	}

?>