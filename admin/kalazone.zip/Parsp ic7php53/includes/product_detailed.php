<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$smarty->assign( 'selected_tab', 0 );

	if (isset( $_POST['cart_x'] )) {
		$variants = array(  );
		foreach ($_POST as $key => $val) {

			if (strstr( $key, 'option_select_hidden_' )) {
				$variants[] = $val;
				continue;
			}
		}

		unset( $_SESSION[variants] );
		$_SESSION['variants'] = $variants;
		header( 'Location: index.php?shopping_cart&add2cart=' . (int)$_GET['productID'] );
	}


	if (( isset( $_GET['vote'] ) && isset( $_GET['productID'] ) )) {
		$smarty->assign( 'selected_tab', 4 );

		if (( ( !isset( $_SESSION['vote_completed'][$productID] ) && isset( $_GET['mark'] ) ) && 0 < strlen( $_GET['mark'] ) )) {
			$mark = (double)$_GET['mark'];

			if (( 0 <= $mark && $mark <= 5 )) {
				if (!( db_query( 'UPDATE ' . PRODUCTS_TABLE . ' SET customers_rating=(customers_rating*customer_votes+\'' . $mark . '\')/(customer_votes+1), customer_votes=customer_votes+1 WHERE productID=\'' . $productID . '\'' ))) {
					exit( db_error(  ) );
					(bool)true;
				}
			}
		}

		$_SESSION['vote_completed'][$productID] = 1;
	}


	if (isset( $_SESSION['vote_completed'][$productID] )) {
		$smarty->assign( 'voted', 1 );
	}


	if (isset( $_POST['request_information'] )) {
		$smarty->assign( 'selected_tab', 3 );
		$customer_name = xStripSlashesGPC( $_POST['customer_name'] );
		$customer_email = xStripSlashesGPC( $_POST['customer_email'] );
		$message_subject = xStripSlashesGPC( $_POST['message_subject'] );
		$message_text = xStripSlashesGPC( $_POST['message_text'] );

		if (( CONF_ENABLE_CONFIRMATION_CODE && $_POST['fConfirmationCode'] != $_SESSION['CAPTCHAString'] )) {
			$smarty->assign( 'error', 1 );
		} 
else {
			if (( ( ( ( trim( $customer_email ) != '' && trim( $customer_name ) != '' ) && trim( $message_subject ) != '' ) && trim( $message_text ) != '' ) && preg_match( '/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i', $customer_email ) )) {
				$customer_name = str_replace( array( '@', '<', '
' ), array( '[at]', '', '' ), $customer_name );

				$customer_email = str_replace( array( '
', '<' ), '', $customer_email );

				$message_text = '<table cellpadding="0" cellspacing="0" style="width: 100%;" align="center" dir="rtl" style="font-family:Tahoma; font-size:8pt">
  		  <tr><td>' . nl2br( $message_text ) . '</td></tr><tr><td>' . $customer_email . '</td></tr><tr><td>' . $customer_name . '</td></tr></table>';
				sendEmail( CONF_GENERAL_EMAIL, mail2utf8( $message_subject ), $message_text, 'From: "' . mail2utf8( $customer_name ) . '"<' . $customer_email . '>
' . EMAIL_MESSAGE_PARAMETERS . '
Return-path: <' . $customer_email . '>' );
				header( 'Location: index.php?productID=' . $_POST['productID'] . '&sent' );
			} 
else {
				if (isset( $_POST['request_information'] )) {
					$smarty->assign( 'error', 1 );
				}
			}
		}
	}


	if (( ( ( empty( $$productID ) && 0 <= $productID ) && !isset( $_POST['add_topic'] ) ) && !isset( $_POST['discuss'] ) )) {
		$product = GetProduct( $productID );

		if (( !$product || $product['enabled'] == 0 )) {
			header( 'Location: index.php' );
			return 1;
		}


		if (!isset( $_GET['vote'] )) {
			IncrementProductViewedTimes( $productID );
		}

		$dontshowcategory = 1690;
		$smarty->assign( 'main_content_template', 'product_detailed.tpl.html' );
		$a = $message_text;
		$a['PriceWithUnit'] = show_price( $a['Price'] );
		$a['in_stock_fa'] = fa_get_persian_number( $a['in_stock'] );
		$a['list_priceWithUnit'] = show_price( $a['list_price'] );

		if (strpos( $a['description'], 'src="http://' ) == false) {
			$a['description'] = str_replace( 'src="', 'src="' . BASE_URL, $a['description'] );
			$a['description'] = str_replace( 'src=/ckeditor/elfinder/php/../../..', 'src="' . BASE_URL, $a['description'] );
		}


		if (0 < (double)$a['shipping_freight']) {
			$a['shipping_freightUC'] = show_price( $a['shipping_freight'] );
		}


		if (isset( $_GET['picture_id'] )) {
			$picture = db_query( 'select filename, thumbnail, enlarged from ' . PRODUCT_PICTURES . ' where photoID=' . (int)$_GET['picture_id'] );
			$picture_row = db_fetch_row( $picture );
		} 
else {
			if (!is_null( $a['default_picture'] )) {
				$picture = db_query( 'select filename, thumbnail, enlarged from ' . PRODUCT_PICTURES . ' where photoID=' . $a['default_picture'] );
				$picture_row = db_fetch_row( $picture );
			} 
else {
				$picture = db_query( 'select filename, thumbnail, enlarged, photoID from ' . PRODUCT_PICTURES . ' where productID=\'' . $productID . '\'' );

				if ($picture_row = db_fetch_row( $picture )) {
					$a['default_picture'] = $picture_row['photoID'];
				} 
else {
					$picture_row = null;
				}
			}
		}


		if ($picture_row) {
			$a['picture'] = $picture_row[0];
			$a['thumbnail'] = $picture_row[1];
			$a['big_picture'] = $picture_row[2];
		} 
else {
			$a['picture'] = '';
			$a['thumbnail'] = '';
			$a['big_picture'] = '';
		}


		if ($a) {
			if (!empty( $$categoryID )) {
				$categoryID = $a['categoryID'];
			}


			if (!( $q = db_query( 'SELECT categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name,' . LanguagesManager::sql_prepareField( 'description' ) . ' as description, picture FROM ' . CATEGORIES_TABLE . ( ' WHERE categoryID=\'' . $categoryID . '\'' ) ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			$row = db_fetch_row( $q );

			if ($row) {
				if (!file_exists( './uploads/products_pictures/' . $row[3] )) {
					$row[3] = '';
				}

				$smarty->assign( 'selected_category', $row );
			} 
else {
				$smarty->assign( 'selected_category', null );
			}

			$smarty->assign( 'product_category_path', catCalculatePathToCategory( $categoryID ) );

			if (!( $q = db_query( 'SELECT count(*) FROM ' . DISCUSSIONS_TABLE . ( ' WHERE productID=\'' . $productID . '\'' ) ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			$k = db_fetch_row( $q );
			$k = $k[0];
			$extra = GetExtraParametrs( $productID );
			$related = array(  );

			if (!( $q = db_query( 'SELECT count(*) FROM ' . RELATED_PRODUCTS_TABLE . ( ' WHERE Owner=\'' . $productID . '\'' ) ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			$cnt = db_fetch_row( $q );
			$smarty->assign( 'product_related_number', $cnt[0] );

			if (0 < $cnt[0]) {

				if (!( $q = db_query( 'SELECT productID FROM ' . RELATED_PRODUCTS_TABLE . ( ' WHERE Owner=\'' . $productID . '\'' ) ))) {
					exit( db_error(  ) );
					(bool)true;
				}


				if ($row = db_fetch_row( $q )) {

					if (!( $p = db_query( 'SELECT productID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS name, Price FROM ' . PRODUCTS_TABLE . ( ' WHERE productID=' . $row[0] ) ))) {
						exit( db_error(  ) );
						(bool)true;
					}


					if ($r = db_fetch_row( $p )) {
						$r[2] = show_price( $r[2] );
						$RelatedPictures = GetPictures( $r['productID'] );
						foreach ($RelatedPictures as $_RelatedPicture) {

							if (!$_RelatedPicture['default_picture']) {
								continue;
							}


							if (!file_exists( './uploads/products_pictures/' . $_RelatedPicture['thumbnail'] )) {
								break;
							}

							$r['pictures'] = array( 'default' => $_RelatedPicture );
							break;
						}

						$related[] = $r;
					}
				}
			}


			if (!file_exists( './uploads/products_pictures/' . $a['picture'] )) {
				$a['picture'] = 0;
			}


			if (!file_exists( './uploads/products_pictures/' . $a['thumbnail'] )) {
				$a['thumbnail'] = 0;
			}


			if (!file_exists( './uploads/products_pictures/' . $a['big_picture'] )) {
				$a['big_picture'] = 0;
			} 
else {
				if ($a['big_picture']) {
					$size = getimagesize( './uploads/products_pictures/' . $a['big_picture'] );
					$a[16] = $size[0] + 40;
					$a[17] = $size[1] + 30;
				}
			}

			$a[12] = show_price( $a['Price'] );
			$a[13] = show_price( $a['list_price'] );
			$a[14] = show_price( $a['list_price'] - $a['Price'] );
			$a['PriceWithOutUnit'] = show_priceWithOutUnit( $a['Price'] );

			if ($a['list_price']) {
				$a[15] = ceil( ( $a['list_price'] - $a['Price'] ) / $a['list_price'] * 100 );
			}


			if (isset( $_GET['picture_id'] )) {
				$pictures = db_query( 'select photoID, filename, thumbnail, enlarged from ' . PRODUCT_PICTURES . ' where photoID!=' . (int)$_GET['picture_id'] . ' AND productID=' . (bool)$productID );
			} 
else {
				if (!is_null( $a['default_picture'] )) {
					$pictures = db_query( 'select photoID, filename, thumbnail, enlarged from ' . PRODUCT_PICTURES . ' where photoID!=' . $a['default_picture'] . ' AND productID=' . (bool)$productID );
				} 
else {
					$pictures = db_query( 'select photoID, filename, thumbnail, enlarged from ' . PRODUCT_PICTURES . ' where productID=' . (bool)$productID );
				}
			}

			$all_product_pictures = array(  );
			$all_product_pictures_id = array(  );
			$product_pictures = array(  );

			if ($picture = db_fetch_row( $pictures )) {
				if ($picture[2] != '') {
					if (file_exists( './uploads/products_pictures/' . $picture[2] )) {
						$all_product_pictures[] = $picture[2];
						$all_product_pictures_id[] = $picture[0];
					}
				} 
else {
					if ($picture[1] != '') {
						if (file_exists( './uploads/products_pictures/' . $picture[1] )) {
							$all_product_pictures[] = $picture[1];
							$all_product_pictures_id[] = $picture[0];
						}
					}
				}

				$thispicture['id'] = $picture['photoID'];

				if (file_exists( './uploads/products_pictures/' . $picture['filename'] )) {
					$thispicture['photo'] = $picture['filename'];
				}


				if (file_exists( './uploads/products_pictures/' . $picture['thumbnail'] )) {
					$thispicture['thumbnail'] = $picture['thumbnail'];
				}


				if (file_exists( './uploads/products_pictures/' . $picture['enlarged'] )) {
					$thispicture['enlarged'] = $picture['enlarged'];
				}

				$product_pictures[] = $thispicture;
			}

			$videos = db_query( 'select videoID, filename from ' . PRODUCT_VIDEOS . ' where productID=' . (bool)$productID );
			$all_product_videos = array(  );

			if ($video = db_fetch_row( $videos )) {
				if ($video['filename'] != '') {
					if (file_exists( './uploads/products_videos/' . $video['filename'] )) {
						if (stripos( $video['filename'], 'flv' )) {
							$video['filetype'] = 'flv';
						}


						if (stripos( $video['filename'], 'mp4' )) {
							$video['filetype'] = 'mp4';
						}


						if (stripos( $video['filename'], 'ogv' )) {
							$video['filetype'] = 'ogv';
						}


						if (stripos( $video['filename'], 'webm' )) {
							$video['filetype'] = 'webm';
						}


						if (stripos( $video['filename'], 'swf' )) {
							$video['filetype'] = 'swf';
						}

						$all_product_videos[] = $video;
					}
				}
			}


			if (( 0 < strlen( $a['eproduct_filename'] ) && file_exists( './uploads/products_files/' . $a['eproduct_filename'] ) )) {
				$size = filesize( './uploads/products_files/' . $a['eproduct_filename'] );

				if (1000 < $size) {
					$size = round( $size / 1000 );
				}

				$a['eproduct_filesize'] = $size . ' Kb';
			} 
else {
				$a['eproduct_filename'] = '';
			}


			if (!isset( $_POST['request_information'] )) {
				if (!isset( $_SESSION['log'] )) {
					$customer_name = '';
					$customer_email = '';
				} 
else {
					regGetCustomerInfo2( $_SESSION['log'] );
					$custinfo = ;
					$customer_name = $custinfo['first_name'] . ' ' . $custinfo['last_name'];
					$customer_email = $custinfo['Email'];
				}

				$message_text = '';
			}

			$smarty->assign( 'customer_name', $customer_name );
			$smarty->assign( 'customer_email', $customer_email );
			$smarty->assign( 'message_text', $message_text );

			if (isset( $_GET['sent'] )) {
				$smarty->assign( 'sent', 1 );
			}

			$smarty->assign( 'all_product_pictures_id', $all_product_pictures_id );
			$smarty->assign( 'all_product_pictures', $all_product_pictures );
			$smarty->assign( 'all_product_videos', $all_product_videos );
			$smarty->assign( 'product_pictures', $product_pictures );
			$smarty->assign( 'product_info', $a );
			$smarty->assign( 'product_reviews_count', $k );
			$smarty->assign( 'product_extra', $extra );
			$smarty->assign( 'product_related', $related );
			return 1;
		}

		header( 'Location: index.php' );
	}

?>