<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (( isset( $_GET['feedback'] ) || isset( $_POST['feedback'] ) )) {
		$error = null;

		if (isset( $_POST['feedback'] )) {
			if (isset( $_POST['send'] )) {
				$customer_name = xStripSlashesGPC( $_POST['customer_name'] );
				$customer_email = xStripSlashesGPC( $_POST['customer_email'] );
				$message_subject = xStripSlashesGPC( $_POST['message_subject'] );
				$message_text = xStripSlashesGPC( $_POST['message_text'] );

				if (CONF_ENABLE_CONFIRMATION_CODE) {
					if ($_POST['fConfirmationCode'] != $_SESSION['CAPTCHAString']) {
						$error = ERR_WRONG_CCODE;
					}
				}


				if (( ( ( empty( $$customer_name ) && empty( $$customer_email ) ) && empty( $$message_subject ) ) && empty( $$message_text ) )) {
					if (( ( ( trim( $customer_email ) == '' && trim( $customer_name ) == '' ) && trim( $message_subject ) == '' ) && trim( $message_text ) == '' )) {
						$error = FEEDBACK_ERROR_FILL_IN_FORM;
					}
				}


				if ($error == null) {
					if (filter_var( $customer_email, FILTER_VALIDATE_EMAIL )) {
						$customer_name = str_replace( array( '@', '<', '
' ), array( '[at]', '', '' ), $customer_name );

						$customer_email = str_replace( array( '
', '<' ), '', $customer_email );

						$message_text = '<table cellpadding="0" cellspacing="0" style="width: 100%;" align="center" dir="rtl" style="font-family:Tahoma; font-size:8pt">
          		  <tr><td>' . nl2br( $message_text ) . '</td></tr><tr><td>' . $customer_email . '</td></tr><tr><td>' . $customer_name . '</td></tr></table>';
						sendEmail( CONF_GENERAL_EMAIL, mail2utf8( $message_subject ), $message_text, 'From: "' . mail2utf8( $customer_name ) . '"<' . $customer_email . '>
' . EMAIL_MESSAGE_PARAMETERS . '
Return-path: <' . $customer_email . '>' );
						$smarty->assign( 'sent', 1 );
					} 
else {
						$error = ERROR_INPUT_EMAIL;
					}
				}
			}
		}

		$customer_name = '';
		$customer_email = '';
		$message_subject = '';
		$message_text = '';
		$smarty->assign( 'error', $error );
		$smarty->assign( 'customer_name', $customer_name );
		$smarty->assign( 'customer_email', $customer_email );
		$smarty->assign( 'message_subject', $message_subject );
		$smarty->assign( 'message_text', $message_text );
		$smarty->assign( 'main_content_template', 'feedback.tpl.html' );
		$regular_head = 872;
	}

?>