<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (( empty( $$contact_info ) && isset( $_SESSION['log'] ) )) {
		function _copyDataFromPostToPage($smarty) {
			$smarty->assign( 'login', $_POST['login'] );
			$smarty->assign( 'cust_password1', $_POST['cust_password1'] );
			$smarty->assign( 'first_name', $_POST['first_name'] );
			$smarty->assign( 'last_name', $_POST['last_name'] );
			$smarty->assign( 'email', $_POST['email'] );
			$smarty->assign( 'subscribed4news', (isset( $_POST['subscribed4news'] ) ? 1 : 0) );
			$additional_field_values = array(  );
			ScanPostVariableWithId( array( 'additional_field' ) );
			$data = $smarty->assign( 'cust_password2', $_POST['cust_password2'] );
			foreach ($data as $key => $val) {
				$item = array( 'reg_field_ID' => $key, 'reg_field_name' => '', 'reg_field_value' => $val['additional_field'] );
				$additional_field_values[] = $item;
			}

			$smarty->assign( 'additional_field_values', $additional_field_values );
		}

		function _copyDataFromDataBaseToPage($smarty, $log) {
			$cust_password = 758;
			$Email = 758;
			$first_name = 758;
			$last_name = 758;
			$subscribed4news = 758;
			$additional_field_values = 758;
			$countryID = 758;
			$zoneID = 758;
			$state = 758;
			$zip = 758;
			$city = 758;
			$address = 758;
			regGetContactInfo( $log, $cust_password, $Email, $first_name, $last_name, $subscribed4news, $additional_field_values, $phone, $mobile );
			$smarty->assign( 'login', $log );
			$smarty->assign( 'cust_password1', $cust_password );
			$smarty->assign( 'cust_password2', $cust_password );
			$smarty->assign( 'first_name', $first_name );
			$smarty->assign( 'last_name', $last_name );
			$smarty->assign( 'email', $Email );
			$smarty->assign( 'phone', $phone );
			$smarty->assign( 'mobile', $mobile );
			$smarty->assign( 'subscribed4news', $subscribed4news );
			$smarty->assign( 'additional_field_values', $additional_field_values );
		}


		if (isset( $_POST['login'] )) {
			_copyDataFromPostToPage( $smarty );
		} 
else {
			_copyDataFromDataBaseToPage( $smarty, $_SESSION['log'] );
		}


		if (isset( $_POST['save'] )) {
			$login = $_POST['login'];
			$cust_password1 = $_POST['cust_password1'];
			$cust_password2 = $_POST['cust_password2'];
			$first_name = $_POST['first_name'];
			$last_name = $_POST['last_name'];
			$Email = $_POST['email'];
			$newemail = $_POST['newemail'];
			$phone = $_POST['phone'];
			$mobile = $_POST['mobile'];
			$subscribed4news = (isset( $_POST['subscribed4news'] ) ? 1 : 0);
			$additional_field_values = ScanPostVariableWithId( array( 'additional_field' ) );

			if (( trim( $login ) != trim( $_SESSION['log'] ) && regIsRegister( $login ) )) {
				$error = ERROR_USER_ALREADY_EXISTS;
			}


			if (!empty( $$error )) {
				$error = regVerifyreContactInfo( $login, $cust_password1, $cust_password2, $Email, $first_name, $last_name, $subscribed4news, $additional_field_values, $phone, $mobile, $newemail );
			}


			if ($error == '') {
				unset( $$error );
			}


			if (!empty( $$error )) {
				regUpdateContactInfo( $_SESSION['log'], $login, $cust_password1, $newemail, $first_name, $last_name, $subscribed4news, $phone, $mobile, $additional_field_values );
				$_SESSION['log'] = $login;
				$_SESSION['pass'] = cryptPasswordCrypt( $cust_password1, null );
				Redirect( 'index.php?user_details' );
			} 
else {
				$smarty->assign( 'error', $error );
			}
		}

		$additional_fields = GetRegFields(  );
		$smarty->assign( 'additional_fields', $additional_fields );
		$smarty->assign( 'main_content_template', 'contact_info.tpl.html' );
	}

?>