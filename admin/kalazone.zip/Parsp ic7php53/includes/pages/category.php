<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function deleteSubCategories($parent) {

		if (!( $q = db_query( 'SELECT categoryID FROM ' . CATEGORIES_TABLE . ( ' WHERE parent=' . $parent . ' and categoryID<>1' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			deleteSubCategories( $row[0] );
		}


		if (!( $q = db_query( 'DELETE FROM ' . CATEGORIES_TABLE . ( ' WHERE parent=' . $parent . ' and categoryID<>1' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if (!( $q = db_query( 'UPDATE ' . PRODUCTS_TABLE . ( ' SET categoryID=1 WHERE categoryID=' . $parent ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}

	}

	function category_Moves_To_Its_SubDirectories($cid, $new_parent) {
		db_query( 'SELECT categoryID FROM ' . CATEGORIES_TABLE . ( ' WHERE parent=' . $cid . ' and categoryID<>1' ) );

		if (!( $q = $a = false)) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			if (!$a) {
				if ($row[0] == $new_parent) {
					return true;
				}

				$a = category_Moves_To_Its_SubDirectories( $row[0], $new_parent );
			}
		}

		return $a;
	}

	function _getOptions($categoryid) {
		$options = optGetOptions(  );
		$i = 774;

		while ($i < count( $options )) {
			if (empty( $$categoryid )) {
				$res = schOptionIsSetToSearch( $categoryid, $options[$i]['optionID'] );
			} 
else {
				$res = array( 'isSet' => true, 'set_arbitrarily' => 1 );
			}


			if ($res['isSet']) {
				$options[$i]['isSet'] = true;
				$options[$i]['set_arbitrarily'] = $res['set_arbitrarily'];
			} 
else {
				$options[$i]['isSet'] = false;
				$options[$i]['set_arbitrarily'] = 1;
			}

			$options[$i]['variants'] = optGetOptionValues( $options[$i]['optionID'] );
			$j = 774;

			while ($j < count( $options[$i]['variants'] )) {
				$isSet = false;

				if (isset( $_GET['categoryID'] )) {
					$isSet = schVariantIsSetToSearch( $_GET['categoryID'], $options[$i]['optionID'], $options[$i]['variants'][$j]['variantID'] );
				}

				$options[$i]['variants'][$j]['isSet'] = $isSet;
				++$j;
			}

			++$i;
		}

		return $options;
	}

	function save_category() {
		$res = null;

		do {
			if (LanguagesManager::ml_isEmpty( 'name', $_POST )) {
				echo '<center><font color=red>' . ERROR_INPUT_ADDITION_FIELD . '</font>
<br></center>
';
				break;
			}

			$categoryID = (isset( $_POST['categoryID'] ) ? intval( $_POST['categoryID'] ) : 0);
			$make_slug = false;

			if ($categoryID == 0) {
				db_phquery( 'INSERT ?#CATEGORIES_TABLE (sort_order) VALUES(0)' );
				$categoryID = db_insert_id( 'CATEGORIES_GEN' );
				renderURL( 'categoryID=' . $categoryID, '', true );
			}


			if ($_POST['parent'] == $categoryID) {
				$original_category_info = catGetCategoryById( $categoryID );
				$_POST['parent'] = $original_category_info['parent'];
			}


			if (catMoveBranchCategoriesTo( $categoryID, $_POST['parent'] )) {
				$r = db_phquery_fetch( DBRFETCH_FIRST, 'SELECT parent FROM ?#CATEGORIES_TABLE WHERE categoryID<>1 and categoryID=?', $categoryID );
				db_phquery( 'UPDATE ?#CATEGORIES_TABLE SET parent=? WHERE parent=?', $r, $categoryID );
			}

			$_POST['meta_d'] = TransformStringToDataBase( $_POST['meta_d'] );
			$_POST['meta_k'] = TransformStringToDataBase( $_POST['meta_k'] );
			$_POST['sort_order'] = (int)$_POST['sort_order'];
			$allow_products_comparison = (isset( $_POST['allow_products_comparison'] ) ? 1 : 0);
			$allow_products_search = (isset( $_POST['allow_products_search'] ) ? 1 : 0);
			$show_subcategories_products = (isset( $_POST['show_subcategories_products'] ) ? 1 : 0);
			$ml_dbqs = LanguagesManager::sql_prepareFieldInsert( 'name', $_POST );
			$ml_dbqsd = LanguagesManager::sql_prepareFieldInsert( 'description', $_POST );

			if (!isset( $_POST['must_delete'] )) {
				db_phquery( 'INSERT INTO ' . CATEGORIES_TABLE . ' (' . $ml_dbqs['fields'] . ', parent,' . $ml_dbqsd['fields'] . ', picture, ' . '    products_count_admin, sort_order, ' . '    allow_products_comparison, ' . '    allow_products_search, ' . 'show_subcategories_products, ' . '    meta_description, meta_keywords,products_count ) ' . ' VALUES (' . $ml_dbqs['values'] . ',' . $_POST['parent'] . ',' . $ml_dbqsd['values'] . ',\'\',0, ' . $_POST['sort_order'] . ( ', ' . $allow_products_comparison ) . ( ', ' . $allow_products_search ) . ( ', ' . $show_subcategories_products . ', \'' ) . $_POST['meta_d'] . '\', \'' . $_POST['meta_k'] . '\',0);' );
				$pid = db_insert_id( 'CATEGORIES_GEN' );
			} 
else {
				if ($_POST['must_delete'] != $_POST['parent']) {
					$mlf[0] = explode( ',', $ml_dbqs['fields'] );
					$mlf[1] = explode( ',', $ml_dbqs['values'] );
					$mlf[2] = explode( ',', $ml_dbqsd['fields'] );
					$mlf[3] = explode( ',', $ml_dbqsd['values'] );
					$str = 'UPDATE ' . CATEGORIES_TABLE . ' SET ';
					$str .= LanguagesManager::sql_prepareFieldUpdate( 'name', $_POST ) . ', ';
					$str .= LanguagesManager::sql_prepareFieldUpdate( 'description', $_POST ) . ', ';

					if (category_Moves_To_Its_SubDirectories( $_POST['must_delete'], $_POST['parent'] )) {

						if (!( $q = db_query( 'SELECT parent FROM ' . CATEGORIES_TABLE . ' WHERE categoryID<>1 and categoryID=\'' . $_POST['must_delete'] . '\'' ))) {
							exit( db_error(  ) );
							(bool)true;
						}

						$r = db_fetch_row( $q );

						if (!( db_query( 'UPDATE ' . CATEGORIES_TABLE . ( ' SET parent=\'' . $r[0] . '\' WHERE parent=\'' ) . $_POST['must_delete'] . '\'' ))) {
							exit( db_error(  ) );
							(bool)true;
						}


						if (!( db_query( $str . ', parent=\'' . $_POST['parent'] . '\', sort_order = ' . $_POST['sort_order'] . ( ', allow_products_comparison=' . $allow_products_comparison . ' ' ) . ( ', allow_products_search=' . $allow_products_search . ' ' ) . ( ', show_subcategories_products=' . $show_subcategories_products . ' ' ) . ', meta_description=\'' . $_POST['meta_d'] . '\', meta_keywords=\'' . $_POST['meta_k'] . '\'  WHERE categoryID=\'' . $_POST['must_delete'] . '\'' ))) {
							exit( db_error(  ) );
							(bool)true;
						}
					} 
else {
						if (!( db_query( $str . ' parent=\'' . $_POST['parent'] . '\', sort_order = ' . $_POST['sort_order'] . ( ', allow_products_comparison=' . $allow_products_comparison . ' ' ) . ( ', allow_products_search=' . $allow_products_search . ' ' ) . ( ', show_subcategories_products=' . $show_subcategories_products . ' ' ) . ', meta_description=\'' . $_POST['meta_d'] . '\', meta_keywords=\'' . $_POST['meta_k'] . '\' WHERE categoryID=\'' . $_POST['must_delete'] . '\'' ))) {
							exit( db_error(  ) );
							(bool)true;
						}
					}
				}

				$pid = $_POST['must_delete'];
			}


			if (CONF_UPDATE_GCV == 1) {
				update_products_Count_Value_For_Categories( 1 );
			}

			schUnSetOptionsToSearch( $categoryID );
			$data = scanArrayKeysForID( $_POST, array( 'checkbox_param' ) );
			foreach ($data as $optionID => $val) {
				schUnSetVariantsToSearch( $categoryID, $optionID );

				if (isset( $_POST[ . 'select_arbitrarily_' . $optionID] )) {
					$set_arbitrarily = $_POST[ . 'select_arbitrarily_' . $optionID];
				} 
else {
					$set_arbitrarily = 1261;
				}

				schSetOptionToSearch( $categoryID, $optionID, $set_arbitrarily );

				if ($set_arbitrarily == 0) {
					$variants = optGetOptionValues( $optionID );
					foreach ($variants as $var) {

						if (isset( $_POST['checkbox_variant_' . $var['variantID']] )) {
							schSetVariantToSearch( $categoryID, $optionID, $var['variantID'] );
							continue;
						}
					}

					continue;
				}
			}


			if (( ( isset( $_FILES['picture'] ) && $_FILES['picture']['name'] ) && is_image( $_FILES['picture']['name'] ) )) {

				if (!( $q = db_query( 'SELECT picture FROM ' . CATEGORIES_TABLE . ( ' WHERE categoryID=\'' . $pid . '\' and categoryID<>0' ) ))) {
					exit( db_error(  ) );
					(bool)true;
				}

				$row = db_fetch_row( $q );
				$picture_name = str_replace( ' ', '_', $_FILES['picture']['name'] );

				if (!@move_uploaded_file( $_FILES['picture']['tmp_name'], './uploads/products_pictures/' . $picture_name )) {
					echo '<center><font color=red>' . ERROR_FAILED_TO_UPLOAD_FILE . '</font>
<br><br>
';
					echo '<a href="javascript:window.close();">' . CLOSE_BUTTON . '</a></center></body>
</html>';
					exit(  );
				} 
else {
					SetRightsToUploadedFile( './uploads/products_pictures/' . $picture_name );

					if (!( db_query( 'UPDATE ' . CATEGORIES_TABLE . ( ' SET picture=\'' . $picture_name . '\' ' ) . ( ' WHERE categoryID=\'' . $pid . '\'' ) ))) {
						exit( db_error(  ) );
						(bool)true;
					}
				}


				if (( ( $row[0] && strcmp( $row[0], $picture_name ) ) && file_exists( './uploads/products_pictures/' . $row[0] ) )) {
					unlink( './uploads/products_pictures/' . $row[0] );
				}
			}
		}while (!( 0));

		echo '<center>' . ADMIN_UPDATE_SUCCESSFUL . '<br><br>';
		echo '<a href=admincp.php?w=-1&page=category>' . ADMIN_CATEGORY_NEW . '</a></center>';
		echo '<script>
';
		echo 'TINY.box.hide();
';
		echo 'window.location.reload();
';
		echo 'window.close();
';
		echo '</script>';
	}

	include( './core_functions/search_function.php' );
	include_once( './smarty/plugins/function.html_text.php' );
	include_once( './smarty/plugins/function.html_textarea.php' );

	if (isset( $_GET['categoryID'] )) {
		$categoryID = $_GET['categoryID'];
	}

	MagicQuotesRuntimeSetting(  );
	include( './checklogin.php' );

	if (( CONF_BACKEND_SAFEMODE != 1 && !isset( $_SESSION['log'] ) )) {
		exit( ERROR_FORBIDDEN );
	}


	if (( isset( $_POST ) && 0 < count( $_POST ) )) {
		if (CONF_BACKEND_SAFEMODE) {
			if (!isset( $_POST['must_delete'] )) {
				Redirect( 'category.php?safemode' );
			} 
else {
				Redirect( 'category.php?safemode&categoryID=' . $_POST['must_delete'] );
			}
		}
	}


	if (isset( $_GET['picture_remove'] )) {
		if (CONF_BACKEND_SAFEMODE) {
			Redirect( 'category.php?safemode&categoryID=' . $_GET['categoryID'] );
		}


		if (!( $q = db_query( 'SELECT picture FROM ' . CATEGORIES_TABLE . ' WHERE categoryID=\'' . $_GET['categoryID'] . '\' and categoryID<>1' ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$r = db_fetch_row( $q );

		if (( $r[0] && file_exists( './uploads/products_pictures/' . $r[0] ) )) {
			unlink( './uploads/products_pictures/' . $r[0] );
		}


		if (!( db_query( 'UPDATE ' . CATEGORIES_TABLE . ' SET picture=\'\' WHERE categoryID=\'' . $_GET['categoryID'] . '\'' ))) {
			exit( db_error(  ) );
			(bool)true;
		}
	}


	if (( isset( $_GET['categoryID'] ) && isset( $_GET['enabled'] ) )) {
		catEnabledCategory( $_GET['categoryID'], $_GET['enabled'] );
		echo '<br><br><p><center>' . SAVE_CHANGES_BUTTON . '</centrt></p>';
		echo '<script type="text/javascript"><!--
          parent.location = "admincp.php?tab=catalog&sub=products_categories";        
            // -->
        </script>';
		exit(  );
	}


	if (( isset( $_GET['categoryID'] ) && isset( $_GET['del'] ) )) {
		if (CONF_BACKEND_SAFEMODE) {
			Redirect( 'category.php?safemode&categoryID=' . $_GET['categoryID'] );
		}

		catDeleteCategory( $_GET['categoryID'] );
		$_GET['del'] = 2;

		if () {
			echo '<p><center>' . STRING_DELETED . '</center></p>';
			echo '<script type="text/javascript"><!--
          parent.location = "admincp.php?tab=catalog&sub=products_categories";        
            // -->
        </script>';
			exit(  );
		} 
else {
			echo '<p><center>' . STRING_DELETED . '</center></p>';
			echo '<script>
';
			echo 'window.opener.location = \'admincp.php?tab=catalog&sub=products_categories&categoryID=1\';
';
			echo 'window.close();';
			echo '</script>
</body>
</html>';
		}
	}

	echo '<html>  
  <head>    
    <link rel=STYLESHEET href="style/admin_style.css" type="text/css">    
    <meta http-equiv="Content-Type" content="text/html; charset=';
	echo DEFAULT_CHARSET;
	echo '">    
    <title>      
      ';
	echo ADMIN_CATEGORY_TITLE;
	echo '    
    </title>
<script type="text/javascript" src="./js/jquery-1.10.1.min.js"></script>
<script>
	
	 
	  $(document).ready(function(){
		
	
		$("a.tab").click(function () {
			
			
	
			$(".active").removeClass("active");
			
	
			$(this).addClass("active");
			
	
			$(".content").slideUp();
			
	
			var content_show = $(this).attr("title");
			$("#"+content_show).slideDown();
		  
		});
	
	  });
  </script>
<script>
function confDelete(text,url)
{
	temp = window.confirm(text);
	if (temp) //delete
	{
		window.location=url;
	}
}
function open_window(link,w,h)
{
	var win = "width="+w+",height="+h+",menubar=no,location=no,resizable,scrollbars";
	wishWin = window.open(link,\'wishWin\',win);
}
function position_this_window()
{
	var x = (screen.availWidth - 795) / 2;
	window.resizeTo(795, screen.availHeight - 50);
	window.moveTo(Math.floor(x),25);
}
</script>
';

	if (( isset( $_GET['categoryID'] ) || isset( $_GET['w'] ) )) {
	}

	echo '    
    <body dir="rtl" style="margin:0px;">
';

	if (( isset( $_POST['save'] ) && !LanguagesManager::ml_isEmpty( 'name', $_POST ) )) {
		save_category(  );
		return 1;
	}

	$param['style'] = 'width:540px;';
	$param['width'] = '540px';

	if (isset( $_GET['categoryID'] )) {
		$row = catGetCategoryById( $_GET['categoryID'] );

		if (!$row) {
			echo '<center><font color=red>' . ERROR_CANT_FIND_REQUIRED_PAGE . '</font>
<br><br>
';
			echo '<a href="TINY.box.hide();">' . CLOSE_BUTTON . '</a></center></body>
</html>';
			exit(  );
		}

		$title = '<b>' . TransformDataBaseStringToText( $row['name'] ) . '</b>';
		$id = rand_name( 2 );
		$param['name'] = 'name';
		$values = $height;
		$param['values'] = $row;
		$dparam = $width;
		$param['width'] = '300px';
		$dparam['name'] = 'description';
		$dparam['height'] = '100px';
		$dparam['id'] = 'description';
		$dparam['dbfield'] = 'description';
		$param['style'] = 'width:300px;';
		$n = smarty_function_html_text( $param, $smarty );
		$d = TransformDataBaseStringToText( $row['description'] );
		$meta_d = TransformDataBaseStringToText( $row['meta_description'] );
		$meta_k = TransformDataBaseStringToText( $row['meta_keywords'] );
		$picture = $row['picture'];
		$sort_order = $row['sort_order'];
		$parent = $row['parent'];
		$allow_products_comparison = $row['allow_products_comparison'];
		$allow_products_search = $row['allow_products_search'];
		$show_subcategories_products = $row['show_subcategories_products'];
	} 
else {
		$title = ADMIN_CATEGORY_NEW;
		$param['name'] = 'name';
		$param['values'] = '';
		$dparam = $width;
		$param['width'] = '300px';
		$param['style'] = 'width:300px;';
		$dparam['name'] = 'description';
		$dparam['height'] = '100px';
		$dparam['id'] = 'description';
		$dparam['dbfield'] = 'description';
		$n = smarty_function_html_text( $param, $smarty );
		$d = ' ';
		$meta_d = '';
		$meta_k = '';
		$picture = '';
		$sort_order = 1440;
		$allow_products_comparison = 1441;
		$allow_products_search = 1441;
		$parent = 1441;
		$show_subcategories_products = 1441;
	}

	$options = _getOptions( $_GET['categoryID'] );
	$showSelectParametrsTable = 1440;

	if (isset( $_GET['SelectParametrsHideTable_hidden'] )) {
		$showSelectParametrsTable = $_GET['SelectParametrsHideTable_hidden'];
	}

	echo '             
<script type="text/javascript" src="./js/behavior.js"></script>       
<script type="text/javascript" src="./js/admin.js"></script>       
<script type="text/javascript" src="./js/functions.js"></script>                 
      <div id="min_header" dir="rtl">        
        <font color=purple ><b>            
            ';
	echo $title;
	echo '</b>        
        </font>      
      </div>      
      <form	enctype="multipart/form-data"  		action="admincp.php"  		method="post"  		name=\'MainForm\' >
      <input type="hidden" name="page" value="category">
      <input type="hidden" name="categoryID" value="';
	echo $categoryID;
	echo '">        	          
        <div class="tabbed_area" >                   
          <ul class="tabs">                         
            <li>            
            <a href="#" title="content_1" class="tab active">              
              ';
	echo ADMIN_CATEGORY_BRIEF;
	echo '</a>            
            </li>                                      
            <li>            
            <a href="#" title="content_2" class="tab">              
              ';
	echo ADMIN_CATEGORY_DESCRIPTION;
	echo '</a>            
            </li>                         
            <li>            
            <a href="#" title="content_3" class="tab">              
              ';
	echo ADMIN_CATEGORY_KEYS;
	echo '</a>            
            </li>                   
            <li>            
            <a href="#" title="content_4" class="tab">              
              ';
	echo ADMIN_CATEGORY_SEARCH;
	echo '</a>            
            </li>
          </ul>                                      
          <div id="content_1" class="content" style="display: block; ">        	             
            <ul>            	               
              <li>                   
              <div style="float:right;width:30%">		 
';

	if (!isset( $_GET['categoryID'] )) {
		echo ADMIN_CATEGORY_PARENT;
	} 
else {
		echo ADMIN_CATEGORY_MOVE_TO;
	}

	echo ' 		               
              </div>		               
              <div>			                 
                <select name="parent" ';

	if (CONF_FULLY_EXPAND_CATEGORIES_IN_ADMIN_MODE == 0) {
	}

	echo ' >          
';

	if (CONF_FULLY_EXPAND_CATEGORIES_IN_ADMIN_MODE == 1) {
		echo '<option value="1">' . ADMIN_CATEGORY_ROOT . '</option>';
	}

	$core_category = (isset( $_GET['change_category'] ) ? (int)$_GET['change_category'] : $parent);

	if (CONF_FULLY_EXPAND_CATEGORIES_IN_ADMIN_MODE == 0) {
		$cats = catGetCategoryCompactCList( $core_category );
	} 
else {
		$cats = catGetCategoryCList(  );
	}

	$i = 1440;

	while ($i < count( $cats )) {
		echo '<option value="' . $cats[$i]['categoryID'] . '"';

		if ($core_category == $cats[$i]['categoryID']) {
			echo ' selected';
		}

		echo '>';
		$j = 1440;

		while ($j < $cats[$i]['level']) {
			echo '&nbsp;&nbsp;';
			++$j;
		}

		echo $cats[$i]['name'];
		echo '</option>';
		++$i;
	}

	echo ' 			                 
                </select>		               
              </div>                 
              </li>            	               
              <li>              
              <div style="float:right;width:30%">			                 
                ';
	echo ADMIN_CATEGORY_NAME;
	echo ' 		               
              </div>		               
              <div>		                 
                ';
	echo $n;
	echo ' 		               
              </div>                                            
              </li>            	               
              <li>              
              <div style="float:right;width:30%">                
                ';
	echo ADMIN_SORT_ORDER;
	echo '		               
              </div>              
              <div>			               
                <input type="text" name="sort_order"  				value="';
	echo $sort_order;
	echo '" size=13>              
              </div>              
              </li>            	               
              <li>              
              <div style="float:right;width:30%;">              
                ';
	echo ADMIN_ALLOW_PRODUCTS_COMPARISON;
	echo '	               
              </div>              
              <div>              
                <input type=checkbox name="allow_products_comparison" value=\'1\' ';

	if ($allow_products_comparison == 1) {
		echo 'checked';
	}

	echo ' >                         
              </div>              
              </li>
              <li>
              <div style="float:right;width:30%">			               
              ';
	echo ADMIN_SHOW_PRODUCT_IN_SUBCATEGORY;
	echo ' 		
              </div>
              <div>			               
              <input type=checkbox name=\'show_subcategories_products\' value=\'1\' ';

	if ($show_subcategories_products == 1) {
		echo 'checked';
	}

	echo ' >
              </div> 		           
              </li>            	               
              <li>              
              <div style="float:right;width:30%">			               
                ';
	echo ADMIN_CATEGORY_LOGO;
	echo ' 		               
              </div>              
              <div>			               
                <input type="file" name="picture">			               
              </div>              
              <div style="float:right;width:100%" ';

	if (( $picture != '' && file_exists( './uploads/products_pictures/' . $picture ) )) {
		$attr = getimagesize( './uploads/products_pictures/' . $picture )[3];
		[2];
		$type = ;
		[1];
		$height = ;
		[0];
		$width = ;
		$width += 1480;
		$height += 1480;
		$href = ( ( 'JavaScript:open_window("products_pictures/' . $picture . '",' . $width . ',' ) . $height . ')' );
		echo '<font class=average>
                </font> 
                <a class=small href=\'' . $href . '\'>' . $picture . '</a>
';
		echo '
                <br>
                <a href="javascript:confDelete(\'' . QUESTION_DELETE_PICTURE . '\',\'admincp.php?page=category&categoryID=' . $_GET['categoryID'] . '&picture_remove\');">' . DELETE_BUTTON . '</a>
';
	} 
else {
		echo '
                <font class=average>' . ADMIN_PICTURE_NOT_UPLOADED . '
                </font>';
	}

	echo '   
              </div>              
              </li>            	                            			             
            </ul>                   
          </div>                   
          <div id="content_2" class="content" style="display: none; ">        	             
            <ul>            	               
              <li>                
              <div style="float:right;width:10%;">		            			                     
                ';
	echo ADMIN_CATEGORY_DESC;
	echo '                     
                <br>(HTML) 		                 
              </div>                
              <div>		 
              ';
	smarty_function_html_textarea( $dparam, $smarty );
	echo ' 			                                           		 
              </div>              
              </li>            	                             			             
            </ul>                   
          </div>                   
          <div id="content_3" class="content" style="display: none; ">        	             
            <ul>            	               
              <li>                
              <div style="float:right;width:20%;">		                			               
                ';
	echo ADMIN_META_KEYWORDS;
	echo ' 		               
              </div>              
              <div>			 
                <textarea name="meta_k" rows=3 cols=22 style="width: 400px; height: 75px">';
	echo str_replace( '<', '&lt;', $meta_k );
	echo '</textarea> 		 
              </div>	               
              </li>            	               
              <li>              
              <div style="float:right;width:20%;">			                 
                ';
	echo ADMIN_META_DESCRIPTION;
	echo ' 		               
              </div>              
              <div>			                   
                <textarea name="meta_d" rows=3 cols=22 style="width: 400px; height: 75px">';
	echo str_replace( '<', '&lt;', $meta_d );
	echo '</textarea> 		 	            
              </div>              
              </li>            	                             			             
            </ul>                   
          </div>  
          <div id="content_4" class="content" style="display: none; ">        	             
            <ul>            	               
              <li>
              <div style="float:right;width:20%">
              ';
	echo ADMIN_ALLOW_SEARCH_IN_CATEGORY;
	echo ' 		
              </div>
              <div>              			               
              <input type=checkbox name="allow_products_search" value=\'1\' ';

	if ($allow_products_search == 1) {
		echo 'checked';
	}

	echo '  > 			
              (  ';
	echo ADMIN_ALLOW_SEARCH_IN_CATEGORY_PROMPT;
	echo '  ) 
              </div>                
              </li>
              <li>
              <div style="float:right;width:20%">			               
              ';
	echo STRING_ADVANCED_SEACH_TITLE;
	echo ' 		
              </div>
              <div>
';

	if (count( $options )) {
		echo '			               
              <a href="JavaScript:SelectParametrsHideTable();">				                 
                ';
		echo ADMIN_SELECT_PARAMETRS;
		echo ' ... 			</a>			               
              <br>			               
              ';
		echo ADMIN_SELECT_PARAMETRS_PROMPT;
		echo '              <input type=hidden name=\'SelectParametrsHideTable_hidden\'  				value=\'';
		echo $showSelectParametrsTable;
		echo '\'>
               	
              		                             			 
        <script language=\'javascript\'>
				function SelectParametrsHideTable()
				{
					if (SelectParametrsTable.style.display == \'none\' ) 
					{
						SelectParametrsTable.style.display = \'block\';
						document.MainForm.SelectParametrsHideTable_hidden.value=\'1\';
					}
					else
					{
						SelectParametrsTable.style.display = \'none\';
						document.MainForm.SelectParametrsHideTable_hidden.value=\'0\';
					}
				}				
			</script> 			               
              			               
              <table id=\'SelectParametrsTable\' style="display:
              ';

		if ($allow_products_search == 1) {
			echo 'block;"';
		} 
else {
			echo 'none"';
		}

		echo '              >					 
';
		foreach ($options as $option) {
			echo ' 						                 
                <tr>							<td>								                     
                    <table>										                       
                      <tr>											                         
                        <td colspan=3>												                           
                          <input type=checkbox 	name=\'checkbox_param_';
			echo $option['optionID'];
			echo '\' 													 
';

			if ($option['isSet']) {
				echo 'checked';
			}

			echo ' onclick=\'JavaScript:Checkbox_param_Change_                           
                          ';
			echo $option['optionID'];
			echo '  ()\' 												> 														                           
                          ';
			echo $option['name'];
			echo '  											
                        </td>										                       
                      </tr>										 
';

			if (count( $option['variants'] ) != 0) {
				echo ' 										                       
                      <tr>											<td>&nbsp;</td>											                         
                        <td colspan=2>												                           
                          <input type=radio name=\'select_arbitrarily_';
				echo $option['optionID'];
				echo '\' id=\'select_arbitrarily1_                           
                          ';
				echo $option['optionID'];
				echo '  \' 													 
';

				if ($option['set_arbitrarily'] == 1) {
					echo '  														checked 													 
';
				}

				echo '  value=\'1\' onclick=\'Select_arbitrarily_Change_                           
                          ';
				echo $option['optionID'];
				echo '  ()\' 												> 														                           
                          ';
				echo ADMIN_SEARCH_IN_CATEGORY_PARAMETR_VALUE_ARBITRARILY;
				echo '  											</td>										                       
                      </tr>										                       
                      <tr>											<td>&nbsp;</td>											                         
                        <td colspan=2>												                           
                          <input type=radio name=\'select_arbitrarily_';
				echo $option['optionID'];
				echo '\' id=\'select_arbitrarily2_                           
                          ';
				echo $option['optionID'];
				echo '  \' 												 
';

				if ($option['set_arbitrarily'] == 0) {
					echo '  														checked 												 
';
				}

				echo '  value=\'0\' onclick=\'Select_arbitrarily_Change_                           
                          ';
				echo $option['optionID'];
				echo '  ()\' 												> 														                           
                          ';
				echo ADMIN_SEARCH_IN_CATEGORY_PARAMETR_VALUE_SELECT_FROM_VALUES;
				echo '  											</td>										                       
                      </tr>											 
';
				foreach ($option['variants'] as $variant) {
					echo ' 												                       
                      <tr>													<td>&nbsp;</td>													<td>&nbsp;</td>													<td>														                           
                          <input type=checkbox  															name=\'checkbox_variant_';
					echo $variant['variantID'];
					echo '\' 															 
';

					if ($variant['isSet']) {
						echo '  																checked 															 
';
					}

					echo '  														> 																                           
                          ';
					echo $variant['option_value'];
					echo '  													</td>												                       
                      </tr>											 
';
				}

				echo ' 										 
';
			}

			echo ' 							                     
                    </table>	
               
<script language=\'JavaScript\'>
								function Checkbox_param_Change_';
			echo $option['optionID'];
			echo '()
								{
									_checked = document.MainForm.
										checkbox_param_';
			echo $option['optionID'];
			echo '.checked;
									';

			if (count( $option['variants'] ) != 0) {
				echo '										document.MainForm.
											select_arbitrarily1_';
				echo $option['optionID'];
				echo '.disabled =
												!_checked;
										document.MainForm.
											select_arbitrarily2_';
				echo $option['optionID'];
				echo '.disabled =
												!_checked;
									';
			}

			echo '									Select_arbitrarily_Change_';
			echo $option['optionID'];
			echo '();									
								}
								function Select_arbitrarily_Change_';
			echo $option['optionID'];
			echo '()
								{
									';

			if (count( $option['variants'] ) != 0) {
				echo '										_enabled =
											document.MainForm.
												select_arbitrarily2_';
				echo $option['optionID'];
				echo '.checked
										    && 
											document.MainForm.
												checkbox_param_';
				echo $option['optionID'];
				echo '.checked;
									';
			}

			echo '									';
			foreach ($option['variants'] as $variant) {
				echo '										document.MainForm.
											checkbox_variant_';
				echo $variant['variantID'];
				echo '.
												disabled = !_enabled;
									';
			}

			echo '								}
								Checkbox_param_Change_';
			echo $option['optionID'];
			echo '();
							</script> 						
              </td>					                 
                </tr>					 
';
		}

		echo ' 			               
              </table>			 

      ';
	} 
else {
		echo '<font color="red">' . ADMIN_NOTANY_PARAMETRS_PROMPT . '</font>';
	}

	echo '						  			           
          	</div>           
              </li>
            </ul>
          </div>                
        </div>      
';

	if (isset( $_GET['safemode'] )) {
		echo '<p>
<font color=red><b>' . ADMIN_SAFEMODE_WARNING . '<b></font>';
	}

	echo '                         	           
        <p>          
          <div style="float:left;padding-left:20px;">            
            <input type="submit" value="';
	echo SAVE_BUTTON;
	echo '" width=5>            
            <input type="hidden" name="save" value="yes">            
            <input type="hidden" value="';
	echo CANCEL_BUTTON;
	echo '" onClick="TINY.box.hide();">
';

	if (isset( $_GET['categoryID'] )) {
		echo '<input type="hidden" name="must_delete" value="' . str_replace( '"', '', $_GET['categoryID'] ) . '">
';
		echo '<input type="button" value="' . DELETE_BUTTON . '" onClick="confDelete(\'' . QUESTION_DELETE_CONFIRMATION . '\',\'admincp.php?page=category&categoryID=' . str_replace( '"', '', $_GET['categoryID'] ) . '&del=1\');"';
	}

	echo '          
          </div>        
        </p>        
        </form>    
    </body>
</html>
';
?>