<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	include( './core_functions/configurator_functions.php' );
	MagicQuotesRuntimeSetting(  );

	if (!( db_connect( DB_HOST, DB_USER, DB_PASS ))) {
		exit( db_error(  ) );
		(bool)true;
	}


	if (!( db_select_db( DB_NAME ))) {
		exit( db_error(  ) );
		(bool)true;
	}

	include( './checklogin.php' );

	if (( CONF_BACKEND_SAFEMODE != 1 && !isset( $_SESSION['log'] ) )) {
		exit( ERROR_FORBIDDEN );
	}


	if (isset( $_GET['optionID'] )) {
		$optionID = $_GET['optionID'];
	} 
else {
		if (isset( $_POST['optionID'] )) {
			$optionID = $_POST['optionID'];
		}
	}


	if (isset( $_GET['productID'] )) {
		$productID = $_GET['productID'];
	} 
else {
		$productID = $_POST['productID'];
	}


	if (isset( $_POST['SAVE'] )) {
		if (CONF_BACKEND_SAFEMODE) {
			Redirect( 'admincp.php?page=option_value_configurator&safemode&productID=' . $productID . '&optionID=' . $optionID );
		}

		$variantID_default = 'null';
		foreach ($_POST as $key => $value) {

			if (strstr( $key, 'default_radiobutton_' )) {
				$key = str_replace( 'default_radiobutton_', '', $key );
				$variantID_default = (int)$key;
				continue;
			}
		}

		$option_show_times = (int)$_POST['option_show_times'];

		if ((int)$option_show_times <= 0) {
			$option_show_times = 1082;
		}

		$data = ScanPostVariableWithId( array( 'switchOn', 'price_surplus' ) );
		UpdateConfiguriableProductOption( $optionID, $productID, $option_show_times, $variantID_default, $data );
	}


	if (( isset( $_POST['SAVE'] ) || isset( $_POST['CLOSE'] ) )) {
		if (isset( $_POST['SAVE'] )) {
			echo '<script language=\'JavaScript\'>';
			echo '		window.opener.document.MainForm.save_product_without_closing.value=\'1\';';
			echo '		window.opener.document.MainForm.option_radio_type_' . $optionID . '[2].click();';
			echo '		window.opener.document.MainForm.save_product.click();';
			echo '</script>';
		}

		echo '<script language=\'JavaScript\'>';
		echo '		window.close();';
		echo '</script>';
		exit(  );
	}

	echo '<html>
<head>
<link rel=STYLESHEET href="style/admin_style.css" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=';
	echo DEFAULT_CHARSET;
	echo '">
<script type="text/javascript"><!--
function checkboxGroup(_GroupBoxID){
	
	this.GroupBoxID = _GroupBoxID
	this.BoxCollection = Array();
	
	this.addBox = function(_ID, _Settings){
		
		_Obj = document.getElementById(_ID)
		this.BoxCollection.push(_Obj)
		_Obj.spNum = _Settings["spNum"]
		_Obj.GroupObj = this
		eval(_Settings["evalCode"])
	}
	
	this.changeState = function(){
		
		var pObj  = document.getElementById(this.GroupBoxID)
		for(var i=0; i<this.BoxCollection.length; i++){
			
			this.BoxCollection[i].checked = !pObj.checked
			this.BoxCollection[i].click()
		}
	}
	
	this.checkState = function(){
		
		var noChecked = true
		for(var i=0; i<this.BoxCollection.length; i++){
			
			if(this.BoxCollection[i].checked){
				noChecked = false
				break
			}
		}
		if(noChecked){
			
			var pObj  = document.getElementById(this.GroupBoxID)
			pObj.checked = false
		}
	}
}

var chbCol = new checkboxGroup(\'id_chbGroup\')
//--></script>
</head>
<body bgcolor=#FFFFE2>
	<center>

	';
	$optionName = db_query( 'select ' . LanguagesManager::sql_prepareField( 'name' ) . ' from ' . PRODUCT_OPTIONS_TABLE . ' where optionID=\'' . $optionID . '\'' );
	$optionNameRow = db_fetch_row( $optionName );
	LanguagesManager::ml_fillFields( PRODUCT_OPTIONS_TABLE, $optionNameRow );
	echo '
	<h5>';
	echo ADMIN_CONFIGURATOR_TITLE;
	echo ' <b>';
	echo $optionNameRow['name'];
	echo '</b></h5>

';

	if (isset( $_GET['safemode'] )) {
		echo '<p>
<font color=red><b>' . ADMIN_SAFEMODE_WARNING . '<b></font>';
	}

	echo '
	<form action="admincp.php?page=option_value_configurator" method=post name="option_value_configurator_form">


	<script language=\'JavaScript\'>

		function OnClickRadioButton( numberRadio )
		{
			';
	$q = db_query( 'select variantID from ' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . ' where optionID=\'' . $optionID . '\'' );
	$r = db_fetch_row( $q );
	$variant_count = $r[0];
	$q = db_query( 'select variantID from ' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . ' where optionID=\'' . $optionID . '\'' );

	if ($r = db_fetch_row( $q )) {
		echo '					document.option_value_configurator_form["default_radiobutton_"+';
		echo $r['variantID'];
		echo '].checked=
							false;
			';
	}

	echo '			document.option_value_configurator_form["default_radiobutton_"+numberRadio].checked = true;
		}

		function OnClickCheckButton( numberCheck )
		{
		 	document.option_value_configurator_form["default_radiobutton_"+numberCheck].disabled=
				!document.option_value_configurator_form["switchOn_"+numberCheck].checked;
			document.option_value_configurator_form["price_surplus_"+numberCheck].disabled=
				!document.option_value_configurator_form["switchOn_"+numberCheck].checked;
			if ( document.option_value_configurator_form["price_surplus_"+numberCheck].disabled )
				document.option_value_configurator_form["price_surplus_"+numberCheck].value="";
			if ( document.option_value_configurator_form["default_radiobutton_"+numberCheck].disabled )
				document.option_value_configurator_form["default_radiobutton_"+numberCheck].checked=false;
		}

	</script>

	';

	if ($variant_count != 0) {
		echo '
	<table border="0" cellspacing="0" cellpadding="4">
		<tr align="center"> 
			<td>
				<strong>
					<b>';
		echo ADMIN_ON_OFF;
		echo '</b>
				</strong>
			</td>
			<td>
				<strong>
					<b>';
		echo ADMIN_BY_DEF;
		echo '</b>
				</strong>
			</td>
			<td>
				<strong>
					<b>';
		echo ADMIN_VALUE;
		echo '<b>
				</strong>
			</td>
			<td>
				<strong>
					<b>';
		echo ADMIN_PRICE_SURPLUS;
		echo '</b>
				</strong>
			</td>
		</tr>
		<tr>
			<td bgcolor="#C3BD7C" align="center" style="padding:0px"><input type="checkbox" id="id_chbGroup" onclick="chbCol.changeState()" /></td>
			<td colspan="3" bgcolor="#C3BD7C"></td>
		</tr>


	';
		$values = db_query( 'select ' . LanguagesManager::sql_prepareField( 'option_value' ) . ', variantID from ' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . ' where optionID=\'' . $optionID . '\' order by sort_order' );
		$q = db_query( 'select option_show_times, variantID from ' . PRODUCT_OPTIONS_VALUES_TABLE . ' where optionID=\'' . $optionID . '\' AND productID=\'' . $productID . '\'' );

		if ($r = db_fetch_row( $q )) {
			$option_show_times = $r['option_show_times'];
			$variantID_default = $r['variantID'];
		} 
else {
			$option_show_times = 1082;
			$variantID_default = null;
		}

		$first_row_bool = true;

		if ($value_row = db_fetch_row( $values )) {
			LanguagesManager::ml_fillFields( PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE, $value_row );
			$q = db_query( 'select price_surplus from ' . PRODUCTS_OPTIONS_SET_TABLE . ' where productID=\'' . $productID . '\' AND optionID=\'' . $optionID . '\' AND variantID=\'' . $value_row['variantID'] . '\'' );

			if ($r = db_fetch_row( $q )) {
				$price_surplus = $r['price_surplus'];
			} 
else {
				$price_surplus = null;
			}

			$q1 = db_query( 'select COUNT(*) from ' . PRODUCTS_OPTIONS_SET_TABLE . ' where productID=\'' . $productID . '\' AND optionID=\'' . $optionID . '\' AND variantID=\'' . $value_row['variantID'] . '\'' );
			$r1 = db_fetch_row( $q1 );
			$check = $r1[0] != 0;
			echo '	
		<tr> 
			<td align="center">
				<input name="switchOn_';
			echo $value_row['variantID'];
			echo '" 
					id="switchOn_';
			echo $value_row['variantID'];
			echo '"
					type="checkbox"
				>
			</td>
			<td align="center" valign="top"> 
				<p> 
						<input name="default_radiobutton_';
			echo $value_row['variantID'];
			echo '" 
							type="radio" value="';
			echo $value_row['variantID'];
			echo '"
				';

			if ((bool)$variantID_default == (bool)$value_row['variantID']) {
				echo '						checked
				';
				$first_row_bool = false;
			}

			echo '						onclick=\'OnClickRadioButton(';
			echo $value_row['variantID'];
			echo ')\'

						disabled=true
					>
				</p>
			</td>
			<td>
				';
			echo $value_row['option_value'];
			echo '			</td>
			<td>
				<input name="price_surplus_';
			echo $value_row['variantID'];
			echo '" 
					type="text" value="';
			echo $price_surplus;
			echo '" disabled=true>
				<script language=\'JavaScript\' type="text/javascript"><!--
					chbCol.addBox("switchOn_';
			echo $value_row['variantID'];
			echo '", {spNum:"';
			echo $value_row['variantID'];
			echo '", evalCode: "_Obj.onclick = function(){OnClickCheckButton(this.spNum);	this.GroupObj.checkState()}"});
		';

			if ($check) {
				echo '		
					document.option_value_configurator_form["switchOn_';
				echo $value_row['variantID'];
				echo '"].click();
		';
			}

			echo '				//--></script>
			</td>
		</tr>

	';
		}

		echo '	</table>




	<p>';
		echo ADMIN_OFFER_TO_SELECT;
		echo '		<input name="option_show_times" type="text" value="';
		echo $option_show_times;
		echo '">
	';
		echo ADMIN_OFFER_TIMES;
		echo '</p>
	<p> 
		<INPUT name="SAVE" type=submit value="';
		echo SAVE_BUTTON;
		echo '">
		<INPUT name="CLOSE" type=submit value="';
		echo CLOSE_BUTTON;
		echo '">
	</p>

		<INPUT type=hidden name="optionID" value="';
		echo $optionID;
		echo '">
		<INPUT type=hidden name="productID" value="';
		echo $productID;
		echo '">

	';
	} 
else {
		echo '		';
		echo ADMIN_NO_VARIANTS;
		echo '...
	';
	}

	echo '
	</form>

	</center>
</body>

</html>';
?>