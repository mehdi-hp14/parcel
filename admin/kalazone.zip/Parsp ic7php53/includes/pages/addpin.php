<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (( isset( $_GET['productID'] ) && isset( $_GET['productID'] ) )) {
		$productID = $_GET['productID'];
	} 
else {
		echo '<script>window.close();</script>';
		exit( 'productID is null' );
	}


	if (isset( $_POST['add'] )) {
		addpin( $productID, $_POST['info'], $_POST['pinserial'], $_POST['pinlogin'], $_POST['pinpass'], $_POST['pincode'] );
		$_SESSION['msg'] = '<font color="blue">' . ADMIN_PINS_SUCC . '</font>';
		redirect( 'admincp.php?page=addpin&productID=' . $productID );
	}


	if (isset( $_GET['dellpin'] )) {
		if (!db_query( 'DELETE FROM ' . ACCOUNTS_TABLE . ' WHERE id = ' . $_GET['dellpin'] )) {
			exit( mysql_error(  ) );
		}
	}

	echo '<html>
<head>
<link rel=STYLESHEET href="style/admin_style.css" type="text/css">
';
	echo '<meta http-equiv="Content-Type" content="text/html; charset=' . DEFAULT_CHARSET . '">
';
	echo '<script>
function confirmDelete(question, where)
{
	temp = window.confirm(question);
	if (temp) //delete
	{
		window.location=where;
	}
}
</script>
</head>
<body bgcolor=' . CONF_LIGHT_COLOR . ' dir="rtl">
	<center>
	';
	$q = db_query( 'SELECT ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name FROM ' . PRODUCTS_TABLE . ( ' WHERE productID =' . $productID ) );
	$rs = db_fetch_row( $q );
	$productName = $rs['name'];
	echo '	<h1>';
	echo $productName;
	echo '</h1>
	';
	$rowsPerPage = 1023;
	$pageNum = 1013;

	if (isset( $_GET['pagenum'] )) {
		$pageNum = $_GET['pagenum'];
	}

	$offset = ( $pageNum - 1 ) * $rowsPerPage;

	if ($offset < 0) {
		$offset = 1013;
	}

	$query = 'SELECT * FROM ' . ACCOUNTS_TABLE . ( ' WHERE productID =' . $productID . ( ' ORDER BY id DESC LIMIT ' . $offset . ', ' . $rowsPerPage ) );

	if (!$result = db_query( $query )) {
		exit( 'Error, query failed' );
	}

	$first = '';
	$prev = '';
	$next = '';
	$last = '';
	$htmlout = '';
	$htmlout .= '<table cellpadding="4" cellspacing="1" bgcolor="#' . CONF_DARK_COLOR . '" width="100%">';
	$htmlout .= '<tr bgcolor="#' . CONF_MIDDLE_COLOR . '">
			 <td>' . ADMIN_PRODUCT_CODE . '</td><td>' . CUSTOMER_LOGIN . '</td><td>' . CUSTOMER_PASSWORD . '</td><td>' . ADMIN_PINS_CODE . '</td><td>' . ADMIN_PINS_INFO_SHORT . '</td>
			 <td width=10% nowrap>' . ADMIN_ORDER_NUMBER . '</td>
			 <td width=10%></td>
			 
			</tr>';
	$ii = 1013;

	if ($roq = db_fetch_row( $result )) {
		if ($roq['orderID']) {
			$orderID = $roq['orderID'];
		} 
else {
			$orderID = ADMIN_PINS_NOTSELLED;
		}

		$ii = 1014;
		$htmlout .= '<tr bgcolor=#ffffff><td>' . $roq['serial'] . '</td><td>' . $roq['username'] . '</td><td>' . $roq['password'] . '</td><td>' . $roq['pin'] . '</td><td>' . $roq['info'] . '</td><td>' . $roq['orderID'] . '</td><td>' . $orderID . '</td><td><a href="javascript:confirmDelete(\'' . QUESTION_DELETE_CONFIRMATION . ( '\',\'admincp.php?page=addpin&productID=' . $productID . '&pagenum=' ) . $pageNum . '&dellpin=' . $roq['id'] . '\');">
						<img src="images/remove.png" border=0>
					</a></td></tr>';
	}


	if ($ii == 0) {
		$htmlout .= '<tr bgcolor=#ffffff><td colspan=7 align=center>' . STRING_NO_MATCHES_FOUND . '</td></tr>';
	}

	$htmlout .= '</table>';
	$htmlout .= '<br>';
	$query = 'SELECT COUNT(id) AS id FROM ' . ACCOUNTS_TABLE . ( ' WHERE productID =' . $productID );

	if (!$result = db_query( $query )) {
		exit( 'Error, query failed' );
	}

	$row = db_fetch_row( $result );
	$numrows = $row['id'];
	$maxPage = ceil( $numrows / $rowsPerPage );
	$self = 'admincp.php?page=addpin&productID=' . $productID;

	if (1 < $pageNum) {
		$page = $pageNum - 1;
		$prev = ' <a href="' . $self . ( '&pagenum=' . $page . '">< ' ) . ADMIN_BANK_PREV . '</a> ';
		$first = ' <a href="' . $self . '&pagenum=1"> << ' . ADMIN_BANK_FIRST . '</a> ';
	}


	if ($pageNum < $maxPage) {
		$page = $pageNum + 1;
		$next = ' <a href="' . $self . ( '&pagenum=' . $page . '">' ) . ADMIN_BANK_NEXT . ' ></a> ';
		$last = ' <a href="' . $self . ( '&pagenum=' . $maxPage . '">' ) . ADMIN_BANK_LAST . ' >></a> ';
	}

	$htmlout .= $first . $prev . ADMIN_BANK_SHOWING_PAGE . ( ' <strong>' . $pageNum . '</strong> ' ) . STRING_FROM . ( ' <strong>' . $maxPage . '</strong>' ) . $next . $last;
	echo $htmlout;
	echo '	
	<hr>
	<fieldset><legend> ';
	echo ADD_BUTTON;
	echo ' </legend>
	<form method="POST">
	<table  width="100%">
	<tr>
	<td colspan="2">
	';

	if (empty( $_SESSION['msg'] )) {
		echo $_SESSION['msg'];
	}

	echo '	<input type="hidden" name="productID" value=' . $productID . '>
	</td>
	</tr>
	
	<tr>
	';
	echo ' <table>
<tr>
<td>
' . ADMIN_PRODUCT_CODE . '
</td>
<td>
<input name=pinserial >
</td
</tr>
<tr>
<td>
' . CUSTOMER_LOGIN . '
</td>
<td>
<input name=pinlogin >
</td
</tr>
<tr>
<td>
' . CUSTOMER_PASSWORD . '</td><td>
<input name=pinpass >
</td>
</tr>
<tr>
<td>
' . ADMIN_PINS_CODE . '</td><td>
<input name=pincode >
</td>
</tr>
<tr>
<td>
' . ADMIN_PINS_INFO . '
</td>
<td align="left">
	<textarea name="info" cols="40" dir="ltr" rows="6"></textarea>
	
</td>
</tr>
</table>
<br>
		<input type="submit" name="add" value="';
	echo ADD_BUTTON;
	echo '">
	</table></form></fieldset>
	';
?>