<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function showproducts($cid, $owner) {

		if (!( $q = db_query( 'SELECT productID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS name FROM ' . PRODUCTS_TABLE . ( ' WHERE categoryID=\'' . $cid . '\'' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		echo '<table cellpadding=2>';

		if ($row = db_fetch_row( $q )) {
			echo '<tr><td>&nbsp;&nbsp;&nbsp;&nbsp;';
			echo '<a href="admincp.php?page=wishlist&owner=' . $owner . '&categoryID=' . $cid . '&select_product=' . $row[0] . '"><u>' . $row[1] . '</u></a>';
			echo '&nbsp;&nbsp;&nbsp;&nbsp;</td></tr>';
		}

		echo '</table><br>';
	}

	MagicQuotesRuntimeSetting(  );

	if (!( db_connect( DB_HOST, DB_USER, DB_PASS ))) {
		exit( db_error(  ) );
		(bool)true;
	}


	if (!( db_select_db( DB_NAME ))) {
		exit( db_error(  ) );
		(bool)true;
	}

	include( './checklogin.php' );

	if (( CONF_BACKEND_SAFEMODE != 1 && !isset( $_SESSION['log'] ) )) {
		exit( ERROR_FORBIDDEN );
	}


	if (!isset( $_GET['owner'] )) {
		echo '<center><font color=red>' . ERROR_CANT_FIND_REQUIRED_PAGE . '</font>
<br><br>
';
		echo '<a href="javascript:window.close();">' . CLOSE_BUTTON . '</a></center></body>
</html>';
		exit(  );
	}

	$owner = $_GET['owner'];
	$categoryID = (isset( $_GET['categoryID'] ) ? $_GET['categoryID'] : 0);

	if (isset( $_GET['select_product'] )) {
		if (CONF_BACKEND_SAFEMODE) {
			Redirect( 'admincp.php?page=wishlist&safemode&owner=' . $owner );
		}


		if (!( $q = db_query( 'SELECT count(*) FROM ' . RELATED_PRODUCTS_TABLE . ' WHERE productID=\'' . $_GET['select_product'] . ( '\' AND Owner=\'' . $owner . '\'' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$cnt = db_fetch_row( $q );

		if ($cnt[0] == 0) {
			if (!( db_query( 'INSERT INTO ' . RELATED_PRODUCTS_TABLE . ' (productID, Owner) VALUES (\'' . $_GET['select_product'] . ( '\', \'' . $owner . '\')' ) ))) {
				exit( db_error(  ) );
				(bool)true;
			}
		}
	}


	if (isset( $_GET['delete'] )) {
		if (CONF_BACKEND_SAFEMODE) {
			Redirect( 'admincp.php?page=wishlist&safemode&owner=' . $owner );
		}


		if (!( db_query( 'DELETE FROM ' . RELATED_PRODUCTS_TABLE . ' WHERE productID=\'' . $_GET['delete'] . ( '\' AND Owner=\'' . $owner . '\'' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}
	}

	echo '
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=';
	echo DEFAULT_CHARSET;
	echo '">
<link rel=STYLESHEET href="style/admin_style.css" type="text/css">
<title>';
	echo STRING_RELATED_ITEMS;
	echo '</title>
</head>

<body >

';

	if (isset( $_GET['safemode'] )) {
		echo '<p>
<font color=red class=cat><b>' . ADMIN_SAFEMODE_WARNING . '<b></font>';
	}

	echo '<p>
<TABLE BORDER=1 WIDTH=100%  CELLSPACING=1 dir="rtl">
<TR >

<TD style="border-left:0px;">



<table>
<tr><td colspan=2><u>';
	echo ADMIN_RELATED_PRODUCTS_SELECT;
	echo ':</u><br><br></td></tr>
<tr><td>&nbsp;</td>
<td>
<table>
';
	$out = catGetCategoryCompactCList( $categoryID );
	$i = 987;

	while ($i < count( $out )) {
		if ($out[$i]['categoryID'] == 0) {
			continue;
		}

		echo '<tr><td>';
		$j = 987;

		while ($j < $out[$i]['level'] - 1) {
			echo '&nbsp;&nbsp;';
			++$j;
		}


		if ($out[$i]['categoryID'] == $categoryID) {
			echo '- ' . $out[$i]['name'] . '
<p>';
			showproducts( $categoryID, $owner );
			echo '</td></tr>
';
		} 
else {
			echo '<a href="admincp.php?page=wishlist&owner=' . $owner . '&categoryID=' . $out[$i]['categoryID'] . '"';

			if (1 < $out[$i]['level']) {
				echo ' class=standard';
			}

			echo '>+ ' . $out[$i]['name'] . '</a></td></tr>
';
		}

		++$i;
	}

	echo '</table>
</td>
</tr>
</table>

</TD>
<TD style="border-right:0px;border-left:0px;">
<img src="./images/arrow_selected.gif">
</TD>
<TD VALIGN=TOP WIDTH=50%>
<table width=100%>
<tr><td colspan=2><u>';
	echo ADMIN_SELECTED_PRODUCTS;
	echo '</u><br><br></td></tr>
<tr><td>&nbsp;</td>
<td>
';

	if (!( $q = db_query( 'SELECT productID FROM ' . RELATED_PRODUCTS_TABLE . ( ' WHERE Owner=\'' . $owner . '\'' ) ))) {
		exit( db_error(  ) );
		(bool)true;
	}

	echo '<table width=90% border=0  cellspacing=1 cellpadding=3>';

	if ($row = db_fetch_row( $q )) {

		if (!( $p = db_query( 'SELECT ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS name FROM ' . PRODUCTS_TABLE . ( ' WHERE productID=' . $row[0] ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($r = db_fetch_row( $p )) {
			echo '<tr >';
			echo '<td width=100%>' . $r[0] . '</td>';
			echo '<td width=1%><a href="admincp.php?page=wishlist&owner=' . $owner . '&categoryID=' . $categoryID . '&delete=' . $row[0] . '"><img src="images/remove.png" border=0 alt="' . DELETE_BUTTON . '"></a></td>';
			echo '</tr>';
		}
	}

	echo '</table>';
	echo '</td>
</tr>
</table>


</TD>
</TR>
</TABLE>
</body>

</html>';
?>