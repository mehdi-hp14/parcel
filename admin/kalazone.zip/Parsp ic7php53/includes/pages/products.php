<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function GetPictureSize($filename) {
		$size_info = getimagesize( './uploads/products_pictures/' . $filename );
		return (bool)$size_info[0] + 40 . ', ' . (bool)$size_info[1] + 40;
	}

	function GetVideoSize($filename) {
		$size_info = getimagesize( './uploads/products_videos/' . $filename );
		return (bool)$size_info[0] + 40 . ', ' . (bool)$size_info[1] + 40;
	}

	function ReLoadOpener() {
		if ($_GET['productID'] == 0) {
			$categoryID = $_POST['categoryID'];
		} 
else {
			$q = ;
			$r = db_query( 'select categoryID from ' . PRODUCTS_TABLE . ' where productID=\'' . $_GET['productID'] . '\'' );
			$r['categoryID'];
			$categoryID = db_fetch_row( $q );
		}

		echo '<script language=\'JavaScript\'>';
		echo '	try';
		echo '	{';
		echo '		window.opener.location.reload();';
		echo '	}';
		echo '	catch(e) { }';
		echo '</script>';
	}

	function CloseWindow() {
		echo '<script language=\'JavaScript\'>';
		echo '	window.close();
';
		echo '</script>';
	}

	function OpenConfigurator($optionID, $productID) {
		$url = 'admincp.php?page=option_value_configurator&optionID=' . $optionID . '&productID=' . $productID;
		echo '<script language=\'JavaScript\'>
';
		echo '		w=400; 
';
		echo '		h=400; 
';
		echo '		link=\'' . $url . '\'; 
';
		echo '		var win = \'width=\'+w+\',height=\'+h+\',menubar=no,location=no,resizable,scrollbars\';
';
		echo '		wishWin = window.open(link,\'wishWin\',win);
';
		echo '</script>
';
	}

	function OpenAddPin($productID) {
		$url = 'addpin.php?productID=' . $productID;
		echo '<script language=\'JavaScript\'>
';
		echo '		w=400; 
';
		echo '		h=400; 
';
		echo '		link=\'' . $url . '\'; 
';
		echo '		var win = \'width=\'+w+\',height=\'+h+\',menubar=no,location=no,resizable,scrollbars\';
';
		echo '		wishWin = window.open(link,\'wishWin\',win);
';
		echo '</script>
';
	}

	include_once( './smarty/plugins/function.html_text.php' );
	include_once( './smarty/plugins/function.html_textarea.php' );
	include_once( './core_functions/configurator_functions.php' );
	@set_time_limit( 0 );
	include( './checklogin.php' );

	if (( CONF_BACKEND_SAFEMODE != 1 && !isset( $_SESSION['log'] ) )) {
		exit( ERROR_FORBIDDEN );
	}


	if (isset( $_GET['delete'] )) {
		if (CONF_BACKEND_SAFEMODE) {
			Redirect( 'products.php?safemode&productID=' . $_GET['productID'] );
		}

		DeleteProduct( $_GET['productID'] );
		CloseWindow(  );
		ReLoadOpener(  );
		echo '<center>' . STRING_DELETED . '</center>';
		echo '<script type="text/javascript"><!--
          parent.location = "admincp.php?tab=catalog&sub=products_categories";        
            // -->
        </script>';
		exit(  );
	}


	if (!isset( $_GET['productID'] )) {
		$_GET['productID'] = 0;
	}

	$_GET['productID'] = (int)$_GET['productID'];
	$productID = $_GET['productID'];

	if (( isset( $_POST ) && 0 < count( $_POST ) )) {
		if (CONF_BACKEND_SAFEMODE) {
			Redirect( 'products.php?safemode&productID=' . $productID );
		}
	}


	if (!isset( $_POST['eproduct_available_days'] )) {
		$_POST['eproduct_available_days'] = 365;
	}


	if (!isset( $_POST['eproduct_download_times'] )) {
		$_POST['eproduct_download_times'] = 1;
	}


	if (isset( $_POST['eproduct_download_times'] )) {
		$_POST['eproduct_download_times'] = (int)$_POST['eproduct_download_times'];
	}


	if (isset( $_GET['killfile'] )) {
		$product = GetProduct( $_GET['productID'] );

		if (( file_exists( './uploads/products_files/' . $product['eproduct_filename'] ) && $product['eproduct_filename'] != null )) {
			unlink( './uploads/products_files/' . $product['eproduct_filename'] );
			$product['eproduct_filename'] = null;
			db_query( 'UPDATE ' . PRODUCTS_TABLE . ' SET ' . 'eproduct_filename=null, ' . 'eproduct_available_days=0, ' . 'eproduct_download_times=0  ' . 'where productID=\'' . $_GET['productID'] . '\'' );
		}
	}


	if (isset( $_POST['save_product'] )) {
		if ($_GET['productID'] == 0) {
			$productID = AddProduct( $_POST, $_POST['categoryID'], $_POST['price'], $_POST['in_stock'], LanguagesManager::sql_prepareFieldInsert( 'brief_description', $_POST ), $_POST['list_price'], $_POST['product_code'], $_POST['sort_order'], isset( $_POST['ProductIsProgram'] ), 'eproduct_filename', $_POST['eproduct_available_days'], $_POST['eproduct_download_times'], $_POST['weight'], $_POST['meta_description'], $_POST['meta_keywords'], isset( $_POST['free_shipping'] ), isset( $_POST['is_account'] ), $_POST['min_order_amount'], $_POST['shipping_freight'], $_POST['tax_class'], $_POST['cod_link'] );
			$_GET['productID'] = $productID;
		} 
else {
			UpdateProduct( $_POST, $productID, $_POST['categoryID'], $_POST['price'], $_POST['in_stock'], $_POST['rating'], $_POST['list_price'], $_POST['product_code'], $_POST['sort_order'], isset( $_POST['ProductIsProgram'] ), 'eproduct_filename', $_POST['eproduct_available_days'], $_POST['eproduct_download_times'], $_POST['weight'], $_POST['meta_description'], $_POST['meta_keywords'], isset( $_POST['free_shipping'] ), isset( $_POST['is_account'] ), $_POST['min_order_amount'], $_POST['shipping_freight'], $_POST['tax_class'], $_POST['cod_link'] );
		}

		$updatedValues = scanArrayKeysForID( $_POST, array( 'option_value_\w{2}', 'option_radio_type' ) );
		cfgUpdateOptionValue( $productID, $updatedValues );

		if (CONF_UPDATE_GCV == '1') {
			update_products_Count_Value_For_Categories( 1 );
		}

		ReLoadOpener(  );
		echo '<script language=\'JavaScript\'>';
		echo '		window.close();';
		echo '</script>';

		if ($_POST['save_product_without_closing'] == '0') {
			CloseWindow(  );
		}
	}


	if (isset( $_POST['save_pictures'] )) {
		if ($_GET['productID'] == 0) {
			$productID = AddProduct( $_POST, $_POST['categoryID'], $_POST['price'], $_POST['in_stock'], LanguagesManager::sql_prepareFieldInsert( 'brief_description', $_POST ), $_POST['list_price'], $_POST['product_code'], $_POST['sort_order'], isset( $_POST['ProductIsProgram'] ), 'eproduct_filename', $_POST['eproduct_available_days'], $_POST['eproduct_download_times'], $_POST['weight'], $_POST['meta_description'], $_POST['meta_keywords'], isset( $_POST['free_shipping'] ), isset( $_POST['is_account'] ), $_POST['min_order_amount'], $_POST['shipping_freight'], $_POST['tax_class'], $_POST['cod_link'] );
			$_GET['productID'] = $productID;
		}

		AddNewPictures( $_GET['productID'], 'new_filename', 'new_thumbnail', 'new_enlarged', $_POST['default_picture'] );
		$updatedFileNames = ScanPostVariableWithId( array( 'filename', 'thumbnail', 'enlarged' ) );
		UpdatePictures( $_GET['productID'], $updatedFileNames, $_POST['default_picture'] );
		ReLoadOpener(  );
	}


	if (isset( $_POST['save_videos'] )) {
		if ($_GET['productID'] == 0) {
			$productID = AddProduct( $_POST, $_POST['categoryID'], $_POST['price'], $_POST['in_stock'], LanguagesManager::sql_prepareFieldInsert( 'brief_description', $_POST ), $_POST['list_price'], $_POST['product_code'], $_POST['sort_order'], isset( $_POST['ProductIsProgram'] ), 'eproduct_filename', $_POST['eproduct_available_days'], $_POST['eproduct_download_times'], $_POST['weight'], $_POST['meta_description'], $_POST['meta_keywords'], isset( $_POST['free_shipping'] ), isset( $_POST['is_account'] ), $_POST['min_order_amount'], $_POST['shipping_freight'], $_POST['tax_class'], $_POST['cod_link'] );
			$_GET['productID'] = $productID;
		}

		AddNewVideos( $_GET['productID'], 'new_videofilename', $_POST['default_picture'] );
		$updatedFileNames = ScanPostVariableWithId( array( 'videofilename' ) );
		UpdateVideos( $_GET['productID'], $updatedFileNames, $_POST['default_picture'] );
		ReLoadOpener(  );
	}


	if (isset( $_GET['delete_videos'] )) {
		if (CONF_BACKEND_SAFEMODE) {
			Redirect( 'products.php?safemode&productID=' . $productID );
		}

		DeleteFilenameVideo( $_GET['videoID'] );
		Redirect( 'admincp.php?page=products&productID=' . $productID . '&picture_tab=1' );
	}


	if (isset( $_GET['delete_pictures'] )) {
		if (CONF_BACKEND_SAFEMODE) {
			Redirect( 'products.php?safemode&productID=' . $productID );
		}

		DeleteThreePictures( $_GET['photoID'] );
		ReLoadOpener(  );
	}


	if (isset( $_GET['delete_one_picture'] )) {
		if (CONF_BACKEND_SAFEMODE) {
			Redirect( 'products.php?safemode&productID=' . $productID );
		}


		if (isset( $_GET['filename'] )) {
			DeleteFilenamePicture( $_GET['filename'] );
		}


		if (isset( $_GET['thumbnail'] )) {
			DeleteThumbnailPicture( $_GET['thumbnail'] );
		}


		if (isset( $_GET['enlarged'] )) {
			DeleteEnlargedPicture( $_GET['enlarged'] );
		}

		Redirect( 'admincp.php?page=products&productID=' . $productID . '&picture_tab=1' );
		exit(  );
	}


	if (isset( $_POST['AddProductAndOpenConfigurator'] )) {
		$productID = AddProduct( $_POST, $_POST['categoryID'], $_POST['price'], $_POST['in_stock'], LanguagesManager::sql_prepareFieldInsert( 'brief_description', $_POST ), $_POST['list_price'], $_POST['product_code'], $_POST['sort_order'], isset( $_POST['ProductIsProgram'] ), 'eproduct_filename', $_POST['eproduct_available_days'], $_POST['eproduct_download_times'], $_POST['weight'], $_POST['meta_description'], $_POST['meta_keywords'], isset( $_POST['free_shipping'] ), isset( $_POST['is_account'] ), $_POST['min_order_amount'], $_POST['shipping_freight'], $_POST['tax_class'], $_POST['cod_link'] );
		$_GET['productID'] = $productID;
		$updatedValues = ScanPostVariableWithId( array( 'option_value', 'option_radio_type' ) );
		cfgUpdateOptionValue( $productID, $updatedValues );
		OpenConfigurator( $_POST['optionID'], $productID );
	}


	if (isset( $_GET['remove_from_app_cat'] )) {
		if (CONF_BACKEND_SAFEMODE) {
			Redirect( 'products.php?safemode&productID=' . $productID );
		}

		catRemoveProductFromAppendedCategory( $_GET['productID'], $_GET['remove_from_app_cat'] );
		catUpdateProductCount( $_GET['productID'], $_GET['remove_from_app_cat'], -1 );
	}


	if (isset( $_POST['add_category'] )) {
		if ($_GET['productID'] == 0) {
			$productID = AddProduct( $_POST, $_POST['categoryID'], $_POST['price'], $_POST['in_stock'], LanguagesManager::sql_prepareFieldInsert( 'brief_description', $_POST ), $_POST['list_price'], $_POST['product_code'], $_POST['sort_order'], isset( $_POST['ProductIsProgram'] ), 'eproduct_filename', $_POST['eproduct_available_days'], $_POST['eproduct_download_times'], $_POST['weight'], $_POST['meta_description'], $_POST['meta_keywords'], isset( $_POST['free_shipping'] ), isset( $_POST['is_account'] ), $_POST['min_order_amount'], $_POST['shipping_freight'], $_POST['tax_class'], $_POST['cod_link'], 1 );
			$_GET['productID'] = $productID;
		}


		if (isset( $_POST['new_appended_category'] )) {
			catAddProductIntoAppendedCategory( $_GET['productID'], $_POST['new_appended_category'] );

			if (CONF_UPDATE_GCV == '1') {
				catUpdateProductCount( $_GET['productID'], $_POST['new_appended_category'] );
			}
		}
	}


	if ($_GET['productID'] != 0) {
		$product = GetProduct( $_GET['productID'] );
		$pr = $app_cat;
		$title = LanguagesManager::ml_getFieldValue( 'name', $product );
	} 
else {
		$product = array(  );
		$title = ADMIN_PRODUCT_NEW;
		$cat = (isset( $_GET['categoryID'] ) ? $_GET['categoryID'] : 0);
		$product['categoryID'] = $cat;
		$product['name_fa'] = '';
		$product['description_fa'] = '';
		$product['customers_rating'] = 0;
		$product['Price'] = 0;
		$product['picture'] = '';
		$product['in_stock'] = 0;
		$product['thumbnail'] = '';
		$product['big_picture'] = '';
		$product['brief_description_fa'] = '';
		$product['list_price'] = 0;
		$product['product_code'] = '';
		$product['sort_order'] = 0;
		$product['date_added'] = null;
		$product['date_modified'] = null;
		$product['eproduct_filename'] = '';
		$product['eproduct_available_days'] = 365;
		$product['eproduct_download_times'] = 1;
		$product['weight'] = 0;
		$product['meta_description'] = '';
		$product['meta_keywords'] = '';
		$product['free_shipping'] = 0;
		$product['min_order_amount'] = 1;
		$product['is_account'] = 0;
		$product['cod_link'] = '';

		if (!isset( $product['classID'] )) {
			$product['classID'] = 'null';
		} 
else {
			if (( CONF_DEFAULT_TAX_CLASS == '0' && 0 < !$product['classID'] )) {
				$product['classID'] = 'null';
			} 
else {
				$product['classID'] = CONF_DEFAULT_TAX_CLASS;
			}
		}

		$product['shipping_freight'] = 0;
	}

	$options = cfgGetProductOptionValue( $_GET['productID'] );
	$options = html_spchars( $options );
	$picturies = GetPictures( $_GET['productID'] );
	$videos = GetVideos( $_GET['productID'] );
	$appended_categories = catGetAppendedCategoriesToProduct( $_GET['productID'] );
	$showAppendedParentsTable = 2763;

	if (isset( $_POST['AppendedParentsTableHideTable_hidden'] )) {
		if ($_POST['AppendedParentsTableHideTable_hidden'] == '1') {
			$showAppendedParentsTable = 2764;
		}
	} 
else {
		if (isset( $_GET['remove_from_app_cat'] )) {
			$showAppendedParentsTable = 2764;
		}
	}

	$showConfiguratorTable = 2763;

	if (isset( $_POST['ConfiguratorHideTable_hidden'] )) {
		if ($_POST['ConfiguratorHideTable_hidden'] == '1') {
			$showConfiguratorTable = 2764;
		}
	}

	$showPhotoTable = 2763;

	if (isset( $_POST['PhotoHideTable_hidden'] )) {
		if ($_POST['PhotoHideTable_hidden'] == '1') {
			$showPhotoTable = 2764;
		}
	} 
else {
		if (( isset( $_GET['delete_pictures'] ) || isset( $_GET['delete_one_picture'] ) )) {
			$showPhotoTable = 2764;
		}
	}

	$tax_classes = taxGetTaxClasses(  );
	echo '
<html>

<head>
<link rel=STYLESHEET href="./style/admin_style.css" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=';
	echo DEFAULT_CHARSET;
	echo '">
<title>';
	echo ADMIN_PRODUCT_TITLE;
	echo '</title>
<script type="text/javascript" src="./js/jquery-1.10.1.min.js"></script>
<script>
	
	 
	  $(document).ready(function(){
		
	
		$("a.tab").click(function () {
			
			
	
			$(".active").removeClass("active");
			
	
			$(this).addClass("active");
			
	
			$(".content").slideUp();
			
	
			var content_show = $(this).attr("name");
			$("#"+content_show).slideDown();
		  
		});
	
	  });
  </script>
<script>
function confDelete(question, where)
{
	temp = window.confirm(question);
	if (temp) //delete
	{
		window.location=where;
	}
}
function open_window(link,w,h) //opens new window
{
	var win = "width="+w+",height="+h+",menubar=no,location=no,resizable,scrollbars";
	wishWin = window.open(link,\'wishWin\',win);
}
function position_this_window()
{
	var x = (screen.availWidth - 795) / 2;
	window.resizeTo(795, screen.availHeight - 50);
	window.moveTo(Math.floor(x),25);
}

</script>

</head>
<body style="margin:0px;" dir="rtl">
<script type="text/javascript" src="./js/behavior.js"></script>       
<script type="text/javascript" src="./js/admin.js"></script>       
<script type="text/javascript" src="./js/functions.js"></script>                 
      <div id="min_header" dir="rtl">              
        <font color=purple ><b>            
            ';
	echo $title;
	echo '</b>
            ';
	echo '(' . ADMIN_PRODUCT_ID . ' ' . $productID . ')';
	echo '        
        </font>
       <span style="float:left;font-weight:normal;font-size:8px;">
   ';

	if (!is_null( $product['date_added'] )) {
		echo ADMIN_DATE_ADDED . ':' . $product['date_added'];
	}


	if (!is_null( $product['date_modified'] )) {
		echo ADMIN_DATE_MODIFIED . ':' . $product['date_modified'];
	}


	if (isset( $_GET['couldntToDelete'] )) {
		echo COULD_NOT_DELETE_THIS_PRODUCT;
	}

	echo ' </span>
 </div>
';

	if (isset( $_GET['safemode'] )) {
		echo '<p><font color=red><b>' . ADMIN_SAFEMODE_WARNING . '<b></font>';
	}


	if (( ( ( ( isset( $_POST['save_pictures'] ) || isset( $_POST['save_videos'] ) ) || isset( $_POST['delete_one_picture'] ) ) || isset( $_POST['delete_videos'] ) ) || isset( $_GET['picture_tab'] ) )) {
		$Content_1 = 'tab ';
		$Content_3 = 'tab active';
		$Content_4 = 'tab ';
		$style_1 = 'display: none;';
		$style_3 = 'display: block;';
		$style_4 = 'display: none;';
	} 
else {
		$Content_1 = 'tab active';
		$Content_3 = 'tab ';
		$Content_4 = 'tab ';
		$style_1 = 'display: block;';
		$style_3 = 'display: none;';
		$style_4 = 'display: none;';
	}

	echo '
<form enctype="multipart/form-data" action="admincp.php?page=products&productID=';
	echo $_GET['productID'];
	echo '"	method=post name="MainForm">
    <input type="hidden" name="page" value="products">        	          
        <div class="tabbed_area" >                   
          <ul class="tabs">                         
            <li> 
                       
            <a href="#" title="';
	echo ADMIN_PRODUCT_BRIEF;
	echo '" name="content_1" class="';
	echo $Content_1;
	echo '">              
              ';
	echo ADMIN_PRODUCT_BRIEF;
	echo '</a>            
            </li>                                      
            <li>            
            <a href="#" title="';
	echo ADMIN_CATEGORY_DESCRIPTION;
	echo '" name="content_2" class="tab">              
              ';
	echo ADMIN_CATEGORY_DESCRIPTION;
	echo '</a>            
            </li>
            <li>
            <a href="#" title="';
	echo ADMIN_PHOTOS;
	echo '" name="content_3" class="';
	echo $Content_3;
	echo '">              
              ';
	echo ADMIN_PHOTOS;
	echo '</a>            
            </li>                                    
            <li>            
            <a href="#" title="';
	echo ADMIN_CONFIGURATOR;
	echo '" name="content_5" class="tab">              
              ';
	echo ADMIN_CONFIGURATOR;
	echo '</a>            
            </li>                   
            <li>            
            <a href="#" title="';
	echo ADMIN_PRODUCT_OTHER;
	echo '"  name="content_6" class="tab">              
              ';
	echo ADMIN_PRODUCT_OTHER;
	echo '</a>
            </li>            
            <li>
            <a href="#" title="';
	echo ADMIN_PRODUCT_CATEGORIES;
	echo '"  name="content_7" class="tab">              
              ';
	echo ADMIN_PRODUCT_CATEGORIES;
	echo '</a>                        
            </li>
            <li>
            <a href="#" title="';
	echo STRING_RELATED_ITEMS;
	echo '" name="content_8" class="tab" style="';

	if ($_GET['productID'] == 0) {
		echo 'display:none;';
	}

	echo '">              
              ';
	echo STRING_RELATED_ITEMS;
	echo '</a>                        
            </li>            
          </ul>                                                
          <div id="content_1" class="content" style="';
	echo $style_1;
	echo '">        	             
                <ul>            	                             
                  <li>
                  <div style="float:right;width:20%">
                  	';
	echo ADMIN_PRODUCT_NAME;
	echo '                  	
                  </div>
    	             <div>
    	             ';
	$param['name'] = 'name';
	$param['style'] = 'width:400px;';
	$param['values'] = $product;
	$param['dbfield'] = 'name';
	echo smarty_function_html_text( $param, $smarty );
	echo '		
                   </div>
                  </li>                  
                  <li>                   
                  <div style="float:right;width:20%">
                  ';
	echo ADMIN_CATEGORY_PARENT;
	echo '                  </div>
                  <div>
                  <select name="categoryID" ';

	if (CONF_FULLY_EXPAND_CATEGORIES_IN_ADMIN_MODE == 0) {
		echo 'onChange="window.location=\'admincp.php?page=products&productID=' . $_GET['productID'] . '&change_category=\'+document.MainForm.categoryID.value;"';
	}

	echo '>
                  ';

	if (CONF_FULLY_EXPAND_CATEGORIES_IN_ADMIN_MODE == 1) {
		echo '<option value="1">' . ADMIN_CATEGORY_ROOT . '</option>';
	}

	$tax_class = $product['classID'];
	$core_category = (isset( $_GET['change_category'] ) ? (int)$_GET['change_category'] : $product['categoryID']);

	if (CONF_FULLY_EXPAND_CATEGORIES_IN_ADMIN_MODE == 0) {
		$cats = catGetCategoryCompactCList( $core_category );
	} 
else {
		$cats = catGetCategoryCList(  );
	}

	$i = 2763;

	while ($i < count( $cats )) {
		echo '<option value="' . $cats[$i]['categoryID'] . '"';

		if ($core_category == $cats[$i]['categoryID']) {
			echo ' selected';
		}

		echo '>';
		$j = 2763;

		while ($j < $cats[$i]['level']) {
			echo '&nbsp;&nbsp;';
			++$j;
		}

		echo $cats[$i]['name'];
		echo '</option>';
		++$i;
	}

	echo '                </select>
                  
                  </div>
                  </li>
                  <li>
                  <div style="float:right;width:20%">
                  ';
	echo ADMIN_PRODUCT_CODE;
	echo '                  </div>
                  <div>
                  <input type="text" name="product_code" 
    			value="';
	echo str_replace( '"', '&quot;', $product['product_code'] );
	echo '">
                  </div>
                  </li>
                  <li>
                  <div style="height:20px;">
                  <div style="float:right;width:20%">
                  ';
	echo ADMIN_SORT_ORDER;
	echo '                  </div>
                  <div style="float:right;width:30%;">
                  <input type="text" name="sort_order" value="';
	echo $product['sort_order'];
	echo '">
                  </div>
                  <div style="float:right;width:20%">
                  ';
	echo ADMIN_PRODUCT_RATING;
	echo '                  </div>
                  <div style="float:right;width:30%;">
                  <input type=text name="rating" 
    			value="';
	echo str_replace( '"', '&quot;', $product['customers_rating'] );
	echo '">
                  </div>
                  </div>
                  </li>                  
                  <li>
                  <div style="float:right;width:20%">
                  	';
	echo ADMIN_PRODUCT_PRICE;
	echo ', ';
	echo STRING_UNIVERSAL_CURRENCY;
	echo '<br>(';
	echo STRING_NUMBER_ONLY;
	echo '):
                  </div>
                  <div style="float:right;width:30%">
                  	<input type="text" name="price" value=';
	echo $product['Price'] - 1 + 1;
	echo '>
                  </div>
                  <div style="float:right;width:20%">
                  	';
	echo ADMIN_PRODUCT_LISTPRICE;
	echo ', ';
	echo STRING_UNIVERSAL_CURRENCY;
	echo '<br>(';
	echo STRING_NUMBER_ONLY;
	echo '):
                  </div>
                  <div style="float:right;width:30%">
                  <input type="text" name="list_price" value=';
	echo $product['list_price'];
	echo '>
                  </div>
                  <div style="height:35px;">
                  </div>
                  </li>
                  
                   <li>
                  <div style="height:20px;">
                  ';

	if ($product['in_stock'] < 0) {
		$is = 2763;
	} 
else {
		$is = $product['in_stock'];
	}


	if (CONF_CHECKSTOCK == 1) {
		echo '<div style="float:right;width:20%">' . ADMIN_PRODUCT_INSTOCK . ':</div>';
		echo '<div style="width:30%;float:right;"><input type="text" name="in_stock" value="' . $is . '"></div>';
	} 
else {
		echo '<div>' . ADMIN_CHECKSTOCK_INSTOCK . '<input type=hidden name="in_stock" value="' . $is . '"></div>';
	}

	echo '                   
                  <div style="width:20%;right:50%;float:right;">
                    ';
	echo ADMIN_TAX_CLASSES;
	echo '                  </div>
                  ';

	if (count( $tax_classes ) == 0) {
		echo '<input type="hidden" name="tax_class" value=0>' . ADMIN_NOT_DEFINED;
	} 
else {
		echo '                  
                  <div style="width:30%;float:right;">
                    <select name="tax_class" id="tax_class" >                  
                  ';
		echo '<option value=0 > ' . ADMIN_NOT_DEFINED . '</option>';
		$i = 2763;

		while ($i < count( $tax_classes )) {
			echo '<option value="' . $tax_classes[$i]['classID'] . '"';

			if ($tax_class == $tax_classes[$i]['classID']) {
				echo ' selected';
			}

			echo '>';
			echo $tax_classes[$i]['name'];
			echo '</option>';
			++$i;
		}

		echo '                </select>                                
                  </div>  
                 ';
	}

	echo ' 
                  </div>                           
                  </li>
                  <li>
                          <table id=\'FileNameTable\'>
                    			<tr>
                    				<td colspan=3>
                    					<input type=checkbox name=\'ProductIsProgram\' 
                    							value=\'1\'
                    							onclick=\'JavaScript:ProductIsProgramHandler();\'
                    							';

	if (trim( $product['eproduct_filename'] ) != '') {
		echo '                    								checked
                    							';
	}

	echo '                    							>
                    							';
	echo ADMIN_PRODUCT_IS_PROGRAM;
	echo '                    				</td>
                    			</tr>
                    
                    			<script language=\'JavaScript\'>
                    				function ProductIsProgramHandler()
                    				{
                    					document.MainForm.eproduct_filename.disabled = 
                    							!document.MainForm.ProductIsProgram.checked;
                    					document.MainForm.eproduct_available_days.disabled = 
                    							!document.MainForm.ProductIsProgram.checked;
                    					document.MainForm.eproduct_download_times.disabled = 
                    							!document.MainForm.ProductIsProgram.checked;
                    				}
                    			</script>
                    
                    
                    			<tr>
                    				<td>
                    					';
	echo ADMIN_EPRODUCT_FILENAME;
	echo '                    				</td>
                    				<td>
                    					';
	echo ADMIN_EPRODUCT_AVAILABLE_DAYS;
	echo '                    				</td>
                    				<td>
                    					';
	echo ADMIN_EPRODUCT_DOWNLOAD_TIMES;
	echo '                    				</td>
                    			</tr>
                    
                    			<tr>
                    				<td>
                    					<input type=\'file\' name=\'eproduct_filename\' 
                    							value=\'';
	echo $product['eproduct_filename'];
	echo '\' >
                    					<br>
                    					';

	if (( file_exists( './uploads/products_files/' . $product['eproduct_filename'] ) && $product['eproduct_filename'] != null )) {
		echo '                    						(';
		echo $product['eproduct_filename'];
		echo ' <a title="';
		echo ADMIN_CLEAR;
		echo '" href="admincp.php?page=products&productID=';
		echo $_GET['productID'] . '&killfile=\'' . $product['eproduct_filename'];
		echo '"\'"><img src="images/0.png"></a>)
                    					';
	} 
else {
		echo '                    						';
		echo ADMIN_FILE_NOT_UPLOADED;
		echo '                    					';
	}

	echo '                    				</td>
                    				<td>
                    					';
	$valueArray[] = 1;
	$valueArray[] = 2;
	$valueArray[] = 3;
	$valueArray[] = 4;
	$valueArray[] = 5;
	$valueArray[] = 7;
	$valueArray[] = 14;
	$valueArray[] = 30;
	$valueArray[] = 180;
	$valueArray[] = 365;
	echo '                    					<select name=\'eproduct_available_days\'>
                    						';
	foreach ($valueArray as $value) {
		echo '                    							<option value=\'';
		echo $value;
		echo '\'
                    							';

		if ($product['eproduct_available_days'] == $value) {
			echo '                    									selected
                    							';
		}

		echo '                    							> ';
		echo $value;
		echo ' </option>
                    						';
	}

	echo '                    					</select>
                    				</td>
                    				<td>
                    					<input type=text name=\'eproduct_download_times\' 
                    						value=\'';
	echo $product['eproduct_download_times'];
	echo '\' >
                    				</td>
                    			</tr>
                    		</table>
                    
                    
                    		<script language=\'JavaScript\'>
                    			ProductIsProgramHandler();
                    		</script>
                    		
                  </li>  
                  <li>
                  ';

	if (CONF_ACCOUNTS_ENABLE == 1) {
		echo '	
		<script type="text/javascript"> 

		if( document.getElementById ) { 
		   getElemById = function( id ) { 
		     return document.getElementById( id ); 
		     } 
		} else if( document.all ) { 
		   getElemById = function( id ) { 
		     return document.all[ id ]; 
		     } 
		} else if( document.layers ) { 
		   getElemById = function( id ) { 
		     return document.layers[ id ]; 
		     } 
		} 
		function showhide( el, id) { 
		   if ( el && el.style ) { 
		     getElemById( id ).style.display = (el.checked) ? \'\' : \'none\'; 
   			} 
		} 
    </script>
    <div style="float:right;width:60%;direction:rtl;">
                			
	     <input type=checkbox name=\'is_account\' ';

		if ($product['is_account']) {
			echo 'checked value=\'1\' ';
		}

		echo ' onclick="showhide(this,\'addpins\');" >
		    ';
		echo ADMIN_IS_ACCOUNT;
		echo '		</div>
		<div name="addpins" id="addpins"  style="float:right;width:40%;direction:rtl;';

		if (!( 0 < $productID && $product['is_account'] )) {
			echo 'display:none;';
		}

		echo ' ">
    ';

		if ($product['is_account']) {
			echo '<a href=\'JavaScript:void(open_window("?page=addpin&productID=' . $productID . '",400,500));\'>' . ADMIN_PINS_INFO_SHORT . '</a><br><br>';
		} 
else {
			echo ADMIN_PINS_INFO_SHORT . '<span style=\'color:red;font-size:10px;\'><i>(' . ADMIN_PINS_INFO_NEEDSAVE . ')</i></span><br><br>';
		}

		echo '  		
		</div>
  </div>
';
	}

	echo '                  </li>                              
                </ul>
          </div>          
          <div id="content_2" class="content" style="display: none; ">
            <ul>
            <li>
              <div style="width:10%;float:right;">
              ';
	echo ADMIN_PRODUCT_DESC;
	echo '              </div>
              <div>
              ';
	$dparam['name'] = 'description';
	$dparam['rows'] = 15;
	$dparam['cols'] = 40;
	$dparam['width'] = 570;
	$dparam['height'] = 200;
	$dparam['values'] = $product;
	$dparam['dbfield'] = 'description';
	smarty_function_html_textarea( $dparam, $smarty );
	echo '              
              </div>
            </li>
            <li>
              <div style="width:10%;float:right;">
              ';
	echo ADMIN_PRODUCT_BRIEF_DESC;
	echo '<br>(HTML):
              </div>
              <div>
              ';
	$dparam['name'] = 'brief_description';
	$dparam['rows'] = 15;
	$dparam['cols'] = 40;
	$dparam['width'] = 570;
	$dparam['height'] = 200;
	$dparam['values'] = $product;
	$dparam['dbfield'] = 'brief_description';
	smarty_function_html_textarea( $dparam, $smarty );
	echo '              
              </div>          
            </li>
            </ul>
          </div>                    
          <div id="content_3" class="content" style="';
	echo $style_3;
	echo '">
    <ul>
    <li>
            <center>
            		<table border=0 cellpadding=1 cellspacing=1 style="width:90%;">
            
            			<tr>
            				<td colspan=6 align=center>
            				<b>';
	echo ADMIN_PHOTOS;
	echo '</b>
            				</td>
            			</tr>
            
            			<tr bgcolor=#FEF0FF>
            			  <td></td>
            				<td>';
	echo ADMIN_DEFAULT_PHOTO;
	echo '</td>
            				<td>';
	echo ADMIN_PRODUCT_PICTURE;
	echo '</td>
            				<td>';
	echo ADMIN_PRODUCT_THUMBNAIL;
	echo '</td>
            				<td>';
	echo ADMIN_PRODUCT_BIGPICTURE;
	echo '</td>
            				<td width=1%>';
	echo ADMIN_CLEAR;
	echo '</td>
            			</tr>
            
            			';
	foreach ($picturies as $picture) {
		echo '<tr bgcolor=#FFFFE2>';
		echo '<td><img src="thumbnail.php?type=admin&imageurl=' . $picture['filename'] . '"></td>';

		if ($picture['default_picture'] == 1) {
			$default_picture_exists = true;
			echo '<td><input type=radio name=default_picture value=\'' . $picture['photoID'] . '\' checked></input></td>';
		} 
else {
			echo '<td><input type=radio name=default_picture value=\'' . $picture['photoID'] . '\'></input></td>';
		}

		echo '<td>';
		echo '		<input type=text name=filename_' . $picture['photoID'] . ' value=\'' . $picture['filename'] . '\'><br>';

		if (( file_exists( './uploads/products_pictures/' . $picture['filename'] ) && trim( $picture['filename'] ) != '' )) {
			echo '		<a class=small href=\'javascript:void(open_window("' . BASE_URL . 'uploads/products_pictures/' . $picture['filename'] . '",' . GetPictureSize( $picture['filename'] ) . '))\'>' . ADMIN_PHOTO_PREVIEW . '</a>';
		} 
else {
			echo ADMIN_PICTURE_NOT_UPLOADED;
		}

		echo '</td>';
		echo '<td>';
		echo '		<input type=text name=thumbnail_' . $picture['photoID'] . ' value=\'' . $picture['thumbnail'] . '\'><br>';

		if (( file_exists( './uploads/products_pictures/' . $picture['thumbnail'] ) && trim( $picture['thumbnail'] ) != '' )) {
			echo '		<a class=small href=\'javascript:void(open_window("' . BASE_URL . 'uploads/products_pictures/' . $picture['thumbnail'] . '",' . GetPictureSize( $picture['thumbnail'] ) . '))\'>' . ADMIN_PHOTO_PREVIEW . '</a>';
			echo '		<a class=small href="javascript:confDelete(\'' . QUESTION_DELETE_PICTURE . '\', \'admincp.php?page=products&delete_one_picture=1&thumbnail=' . $picture['photoID'] . '&productID=' . $_GET['productID'] . '\')">' . DELETE_BUTTON . '</a>';
		} 
else {
			echo ADMIN_PICTURE_NOT_UPLOADED;
		}

		echo '</td>';
		echo '<td>';
		echo '		<input type=text name=enlarged_' . $picture['photoID'] . ' value=\'' . $picture['enlarged'] . '\'><br>';

		if (( file_exists( './uploads/products_pictures/' . $picture['enlarged'] ) && trim( $picture['enlarged'] ) != '' )) {
			echo '		<a class=small href=\'javascript:void(open_window("' . BASE_URL . 'uploads/products_pictures/' . $picture['enlarged'] . '",' . GetPictureSize( $picture['enlarged'] ) . '))\'>' . ADMIN_PHOTO_PREVIEW . '</a>';
			echo '		<a class=small href="javascript:confDelete(\'' . QUESTION_DELETE_PICTURE . '\', \'admincp.php?page=products&delete_one_picture=1&enlarged=' . $picture['photoID'] . '&productID=' . $_GET['productID'] . '\')">' . DELETE_BUTTON . '</a>';
		} 
else {
			echo ADMIN_PICTURE_NOT_UPLOADED;
		}

		echo '</td>';
		echo '<td>';
		echo '		
            						<a href="javascript:confDelete(\'';
		echo QUESTION_DELETE_PICTURE;
		echo '\',\'admincp.php?page=products&productID=';
		echo $_GET['productID'];
		echo '&photoID=';
		echo $picture['photoID'];
		echo '&delete_pictures=1\');">
            							<img src="images/remove.png" border=0 alt="';
		echo DELETE_BUTTON;
		echo '">
            						</a>
            					';
		echo '</td>';
		echo '</tr>';
	}

	echo '            			
                              
            			<tr>
            				<td colspan=7 align=center>
            					';
	echo ADD_BUTTON;
	echo ':
            				</td>
            			</tr>
            
            			<tr bgcolor=#FFFFE2>
            			   <td></td>
            				<td width=1%>
            					<input type=radio name=default_picture
            					';

	if (!empty( $$default_picture_exists )) {
		echo '            						checked
            					';
	}

	echo '            						value=-1
            						>
            					</input>
            				</td>
            				';

	if (CONF_CHANGE_IMAGESIZE == 1) {
		echo '<td colspan="4">';
	} 
else {
		echo '<td>';
	}

	echo '            				
            				<input type="file" name="new_filename" style="width:190px;" >
                    </td>
            				';

	if (CONF_CHANGE_IMAGESIZE == 0) {
		echo '            				                
            				<td><input type="file" name="new_thumbnail" style="width:190px;"></td>
            				<td><input type="file" name="new_enlarged" style="width:190px;"></td>
                    <td bgcolor="#FFFFFF"></td>            				
            				';
	}

	echo '                                				
            				
            			</tr>
            
            		</table>
       <br>                   
            		<center>
            			<input type=submit name="save_pictures" value="';
	echo ADMIN_SAVE_PHOTOS;
	echo '">
            		</center>
      <br>    
            		
</center>
</li>
</ul>
';
	echo '          </div>    

          
          <div id="content_5" class="content" style="display: none; ">        	             
            <ul>            	                             
             <li>
              <div style="float:right;width:20%">
              </div>
              <div>
              </div>
              <table id=\'ConfiguratorTable\'>
	<tr><td>


	<script language=\'JavaScript\'>
			function SetOptionValueTypeRadioButton( id, radioButtonState )
			{
				if ( radioButtonState == "UN_DEFINED" )
					document.all["option_radio_type_"+id][0].click();
				else if ( radioButtonState == "ANY_VALUE" )
					document.all["option_radio_type_"+id][1].click();
				else if ( radioButtonState == "N_VALUES" )
					document.all["option_radio_type_"+id][2].click();
			}

			function SetEnabledStateTextValueField( id, radioButtonState )
			{
				if ( radioButtonState == "UN_DEFINED" || 
					radioButtonState == "N_VALUES" )
				{
					document.all["option_value_"+id].disabled=true;
					document.all["option_value_"+id].value="";
				}
				else
					document.all["option_value_"+id].disabled=false;
			}
	</script>	
		';
	$ij = 2763;

	if (3 < count( $options )) {
		$perrow = count( $options ) / 3;
	} 
else {
		$perrow = 2766;
	}

	foreach ($options as $option) {
		$option_row = $option['option_row'];
		$value_row = $option['option_value'];
		$ValueCount = $option['value_count'];

		if (( 0 < $perrow && 0 < $ij )) {
			if ($ij % $perrow == 0) {
				echo '</td><td>';
			}
		}

		$ij = $ij + 1;
		echo '		<table border=\'0\' cellspacing=\'0\' cellpadding=\'4\' width=100%>
			<tr> 
				<td align=left width=25%>
					<b>';
		echo $option_row['name'];
		echo '</b>:
				</td>
				<td>
					<input name=\'option_radio_type_';
		echo $option_row['optionID'];
		echo '\' 
						type=\'radio\' value="UN_DEFINED" 
						onclick="JavaScript:SetEnabledStateTextValueField(';
		echo $option_row['optionID'];
		echo ', \'UN_DEFINED\' );"
						';

		if (( ( is_null( $value_row['option_value'] ) || $value_row['option_value'] == '' ) && $value_row['option_type'] == 0 )) {
			echo 'checked';
		}

		echo '					>
				</td>
				<td>
					';
		echo ADMIN_NOT_DEFINED;
		echo '				</td>
			</tr>
			<tr> 
				<td>&nbsp;</td>
				<td valign=\'top\'> 
					<input name=\'option_radio_type_';
		echo $option_row['optionID'];
		echo '\'  
						type=\'radio\' value="ANY_VALUE"
						onclick="JavaScript:SetEnabledStateTextValueField(';
		echo $option_row['optionID'];
		echo ', \'ANY_VALUE\' );"
						';

		if (( $value_row['option_type'] == 0 && 0 < strlen( $value_row['option_value'] ) )) {
			echo 'checked';
		}

		echo '					> 
				</td>
				<td>
					';
		echo ADMIN_ANY_VALUE . ':';
		$param['name'] = 'option_value_%lang%_' . $option_row['optionID'];
		$param['style'] = 'width:100px;';
		$param['values'] = $value_row;
		$param['dbfield'] = 'option_value';
		$param['table'] = PRODUCT_OPTIONS_TABLE;
		echo smarty_function_html_text( $param, $smarty );
		echo '           					
				</td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td valign=\'top\'>
					<input name=\'option_radio_type_';
		echo $option_row['optionID'];
		echo '\' 
						type=\'radio\' value="N_VALUES"
						onclick="JavaScript:SetEnabledStateTextValueField(';
		echo $option_row['optionID'];
		echo ', \'N_VALUES\' );"
						';

		if ($value_row['option_type'] == 1) {
			echo 'checked';
		}

		echo '					>
				</td>
				<td>
					<table cellpadding=\'0\' id=\'OptionTable_';
		echo $option_row['optionID'];
		echo '\'>
						<tr>
							<td>
								';
		echo ADMIN_SELECTING_FROM_VALUES;
		echo ' (';
		echo $ValueCount;
		echo ' ';
		echo ADMIN_VARIANTS;
		echo ')
							</td>
						</tr>
						<tr>
							<td>
								<a name="option_value_configurator_';
		echo $option_row['optionID'];
		echo '" 
									';

		if ($_GET['productID'] != 0) {
			echo '											href="JavaScript:void(open_window(\'admincp.php?page=option_value_configurator&optionID=';
			echo $option_row['optionID'];
			echo '&productID=';
			echo $_GET['productID'];
			echo '\',400,400));"
									';
		} 
else {
			echo '											href="JavaScript:AddProductAndOpen_option_value_configurator(';
			echo $option_row['optionID'];
			echo ')"
									';
		}

		echo '										
									>
									';
		echo ADMIN_SELECT_SETTING;
		echo '...
								</a>

							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td colspan=3>
					<hr width="100%" color=black></hr>
				</td>
			</tr>
		</table>

				';
	}

	echo '    

		</td></tr>
		</table>
              </li> 
            </ul>
          </div>
          <div id="content_6" class="content" style="display: none; ">        	             
                <ul>            	                             
                 <li>
                  <div style="float:right;width:20%">
                  ';
	echo ADMIN_SHIPPING_FREIGHT;
	echo '                  </div>
                  <div>
    		          <input type="text" name="shipping_freight" value=';
	echo $product['shipping_freight'];
	echo '>
    	            </div>
    	            </li>
    	            <li>
                  <div style="float:right;width:20%">
    	               ';
	echo ADMIN_PRODUCT_WEIGHT;
	echo '    	            </div>
    	            <div>
    	               <input type=text name=\'weight\' value=\'';
	echo $product['weight'];
	echo '\'> ';
	echo CONF_WEIGHT_UNIT;
	echo '                  </div>
                  </li>
                  <li>
                  <div style="float:right;width:20%">
                  ';
	echo ADMIN_FREE_SHIPPING;
	echo '                  </div>
                  <div>
                  <input type=checkbox name=\'free_shipping\' ';

	if ($product['free_shipping']) {
		echo 'checked';
	}

	echo ' value=\'1\'>
                  </div>
                  </li>
                  <li>
                  <div style="float:right;width:20%">
                  ';
	echo ADMIN_MIN_ORDER_AMOUNT;
	echo '                  </div>
                  <div>
                  <input type=text name=\'min_order_amount\' 
    			value=\'';
	echo $product['min_order_amount'];
	echo '\'>
                  </div>
                  </li>
                  <li>
                  <div style="float:right;width:20%">              
    		            ';
	echo DIRECT_COD_LINK;
	echo '    		          </div>
    		          <div>
    		            <input name="cod_link" value="';
	echo $product['cod_link'];
	echo '">
    		          </div>
    	             </li>  
                                 <li>
                  <div style="float:right;width:20%">
                  		';
	echo ADMIN_META_DESCRIPTION;
	echo '            
                  </div>
                  <div>
                  <textarea name=\'meta_description\' 
    				rows=4 cols=15 style="width: 400px; height: 75px">';
	echo $product['meta_description'];
	echo '</textarea>
                  </div>
              </li>
              <li>
                  <div style="float:right;width:20%">
                  		';
	echo ADMIN_META_KEYWORDS;
	echo '                  </div>
                  <div>
                    		<textarea name=\'meta_keywords\' 
				rows=4 cols=15 style="width: 400px; height: 75px">';
	echo $product['meta_keywords'];
	echo '</textarea>
                  </div>              
              </li>              
                </ul>
          </div>                  
           <div id="content_7" class="content" style="display: none; ">
            <ul>
            <li>
            <table border=0 cellpadding=5 cellspacing=1 bgcolor=\'\' id=\'AppendedParentsTable\'>
          			<tr>
          				<td colspan=2 align=center>
          					<b>';
	echo ADMIN_CATEGORY_APPENDED_PARENTS;
	echo ':</b>
          				</td>
          			</tr>
          			<tr bgcolor=#FEF0FF>
          				<td align=center>';
	echo ADMIN_CATEGORY_TITLE;
	echo '</td>
          				<td width=1%>';
	echo ADMIN_CLEAR;
	echo '</td>
          			</tr>
          
          			';
	foreach ($appended_categories as $app_cat) {
		echo '          			<tr bgcolor=#FFFFE2>
          				<td align=center>
          					';
		echo $app_cat['category_name'];
		echo '          				</td>
          				<td width=1%>
          					<a href="javascript:confDelete(\'';
		echo QUESTION_DELETE_CONFIRMATION;
		echo '\',\'admincp.php?page=products&productID=';
		echo $_GET['productID'];
		echo '&remove_from_app_cat=';
		echo $app_cat['categoryID'];
		echo '\');">
          						<img src="images/remove.png" border=0 alt="';
		echo DELETE_BUTTON;
		echo '">
          					</a>
          				</td>
          			</tr>
          			';
	}

	echo '          
          			<tr>
          				<td align=center colspan=2>
          					';
	echo ADD_BUTTON;
	echo ':
          				</td>
          			</tr>
          
          			<tr bgcolor=white>
          				<td align=center>
          					<select name=\'new_appended_category\' ';

	if (CONF_FULLY_EXPAND_CATEGORIES_IN_ADMIN_MODE == 0) {
		echo 'onChange="window.location=\'products.php?productID=' . $_GET['productID'] . '&change_app_category=\'+document.MainForm.new_appended_category.value;"';
	}

	echo '>
          					';
	$change_app_category = (isset( $_GET['change_app_category'] ) ? (int)$_GET['change_app_category'] : $product['categoryID']);

	if (CONF_FULLY_EXPAND_CATEGORIES_IN_ADMIN_MODE == 0) {
		$cats = catGetCategoryCompactCList( $change_app_category );
	} 
else {
		$cats = catGetCategoryCList(  );
	}

	$i = 2763;

	while ($i < count( $cats )) {
		if (1 < $cats[$i]['categoryID']) {
			echo '<option value="' . $cats[$i]['categoryID'] . '"';

			if ($change_app_category == $cats[$i]['categoryID']) {
				echo ' selected';
			}

			echo '>';
			$j = 2763;

			while ($j < $cats[$i]['level']) {
				echo '&nbsp;&nbsp;';
				++$j;
			}

			echo $cats[$i]['name'];
			echo '</option>';
		}

		++$i;
	}

	echo '          					</select>
          				</td>
          				<td width=1%>&nbsp;</td>
          			</tr>
          			<tr>
          				<td colspan=2 align=center>
          					<input type=submit value=\'';
	echo ADD_BUTTON;
	echo '\' name=\'add_category\'>
          				</td>
          			</tr>
          		</table>
            </li>
            </ul>          
          </div>
          ';

	if ($_GET['productID']) {
		echo '          <div id="content_8" class="content" style="display: none; ">
            <iframe name="RELATED_C" src="admincp.php?page=wishlist&owner=';
		echo $_GET['productID'];
		echo '" scrolling="auto" style="width:100%;height:400px;border:0px;"></iframe>        	                         
          </div>
          ';
	}

	echo '      </div>             
        

<p style="float:left;padding-left:20px;">
<input type="submit" name="save_product" value="';
	echo SAVE_BUTTON;
	echo '" width=5>
';

	if ($_GET['productID']) {
		echo '<input type=button value="' . DELETE_BUTTON . '" onClick="confirmDelete(1,' . '\'' . QUESTION_DELETE_CONFIRMATION . '\',\'admincp.php?w=-1&page=products&productID=' . $_GET['productID'] . '&delete=1\');' . '">';
	}


	if (isset( $_POST['save_product'] )) {
		echo '<center style=\'color:red\'> ' . MOD_NEWS_TXT_EDIT_OK . ' </center>';
	}

	echo '</p>

<input type=hidden name=\'save_product_without_closing\' value=\'0\'>

</form>


</center>
</body>

</html>';
?>