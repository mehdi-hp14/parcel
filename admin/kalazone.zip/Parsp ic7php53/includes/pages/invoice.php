<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (( CONF_BACKEND_SAFEMODE != 1 && ( !isset( $_SESSION['log'] ) || !isset( $_GET['orderID'] ) ) )) {
		$error = ERROR_FORBIDDEN;
	} 
else {
		$orderID = (int)$_GET['orderID'];
		$order = ordGetOrder( $orderID );
		$order['discount_value'] = round( (double)$order['order_discount'] * $order['clear_total_priceToShow'] ) / 100;

		if (!$order) {
			$error = ERROR_CANT_FIND_REQUIRED_PAGE;
		} 
else {
			$needauth = 'new_orders';
			regGetCustomerInfo2( $_SESSION['log'] );
			$custinfo = ;
			$custgroup = GetGroupById( $custinfo['custgroupID'] );
			$orderContent = ordGetOrderContent( $orderID );
			$orderlogin = regGetLoginById( $order['customerID'] );

			if (( $_SESSION['log'] != $orderlogin && ( $custgroup['action_list'] != '' && !is_numeric( stripos( $custgroup['action_list'], $needauth ) ) ) )) {
				$error = ERROR_FORBIDDEN;
			} 
else {
				$smarty->assign( 'orderContent', $orderContent );
				$smarty->assign( 'order', $order );
			}
		}
	}

	$smarty->assign( 'error', $error );
	$smarty->display( 'invoice.tpl.html' );
?>