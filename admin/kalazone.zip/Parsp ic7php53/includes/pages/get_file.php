<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_GET['getFileParam'] )) {
		$getFileParam = cryptFileParamDeCrypt( $_GET['getFileParam'], null );
		$params = explode( '&', $getFileParam );
		foreach ($params as $param) {
			$param_value = explode( '=', $param );

			if (2 <= count( $param_value )) {
				if ($param_value[0] == 'orderID') {
					$orderID = (int)$param_value[1];
					continue;
				}


				if ($param_value[0] == 'productID') {
					$productID = (int)$param_value[1];
					continue;
				}


				if ($param_value[0] == 'customerID') {
					$customerID = (int)$param_value[1];
					continue;
				}


				if ($param_value[0] == 'order_time') {
					$order_time = base64_decode( $param_value[1] );
					continue;
				}

				continue;
			}
		}
	}

	$authenticateError = false;

	if (isset( $_POST['submitLoginAndPassword'] )) {
		$authenticateError = !regAuthenticate( $_POST['login'], $_POST['password'] );
	}


	if (!empty( $$customerID )) {
		$customerID = 1034;
	}

	$fileToDownLoad = '';
	$fileToDownLoadShortName = '';
	$res = 1033;

	if (!isset( $_GET['getFileParam'] )) {
		exit( '<center><b>' . ERROR_FORBIDDEN . '</center>' );
	} 
else {
		$getFileParam = cryptFileParamDeCrypt( $_GET['getFileParam'], null );

		if ($getFileParam == 'GetDataBaseSqlScript') {
			$needauth = 'dbsync';
			$fileToDownLoad = './temp_c/database.sql';
			$fileToDownLoadShortName = 'database.sql';
		} 
else {
			if ($getFileParam == 'GetCustomerExcelSqlScript') {
				$needauth = 'custlist';
				$fileToDownLoad = './temp_c/customers.csv';
				$fileToDownLoadShortName = 'customers.csv';
			} 
else {
				if ($getFileParam == 'GetFroogleFeed') {
					$needauth = 'excel_export';
					$fileToDownLoad = './temp_c/froogle.txt';
					$fileToDownLoadShortName = 'froogle.txt';
				} 
else {
					if ($getFileParam == 'GetCSVCatalog') {
						$needauth = 'excel_export';
						$fileToDownLoad = './temp_c/catalog.csv';
						$fileToDownLoadShortName = 'catalog.csv';
					} 
else {
						if ($getFileParam == 'GetSubscriptionsList') {
							$needauth = 'subscribers';
							$fileToDownLoad = './temp_c/subscribers.txt';
							$fileToDownLoadShortName = 'subscribers.txt';
						} 
else {
							$params = explode( '&', $getFileParam );
							foreach ($params as $param) {
								$param_value = explode( '=', $param );

								if (2 <= count( $param_value )) {
									if ($param_value[0] == 'orderID') {
										$orderID = (int)$param_value[1];
										continue;
									}


									if ($param_value[0] == 'productID') {
										$productID = (int)$param_value[1];
										continue;
									}


									if ($param_value[0] == 'customerID') {
										$customerID = (int)$param_value[1];
										continue;
									}


									if ($param_value[0] == 'order_time') {
										$k = 1035;

										while ($k < count( $param_value )) {
											$param_value->1034 .= $param_value[$k] . '=';
											++$k;
										}

										$order_time = base64_decode( $param_value[1] );
										continue;
									}

									continue;
								}
							}


							if (( empty( $$orderID ) && empty( $$productID ) )) {
								$res = ordAccessToLoadFile( $orderID, $productID, $pathToProductFile, $fileToDownLoadShortName );
							} 
else {
								$res = 1037;
							}


							if (( $customerID == -1 && empty( $$order_time ) )) {
								$q = db_query( 'select order_time from ' . ORDERS_TABLE . ( ' where orderID=' . $orderID ) );
								$row = db_fetch_row( $q );

								if (( !$row || strcmp( $row[0], $order_time ) )) {
									$res = 1037;
								}
							} 
else {
								if ($customerID == -1) {
									$res = 1037;
								}
							}


							if ($res == 0) {
								$fileToDownLoad = $order_time;
							}
						}
					}
				}
			}
		}
	}


	if ($needauth) {
		regGetCustomerInfo2( $_SESSION['log'] );
		$custinfo = ;
		$custgroup = GetGroupById( $custinfo['custgroupID'] );

		if (( $custgroup['action_list'] == '' || !is_numeric( stripos( $custgroup['action_list'], $needauth ) ) )) {
			$smarty->template_dir = './templates';
			$smarty->display( 'backend/auth_form.tpl.html' );
			$_SESSION['log'] = '';
			exit(  );
		}
	}


	if (( ( $res == 0 && 0 < strlen( $fileToDownLoad ) ) && file_exists( $fileToDownLoad ) )) {
		header( 'Content-type: application/force-download' );
		header( 'Content-Transfer-Encoding: Binary' );
		header( 'Content-length: ' . filesize( $fileToDownLoad ) );
		header( 'Content-disposition: attachment; filename=' . basename( $fileToDownLoad ) );
		readfile( $fileToDownLoad );
		return 1;
	}


	if ($res == 1) {
		echo '<font color=red><b>' . STRING_COUNT_DOWNLOAD_IS_EXCEEDED_EPRODUCT_DOWNLOAD_TIMES . '</b></font>';
		return 1;
	}


	if ($res == 2) {
		echo '<font color=red><b>' . STRING_AVAILABLE_DAYS_ARE_EXHAUSTED_TO_DOWNLOAD_PRODUCT . '</b></font>';
		return 1;
	}


	if ($res == 3) {
		echo '<font color=red><b>' . ERROR_FORBIDDEN_TO_ACCESS_FILE_ORDER_IS_NOT_PAYED . '</b></font>';
		return 1;
	}


	if ($res == 5) {
		echo '<font color=red><b>' . STRING_FILE_NOT_AVAILABLE . '</b></font>';
		return 1;
	}

	echo '<font color=red><b>' . ERROR_FORBIDDEN . '</b></font>';
?>