<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!( $q = db_query( 'select * from ' . CURRENCY_TYPES_TABLE . ' order by sort_order' ))) {
		exit( db_error(  ) );
		(bool)true;
	}

	$currencies = array(  );

	while ($row = db_fetch_row( $q )) {
		LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
		$currencies[] = $row;
	}

	$smarty->assign( 'currencies', $currencies );
	$smarty->assign( 'currencies_count', count( $currencies ) );

	if (isset( $_SESSION['log'] )) {
		$smarty->assign( 'log', $_SESSION['log'] );
	}

	$printable_version = true;
	$smarty->assign( 'printable_version', 1 );

	if (isset( $_GET['productID'] )) {
		$productID = (int)$_GET['productID'];
		unset( $$categoryID );
		include( './includes/product_detailed.php' );
	} 
else {
		if (isset( $_GET['show_price'] )) {
			include( './includes/pricelist.php' );
		} 
else {
			if (isset( $_GET['page_id'] )) {
				$view_content = $_GET['page_id'];
				include( './includes/view_content.php' );
			}
		}
	}

	include( './includes/head.php' );
	$smarty->display( 'printable_version.tpl.html' );
?>