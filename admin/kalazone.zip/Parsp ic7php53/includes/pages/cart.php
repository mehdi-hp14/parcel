<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function _check_and_apply_coupon($coupon_code) {
		ClassManager::includeClass( 'discount_coupon' );
		$coupon_id = discount_coupon::check( $coupon_code );

		if ($coupon_id !== null) {
			discount_coupon::apply( $coupon_id );
		}

		return $coupon_id;
	}

	include( './classes/class.JsHttpRequest.php' );
	$JsHttpRequest = new JsHttpRequest( 'utf-8' );
	$current_currency = (isset( $_SESSION['current_currency'] ) ? $_SESSION['current_currency'] : CONF_DEFAULT_CURRENCY);
	switch ($_REQUEST['action']) {
		case 'try_apply_discount_coupon': {
			$coupon_code = $_REQUEST['coupon_code'];
			$coupon_id = _check_and_apply_coupon( $coupon_code );
			$resCart = cartGetCartContent(  );
			$resDiscount = dscGetCartDiscounts( $resCart['total_price'], (isset( $_SESSION['log'] ) ? $_SESSION['log'] : '') );
			$coupon_discount_show = (0 < $resDiscount['discount_percent'] ? $resDiscount['discount_percent'] : '');
			$GLOBALS['_RESULT'] = array( 'applied' => ($coupon_id != null ? 'Y' : 'N'), 'new_coupon_show' => fa_get_persian_number( $coupon_discount_show ) . '%', 'new_total_show_value' => show_price( $resDiscount['rest_standart_unit'] ) );
			exit(  );
			break;
		}

		case 'remove_doscount_coupon': {
			ClassManager::includeClass( 'discount_coupon' );
			discount_coupon::remove(  );
			$resCart = cartGetCartContent(  );
			$resDiscount = dscGetCartDiscounts( $resCart['total_price'], (isset( $_SESSION['log'] ) ? $_SESSION['log'] : '') );
			$GLOBALS['_RESULT'] = array( 'new_total_show_value' => show_price( $resDiscount['rest_standart_unit'] ) );
			exit(  );
			break;
		}
	}

	break;
	$smarty->assign( 'current_currency', $current_currency );

	if (!( $q = db_query( 'select ' . LanguagesManager::sql_prepareField( 'code' ) . ' as code, ' . CURRENCY_TYPES_TABLE . '.* from ' . CURRENCY_TYPES_TABLE . ( ' where CID=\'' . $current_currency . '\'' ) ))) {
		exit( db_error(  ) );
		(bool)true;
	}


	if ($row = db_fetch_row( $q )) {
		$smarty->assign( 'currency_name', $row[0] );
		$selected_currency_details = $coupon_discount_show;
	} 
else {

		if (!( $q = db_query( 'select ' . LanguagesManager::sql_prepareField( 'code' ) . ' as code, currency_value, where2show from ' . CURRENCY_TYPES_TABLE ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			$smarty->assign( 'currency_name', $row['code'] );
			$selected_currency_details = $coupon_discount_show;
		}
	}

	$smarty->template_dir = './templates/frontend/' . $templateDirectory;
	$smarty_mail->template_dir = './templates/email';

	if (isset( $_SESSION['log'] )) {
		$smarty->assign( 'log', $_SESSION['log'] );
	}


	if (isset( $_GET['addproduct'] )) {
		$variants = array(  );
		foreach ($_GET as $key => $val) {

			if (strstr( $key, 'option_select_hidden_' )) {
				$variants[] = $val;
				continue;
			}
		}

		unset( $_SESSION[variants] );
		$_SESSION['variants'] = $variants;
		$location = 'index.php?page=cart&shopping_cart=yes&add2cart=' . (int)$_GET['addproduct'];
		$code = 1230;
		$_GET['shopping_cart'] = 'yes';
		header( 'Location: ' . $location, true, $code );
		exit(  );
	}

	$this_is_a_popup_cart_window = true;
	$smarty->assign( 'this_is_a_popup_cart_window', 1 );
	include( './includes/shopping_cart.php' );
?>