<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (empty( $$order3_billing )) {
		if (!cartCheckMinTotalOrderAmount(  )) {
			Redirect( 'index.php?shopping_cart&min_order=error' );
		}


		if (!isset( $_GET['isaccount'] )) {
			if (( ( ( !isset( $_GET['order3_billing'] ) || !isset( $_GET['shippingAddressID'] ) ) || !isset( $_GET['shippingMethodID'] ) ) || !isset( $_GET['billingAddressID'] ) )) {
				Redirect( 'index.php?page_not_found' );
			}

			$_GET['shippingAddressID'] = (int)$_GET['shippingAddressID'];
			$_GET['billingAddressID'] = (int)$_GET['billingAddressID'];
			$_GET['shippingMethodID'] = (int)$_GET['shippingMethodID'];

			if (( $_GET['shippingAddressID'] != 0 && !regAddressBelongToCustomer( regGetIdByLogin( $_SESSION['log'] ), $_GET['shippingAddressID'] ) )) {
				Redirect( 'index.php?page_not_found' );
			}


			if (( $_GET['billingAddressID'] != 0 && !regAddressBelongToCustomer( regGetIdByLogin( $_SESSION['log'] ), $_GET['billingAddressID'] ) )) {
				Redirect( 'index.php?page_not_found' );
			}


			if ($_GET['shippingMethodID'] != 0) {
				if (!shShippingMethodIsExist( $_GET['shippingMethodID'] )) {
					Redirect( 'index.php?page_not_found' );
				}
			}
		}


		if (!cartCheckMinOrderAmount(  )) {
			Redirect( 'index.php?shopping_cart' );
		}


		if (isset( $_POST['continue_button'] )) {
			RedirectProtected( 'index.php?order4_confirmation&' . 'shippingAddressID=' . $_GET['shippingAddressID'] . '&' . 'shippingMethodID=' . $_GET['shippingMethodID'] . '&' . 'billingAddressID=' . $_GET['billingAddressID'] . '&' . 'paymentMethodID=' . $_POST['select_payment_method'] . (isset( $_GET['shServiceID'] ) ? '&shServiceID=' . $_GET['shServiceID'] : '') . (isset( $_GET['isaccount'] ) ? '&isaccount=1' : '') );
		}


		if (isset( $_GET['selectedNewAddressID'] )) {
			RedirectProtected( 'index.php?order3_billing&' . 'shippingAddressID=' . $_GET['shippingAddressID'] . '&' . 'shippingMethodID=' . $_GET['shippingMethodID'] . '&' . 'billingAddressID=' . $_GET['selectedNewAddressID'] . '&' . 'shServiceID=' . $_GET['shServiceID'] . (isset( $_GET['isaccount'] ) ? '&isaccount=1' : '') );
		}

		$moduleFiles = GetFilesInDirectory( './includes/modules/payment', 'php' );
		foreach ($moduleFiles as $fileName) {
			include( $fileName );
		}

		$payment_methods = payGetAllPaymentMethods( true );
		$payment_methodsToShow = array(  );
		foreach ($payment_methods as $payment_method) {

			if ($_GET['shippingMethodID'] == 0) {
				$shippingMethodsToAllow = true;
			} 
else {
				$shippingMethodsToAllow = false;
				foreach ($payment_method['ShippingMethodsToAllow'] as $ShippingMethod) {

					if (( (int)$_GET['shippingMethodID'] == (int)$ShippingMethod['SID'] && $ShippingMethod['allow'] )) {
						$shippingMethodsToAllow = true;
						break;
						continue;
					}
				}
			}


			if ($shippingMethodsToAllow) {
				$payment_methodsToShow[] = $payment_method;
				continue;
			}
		}


		if (count( $payment_methodsToShow ) == 0) {
			RedirectProtected( 'index.php?order4_confirmation&' . 'shippingAddressID=' . $_GET['shippingAddressID'] . '&' . 'shippingMethodID=' . $_GET['shippingMethodID'] . '&' . 'billingAddressID=' . regGetDefaultAddressIDByLogin( $_SESSION['log'] ) . '&' . 'paymentMethodID=0' . (isset( $_GET['isaccount'] ) ? '&isaccount=1' : '') );
		}

		$smarty->assign( 'shippingAddressID', $_GET['shippingAddressID'] );
		$smarty->assign( 'billingAddressID', $_GET['billingAddressID'] );
		$smarty->assign( 'shippingMethodID', $_GET['shippingMethodID'] );
		$smarty->assign( 'strAddress', regGetAddressStr( $_GET['billingAddressID'] ) );
		$smarty->assign( 'payment_methods', $payment_methodsToShow );
		$smarty->assign( 'main_content_template', 'order3_billing.tpl.html' );
	}

?>