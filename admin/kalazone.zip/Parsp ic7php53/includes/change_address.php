<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (empty( $$change_address )) {
		$_POST = xStripSlashesGPC( $_POST );
		function _copyDataFromPostToPage($smarty) {
			$smarty->assign( 'receiver_first_name', $_POST['receiver_first_name'] );
			$smarty->assign( 'receiver_last_name', $_POST['receiver_last_name'] );
			$smarty->assign( 'zip', $_POST['zip'] );
			$smarty->assign( 'city', $_POST['city'] );
			$smarty->assign( 'address', $_POST['address'] );

			if (!isset( $_POST['countryID'] )) {
				$_POST['countryID'] = 'IR';
			}

			$smarty->assign( 'countryID', $_POST['countryID'] );

			if (( isset( $_POST['state'] ) && !isset( $_POST['zoneID'] ) )) {
				$smarty->assign( 'state', $_POST['state'] );
			} 
else {
				$smarty->assign( 'zoneID', $_POST['zoneID'] );
			}

			$country_iso_2 = cnGetCountryById( $_POST['countryID'] );
			$country_iso_2 = $country_iso_2['country_iso_2'];
			$zones = znGetZonesById( $country_iso_2 );
			$smarty->assign( 'zones', $zones );
			$cities = ctGetCitysById( $country_iso_2, $_POST['zoneID'] );
			$smarty->assign( 'cities', $cities );

			if (isset( $_POST['address_radiobutton'] )) {
				$smarty->assign( 'addressID', $_POST['address_radiobutton'] );
			}

		}

		function _getAllAddresses() {
			$addresses = regGetAllAddressesByLogin( $_SESSION['log'] );
			$res = array(  );
			foreach ($addresses as $address) {
				$strAddress = regGetAddressStr( $address['addressID'] );
				$res[] = array( 'strAddress' => $strAddress, 'addressID' => $address['addressID'] );
			}

			return $res;
		}

		$returnParamStr = '';
		$orderStage = '';
		$addressID = 978;
		foreach ($_GET as $key => $value) {

			if ($key == 'change_address') {
				continue;
			}


			if (( $key == 'shippingAddressID' && $addressID == 0 )) {
				$orderStage = 'order2_shipping';
				$addressID = $zones;
			}


			if ($key == 'billingAddressID') {
				$orderStage = 'order3_billing';
				$addressID = $zones;
			}


			if ($returnParamStr != '') {
				$returnParamStr .= '&';
			}

			$returnParamStr .= $key . '=' . $value;
		}

		$countryID = $_POST['countryID'];
		$state = $_POST['state'];
		$zip = $_POST['zip'];
		$city = $_POST['city'];
		$cityID = $_POST['cityID'];
		$address = $_POST['address'];

		if (isset( $_POST['zoneID'] )) {
			$zoneID = $_POST['zoneID'];
		} 
else {
			$zoneID = 978;
		}


		if (isset( $_POST['select_address'] )) {
			if (!isset( $_POST['zoneID'] )) {
				$_POST['zoneID'] = 0;
			}


			if (!isset( $_POST['state'] )) {
				$_POST['state'] = '';
			}
		} 
else {
			$zones = znGetZonesById( CONF_DEFAULT_COUNTRY );
			$smarty->assign( 'zones', $zones );
		}


		if (isset( $_POST['select_address'] )) {
			if ($_POST['address_radiobutton'] == 0) {
				$error_message = regVerifyAddress( $_POST['receiver_first_name'], $_POST['receiver_last_name'], $_POST['countryID'], $_POST['zoneID'], $_POST['state'], $_POST['zip'], $_POST['city'], $_POST['cityID'], $_POST['address'], $_POST['phone'], $_POST['mobile'] );

				if ($error_message != '') {
					$smarty->assign( 'error_message', $error_message );
				} 
else {
					$errorCode = '';
					$country_detail = cnGetCountryById( $countryID );
					$country_iso_2 = $country_detail['country_iso_2'];
					$_POST['address_radiobutton'] = regAddAddress( $_POST['receiver_first_name'], $_POST['receiver_last_name'], $_POST['countryID'], $_POST['zoneID'], $_POST['state'], $_POST['zip'], $_POST['city'], $_POST['cityID'], $_POST['address'], $_SESSION['log'], $errorCode, $country_iso_2, $_POST['phone'], $_POST['mobile'] );
				}
			}


			if ($_POST['address_radiobutton'] != 0) {
				Redirect( 'index.php?' . $orderStage . '&' . $returnParamStr . '&selectedNewAddressID=' . $_POST['address_radiobutton'] );
			}
		}

		_copyDataFromPostToPage( $smarty );
		$addresses = _getAllAddresses(  );
		$count_row = 978;
		$countries = cnGetCountries( array(  ), $count_row, null );

		if (isset( $_POST['phone'] )) {
			$smarty->assign( 'phone', $_POST['phone'] );
		}


		if (isset( $_POST['mobile'] )) {
			$smarty->assign( 'mobile', $_POST['mobile'] );
		}


		if (isset( $_POST['state'] )) {
			$smarty->assign( 'state', $_POST['state'] );
		}


		if (isset( $_POST['zoneID'] )) {
			$smarty->assign( 'zoneID', $_POST['zoneID'] );
		}


		if (isset( $_POST['cityID'] )) {
			$smarty->assign( 'cityID', $_POST['cityID'] );
		}


		if (!isset( $_POST['address_radiobutton'] )) {
			$smarty->assign( 'addressID', $addressID );
		}

		$smarty->assign( 'addresses', $addresses );
		$smarty->assign( 'countries', $countries );
		$smarty->assign( 'main_content_template', 'change_address.tpl.html' );
	}

?>