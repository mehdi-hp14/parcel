<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	error_reporting( 0 );
	ini_set( 'display_errors', 0 );

	if (( ( $_GET['f'] == 'json' || $_GET['f'] == 'xml' ) && isset( $_GET['criterion'] ) )) {
		$searchstrings = array(  );
		$tmp = explode( ' ', $_GET['criterion'] );
		foreach ($tmp as $key => $val) {

			if (0 < strlen( trim( $val ) )) {
				$searchstrings[] = str_replace( 'ي', 'ي', $val );

				if (stristr( $val, 'ي' ) != false) {
					$searchstrings[] = str_replace( 'ي', 'ي', $val );
					continue;
				}

				continue;
			}
		}

		$callBackParam = array(  );
		$products = array(  );
		$callBackParam['search_simple'] = $searchstrings;

		if (( $_GET['i'] == 'ALL' || stristr( $_GET['i'], 'P' ) != false )) {
			$where_clause = '';
			$order_by_clause = '';

			if (!count( $callBackParam['search_simple'] )) {
				$where_clause = ' where 0';
			} 
else {
				foreach ($callBackParam['search_simple'] as $value) {
					$where_clause .= ($where_clause ? ' AND' : '') . ' ( ' . LanguagesManager::sql_prepareField( 'name' ) . ' LIKE "%' . $value . '%" OR
    				' . LanguagesManager::sql_prepareField( 'description' ) . ' LIKE "%' . $value . '%" OR
    				' . LanguagesManager::sql_prepareField( 'brief_description' ) . ' LIKE "%' . $value . '%") ';
				}


				if ($where_clause != '') {
					$where_clause = ' where categoryID>1 and enabled=1 and ' . $where_clause;
				} 
else {
					$where_clause = 'where categoryID>1 and enabled=1';
				}
			}

			$order_by_clause = 'order by _name_sort';
			$sqlQuery = 'select *,' . LanguagesManager::sql_constractSortField( PRODUCTS_TABLE, 'name' ) . ', ' . LanguagesManager::sql_prepareField( 'name' ) . ', ' . LanguagesManager::sql_prepareField( 'brief_description' ) . ', ' . LanguagesManager::sql_prepareField( 'description' ) . ' from ' . PRODUCTS_TABLE . ( ( ( ' ' ) . $where_clause . ' ' ) . $order_by_clause );
			$q = db_query( $sqlQuery );
			$result = array(  );

			if ($row = db_fetch_row( $q )) {
				$ret['img'] = './uploads/products_pictures/' . GetThumbnail( $row['productID'] );
				$ret['title'] = $row[ . 'name_' . $lang];
				$ret['description'] = $row[ . 'description_' . $lang];
				$ret['link'] = 'productID=' . $row['productID'] . '&product_slug=' . $row[LanguagesManager::sql_prepareField( 'name' )];
				$result[] = $ret;
			}

			$retval['products'] = $result;
		}


		if (( $_GET['i'] == 'ALL' || stristr( $_GET['i'], 'C' ) != false )) {
			$where_clause = '';
			$order_by_clause = '';

			if (!count( $callBackParam['search_simple'] )) {
				$where_clause = ' where 0';
			} 
else {
				foreach ($callBackParam['search_simple'] as $value) {
					$where_clause .= ($where_clause ? ' AND' : '') . ' ( ' . LanguagesManager::sql_prepareField( 'name' ) . ' LIKE "%' . $value . '%" OR
    				' . LanguagesManager::sql_prepareField( 'description' ) . ' LIKE "%' . $value . '%" )';
				}


				if ($where_clause != '') {
					$where_clause = ' where categoryID>1 and enabled=1 and ' . $where_clause;
				} 
else {
					$where_clause = 'where categoryID>1 and enabled=1';
				}

				$order_by_clause = 'order by _name_sort';
				$sqlQuery = 'select *,' . LanguagesManager::sql_constractSortField( PRODUCTS_TABLE, 'name' ) . ', ' . LanguagesManager::sql_prepareField( 'name' ) . ', ' . LanguagesManager::sql_prepareField( 'description' ) . ' from ' . CATEGORIES_TABLE . ( ( ( ' ' ) . $where_clause . ' ' ) . $order_by_clause );
				$q = db_query( $sqlQuery );
				$result = array(  );

				if ($row = db_fetch_row( $q )) {
					$ret['img'] = $row['default_picture'];
					$ret['title'] = $row[ . 'name_' . $lang];
					$ret['description'] = $row[ . 'description_' . $lang];
					$ret['link'] = 'categoryID=' . $row['categoryID'] . '&category_slug=' . $row[LanguagesManager::sql_prepareField( 'name' )];
					$result[] = $ret;
				}
			}

			$retval['cats'] = $result;
		}


		if (( $_GET['i'] == 'ALL' || stristr( $_GET['i'], 'N' ) != false )) {
			$where_clause = '';
			$order_by_clause = '';

			if (!count( $callBackParam['search_simple'] )) {
				$where_clause = ' where 0';
			} 
else {
				foreach ($callBackParam['search_simple'] as $value) {
					$where_clause .= ($where_clause ? ' AND' : '') . ' ( `title` LIKE "%' . $value . '%" OR
    				`textToPublication` LIKE "%' . $value . '%" )';
				}

				$order_by_clause = 'order by priority';
				$sqlQuery = 'select * from ' . NEWS_TABLE . ( ( ' where ' . $where_clause . ' ' ) . $order_by_clause );
				$q = db_query( $sqlQuery );
				$result = array(  );

				if ($row = db_fetch_row( $q )) {
					$ret['img'] = $row['picture'];
					$ret['title'] = $row['title'];
					$ret['description'] = $row['textToPublication'];
					$ret['link'] = '?news&news_page=' . $row['NID'];
					$result[] = $ret;
				}
			}

			$retval['news'] = $result;
		}


		if ($_GET['f'] == 'json') {
			echo json_encode( $retval );
		}

		$_GET['f'] = 'xml';

		if () {
			echo xmlrpc_encode( $retval );
		}

		exit(  );
	}

?>