<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (( empty( $$visit_history ) && isset( $_SESSION['log'] ) )) {
		$callBackParam = array( 'log' => $_SESSION['log'] );
		$visits = null;
		$offset = 726;
		$count = 726;
		$navigatorHtml = GetNavigatorHtml( 'index.php?visit_history', 20, 'stGetVisitsByLogin', $callBackParam, $visits, $offset, $count );
		$smarty->assign( 'navigator', $navigatorHtml );
		$smarty->assign( 'visits', $visits );
		$smarty->assign( 'main_content_template', 'visit_history.tpl.html' );
	}

?>