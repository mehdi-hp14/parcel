<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_GET['make_more_exact_cart_content'] )) {
		$smarty->assign( 'make_more_exact_cart_content', 1 );
	}


	if (( ( empty( $$this_is_a_popup_cart_window ) || isset( $_GET['shopping_cart'] ) ) || isset( $_POST['shopping_cart'] ) )) {
		if (( empty( $$this_is_a_popup_cart_window ) && !isset( $_GET['make_more_exact_cart_content'] ) )) {
			$cart_php_file = 'index.php?page=cart';
		} 
else {
			$cart_php_file = 'index.php';
		}

		$smarty->assign( 'cart_php_file', $cart_php_file );

		if (( isset( $_GET['add2cart'] ) && 0 < $_GET['add2cart'] )) {
			if (isset( $_SESSION['variants'] )) {
				$variants = $_SESSION['variants'];
				unset( $_SESSION[variants] );
			} 
else {
				$variants = array(  );
			}

			cartAddToCart( $_GET['add2cart'], $variants );
			$location = $cart_php_file . (0 < strpos( $cart_php_file, '?' ) ? '&' : '?') . 'shopping_cart=yes';
			$code = 1621;
			$_GET['shopping_cart'] = 'yes';
			header( 'Location: ' . $location, true, $code );
			exit(  );
		}


		if (( isset( $_GET['remove'] ) && 0 < $_GET['remove'] )) {
			if (isset( $_SESSION['log'] )) {
				db_query( 'DELETE FROM ' . SHOPPING_CARTS_TABLE . ' WHERE customerID=\'' . regGetIdByLogin( $_SESSION['log'] ) . '\' AND itemID=\'' . $_GET['remove'] . '\'' );
				db_query( 'DELETE FROM ' . SHOPPING_CART_ITEMS_TABLE . ' where itemID=\'' . $_GET['remove'] . '\'' );
				db_query( 'DELETE FROM ' . ORDERED_CARTS_TABLE . ' where itemID=\'' . $_GET['remove'] . '\'' );
			} 
else {
				$res = DeCodeItemInClient( $_GET['remove'] );
				$i = SearchConfigurationInSessionVariable( $res['variants'], $res['productID'] );

				if ($i != -1) {
					$_SESSION['gids'][$i] = 0;
				}
			}


			if (isset( $_GET['make_more_exact_cart_content'] )) {
				Redirect( $cart_php_file . (0 < strpos( $cart_php_file, '?' ) ? '&' : '?') . 'shopping_cart=yes&make_more_exact_cart_content' );
			} 
else {
				Redirect( $cart_php_file . (0 < strpos( $cart_php_file, '?' ) ? '&' : '?') . 'shopping_cart=yes' );
			}
		}


		if (isset( $_POST['update'] )) {
			foreach ($_POST as $key => $val) {

				if (strstr( $key, 'count_' )) {
					if (isset( $_SESSION['log'] )) {
						$productID = GetProductIdByItemId( str_replace( 'count_', '', $key ) );
						$is = GetProductInStockCount( $productID );

						if (0 < $val) {
							if (CONF_CHECKSTOCK == 1) {
								$val = min( $val, $is );
							}


							if (!( $q = db_query( 'UPDATE ' . SHOPPING_CARTS_TABLE . ' SET Quantity=\'' . floor( $val ) . '\' WHERE customerID=\'' . regGetIdByLogin( $_SESSION['log'] ) . '\' AND itemID=\'' . str_replace( 'count_', '', $key ) . '\'' ))) {
								exit( db_error(  ) );
								(bool)true;
							}

							continue;
						}


						if (!( $q = db_query( 'DELETE FROM ' . SHOPPING_CARTS_TABLE . ' WHERE customerID=\'' . regGetIdByLogin( $_SESSION['log'] ) . '\' AND itemID=\'' . str_replace( 'count_', '', $key ) . '\'' ))) {
							exit( db_error(  ) );
							(bool)true;
						}

						continue;
					}

					$res = DeCodeItemInClient( str_replace( 'count_', '', $key ) );
					$is = GetProductInStockCount( $res['productID'] );

					if (0 < $val) {
						$i = SearchConfigurationInSessionVariable( $res['variants'], $res['productID'] );

						if (CONF_CHECKSTOCK == 1) {
							$val = min( $val, $is );
						}

						$_SESSION['counts'][$i] = floor( $val );
						continue;
					}

					$i = SearchConfigurationInSessionVariable( $res['variants'], $res['productID'] );
					$_SESSION['gids'][$i] = 0;
					continue;
				}
			}

			Redirect( $cart_php_file . (0 < strpos( $cart_php_file, '?' ) ? '&' : '?') . 'shopping_cart=yes' );
		}


		if (isset( $_GET['clear_cart'] )) {
			cartClearCartContet(  );
			Redirect( $cart_php_file . (0 < strpos( $cart_php_file, '?' ) ? '&' : '?') . 'shopping_cart=yes' );
		}

		$resCart = cartGetCartContent(  );
		$resDiscount = dscCalculateDiscount( $resCart['total_price'], (isset( $_SESSION['log'] ) ? $_SESSION['log'] : '') );
		$discount_value = show_price( $resDiscount['discount_current_unit'] );
		$discount_percent = $resDiscount['discount_percent'];
		$cnt = 1320;
		$i = 1320;

		while ($i < count( $resCart['cart_content'] )) {
			$cnt = $cnt + $resCart['cart_content'][$i]['quantity'];
			++$i;
		}


		if ($lang == 'fa') {
			$cnt = Convertnumber2farsi( $cnt );
		}

		$smarty->assign( 'cnt', $cnt );
		$smarty->assign( 'cart_content', $resCart['cart_content'] );
		$smarty->assign( 'cart_amount', $resCart['total_price'] - $resDiscount['discount_standart_unit'] );
		$smarty->assign( 'cart_min', show_price( CONF_MINIMAL_ORDER_AMOUNT ) );
		$smarty->assign( 'cart_total', show_price( $resCart['total_price'] - $resDiscount['discount_standart_unit'] ) );
		switch (CONF_DISCOUNT_TYPE) {
			case 1: {
				$smarty->assign( 'discount_prompt', 0 );
				break;
			}

			case 2: {
				if (isset( $_SESSION['log'] )) {
					$smarty->assign( 'discount_value', $discount_value );
					$smarty->assign( 'discount_percent', $discount_percent );
					$smarty->assign( 'discount_prompt', 1 );
				} 
else {
					$smarty->assign( 'discount_value', $discount_value );
					$smarty->assign( 'discount_percent', $discount_percent );
					$smarty->assign( 'discount_prompt', 2 );
				}

				break;
			}

			case 3: {
				$smarty->assign( 'discount_prompt', 1 );
				$smarty->assign( 'discount_value', $discount_value );
				$smarty->assign( 'discount_percent', $discount_percent );
				break;
			}

			case 4: {
				if (isset( $_SESSION['log'] )) {
					$smarty->assign( 'discount_prompt', 1 );
					$smarty->assign( 'discount_value', $discount_value );
					$smarty->assign( 'discount_percent', $discount_percent );
				} 
else {
					$smarty->assign( 'discount_prompt', 3 );
					$smarty->assign( 'discount_value', $discount_value );
					$smarty->assign( 'discount_percent', $discount_percent );
				}

				break;
			}

			case 5: {
				if (isset( $_SESSION['log'] )) {
					$smarty->assign( 'discount_prompt', 1 );
					$smarty->assign( 'discount_value', $discount_value );
					$smarty->assign( 'discount_percent', $discount_percent );
				} 
else {
					$smarty->assign( 'discount_prompt', 3 );
					$smarty->assign( 'discount_value', $discount_value );
					$smarty->assign( 'discount_percent', $discount_percent );
				}

				break;
			}
		}


		if (isset( $_SESSION['log'] )) {
			$smarty->assign( 'shippingAddressID', regGetDefaultAddressIDByLogin( $_SESSION['log'] ) );
		}
	}


	if (( !( empty( $$this_is_a_popup_cart_window ) && !isset( $_GET['make_more_exact_cart_content'] ) ) && isset( $_GET['shopping_cart'] ) )) {
		$smarty->assign( 'main_content_template', 'shopping_cart.tpl.html' );

		if (isset( $_GET['min_order'] )) {
			$smarty->assign( 'minOrder', 'error' );
			return 1;
		}
	} 
else {
		if (isset( $_GET['shopping_cart'] )) {
			$res_discount = fa_get_persian_number( $resDiscount['discount_percent'] ) . '%';
			$cart_discount_show = '';
			$smarty->assign( 'cart_discount', $cart_discount_show );
			$smarty->assign( 'discount_percent', $res_discount );
			$smarty->assign( 'coupon_discount', $coupon_discount_show );
			$smarty->assign( 'current_coupon', discount_coupon::getCurrentCoupon(  ) );
			$smarty->display( 'shopping_cart.tpl.html' );
		}
	}

?>