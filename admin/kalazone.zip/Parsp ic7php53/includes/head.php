<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!isset( $_GET['view_content'] )) {
		if (( ( empty( $$categoryID ) && !empty( $$productID ) ) && 0 < $categoryID )) {

			if (!( $q = db_query( 'SELECT ' . LanguagesManager::sql_prepareField( 'name' ) . ' FROM ' . CATEGORIES_TABLE . ( ' WHERE categoryID<>0 and categoryID<>1 and categoryID=\'' . $categoryID . '\'' ) ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			$r = db_fetch_row( $q );

			if ($r) {
				$page_title = $r[0] . ' - ' . CONF_DEFAULT_TITLE;
			} 
else {
				$page_title = CONF_DEFAULT_TITLE;
			}

			$page_title = str_replace( '<', '&lt;', $page_title );
			$page_title = str_replace( '>', '&gt;', $page_title );
			$meta_tags = catGetMetaTags( $categoryID );
		} 
else {
			if (( empty( $$productID ) && 0 < $productID )) {

				if (!( $q = db_query( 'SELECT ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name FROM ' . PRODUCTS_TABLE . ( ' WHERE productID=\'' . $productID . '\'' ) ))) {
					exit( db_error(  ) );
					(bool)true;
				}

				$r = db_fetch_row( $q );

				if ($r) {
					$page_title = $r[0] . ' - ' . CONF_DEFAULT_TITLE;
				} 
else {
					$page_title = CONF_DEFAULT_TITLE;
				}

				$page_title = str_replace( '<', '&lt;', $page_title );
				$page_title = str_replace( '>', '&gt;', $page_title );
				$meta_tags = prdGetMetaTags( $productID );
			} 
else {
				$page_title = CONF_DEFAULT_TITLE;
				$meta_tags = '';

				if (CONF_HOMEPAGE_META_DESCRIPTION != '') {
					$meta_tags .= '<meta name="Description" content="' . CONF_HOMEPAGE_META_DESCRIPTION . '">
';
				}


				if (CONF_HOMEPAGE_META_KEYWORDS != '') {
					$meta_tags .= '<meta name="KeyWords" content="' . CONF_HOMEPAGE_META_KEYWORDS . '" >
';
				}
			}
		}
	} 
else {
		$page = auxpgGetAuxPage( $view_content );
		$page_title = $page['aux_page_name'] . ' - ' . CONF_DEFAULT_TITLE;
		$meta_tags = '';

		if ($page['meta_description'] != '') {
			$meta_tags .= '<meta name="Description" content="' . str_replace( '"', '&quot;', $page['meta_description'] ) . '">
';
		}


		if ($page['meta_keywords'] != '') {
			$meta_tags .= '<meta name="KeyWords" content="' . str_replace( '"', '&quot;', $page['meta_keywords'] ) . '" >
';
		}
	}

	$meta_tags .= str_replace( '\"', '"', CONF_GOOGLE_SITEMAP_META );
	$smarty->assign( 'page_title', $page_title );
	$smarty->assign( 'page_meta_tags', $meta_tags );
?>