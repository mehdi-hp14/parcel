<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (( isset( $_POST['links_exchange'] ) || isset( $_GET['links_exchange'] ) )) {
		if (isset( $_POST['fACTION'] )) {
			if ($_POST['fACTION'] == 'ADD_LINK') {
				do {
					if (!strlen( str_replace( 'http://', '', $_POST['LINK']['le_lURL'] ) )) {
						$error = '<font color="red"><b>' . STRING_ERROR_LE_ENTER_LINK . '</b></font>';
						break;
					}


					if (!strlen( $_POST['LINK']['le_lText'] )) {
						$error = '<font color="red"><b>' . STRING_ERROR_LE_ENTER_TEXT . '</b></font>';
						break;
					}


					if (strpos( $_POST['LINK']['le_lURL'], 'http://' )) {
						$_POST['LINK']['le_lURL'] = 'http://' . $_POST['LINK']['le_lURL'];
					}


					if (le_addLink( $_POST['LINK'] )) {
						break;
					}

					$error = '<font color="red"><b>' . STRING_ERROR_LE_LINK_EXISTS . '</b></font>';
				}while (!( 0));


				if (!empty( $$error )) {
					Redirect( BASE_URL . 'index.php?links_exchange&added=ok' );
				}
			}
		}

		$ob_per_list = 1013;

		if (empty( $_GET['le_categoryID'] )) {
			$_GET['le_categoryID'] = 0;
		} 
else {
			$_GET['le_categoryID'] = intval( $_GET['le_categoryID'] );
		}

		$TotalPages = ceil( le_getLinksNumber( ($_GET['le_categoryID'] ? 'le_lCategoryID = ' . $_GET['le_categoryID'] : '1') . ' AND le_lVerified IS NOT NULL' ) / $ob_per_list );

		if (empty( $_GET['p'] )) {
			$_GET['p'] = 1;
		} 
else {
			$_GET['p'] = ($TotalPages < intval( $_GET['p'] ) ? $TotalPages : intval( $_GET['p'] ));
		}


		if (( isset( $_GET['added'] ) || isset( $_POST['added'] ) )) {
			$error = '<font color="green"><b>' . STRING_ERROR_LE_LINK_ADDED . '</b></font>';
		}

		$_SERVER['REQUEST_URI'] = set_query( 'added=' );
		$lister = getListerRange( $_GET['p'], $TotalPages );
		$le_Categories = html_spchars( le_getCategories(  ) );

		if (( isset( $_GET['show_all'] ) || isset( $_POST['show_all'] ) )) {
			$ob_per_list = $ob_per_list * $TotalPages;
			$smarty->assign( 'showAllLinks', '1' );
			$_GET['p'] = 1;
		}

		$smarty->assign( 'REQUEST_URI', $_SERVER['REQUEST_URI'] );
		$smarty->assign( 'url_allcategories', set_query( 'le_categoryID=' ) );
		$smarty->assign( 'le_categories', $le_Categories );
		$smarty->assign( 'le_CategoryID', $_GET['le_categoryID'] );
		$smarty->assign( 'curr_page', $_GET['p'] );
		$smarty->assign( 'last_page', $TotalPages );

		if (empty( $$error )) {
			if ($error != STRING_ERROR_LE_LINK_ADDED) {
				$smarty->assign( 'error', $error );
				$smarty->assign( 'pst_LINK', html_spchars( xStripSlashesGPC( $_POST['LINK'] ) ) );
			} 
else {
				$smarty->assign( 'error_ok', $error );
			}
		}

		$smarty->assign( 'le_links', html_spchars( le_getLinks( $_GET['p'], $ob_per_list, ($_GET['le_categoryID'] ? 'le_lCategoryID = ' . $_GET['le_categoryID'] : '1') . ' AND (le_lVerified IS NOT NULL AND le_lVerified <>\'0000-00-00 00:00:00\' )', 'le_lID, le_lText, le_lURL, le_lCategoryID, le_lVerified', 'le_lVerified ASC, le_lURL ASC' ) ) );

		if ($lister['start'] < $lister['end']) {
			$smarty->assign( 'le_lister_range', range( $lister['start'], $lister['end'] ) );
		}

		$smarty->assign( 'le_categories_pr', ceil( count( $le_Categories ) / 2 ) );
		$smarty->assign( 'main_content_template', 'links_exchange.tpl.html' );
	}

?>