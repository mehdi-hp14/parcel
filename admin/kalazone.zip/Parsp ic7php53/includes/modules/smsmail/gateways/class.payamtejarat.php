<?php
/*****************************************************************************
 *                                                                           *
 * www.parsp.com                                                       *
 * Copyright (c) 2014    	  . All rights reserved.                     *
 *                                                                           *
 *****************************************************************************/
/**
 * @connect_module_class_name PAYAMTEJARAT
 */

class PAYAMTEJARAT extends SMSMail {
	
	function _initVars(){
		
		$this->title = 'درگاه پيام کوتاه پیام تجارت';
		$this->description = '<a href="http://www.sms.payamsms.net/" target="_blank">پیام تجارت</a>';
		$this->sort_order = 0;
		
		$this->Settings[] = 'CONF_PAYAMTEJARAT_USERNAME';
		$this->Settings[] = 'CONF_PAYAMTEJARAT_PASSWORD';
		$this->Settings[] = 'CONF_PAYAMTEJARAT_FROM';
	}
	
	function _initSettingFields(){
		
		$this->SettingsFields['CONF_PAYAMTEJARAT_USERNAME'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> 'Username:', 
			'settings_description' 	=> 'لطفا نام کاربري خود در پیام تجارت را وارد نماييد', 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		$this->SettingsFields['CONF_PAYAMTEJARAT_PASSWORD'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> 'Password', 
			'settings_description' 	=> 'لطفا رمز عبور خود در پیام تجارت را وارد نماييد', 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		$this->SettingsFields['CONF_PAYAMTEJARAT_FROM'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> 'شماره شخصي', 
			'settings_description' 	=> 'لطفا شماره شخصي خود در پیام تجارت را وارد نماييد', 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
	}

	function _prepareRequest($_SMSMessage, $_PhonesList, $_Params){
		
		if(!$_SMSMessage)return null;
		if(!count($_PhonesList))return null;
		
		$Request = array();
		foreach ($_PhonesList as $_Phone){
			
			$Request[] = 'from='.$this->_getSettingValue('CONF_PAYAMTEJARAT_FROM').
				'&to='.$_Phone.
				'&user='.$this->_getSettingValue('CONF_PAYAMTEJARAT_USERNAME').
				'&password='.$this->_getSettingValue('CONF_PAYAMTEJARAT_PASSWORD').
				'&text='.$_SMSMessage.'&';
				
		}
		return $Request;
	}
	
	function _sendRequest($_Request){
		$host = 'www.sms.payamsms.net';
		$doc = '/scripts/sender_url.php';
		$result = '';
		$errno = '';
		$errstr = '';
		
		foreach ($_Request as $_req){
		  $url= str_replace(" ","%20","http://$host$doc?$_req");		  
    	$result = file_get_contents($url);    	
      /*            
			$so = fsockopen($host, 80, $errno, $errstr, 30);
			if(!$so)return "Couldnt open socket";
			$in = "GET ".$doc." HTTP/1.1"."\n".
				"Host: ".$host."\n".
				"Content-Length: ".strlen($_req)."\n".
				"Content-type: application/x-www-form-urlencoded"."\n".
				"Cache-Control: no-cache"."\n".
				"Connection: Close"."\n".
				"\n";
			fputs($so,$in.$_req);
			while(!feof($so)){				
				$result .= fgets($so,128);
			}			
			fclose($so);
		*/
		}		
		return 1; 
	}
	
	function _parseResponce($_Responce){
/*		
		print '<pre>';
		print_r($_Responce);
		print '</pre>';
		die;
	*/
	}
}
?>