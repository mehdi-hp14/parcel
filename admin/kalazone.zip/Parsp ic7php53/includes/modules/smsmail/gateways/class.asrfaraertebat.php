<?php
/*****************************************************************************
 *                                                                           *
 * www.parsp.com                                                       *
 * Copyright (c) 2008    	  . All rights reserved.                     *
 *                                                                           *
 *****************************************************************************/
/**
 * @connect_module_class_name FARAERTEBAT
 */

class FARAERTEBAT extends SMSMail {
	
	function _initVars(){
		
		$this->title = 'درگاه پيام کوتاه عصر فرا ارتباط';
		$this->description = '<a href="http://www.afe.ir/" target="_blank">عصر فرا ارتباط</a>';
		$this->sort_order = 0;
		
		$this->Settings[] = 'CONF_FARAERTEBAT_USERNAME';
		$this->Settings[] = 'CONF_FARAERTEBAT_PASSWORD';
		$this->Settings[] = 'CONF_FARAERTEBAT_FROM';
	}
	
	function _initSettingFields(){
		
		$this->SettingsFields['CONF_FARAERTEBAT_USERNAME'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> 'Username:', 
			'settings_description' 	=> 'لطفا نام کاربري خود در  را وارد نماييد', 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		$this->SettingsFields['CONF_FARAERTEBAT_PASSWORD'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> 'Password', 
			'settings_description' 	=> 'لطفا رمز عبور خود در  را وارد نماييد', 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		$this->SettingsFields['CONF_FARAERTEBAT_FROM'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> 'شماره شخصي', 
			'settings_description' 	=> 'لطفا شماره اختصاصی را وارد نماييد', 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
	}

	function _prepareRequest($_SMSMessage, $_PhonesList, $_Params){		
     
		if(!$_SMSMessage)return null;
		if(!count($_PhonesList))return null;
		
		$Request = array();
    $Username=$this->_getSettingValue('CONF_FARAERTEBAT_USERNAME');
    $Password=$this->_getSettingValue('CONF_FARAERTEBAT_PASSWORD');
    $Number=$this->_getSettingValue('CONF_FARAERTEBAT_FROM');
        
		foreach ($_PhonesList as $_Phone){    			
			$Request[] =
       array('Username' => "$Username",
             'Password' => "$Password",
             'Number' => "$Number",
             'Mobile' => array($_Phone),
             'Message' => "$_SMSMessage",
             'Type' => "2");      				      				
		}
		return $Request;
	}
	
	function _sendRequest($_Request){
   ini_set("soap.wsdl_cache_enabled", "0");
   $url = 'http://www.afe.ir/WebService/V4/BoxService.asmx?wsdl';
   $client = new SoapClient($url);
        $i=0;   
        foreach ($_Request as $param){                                
        $result = $client->__SoapCall('SendMessage', array($param));        
        get_object_vars($result);
        $merge = 'SendMessageResult';
        
        if($result->$merge->string != '')
            if ($result->$merge->string=='Send Successfully')
              $i=$i+1;                
 	}
   return $i;
}	
	function _parseResponce($_Responce){
		if ($_Responce>0) 
	  {
     // echo '<center>'.$_Responce.' SMS Send Successfully</center>';
		  return 1;     		
	 }
   return 0; 
	}

}
?>