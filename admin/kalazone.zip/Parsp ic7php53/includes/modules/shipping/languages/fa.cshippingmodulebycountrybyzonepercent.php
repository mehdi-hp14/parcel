<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONEPERCENT_TTL', 'بر اساس کشورها/استانها (درصدي از کل سفارش)' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONEPERCENT_DSCR', 'به شما اجازه ميدهد که قيمتهاي حمل و نقل بر اساس کشورها و يا استانها مشخص نماييد که درصدي از کل مبلغ سفارش مي باشد' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONEPERCENT_CFG_IS_INSTALLED_TTL', 'لطفا قيمت ها را بر اساس استانها و کشورها مشخص نماييد' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONEPERCENT_CFG_IS_INSTALLED_DSCR', 'اين ماژول قيمت حمل و نقل را بر اساس درصدي از کل سفارش مشخص مي نمايد' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONEPERCENT_TXT_1', 'کشوري را انتخاب نماييد' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONEPERCENT_TXT_2', 'انتخاب' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONEPERCENT_TXT_3', ' درصد از کل مبلغ سفارش<br>(براي جلوگيري از ارسال کالا به اين کشور عددي منفي مشخص نماييد)' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONEPERCENT_TXT_4', 'قيمت حمل و نقل بر اساس منطقه يا استان<br>(براي جلوگيري از ارسال کالا به اين استان عددي منفي مشخص نماييد)' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONEPERCENT_TXT_5', ' درصد از کل مبلغ سفارش' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONEPERCENT_TXT_6', 'هيچ استاني براي کشور انتخاب شده موجود نيست' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONEPERCENT_TXT_7', 'قيمت ثبت شده حمل و نقل براي اين کشور: ' );
?>