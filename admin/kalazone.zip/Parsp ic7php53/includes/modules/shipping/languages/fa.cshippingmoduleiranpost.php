<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CSHIPPINGMODULEEXPRESSPOST_TTL', 'ماژول پست جمهوری اسلامی ایران' );
	define( 'CSHIPPINGMODULEEXPRESSPOST_DESCRIPTION', 'محاسبه خودکار هزینه ارسال مرسوله بر اساس وزن با تعرفه پست  جمهوری اسلامی- برای استفاده از ماژول حتما برای محصولات خود وزن تعیین نمایید' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_IS_INSTALLED_TTL', 'نرخ های مصوب سال جاری' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_IS_INSTALLED_DSCR', 'بر اساس دسته بندی های مشخص شده می بایست نرخ پایه و اطلاعات مربوطه را بر اساس تعرفه های پست وارد کنید.' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_TYPE_TTL', 'نوع پست' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_TYPE_ARRAY', 'عادی:0,سفارشی:1,پیشتاز:2' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_VARIABLE_TTL', 'حق مقر' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_VARIABLE_DESCR', 'نرخ مقر متغیر است که در تعرفه های پست وجود دارد' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_INSURANSE_TTL', 'نرخ بیمه' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_INSURANSE_DESCR', 'نرخ بیمه را برای بسته های با قیمت زیر حداکثر مشمول بیمه مرسوله را وارد کنید' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_INCITY', 'درون شهری' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_INZONE', 'درون استانی' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_NEARZONE', 'برون استانی مجاور' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_FARZONE', 'برون استانی غیرمجاور' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_WIGHT', 'رده وزنی' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_TO250', 'تا 250 گرم' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_TO500', 'از 251 تا 500 گرم' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_TO1000', 'از 501 تا 1000 گرم' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_TO2000', 'از 1001 تا 2000 گرم' );
	define( 'CSHIPPINGMODULEIRANPOST_CFG_FROM2000', 'بیش از 2000 هر کیلوگرم و کسری از آن' );
?>