<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CSHIPPINGMODULEFIXEDXORPERCENT_TTL', 'حداکثر مقدار ثابت يا درصد از کل مبلغ سفارش' );
	define( 'CSHIPPINGMODULEFIXEDXORPERCENT_DSCR', ' در اين روش هزينه ثابت يا درصد از کل سفارش، هرکدام که بيشتر باشد در نظر ميگيرد' );
	define( 'CSHIPPINGMODULEFIXEDXORPERCENT_CONF_FIXEDRATE_TTL', 'هزينه حمل و نقل ثابت' );
	define( 'CSHIPPINGMODULEFIXEDXORPERCENT_CONF_FIXEDRATE_DSCR', 'هزينه حمل و نقل = MAX ( هزينه حمل و نقل ثابت , يا درصد از کل يک سفارش)' );
	define( 'CSHIPPINGMODULEFIXEDXORPERCENT_CONF_PERCENT_TTL', 'درصد از کل سفارش(بين 0 تا 100)' );
	define( 'CSHIPPINGMODULEFIXEDXORPERCENT_CONF_PERCENT_DSCR', 'هزينه حمل و نقل = MAX ( هزينه حمل و نقل ثابت , يا درصد از کل يک سفارش)' );
?>