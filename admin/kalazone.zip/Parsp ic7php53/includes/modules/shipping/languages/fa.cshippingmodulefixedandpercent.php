<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CSHIPPINGMODULEFIXEDANDPERCENT_TITLE', 'هزينه حمل و نقل ثابت + درصد' );
	define( 'CSHIPPINGMODULEFIXEDANDPERCENT_DESCR', 'هزينه حمل و نقل = هزينه حمل و نقل ثابت +درصدي از کل مبلغ سفارش' );
	define( 'CSHIPPINGMODULEFIXEDANDPERCENT_CONF_FIXEDRATE_TTL', 'هزينه حمل و نقل ثابت' );
	define( 'CSHIPPINGMODULEFIXEDANDPERCENT_CONF_FIXEDRATE_DSCR', 'لطفا هزينه حمل و نقل را مشخص نماييد' );
	define( 'CSHIPPINGMODULEFIXEDANDPERCENT_CONF_PERCENT_TTL', 'درصد از کل سفارش(ميتواند بين 0 تا 100 باشد)' );
	define( 'CSHIPPINGMODULEFIXEDANDPERCENT_CONF_PERCENT_DSCR', '' );
?>