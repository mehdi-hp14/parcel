<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONE_TTL', 'بر اساس کشورها/ استانها' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONE_DSCR', 'به شما اجازه ميدهد که قيمتهاي حمل و نقل ثابتي بر اساس کشورها و يا استانها مشخص نماييد' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONE_CNF_IS_INSTALLED_TTL', 'هزينه ثابت حمل و نقل' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONE_CNF_IS_INSTALLED_DSCR', 'لطفا قيمت ها را بر اساس استانها و کشورها مشخص نماييد' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONE_TXT_SELECT_COUNTRY', 'يک کشور انتخاب نماييد' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONE_TXT_1', 'لطفا قيمت ارسال براي اين کشور را مشخص نماييد:' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONE_TXT_2', '(براي جلوگيري از ارسال کالا به اين کشور عددي منفي مشخص نماييد)' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONE_TXT_3', 'لطفا قيمت ارسال براي اين استان را مشخص نماييد:<br>(براي جلوگيري از ارسال کالا به اين استان عددي منفي مشخص نماييد)' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONE_TXT_4', 'هيچ استاني براي کشور انتخاب شده موجود نيست' );
	define( 'CSHIPPINGMODULEBYCOUNTRYBYZONE_TXT_5', 'انتخاب' );
?>