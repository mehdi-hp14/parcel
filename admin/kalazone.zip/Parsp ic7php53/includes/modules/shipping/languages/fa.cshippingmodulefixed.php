<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CSHIPPINGMODULEFIXED_TITLE', 'قيمت حمل و نقل ثابت' );
	define( 'CSHIPPINGMODULEFIXED_DESCRIPTION', 'به شما اين امکان را ميدهد که براي تمامي حمل و نقل ها قيمت ثابت مشخص نماييد' );
	define( 'CSHIPPINGMODULEFIXED_CONF_SHIPPINGRATE_TITLE', 'قيمت حمل و نقل ثابت' );
	define( 'CSHIPPINGMODULEFIXED_CONF_SHIPPINGRATE_DESCR', 'لطفا هزينه حمل و نقل (ثابت) را مشخص نماييد' );
?>