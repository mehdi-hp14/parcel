<?php



/**

 * @connect_module_class_name CShippingModuleiranPost

 *

 */

define('CSHIPPINGMODULEIRANPOST_TABLE',DBTABLE_PREFIX.'_module_shipping_iranpost');

class CShippingModuleiranPost extends ShippingRateCalculator{

	

	function _initVars(){

		

		$this->title = CSHIPPINGMODULEEXPRESSPOST_TTL;

		$this->description = CSHIPPINGMODULEEXPRESSPOST_DESCRIPTION;

		$this->sort_order = 2;

		

		$this->Settings = array(

    'CONF_SHIPPING_MODULE_IRANPOST_TYPE',

    'CONF_SHIPPING_MODULE_IRANPOST_INSURANCE',

    'CONF_SHIPPING_MODULE_IRANPOST_VARIABLE',    

    'CONF_SHIPPING_MODULE_IRANPOST_IS_INSTALLED'            

    );

	}



	public function allow_shipping_to_address($address) //defines is shipping allowed to the specified address

	{

		$country = cnGetCountryById($address["countryID"]);

				 

		if ($country['country_iso_2']=="IR")

		{

		$zone = $address["zoneID"];



		$sql = 'SELECT COUNT(*) FROM '.CSHIPPINGMODULEIRANPOST_TABLE.' WHERE module_id="'.$this->ModuleConfigID.'"';

		$q = db_query($sql) or die (db_error());

		$row = db_fetch_row($q);

		if ($row[0] > 0) //there are some rates defined

		{			

				return 1;

			}

			else

			{

        return 0;				

			}

		 }

		 else

		 return 0;

		}

	



  function zones_status($a,$b)

  {

    $zone_ids=array(71,25,28,74,34,83,87,66,15,86,38,81,76,35,17,13,41,44,84,45,31,77,26,21,61,51,56,58,24,23,54);

    $zone[71]=array(2);

    $zone[25]=array(0,2);

    $zone[28]=array(0,0,2);

    $zone[74]=array(1,0,0,2);

    $zone[34]=array(1,0,0,0,2);

    $zone[83]=array(0,0,0,0,0,2);

    $zone[87]=array(0,0,0,0,0,1,2);

    $zone[66]=array(0,0,0,0,0,1,0,2);

    $zone[15]=array(0,0,1,0,0,0,0,0,2);

    $zone[86]=array(0,1,1,0,0,0,0,1,0,2);

    $zone[38]=array(0,0,0,1,0,0,0,1,0,0,2);

    $zone[81]=array(0,0,1,0,0,1,1,1,0,0,0,2);

    $zone[76]=array(1,0,0,0,1,0,0,0,0,0,0,0,2);

    $zone[35]=array(1,0,0,0,1,0,0,0,0,0,0,0,0,2);

    $zone[17]=array(0,0,0,0,0,0,0,0,1,0,0,0,0,0,2);

    $zone[13]=array(0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,2);

    $zone[41]=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2);

    $zone[44]=array(0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,1,2);

    $zone[84]=array(0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,2);

    $zone[45]=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,2);

    $zone[31]=array(1,1,0,1,0,0,0,1,0,1,1,0,0,1,0,0,0,0,0,0,2);

    $zone[77]=array(1,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,2);

    $zone[26]=array(0,0,1,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,2);

    $zone[21]=array(0,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,2);

    $zone[61]=array(0,0,0,1,0,0,0,1,0,0,1,0,0,0,0,0,0,0,1,0,0,1,0,0,2);

    $zone[51]=array(0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,2);

    $zone[56]=array(0,0,0,0,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,2);

    $zone[58]=array(0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,2);

    $zone[24]=array(0,0,1,0,0,0,1,0,0,0,0,1,0,0,0,1,1,1,0,1,0,0,0,0,0,0,0,0,2);

    $zone[23]=array(0,1,0,0,0,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,1,0,0,1,0,1,0,1,0,2);

    $zone[54]=array(0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,2);





    $indx= array_search($b,$zone_ids);

    if (count($zone[$a])>$indx) 

      $indx=$zone[$a][$indx];

    else

    {

      $indx= array_search($a,$zone_ids);

      $indx=$zone[$b][$indx];

    }

    return $indx;

   

  }



	function calculate_shipping_rate($order, $address){

		

		if(!count($this->_getShippingProducts($order)))return 0;

		$country = $address["countryID"];

		$zone = $address["zoneID"];

		$city = $address["cityID"];		

    $ship_rate=0;

		$sql='select * from '.CSHIPPINGMODULEIRANPOST_TABLE.' WHERE module_id="'.$this->ModuleConfigID.'" order by weight_type';

    $res=db_query($sql) or die (db_error());    

    while ($row=db_fetch_row($res))

    {

      $rateincity[$row['weight_type']]=$row['rate_incity'];

      $rateinzone[$row['weight_type']]=$row['rate_inzone'];

      $ratenearzone[$row['weight_type']]=$row['rate_nearzone'];

      $ratefarzone[$row['weight_type']]=$row['rate_farzone'];     

    }

    $oweight=CShippingModuleiranPost::_getorderweight($order);

    switch (_getSettingOptionValue("CONF_WEIGHT_UNIT")) {            

    case 'lbs':

    $oweight=$oweight*0.45359;    

    case 'kg':

    $oweight=$oweight*100;

    break;    

    default:    	

    	break;

    }

             

    $ot=-1;

    if ($oweight<250) $ot=0;

    if (($oweight>250) && ($oweight<500)) $ot=1;

    if (($oweight>500)&& ($oweight<1000)) $ot=2;

    if (($oweight>1000) && ($oweight<2000)) $ot=3;

        

    if (_getSettingOptionValue("CONF_CITY")==$city)      

        $ship_rate=$rateincity[$ot];              

    else 

    {        

      switch ($this->zones_status($zone,_getSettingOptionValue("CONF_ZONE"))) 

      {

      	case 0:

      	   $ship_rate=$ratefarzone[$ot];

      	   break;

      	case 1:

      	   $ship_rate=$ratenearzone[$ot];

      	   break;

      	case 2:

      	   $ship_rate=$rateinzone[$ot];

      	   break;

      default:    

      	break;

      }                            

    }

    

        if ($ot==-1)

        {

              if (_getSettingOptionValue("CONF_CITY")==$city)      

                $base_rate=$rateincity[3];              

              else 

              {        

                switch ($this->zones_status($zone,_getSettingOptionValue("CONF_ZONE"))) 

                {

                	case 0:

                	   $base_rate=$ratefarzone[3];

                	   break;

                	case 1:

                	   $base_rate=$ratenearzone[3];

                	   break;

                	case 2:

                	   $base_rate=$rateinzone[3];

                	   break;

                default:    

                	break;

                }                            

              }              

              $owa=$oweight/1000-2;                            

              //if ($owa>0)

              $ship_rate=$base_rate+($ship_rate*$owa);

              //else

               //$ship_rate=$ship_rate*($oweight/1000);  

        }

          

                     

		//otherwise return 0 (free shipping)

		return $ship_rate+$this->_getSettingValue('CONF_SHIPPING_MODULE_IRANPOST_INSURANCE')+$this->_getSettingValue('CONF_SHIPPING_MODULE_IRANPOST_VARIABLE');

	}



	function install(){

		

		//create table to store shipping rate values



		//create new empty database

		if(!in_array(strtolower(CSHIPPINGMODULEIRANPOST_TABLE), db_get_all_tables())){

			  // weight_type -1->perkillogram; 0->to250 ; 1->to 500 ; 2-> to 1000 ; 3-> to 2000;

		db_query('CREATE TABLE '.CSHIPPINGMODULEIRANPOST_TABLE.' 

				(module_id INT UNSIGNED NOT NULL, rate_incity INT, rate_inzone INT,rate_nearzone INT,rate_farzone INT,weight_type INT)

				');

		}

    

    $this->SettingsFields['CONF_SHIPPING_MODULE_IRANPOST_TYPE'] = array(

			'settings_value' 		=> '1', 

			'settings_title' 			=> CSHIPPINGMODULEIRANPOST_CFG_TYPE_TTL, 

			'settings_description' 	=> '', 

			'settings_html_function' 	=> 'setting_SELECT_BOX(CSHIPPINGMODULEIRANPOST_CFG_TYPE_ARRAY,', 

			'sort_order' 			=> 0,                         // iranpost_getConfigTypes()

		);

                                   

		$this->SettingsFields['CONF_SHIPPING_MODULE_IRANPOST_IS_INSTALLED'] = array(

			'settings_value' 		=> '1', 

			'settings_title' 			=> CSHIPPINGMODULEIRANPOST_CFG_IS_INSTALLED_TTL, 

			'settings_description' 	=> CSHIPPINGMODULEIRANPOST_CFG_IS_INSTALLED_DSCR, 

			'settings_html_function' 	=> 'CShippingModuleiranPost::settingCONF_IRANPOST_FORM()', 

			'sort_order' 			=> 1,

		);				

		                               

		$this->SettingsFields['CONF_SHIPPING_MODULE_IRANPOST_VARIABLE'] = array(

			'settings_value' 		=> '1', 

			'settings_title' 			=> CSHIPPINGMODULEIRANPOST_CFG_VARIABLE_TTL, 

			'settings_description' 	=> CSHIPPINGMODULEIRANPOST_CFG_VARIABLE_DESCR, 

			'settings_html_function' 	=> 'setting_TEXT_BOX(0,',  

			'sort_order' 			=> 2,

		);

		

				$this->SettingsFields['CONF_SHIPPING_MODULE_IRANPOST_INSURANCE'] = array(

			'settings_value' 		=> '1', 

			'settings_title' 			=> CSHIPPINGMODULEIRANPOST_CFG_INSURANSE_TTL, 

			'settings_description' 	=> CSHIPPINGMODULEIRANPOST_CFG_INSURANSE_DESCR, 

			'settings_html_function' 	=> 'setting_TEXT_BOX(0,',  

			'sort_order' 			=> 2,

		);



		ShippingRateCalculator::install();

	}

	

	function settingCONF_IRANPOST_FORM()

  {

  

/*	$curr_country = isset($_POST["shipping_module_bycountry_byzone_country"]) ? $_POST["shipping_module_bycountry_byzone_country"] : 0;

	$curr_country = (int) $curr_country;

	if(!$curr_country){

	

		$curr_country = xGetData('SXshipping_module_bycountry_byzone_countryPERC');

	}

	xSaveData('SXshipping_module_bycountry_byzone_countryPERC',$curr_country);*/

	

	$module_id = isset($_GET['setting_up'])?$_GET['setting_up']:0;

	$ModuleConfig = modGetModuleConfig($module_id);

	if(!$ModuleConfig['ModuleClassName'])$module_id = 0;



	if ( isset($_POST["savesetting"]) )

	{  

       db_query("DELETE FROM ".CSHIPPINGMODULEIRANPOST_TABLE." where module_id=".$module_id);  			    

	    for ($i=-1;$i<5 ;$i++ ) {       	  	               

	    			$sql = 'INSERT INTO '.CSHIPPINGMODULEIRANPOST_TABLE.' 

							(module_id,rate_incity, rate_inzone, rate_nearzone, rate_farzone , weight_type) 

							VALUES ('.$module_id.', '.intval($_POST['rateincity'][$i]).', '.intval($_POST['rateinzone'][$i]).', '.intval($_POST['ratenearzone'][$i]).', '.intval($_POST['ratefarzone'][$i]).', '.$i.')';

						  db_query($sql) or die (db_error());     	                   

     }  			

	} 

 	

  $sql='select * from '.CSHIPPINGMODULEIRANPOST_TABLE.' WHERE module_id="'.$module_id.'" order by weight_type';

  $res=db_query($sql) or die (db_error());

  while ($row=db_fetch_row($res))

  {

    $rateincity[$row['weight_type']]=$row['rate_incity'];

    $rateinzone[$row['weight_type']]=$row['rate_inzone'];

    $ratenearzone[$row['weight_type']]=$row['rate_nearzone'];

    $ratefarzone[$row['weight_type']]=$row['rate_farzone'];

     

  }

  

  $res = "<table border=1 cellpadding=5 class=grid style=font-size:11px; bgcolor=#888888>\n<tr class=gridsheader>\n<th>".CSHIPPINGMODULEIRANPOST_CFG_WIGHT."</th><th>".CSHIPPINGMODULEIRANPOST_CFG_INCITY."</th><th>".CSHIPPINGMODULEIRANPOST_CFG_INZONE."</th><th>".CSHIPPINGMODULEIRANPOST_CFG_NEARZONE."</th><th>".CSHIPPINGMODULEIRANPOST_CFG_FARZONE."</th>\n</tr>";

  $res .="<tr bgcolor=white><td>".CSHIPPINGMODULEIRANPOST_CFG_TO250."</td><td><input type=text name=rateincity[0] value=".$rateincity[0]."></td>	<td><input type=text name=rateinzone[0] value=".$rateinzone[0]."></td><td><input type=text name=ratenearzone[0] value=".$ratenearzone[0]."></td><td><input type=text name=ratefarzone[0] value=".$ratefarzone[0]."></td></tr>";

  $res .="<tr bgcolor=white><td>".CSHIPPINGMODULEIRANPOST_CFG_TO500."</td><td><input type=text name=rateincity[1] value=".$rateincity[1]."></td>	<td><input type=text name=rateinzone[1] value=".$rateinzone[1]."></td><td><input type=text name=ratenearzone[1] value=".$ratenearzone[1]."></td><td><input type=text name=ratefarzone[1] value=".$ratefarzone[1]."></td></tr>";

  $res .="<tr bgcolor=white><td>".CSHIPPINGMODULEIRANPOST_CFG_TO1000."</td><td><input type=text name=rateincity[2] value=".$rateincity[2]."></td>	<td><input type=text name=rateinzone[2] value=".$rateinzone[2]."></td><td><input type=text name=ratenearzone[2] value=".$ratenearzone[2]."></td><td><input type=text name=ratefarzone[2] value=".$ratefarzone[2]."></td></tr>";

  $res .="<tr bgcolor=white><td>".CSHIPPINGMODULEIRANPOST_CFG_TO2000."</td><td><input type=text name=rateincity[3] value=".$rateincity[3]."></td>	<td><input type=text name=rateinzone[3] value=".$rateinzone[3]."></td><td><input type=text name=ratenearzone[3] value=".$ratenearzone[3]."></td><td><input type=text name=ratefarzone[3] value=".$ratefarzone[3]."></td></tr>";

  $res .="<tr bgcolor=white><td>".CSHIPPINGMODULEIRANPOST_CFG_FROM2000."</td><td><input type=text name=rateincity[-1]  value=".$rateincity[-1]."></td>	<td><input type=text name=rateinzone[-1] value=".$rateinzone[-1]."></td><td><input type=text name=ratenearzone[-1] value=".$ratenearzone[-1]."></td><td><input type=text name=ratefarzone[-1] value=".$ratefarzone[-1]."></td></tr>";

  $res .="</table>";

  

	//show toggle + zones

	

	$res .= "</table>";		



	return $res;

}



	function uninstall($_ModuleConfigID = 0){



		ShippingRateCalculator::uninstall($_ModuleConfigID);

		

		if(!count(modGetModuleConfigs(get_class($this)))){

			

			//drop shipping rates table

			db_query('DROP TABLE IF EXISTS '.CSHIPPINGMODULEIRANPOST_TABLE);

		}else {

			

			$sql = '

				DELETE FROM '.CSHIPPINGMODULEIRANPOST_TABLE.' WHERE module_id="'.$this->ModuleConfigID.'"

			';

		}

	}

}



?>
