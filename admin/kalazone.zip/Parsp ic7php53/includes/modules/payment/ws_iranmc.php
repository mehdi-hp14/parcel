<?php
/*****************************************************************************
 *                                                                           *
 * www.parsp.com                                                       *
 * Copyright (c) 2015 . All rights reserved.                                 *
 *                                                                           *
 *****************************************************************************/

/**
 * @connect_module_class_name CwebIranmc
 *
 */
 
define('CIRANMC_DB_TABLE', DBTABLE_PREFIX.'_module_payment_iranmc');

class CwebIranmc extends PaymentModule{
	
	function _initVars(){
		$this->title 		= CWEBSERVICE_IRANMC_TTL;
		$this->description 	= CWEBSERVICE_IRANMC_DSCR;
		$this->sort_order 	= 0;
		$this->Settings = array(
				"CONF_PAYMENTMODULE_IRANMC_USER_ID", 
				"CONF_PAYMENTMODULE_IRANMC_PASSWORD",
				"CONF_PAYMENTMODULE_IRANMC_VENDOR_ID",
				"CONF_PAYMENTMODULE_IRANMC_DOMAIN",
				"CONF_PAYMENTMODULE_IRANMC_RLS_CURRENCY",  
		);						
	}

  function _initSettingFields(){

		$this->SettingsFields['CONF_PAYMENTMODULE_IRANMC_USER_ID'] = array(
			'settings_value' 		=> 'tester', 
			'settings_title' 			=> CWEBSERVICE_ACCOUNT_TTL, 
			'settings_description' 	=> CWEBSERVICE_ACCOUNT_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		$this->SettingsFields['CONF_PAYMENTMODULE_IRANMC_PASSWORD'] = array(
			'settings_value' 		=> 'tester', 
			'settings_title' 			=> CWEBSERVICE_PASSWORD_TTL, 
			'settings_description' 	=> CWEBSERVICE_PASSWORD_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		$this->SettingsFields['CONF_PAYMENTMODULE_IRANMC_VENDOR_ID'] = array(
			'settings_value' 		=> '51080523', 
			'settings_title' 			=> CWEBSERVICE_VENDORID_TTL, 
			'settings_description' 	=> CWEBSERVICE_VENDORID_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);                      
		$this->SettingsFields['CONF_PAYMENTMODULE_IRANMC_DOMAIN'] = array(
			'settings_value' 		=> 'http://www.webimc.info/Webservice/wsdl.php',
			'settings_title' 			=> CWEBSERVICE_WEBSERVICEADDRESS_TTL , 
			'settings_description' 	=> CWEBSERVICE_WEBSERVICEADDRESS_DSCR ,
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,',
			'sort_order' 			=> 1,
		);
		$this->SettingsFields['CONF_PAYMENTMODULE_IRANMC_RLS_CURRENCY'] = array(
			'settings_value' 		=> '1',
			'settings_title' 			=> CWEBSERVICE_CURRENCY_TTL,
			'settings_description' 	=> CWEBSERVICE_CURRENCY_DSCR,
			'settings_html_function' 	=> 'setting_CURRENCY_SELECT(', 
			'sort_order' 			=> 1,
		);		
			
			if(!db_table_exists(CIRANMC_DB_TABLE)){
			$sql = 'CREATE TABLE '.CIRANMC_DB_TABLE.' 
		(`module_id` int(10) unsigned default NULL,
  		`orderID` int(11) default NULL,
  		`final_code` varchar(64) default NULL,
  		`order_amount_string` varchar(64) default NULL,
  		`weight` varchar(64) default NULL,  		
  		`order_comment` varchar(64) default NULL
		) DEFAULT CHARSET=utf8';
			db_query($sql);
		}
	}
  
  function _convertmeasurement( $_Units, $_From, $_To )
    {
        switch ( strtolower( $_From )."_".strtolower( $_To ) )
        {
        case "kg_g" :
         $_Units = $_Units * 1000;
         break;   
        case "lb_kg" :
        case "lbs_kgs" :
        case "lbs_kg" :
        case "lb_kgs" :
            $_Units /= 2.2046;
            break;
        case "kg_lb" :
        case "kg_lbs" :
        case "kgs_lb" :
        case "kgs_lbs" :
            $_Units *= 2.2046;
            break;
        case "g_lb" :
        case "g_lbs" :
            $_Units = $_Units / 1000 * 2.2046;
            break;
        case "lb_g" :
        case "lbs_g" :
            $_Units = $_Units / 2.2046 * 1000;
            break;
        case "g_kg" :
        case "g_kgs" :
            $_Units /= 1000;
        }
        return $_Units;
    }
    
  function payment_form_html($address,$customer){
    $userid = $this->_getSettingValue('CONF_PAYMENTMODULE_IRANMC_USER_ID');
    $password = $this->_getSettingValue('CONF_PAYMENTMODULE_IRANMC_PASSWORD');
    $wsdl =$this->_getSettingValue('CONF_PAYMENTMODULE_IRANMC_DOMAIN'); 
     		
    $cartContent = cartGetCartContent();        				
		$TotalPrice=$cartContent['total_price'];
		$TC = count($cartContent['cart_content']);            
    
		$OrderWeight = $this->_convertmeasurement($this->_getOrderWeight($cartContent),_getSettingOptionValue("CONF_WEIGHT_UNIT"),"g");
    		
    $cart_content=$cartContent['cart_content'];     
    
    if (!isset($address['cityID']))
      $city = ctGetSingleCityById($_SESSION['receiver_cityID']);
    else
      $city = ctGetSingleCityById($address['cityID']);
       
    $city = $city['city_code'];
    
    $zone= znGetSingleZoneById($address['zoneID']);
    $zone= $zone['zone_codeim'];     
    $_SESSION['ir_city']=$city;
    $_SESSION['ir_zone']=$zone;
        
            require_once('nusoap/nusoap.php');
      try{
            $client = new nusoap_client($wsdl,true,false,$wsdl,80,$userid,$password);            
            $client->setEndpoint($apiPath);                                                              
            $client->setCredentials($userid,$password,'basic');
            $client->setUseCurl(true);
            $client->useHTTPPersistentConnection();
            $client->setCurlOption(CURLOPT_USERPWD, $userid.':'.$password);
            $client->loadWSD;             
            $client->setCredentials($userid, $password);
            $proxy = $client->getProxy();                                        
  }
            catch (SoapFault $sf) {
                echo $sf->faultcode."\n";
                echo $sf->faultstring."\n";
            }
    
    if (!isset($client))
    {       
      return CWEBSERVICE_ERRORINCONNECTION;
    }
    try{
          $response0 = $client->call('GetSendPrice',array($TotalPrice,$OrderWeight,$zone,$city,0));
          $response1 = $client->call('GetSendPrice',array($TotalPrice,$OrderWeight,$zone,$city,1));
          $response2 = $client->call('GetSendPrice',array($TotalPrice,$OrderWeight,$zone,$city,2));
    }
    catch (SoapFault $sf) {
          echo $sf->faultcode."\n";
          echo $sf->faultstring."\n";
    } 
    		
        			                    

$res='
        <table cellpadding="5" cellspacing="0" dir="rtl">
			<tbody >
      <tr>
				<td colspan="3" align="right">نوع سفارش را با توجه به شرايط موجود انتخاب کنيد.</td>
	</tr>';
	    if (!is_array($response0))
	    {
      $res .='<tr>
		<td valign="middle"><input name="ship_type" value="0" id="ship_type" type="radio" checked="checked" ></td>
				<td align="right" valign="middle"><label for="paymtd-cc" valign="middle"><strong> پست پيشتاز </strong></label></td>
				<td>
        <table dir="rtl">
        <tr><td> هزينه پست:</td><td align="left">'.show_price($response0,CONF_DEFAULT_CURRENCY,CONF_DEFAULT_CURRENCY,1).'</td></tr>
         </table>
         </td>
	</tr>';
	}
	if (!is_array($response1))
	  $res.='<tr>
		<td valign="top"><input name="ship_type" value="1" id="ship_type" type="radio"></td>
				<td align="right"><label for="paymtd-online"><strong>پست سفارشي</strong><br></label></td>
				<td>
        <table dir="rtl">
        <tr><td> هزينه پست:</td><td align="left">'.show_price($response1,CONF_DEFAULT_CURRENCY,CONF_DEFAULT_CURRENCY,1).'</td></tr>
         </table>        
        </td>
	</tr>';
	$res.='<tr>
	<td>
	شماره تلفن :<br> به همراه کد شهرستان
	</td>
	<td>
    <input type="text" name="phonenumber" id="phonenumber" value="" onChange="return Validate()">	
	</td>
	<td>
	وزن :'.$OrderWeight.'گرم<br>
	</td>			
			</tbody></table>';                    
        
        return $res;      
	}	
	
	function payment_process($order){
  	
	  $userid = $this->_getSettingValue('CONF_PAYMENTMODULE_IRANMC_USER_ID');
    $password = $this->_getSettingValue('CONF_PAYMENTMODULE_IRANMC_PASSWORD');
    $wsdl =$this->_getSettingValue('CONF_PAYMENTMODULE_IRANMC_DOMAIN');     		    				    
    $post_type= $_POST['ship_type'];
    $phone= $_POST['phonenumber'];
    $comment= $_POST['order_comment'];
    $name= $order['shipping_info']['first_name'];
    $family=$order['shipping_info']['last_name'];
    $email = $order['customer_email'];
    $postal_code =$order['shipping_info']['zip'];
    $address=$order['shipping_info']['address'];
    $ip=$order['customer_ip'];
    //$city = ctGetSingleCityById($order['shipping_info']['cityID']);
    $city = $_SESSION['ir_city'];//$city['city_code'];
    //$zone= znGetSingleZoneById($order['shipping_info']['zoneID']);
    $zone= $_SESSION['ir_zone'];//$zone['zone_codeim'];     
    
    $cartContent = cartGetCartContent();
		$cart_content =$cartContent['cart_content'];
		$order_amount = $cartContent["total_price"];	
		if ( $this->_getSettingValue('CONF_PAYMENTMODULE_IRANMC_RLS_CURRENCY') > 0 )
		{
      $PAcurr= currGetCurrencyByID($this->_getSettingValue('CONF_PAYMENTMODULE_IRANMC_RLS_CURRENCY')); 
		  $PAcurr_rate = $PAcurr["currency_value"];
    }
		if (!isset($PAcurr) || !$PAcurr)
		{
			$PAcurr_rate = 1;
		}  
			
          			    
	     $order_amount = round($order_amount/$PAcurr_rate,2);
    		
       if(!count($cart_content))return 'Empty cart';
       foreach ($cart_content as $cart_item){              
        $product = GetProduct($cart_item['productID']);
        $Quantity=$cart_item['quantity'];
        $resDiscount = dscCalculateDiscount( $cart_content["total_price"], isset($_SESSION["log"])?$_SESSION["log"]:"" );
        if($resDiscount['discount_standart_unit']>0&&false){
			   			 $discount_amount = SHIPPING::_convertCurrency($resDiscount['discount_standart_unit'],0, $currency['currency_iso_3']);
			         $discount_amount = RoundFloatValue($discount_amount);
			         $discountDescription = '';
			         if(CONF_DSC_COUPONS_ENABLED){
				          ClassManager::includeClass('discount_coupon');
				          $discountDescription =discount_coupon::getCurrentCoupon();
			         }
			           $ItemDescription->setData($discountDescription?$discountDescription:'');			
			   }        
        $prd_name=$product['name'];  
        $prd_price = round($cart_item['costUC']*$PAcurr_rate,2);


        // $prd_price = round($product['Price']/$PAcurr_rate,2);
        $prd_id=$product['product_code']; 
        $prd_price=$prd_price-$discount_amount;        			        
        $Torder=$prd_id.'^'.$prd_name.'^'.$prd_price.'^'.$product['weight'].'^'.$Quantity;
        $Orders.=$Torder.';';
        }
        
		        require_once('nusoap/nusoap.php');
       try{ 
            $client = new nusoap_client($wsdl,true,false,$wsdl,80,$userid,$password);
            $client->xml_encoding = "UTF-8";
	          $client->soap_defencoding = "UTF-8";
	          $client->decode_utf8 = false;            
            $client->setEndpoint($apiPath);                                                              
            $client->setCredentials($userid,$password,'basic');
            $client->setUseCurl(true);
            $client->useHTTPPersistentConnection();
            $client->setCurlOption(CURLOPT_USERPWD, $userid.':'.$password);
            $client->loadWSD;             
         //   $client->setCredentials($userid, $password);
            $proxy = $client->getProxy();                                        
            
        if (!isset($client))
        {           
          return CWEBSERVICE_ERRORINCONNECTION;
        }
        
          
		        $params=array(
            'Name'=>$name,
            'LastName'=>$family,
            'Company'=>'',
            'JobTel'=>'',
            'HomeTel'=>$phone,
            'Mobile'=>'',
            'Email'=>$email,
            'ZipCode'=>$postal_code,
            'Address'=>$address,
            'Comment'=>$comment,
            'Orders'=>$Orders,
            'OstanId'=>$zone,
            'ShahrId'=>$city,    
            'SendType'=>$post_type
            );          

          $finalcode =$client->call('RegisterOrder',$params);
          
          if (is_array($finalcode))
          {          
          switch ($finalcode['faultcode']) 
          { 
          case '1':
              $errstr="نام کاربري يا رمز عبور صحيح برای ارتباط وارد شود";
              break;
          case 2:
              $errstr="اشتباه در ارسال محصولات(استفاده از ; بعد در توضيحات محصول الزامي است)";
              break;
          case 3:
              $errstr="اشتباه در شناسه شهر و استان رفع شود";
              break;
          case 4:
              $errstr="وارد کردن نام و نام خانوادگي و آدرس الزامي است";
              break;
          case '5':
              $errstr="حداقل يک شماره تلفن قيد شود";
              break;
          case 6:
              $errstr="ايميل بدرستي وارد نشده است";
              break;
          case 7:
              $errstr="مشخصات کالا صحيح نيست";
              break;
          case 8:
              $errstr="نوع ارسال بدرستي انتخاب نشده است";
              break;
          case 9:
              $errstr="شناسه سفارش معتبر نيست";
              break;                                                                      
          }
          
          $errstr=' <div style=" display:        table-cell;width:          100%;height:         100%;background:     #000;text-align:     center;vertical-align: middle;font-size:      14px;color:          white;"><p>در فرآيند انتقال اطلاعات به ایران مارکت سنتر مشکلی پیش آمده است.</p> '. $errstr .'</div>';          
          return $errstr.": اطلاعات وارد شده اشتباه است";        

          }
        }
        catch (SoapFault $sf) {
          $errorcode= $sf->faultcode;
        } 
                    
        if ( !$errorcode==0){
          switch ($errorcode) { 
          case 1:
              $errstr="نام کاربري يا رمز عبور صحيح نيست";
              break;
          case 2:
              $errstr="اشتباه در ارسال محصولات(استفاده از ; بعد در توضيحات محصول الزامي است)";
              break;
          case 3:
              $errstr="اشتباه در شناسه شهر و استان";
              break;
          case 4:
              $errstr="وارد کردن نام و نام خانوادگي و آدرس الزامي است";
              break;
          case 5:
              $errstr="حداقل يک شماره تلفن قيد شود";
              break;
          case 6:
              $errstr="ايميل بدرستي وارد نشده است";
              break;
          case 7:
              $errstr="مشخصات کالا صحيح نيست";
              break;
          case 8:
              $errstr="نوع ارسال بدرستي انتخاب نشده است";
              break;
          case 9:
              $errstr="شناسه سفارش معتبر نيست";
              break;                                                                      
          }
          return $errstr.": اطلاعات وارد شده اشتباه است";
        }
        //session_start();
        $_SESSION['orderamount']=$order_amount;
        $_SESSION['finalcode']=$finalcode;       
                                               				
		    return 1;		    
                
	}
	
  function after_processing_php($order_id){
        $finalcode=$_SESSION['finalcode'];
        $order_amount=$_SESSION['orderamount'];        
        $dbq = "INSERT INTO ?#CIRANMC_DB_TABLE (module_id, orderID,final_code, order_amount_string) VALUES (?,?,?,?)";
        db_phquery($dbq,$this->ModuleConfigID, $order_id,$finalcode,$order_amount);
       // $comStatID = _getSettingOptionValue('CONF_BANKBILLED_ORDER_STATUS');                                                                              
  		 // ostSetOrderStatusToOrder($order_id, $comStatID,"کدرهگيري ايران مارکت سنتر : ".$_SESSION['finalcode'] );        
        return "";			
  }

	function after_processing_html( $orderID ) 
	{
  $userid = $this->_getSettingValue('CONF_PAYMENTMODULE_IRANMC_USER_ID');
  $password = $this->_getSettingValue('CONF_PAYMENTMODULE_IRANMC_PASSWORD');
  $wsdl =$this->_getSettingValue('CONF_PAYMENTMODULE_IRANMC_DOMAIN'); 
	$order = ordGetOrder( $orderID );
	$selstr="select * from ".CIRANMC_DB_TABLE." where orderID=".$orderID." AND module_id='{$this->ModuleConfigID}'";
	$q = db_query($selstr);
	$row = db_fetch_row($q);
  $finalcode= $row['final_code'];
  $order_id=$orderID;
		       
            require_once('nusoap/nusoap.php');
            $client = new nusoap_client($wsdl,true,false,$wsdl,80,$userid,$password);            
            $client->setEndpoint($apiPath);                                                              
            $client->setCredentials($userid,$password,'basic');
            $client->setUseCurl(true);
            $client->useHTTPPersistentConnection();
            $client->setCurlOption(CURLOPT_USERPWD, $userid.':'.$password);
            $client->loadWSD;             
            $client->setCredentials($userid, $password);
            $proxy = $client->getProxy();                                        
    if (!isset($client))
    {
      echo CWEBSERVICE_ERRORINCONNECTION;
      return 0;
    }
       $param = array('FactorKey'=>$finalcode);
       $tracking=$client->call('GetState',$param);
	        switch ($tracking) {                               
          case 0:
          $status="معلق";
          break;
          case 1:
          $status="آماده ارسال";
          break;
          case 2:
          $status="ارسال شده";
          break;
          case 3:
          $status="توزیع شده";
          break;
          case 4:
          $status="وصول شده";
          break;
          case 5:
          $status="برگشتي";
          break;
          case 6:
          $status="انصرافی";
          break;
          }
  
	$order_amount = show_price($order['order_amount'],$this->_getSettingValue('CONF_PAYMENTMODULE_BANKBILL_RLS_CURRENCY'));
	$res .= 'شماره سفارش: <b>'.$orderID.'</b><br>';
	$res .= 'مبلغ کل بدون هزينه حمل و نقل: <b>'.$order_amount.'</b></br>';
	$res .="<br>";
  //$res .= '<b>'.show_price($row['order_amount_string']).'</b><br><br>';       	
	$res .= "<b>شماره پيگيري سفارش : <br>".$finalcode."</b>";  						
	$res .= "<br><b>وضعيت سفارش : <span style='color:red'>".$status."</span></b>";

    
  $dbq = "INSERT INTO ?#CIRANMC_DB_TABLE (module_id, orderID,final_code, order_amount_string) VALUES (?,?,?,?)";
  db_phquery($dbq,$this->ModuleConfigID, $order_id,$finalcode,$order_amount);
 // $comStatID = _getSettingOptionValue('CONF_BANKBILLED_ORDER_STATUS');                                                                              
 // ostSetOrderStatusToOrder($order_id, $comStatID,"کدرهگيري ايران مارکت سنتر : ".$finalcode );
  
  		return "<center><div style=\"border: 1px solid #CCCCCC; background-color: #EEEEEE; width: 70%; padding: 10px\" align=\"center\">".$res."</div></center>";  
	}		
	
	function _getOrderWeight(&$Order){
    
		$TC = count($Order['cart_content']);
		$OrderWeight = 0;
		$ShippingProducts = 0;

		for( $i = 0; $i<$TC; $i++ ){
    				
			$Product = GetProduct($Order['cart_content'][$i]['productID']);      
			if($Product['free_shipping'])continue;
			$ShippingProducts++;
			if(!isset($Product['weight']))continue;
			if(!$Product['weight'])continue;
			$OrderWeight += $Order['cart_content'][$i]['quantity']*$Product['weight'];
		}
		if($OrderWeight<=0 && $ShippingProducts)$OrderWeight=0.1;
        
		return $OrderWeight;
	}
}
?>