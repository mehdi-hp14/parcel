<?php
	// bankpasargad payment module
	// http://www.bankpasargad.com

/**
 * @connect_module_class_name CPASARGAD
 *
 */

class CPasargad extends PaymentModule{
	
	
	function _initVars(){
			
		$this->title 		= CPASARGAD_TTL;
		$this->description 	= CPASARGAD_DSCR;
		$this->sort_order 	= 1;
		
		$this->Settings = array( 
      "CONF_PAYMENTMODULE_PASARGAD_TERMINAL",		
			"CONF_PAYMENTMODULE_PASARGAD_MERCHANT",
			"CONF_PAYMENTMODULE_PASARGAD_RLS_CURRENCY"
			);
	}

	function after_processing_html( $orderID ) 
	{
		$order = ordGetOrder( $orderID );
		if ( $this->_getSettingValue('CONF_PAYMENTMODULE_PASARGAD_RLS_CURRENCY') > 0 )
		{
			$SAcurr = currGetCurrencyByID ( $this->_getSettingValue('CONF_PAYMENTMODULE_PASARGAD_RLS_CURRENCY') );
			$SAcurr_rate = $SAcurr["currency_value"];
		}
		if (!isset($SAcurr) || !$SAcurr)
		{
			$SAcurr_rate = 1;
		}
		
		$modID =  $this ->get_id();
		$amount = round(100*$order["order_amount"] * $SAcurr_rate)/100;
    $certificate="certificate.xml";
    $invoiceNumber= $orderID;
        
    require_once("RSA/RSAProcessor.class.php");
    $processor = new RSAProcessor("<RSAKeyValue><Modulus>mzU4EP4rA/oNrks61y5RIpgch2CfbWUUh3E4NSg/UPfwUMCw9X8QkIP8QuD1Q74sRIzjgHR745DMoHYNaETqUP31Npl3iOusbS0aFn2C7LWa4G7xNZHS6ySwgXOj0tcwa89XDilG/xK/mbSjjZ4G4wExSY1ZJTYbmq466rkiB6c=</Modulus><Exponent>AQAB</Exponent><P>x77HtFGRBNJ7LY9HJdu4ZCAX6Di//B4IpCD9utADz39RTxAOWlegTkmu73t1HwqJUIMP/XGdBQQKGs5izFFbHw==</P><Q>xutjTCnkpYZbDHLmEszoDmB8o9HnnLDJ/zcm25i+6gK0B7UfdzmCadHsuo9GSS1/w5WAOmOrUHIiktpsCclKeQ==</Q><DP>N25HJ1A3aVor2sHXIbdu3UJWwBf3lzSSe1G4d/5AAHY5jzJKeWG11+P0yvq8zudyocgtSM0doQW09ClwG3k8Sw==</DP><DQ>FBu9ePiPLZBsadC/o0zldHaagvD4KeXRNaR8oBxLyFonmtPbb3D31vyqop1TLJiV3s6hHMXwjnxLNG8yFrcreQ==</DQ><InverseQ>SRwLOAgLDH04+UQjXfoQsHBJX3gnAMVt6rJMMUxPMWpAtCyK0SkGoFjWEpRefH0DUOl64joyE8IwxE1nmXtc6A==</InverseQ><D>T7vzZadtacmYJaY4QDtnKyKB5XpZ7NU0yq/7dDOM84esSY/0WOpCFDv56FGxLnAQRdcrON6elrXYqcZ79MkSpmRCZV7egPXaf327FvdsPilq5PlYAC+hTwWD45Ezun/FDJd8OYhVwTI/dU70W2mRLpuDTBMGfv5Zfj2E0ha7wEE=</D></RSAKeyValue>",RSAKeyType::XMLString);
    $timeStamp = date("Y/m/d H:i:s");
    $invoiceDate = date("Y/m/d H:i:s"); // تاريخ فاآتور
    $action = "1003"; // براي درخواست خريد : 1003
    $merchantCode=$this->_getSettingValue('CONF_PAYMENTMODULE_PASARGAD_MERCHANT');
    $terminalCode=$this->_getSettingValue('CONF_PAYMENTMODULE_PASARGAD_TERMINAL');
    $redirectAddress=CONF_FULL_SHOP_URL."?PASARGAD&modID=$modID";
    $data = "#". $merchantCode ."#". $terminalCode ."#". $invoiceNumber ."#". $invoiceDate
    ."#". $amount ."#". $redirectAddress ."#". $action ."#". $timeStamp ."#";
    $data = sha1($data,true);
    $data = $processor->sign($data); // امضاي ديجيتال
    $result = base64_encode($data); // base64_encode



		$res = "";

		$res .= 
			"<table width='100%'>\n".
			"	<tr>\n".
			"		<td align='center'>\n".
			"<form method='POST' action='https://pep.shaparak.ir/gateway.aspx'>\n".
      "<input type=\"hidden\" name=\"terminalCode\" value=\"".$terminalCode."\">\n".			
			"<input type=\"hidden\" name=\"merchantCode\" value=\"".$merchantCode."\">\n".
			"<input type=\"hidden\" name=\"amount\" value=\"".$amount."\">\n".
			"<input type=\"hidden\" name=\"redirectAddress\" value=\"".$redirectAddress."\">".
			"<input type=\"hidden\" name=\"invoiceNumber\" value=\"".$orderID."\">\n".
			"<input type=\"hidden\" name=\"invoiceDate\" value=\"".$invoiceDate."\">\n".
			"<input type=\"hidden\" name=\"timeStamp\" value=\"".$timeStamp."\">\n".
			"<input type=\"hidden\" name=\"action\" value=\"".$action."\">\n".
			"<input type=\"hidden\" name=\"sign\" value=\"".$result."\">\n".
			"<input type=\"submit\" name=\"PAYMENT_METHOD\" value=\"".CPASARGAD_TXT_1."\">\n".		
			"		</td>\n".
			"	</tr>\n".
			"</table>";
			
		return $res;
	}

	function _initSettingFields(){
	
	  $this->SettingsFields['CONF_PAYMENTMODULE_PASARGAD_TERMINAL'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CPASARGAD_CFG_TERMINAL_CODE_TTL, 
			'settings_description' 	=> CPASARGAD_TERMINAL_CODE_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		
		$this->SettingsFields['CONF_PAYMENTMODULE_PASARGAD_MERCHANT'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CPASARGAD_CFG_MERCHANT_ACCOUNT_TTL, 
			'settings_description' 	=> CPASARGAD_CFG_MERCHANT_ACCOUNT_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 2,
		);

		$this->SettingsFields['CONF_PAYMENTMODULE_PASARGAD_RLS_CURRENCY'] = array(
			'settings_value' 		=> '0', 
			'settings_title' 			=> CPASARGAD_CFG_RLS_CURRENCY_TTL, 
			'settings_description' 	=> CPASARGAD_CFG_RLS_CURRENCY_DSCR, 
			'settings_html_function' 	=> 'setting_CURRENCY_SELECT(', 
			'sort_order' 			=> 3,
		);
	}
}
?>