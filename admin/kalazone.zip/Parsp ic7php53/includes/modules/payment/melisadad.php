<?php
// sadad payment module
// http://www.bmi.com	

/**
 * @connect_module_class_name CSADAD
 *
 */

class CSADAD extends PaymentModule{

		private $_webURL;		
		private $_webURLVerify;		
		
        	
	function _initVars(){
			
		$this->title 		= CSADAD_TTL;
		$this->description 	= CSADAD_DSCR;
		$this->sort_order 	= 1;
		
		$this->_webURL = 'https://sadad.shaparak.ir/services/MerchantUtility.asmx?wsdl';				
    $this->_webURLVerify = 'https://sadad.shaparak.ir/services?wsdl';		
		
		$this->Settings = array( 
      "CONF_PAYMENTMODULE_SADAD_TRANSACTIONKEY",      		
			"CONF_PAYMENTMODULE_SADAD_CARDACQID",
			"CONF_PAYMENTMODULE_SADAD_TERMINALID",
			"CONF_PAYMENTMODULE_SADAD_RLS_CURRENCY"
			);
	}

  
	function after_processing_html( $orderID ) 
	{
    
  
		$order = ordGetOrder( $orderID );
		if ( $this->_getSettingValue('CONF_PAYMENTMODULE_SADAD_RLS_CURRENCY') > 0 )
		{
			$SAcurr = currGetCurrencyByID ( $this->_getSettingValue('CONF_PAYMENTMODULE_SADAD_RLS_CURRENCY') );
			$SAcurr_rate = $SAcurr["currency_value"];
		}
		if (!isset($SAcurr) || !$SAcurr)
		{
			$SAcurr_rate = 1;
		}
		
		$modID =  $this ->get_id();
		$order_amount = round(100*$order["order_amount"] * $SAcurr_rate)/100;
      

     
  $_SESSION['CardAcqID'] = $this->_getSettingValue('CONF_PAYMENTMODULE_SADAD_CARDACQID'); 
	$_SESSION['TerminalId'] = $this->_getSettingValue('CONF_PAYMENTMODULE_SADAD_TERMINALID');
	$_SESSION['TransactionKey'] = $this->_getSettingValue('CONF_PAYMENTMODULE_SADAD_TRANSACTIONKEY');
	$_SESSION['OrderId'] = $orderID;
	$_SESSION['AmountTrans'] =$order_amount;
	$_SESSION['ReturnURL'] = CONF_FULL_SHOP_URL."?sadad&modID=$modID";;

		
    require_once("nusoap/nusoap.php");
      	
    $soapclient = new nusoap_client($this->_webURL,'wsdl');
	  $soapProxy = $soapclient->getProxy();    
    
 		$soapresult=$soapProxy->PaymentUtility($_SESSION['CardAcqID'],$order_amount,$orderID,$_SESSION['TransactionKey'],$_SESSION['TerminalId'],$_SESSION['ReturnURL']);
             
	  echo $soapProxy->getError();//If exists any errors    
    $req=$soapresult['RequestKey'];
        
   
  	$FormStr = $soapresult['PaymentUtilityResult'];         	
		

		$res = 
			"<table width='100%'>\n".
			"	<tr>\n".
			"		<td align='center'>\n".$FormStr.
      "<input type=\"submit\" name=\"PAYMENT_METHOD\" value=\"".CSADAD_TXT_1."\">\n</form>".		
			"		</td>\n".
			"	</tr>\n".
			"</table>"; 
      if (!isset($order['refnum']))
      {       
		    db_query( "update ".ORDERS_TABLE." set refnum='".$req."' where orderID=".$orderID);
        $_SESSION['requestnumber'] = $soapresult['RequestKey'];
     }                    		   
    //$_SESSION['req'] = $sresult['RequestKey'];	
			
		return $res;
	}

  	


	function _initSettingFields(){
	
		$this->SettingsFields['CONF_PAYMENTMODULE_SADAD_TRANSACTIONKEY'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CSADAD_CFG_TRANSACTIONKEY_TTL, 
			'settings_description' 	=> CSADAD_CFG_TRANSACTIONKEY_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		
		$this->SettingsFields['CONF_PAYMENTMODULE_SADAD_CARDACQID'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CSADAD_CFG_CARDACQID_TTL, 
			'settings_description' 	=> CSADAD_CFG_CARDACQID_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);

    $this->SettingsFields['CONF_PAYMENTMODULE_SADAD_TERMINALID'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CSADAD_CFG_TERMINALID_TTL, 
			'settings_description' 	=> CSADAD_CFG_TERMINALID_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		$this->SettingsFields['CONF_PAYMENTMODULE_SADAD_RLS_CURRENCY'] = array(
			'settings_value' 		=> '0', 
			'settings_title' 			=> CSADAD_CFG_RLS_CURRENCY_TTL, 
			'settings_description' 	=> CSADAD_CFG_RLS_CURRENCY_DSCR, 
			'settings_html_function' 	=> 'setting_CURRENCY_SELECT(', 
			'sort_order' 			=> 1,
		);
	}

  public function validate($modid)
  {
      //$MerchantId=$this->_getSettingValue('CONF_PAYMENTMODULE_SADAD_CARDACQID_'.$modid);
	    //$TerminalID=$this->_getSettingValue('CONF_PAYMENTMODULE_SADAD_TERMINALID_'.$modid);
	    //$TransactionKey=$this->_getSettingValue('CONF_PAYMENTMODULE_SADAD_TRANSACTIONKEY_'.$modid);
      
     
  }
    
  				
		
		
		
}
?>