<?php
/*****************************************************************************
 *                                                                           *
 * www.parsp.com                                                       *
 * Copyright (c) 2008 . All rights reserved.                                 *
 *                                                                           *
 *****************************************************************************/
?><?php
	// mellat payment module
	// http://www.mellat.com

/**
 * @connect_module_class_name CMellat
 *
 */

class CMellat extends PaymentModule{
	
	function _initVars(){
		
		$this->title 		= CMELLAT_TTL;
		$this->description 	= CMELLAT_DSCR;
		$this->sort_order 	= 1;
		
		$this->Settings = array( 
			"CONF_PAYMENTMODULE_MELLAT_TERMID",
			"CONF_PAYMENTMODULE_MELLAT_USERID",
			"CONF_PAYMENTMODULE_MELLAT_PASS",
			"CONF_PAYMENTMODULE_MELLAT_RIAL_CURRENCY"
			);
	}

	function after_processing_html( $orderID ) 
	{
	  $bankerrors=array(0=>'تراکنش با موفقیت انجام شد',11=>'شماره کارت نامعتبر است',
12=>'موجودی کافی نیست',
13=>'رمز نادرست است',
14=>'تعداد دفعات وارد کردن رمز از حد مجاز بیشتر است',
15=>'کارت نامعتبر است',
17=> 'کاربر از انجام تراکنش منصرف شده است',
18=> 'تاریخ انتقضای کارت گذشته است',
111=> 'صادر کننده کارت نامعتبر است',
112=> 'خطای سوییچ صادر کننده کارت',
113=> 'پاسخی از صادر کننده کارت دریافت نشد',
114=> 'دارنده کارت مجاز به انجام این تراکنش نیست',
21=> 'پذیرنده نامعتبر است',
22=> 'ترمینال مجوز ارائه سرویس درخواستی را ندارد',
23=> 'خطای امنیتی رخ داده است',
24=> 'اطلاعات کاربری پذیرنده نامعتبر است',
25=> 'مبلغ نامعتبر است',
31=> 'پاسخ نامعتبر است',
32=> 'فرمت اطلاعات وارد شده صحیح نمی باشد',
33=> 'حساب نامعتبر است',
34=> 'خطای سیستمی',
35=> 'تاریخ نامعتبر است',
41=> 'شماره درخواست تکراری است ',
42=> 'تراکنش Sale یافت نشد',
43=> 'قبلا درخواست Verify داده شده است',
44=> 'درخواست Verify  یافت نشد',
45=> 'تراکنش Settle  شده است',
46=> 'تراکنش Settle نشده است',
47=> 'تراکنش Settle  یافت نشد',
48=> 'تراکنش Reverse شده است',
49=> 'تراکنش Refound یافت نشد',
412=> 'شناسه قبض نادرست است',
413=> 'شناسه پرداخت نادرست است',
414=> 'سازمان صادر کننده قبض نامعتبر است',
415=> 'زمان جلسه کاری به پایان رسیده است',
416=> 'خطا در ثبت اطلاعات رخ داده است',
417=> 'شناسه پرداخت کننده نامعتبر است',
418=> 'اشکال در تعریف اطلاعات مشتری',
419=> 'تعداد دفعات ورود اطلاعات از حد مجاز گذشته است',
421=> 'IP نامعتبر است',
51=> 'تراکنش تکراری است',
52=> 'سرویس درخواستی موجود نمی باشد',
54=> 'تراکنش مرجع موجود نیست',
55=> 'تراکنش نامعتبر است',
61=> 'خطا در واریز',
80=> 'تراكنش موفق عمل نكرده است');
	
	  $bankserver='https://bpm.shaparak.ir/pgwchannel/services/pgw?wsdl';
	  
		$order = ordGetOrder( $orderID );
		if ( $this->_getSettingValue('CONF_PAYMENTMODULE_MELLAT_RIAL_CURRENCY') > 0 )
		{
			$Mellatcurr = currGetCurrencyByID ( $this->_getSettingValue('CONF_PAYMENTMODULE_MELLAT_RIAL_CURRENCY') );
			$Mellatcurr_rate = $Mellatcurr["currency_value"];
		}
		if (!isset($Mellatcurr) || !$Mellatcurr)
		{
			$Mellatcurr_rate = 1;
		}

		$order_amount = round(100*$order["order_amount"] * $Mellatcurr_rate)/100;
		
		$modID =  $this ->get_id();
		$callbackUrl = CONF_FULL_SHOP_URL."?mellat&modID=$modID";
		
		// start of mellat code //////////////////////////////////////////////////////////////////////////////////////////////////////////
		
		  require_once("nusoap/nusoap.php");			
			$client = new nusoap_client($bankserver,'wsdl');
			$err = $client->getError();
			if ($err)
				 {
				 echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
				 echo '<h2>Debug</h2><pre>' . htmlspecialchars($client->getDebug(), ENT_QUOTES) . '</pre>';
				 exit();
			     }
		
			$soapProxy  = $client->getProxy();
			$parameters = array(	'terminalId' => $this->_getSettingValue('CONF_PAYMENTMODULE_MELLAT_TERMID'),
			'userName' => $this->_getSettingValue('CONF_PAYMENTMODULE_MELLAT_USERID'),
			'userPassword' => $this->_getSettingValue('CONF_PAYMENTMODULE_MELLAT_PASS'),
			'orderId' => $orderID,
			'amount' => $order_amount,
			'localDate' => date("Ymd"),
			'localTime' => date("His"),
			'additionalData' => '' ,
			'callBackUrl' => $callbackUrl,
			'payerId' => "0");
			
			$result = $soapProxy->bpPayRequest($parameters);
			// Check for a fault
			if ($client->fault)
				 {
				 echo '<h2>Fault</h2><pre>';
				 print_r($result);
				 echo '</pre>';
			     }
			 else
					{					
					$res = explode (',',$result['return']);
                           settype($res[0],"string");
			   settype($res[1],"string");

			   $ResCode = $res[0];
			   $Hashcode = $res[1]; 
					if ($ResCode == "0") {
					
		$res = "";
		$res .= 
			"<table width='100%'>\n".
			"	<tr>\n".
			"		<td align='center'>\n".
			'<form  action="https://bpm.shaparak.ir/pgwchannel/startpay.mellat" method="post" class="block">
<input type="hidden" name="TerminalId" value="'.$parameters['terminalId'].'">
<input type="hidden" name="UserName"  value="'.$parameters['userName'].'">
<input type="hidden" name="UserPassword" value="'.$parameters['userPassword'].'">
<input type="hidden" name="PayDate" id="PayDate" value="'.$parameters['localDate'].'">
<input type="hidden" name="PayTime" id="PayTime" value="'.$parameters['localTime'].'">
<input type="hidden" name="PayPayerId" id="PayPayerId" value="'.$parameters['payerId'].'">
<input type="hidden" name="PayAdditionalData" id="PayAdditionalData" value="'.$parameters['additionalData'].'">
<input type="hidden" name="PayCallBackUrl" id="PayCallBackUrl" value="'.$parameters['callBackUrl'].'">
<input type="hidden" name="PayOrderId" id="PayOrderId" value="'.$parameters['orderId'].'">
<input type="hidden" name="PayAmount" id="PayAmount" value="'.$parameters['amount'].'">			
<input type="hidden" name="RefId" id="RefId" value="'.$Hashcode.'">'.
			"<input type=\"submit\" name=\"PAYMENT_METHOD\" value=\"".CMELLAT_TXT_1."\">\n".		
			"		</td>\n".
			"	</tr>\n".
			"</table>";
					}else {
					  $res="<p><center>";
						$res.="متاسفانه امکان پرداخت از طریق درگاه بانک ملت وجود ندارد ."."<br><br><b>"."دلیل :". $bankerrors[$ResCode].$Hashcode;
						$res.="</center></b></p>";
					}
				}
			
			
			// end of mellat //////////////////////////////////////////////////////////////////////////////////

		

		return $res;
	}

	function _initSettingFields(){

		
		$this->SettingsFields['CONF_PAYMENTMODULE_MELLAT_TERMID'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CMELLAT_CFG_TERMID_TTL, 
			'settings_description' 	=> CMELLAT_CFG_TERMID_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		
		
		$this->SettingsFields['CONF_PAYMENTMODULE_MELLAT_USERID'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CMELLAT_CFG_USERID_TTL, 
			'settings_description' 	=> CMELLAT_CFG_USERID_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		
		$this->SettingsFields['CONF_PAYMENTMODULE_MELLAT_PASS'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CMELLAT_CFG_PASS_TTL, 
			'settings_description' 	=> CMELLAT_CFG_PASS_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);

		$this->SettingsFields['CONF_PAYMENTMODULE_MELLAT_RIAL_CURRENCY'] = array(
			'settings_value' 		=> '0', 
			'settings_title' 			=> CMELLAT_CFG_RIAL_CURRENCY_TTL, 
			'settings_description' 	=> CMELLAT_CFG_RIAL_CURRENCY_DSCR, 
			'settings_html_function' 	=> 'setting_CURRENCY_SELECT(', 
			'sort_order' 			=> 1,
		);
	}
}
?>