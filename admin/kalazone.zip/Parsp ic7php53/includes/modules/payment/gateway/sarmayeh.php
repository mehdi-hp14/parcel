<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_GET['SARMAYEH'] )) {
		function checkpayment() {
			$bankerrors = array( '00' => 'تراکنش با موفقیت انجام شد', '01' => 'خطا در فرمت اطلاعات ارسالی', '02' => 'فروشگاه نامعتبر می باشد', '03' => 'تراکنش با وقفه ایجاد شده است', '04' => 'ای پی فروشگاه مجاز نیست', '05' => 'کد سفارش قبلا استفاده شده است', '06' => 'خطای داخلی در سیستم بانکی', '07' => 'تراکنش Void قبلا انجام شده است', '08' => 'وضعیت تراکنش خرید ، وارسی شده نمی باشد.', '09' => 'مبلغ تراکنش خرید با مبلغی که قرار است void شود برابر نیست.', '10' => 'تراکنش خرید یافت نشد.', '11' => 'فروشگاه مجوز تسویه انی ندارد', '12' => 'انصراف از خرید', '13' => 'pac معتبر نمی باشد' );

			if (( ( isset( $_GET['modID'] ) && isset( $_POST['reservationNum'] ) ) && isset( $_POST['merchantResponseCode'] ) )) {
				$modID = $_GET['modID'];
				$orderID = $_POST['rrn'];
				$rescode = $_POST['merchantResponseCode'];
				_getSettingOptionValue( 'CONF_COMPLETED_ORDER_STATUS' );
				$comStatID = require_once( './includes/modules/payment/nusoap/nusoap.php' );
				db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_SARMAYEH_USERID_' . $modID . '\'' ) );
				db_fetch_row( $q );

				if (!empty( $res['settings_value'] )) {
					$payment['username'] = $res['settings_value'];
				} 
else {
					Redirect( 'index.php' );
				}

				db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_SARMAYEH_NETUSERID_' . $modID . '\'' ) );
				db_fetch_row( $q );
				$res = $res = $_POST['reservationNum'];
				$net_user = $res['settings_value'];
				$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_SARMAYEH_NETPASS_' . $modID . '\'' ) );
				$res = db_fetch_row( $q );
				$res = $q = $net_pass = $q = $q = $rrn = $res['settings_value'];
				$payment['password'] = $res['settings_value'];
				db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_SARMAYEH_BANKURL_' . $modID . '\'' ) );
				db_fetch_row( $q );
				$res = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_SARMAYEH_PASS_' . $modID . '\'' ) );
				$res['settings_value'];
				$wsdl = db_fetch_row( $q );
				$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_SARMAYEH_SITE_ADDRESS_' . $modID . '\'' ) );
				$res = db_fetch_row( $q );
				$site_url = $q = $res['settings_value'];

				if (( $rescode == 0 && $order['StatusID'] != $comStatID )) {
					$order = _getOrderById( $orderID );
					$refID = $_POST['reservationNum'];
					$status = $rrn = $_POST['rrn'];
					$stan = $_POST['stan'];
					$_POST['amount'];
					$parameters = array( 'purchaseRRN' => $rrn, 'purchaseStan' => $stan, 'reservationNum' => $refID, 'userName' => $payment['username'], 'password' => $payment['password'], 'url' => $site_url );
					new nusoap_client( $wsdl, true, false, $wsdl, 80, $net_user, $net_pass );
					$client = $_POST['merchantResponseCode'];
					$client->setCredentials( $net_user, $net_pass, 'digest' );
					$client->getError(  );

					if (( !$client || $err = $amount =  )) {
						$error .= $err . '<br />';
						echo $error . ' Line:' . 80;
						echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
						echo '<h2>Debug</h2><pre>' . htmlspecialchars( $client->getDebug(  ), ENT_QUOTES ) . '</pre>';
						exit(  );
						print '<script type="text/javascript">';
						print 'alert("اطلاعات وارد شده برای اتصال به درگاه سرمایه اشتباه است مجددا اطلاعات را وارد کنید.")';
						print '</script>';
					}

					$soapProxy = $client->getProxy(  );
					$result = $client->call( 'paymentGatewayVerificationRequest', $parameters );
					$status = explode( ';', $result )[1];
					[0];
					$amount = ;

					if ($status != 0) {
						$body = 'پرداخت با موفقیت انجام نشد ، در صورتی که پول از حساب شما کسر شده باشد مجددا به حساب بازگشت داده  خواهد شد.<br>' . $bankerrors[$status];
					} 
else {
						$parameters = array( 'userName' => $payment['username'], 'password' => $payment['password'], 'url' => $site_url );
						$result = $client->call( 'paymentGatewayReconciliationRequest', $parameters );
						$pininfo = ostSetOrderStatusToOrder( $orderID, $comStatID, 'سفارش شما از طریق بانک سرمایه پرداخت شد ', 1 );
						$body = '<font color=\'green\'>با تشکر ، پرداخت به مبلغ ' . $amount . ' ریال با موفقیت انجام شد .</font><br>شماره پیگیری  :<b> ' . $stan . '</b><br>';
					}

					return $body;
				}
			}

		}

		$body = checkpayment(  );
		$smarty->assgin( 'payment_name', CSARMAYEH_TTL );
		$smarty->assign( 'page_body', $body );
		$smarty->assign( 'main_content_template', 'pay_result.tpl.html' );
	}

?>