<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_GET['eghtesadnovin'] )) {
		if (isset( $_GET['modID'] )) {
			$modID = $_GET['modID'];
			$orderID = $_POST['ResNum'];
			$comStatID = _getSettingOptionValue( 'CONF_COMPLETED_ORDER_STATUS' );
			$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_EGHTESADNOVIN_MERCHANT_ACCOUNT_' . $modID . '\'' ) );
			$res = db_fetch_row( $q );

			if (!empty( $res['settings_value'] )) {
				$mid = $res['settings_value'];
			} 
else {
				Redirect( 'index.php' );
			}

			$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_EGHTESADNOVIN_USERNAME_' . $modID . '\'' ) );
			$res = db_fetch_row( $q );

			if (!empty( $res['settings_value'] )) {
				$username = $res['settings_value'];
			} 
else {
				Redirect( 'index.php' );
			}

			$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_EGHTESADNOVIN_PASSWORD_' . $modID . '\'' ) );
			$res = db_fetch_row( $q );

			if (!empty( $res['settings_value'] )) {
				$password = $res['settings_value'];
			} 
else {
				Redirect( 'index.php' );
			}


			if (!empty( $_POST['RefNum'] )) {
				$order = _getOrderById( $orderID );
				$amount = $order['order_amount'];
				$RefNum = $_POST['RefNum'];
				require_once( './includes/modules/payment/nusoap/nusoap.php' );
				$client = new nusoap_client( 'https://pna.shaparak.ir/ref-payment/jax/merchantAuth?wsdl', true );
				$err = $client->getError(  );

				if ($err) {
					echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
					echo '<h2>Debug</h2><pre>' . htmlspecialchars( $client->getDebug(  ), ENT_QUOTES ) . '</pre>';
					exit(  );
				}

				$params = array( 'loginRequest' => array( 'password' => $password, 'username' => $username ) );
				$login = $client->call( 'login', $params );
				$login = $login['return'];
				$params = array( 'context' => array( 'data' => array( 'entry' => array( 'key' => 'SESSION_ID', 'value' => $login ) ) ), 'verifyRequest' => array( 'refNumList' => array( $RefNum ) ) );
				$res = $client->call( 'verifyTransaction', $params );

				if ($client->fault) {
					echo '<h2>Fault (Expect - The request contains an invalid SOAP body)</h2><pre>';
					print_r( $result );
					echo '</pre>';
				} 
else {
					$err = $client->getError(  );

					if ($err) {
						echo '<h2>Error</h2><pre>' . $err . '</pre>';
					}
				}

				$params = array( 'context' => array( 'data' => array( 'entry' => array( 'key' => 'SESSION_ID', 'value' => $login ) ) ) );
				$result = $client->call( 'logout', $params );

				if ($client->fault) {
					echo '<h2>Fault (Expect - The request contains an invalid SOAP body)</h2><pre>';
					print_r( $result );
					echo '</pre>';
				} 
else {
					$err = $client->getError(  );

					if ($err) {
						echo '<h2>Error</h2><pre>' . $err . '</pre>';
					}
				}

				$res = $res['return'];
				$res = $res['verifyResponseResults'];

				if (isset( $res['amount'] )) {
					if ($res['amount'] != $amount) {
						$res['verificationError'] = 'ERROR_IN_AMOUNT';
					}
				}


				if (isset( $res['verificationError'] )) {
					ostSetOrderStatusToOrder( $orderID, 1 );
					$body = ERROR_SHETAB_PAYMENTFAILD . '<br> ' . STR_SHETAB_RESON . ' ';
					switch ($res['verificationError']) {
						case 'TRANSACTION_NOT_FOUND_ERROR': {
							$body .= 'تراکنش اصلی یافت نشد یا شماره پیگیری اشتباه است';
							break;
						}

						case 'TRANSACTION_IS_NOT_VERIFIABLE': {
							$body .= 'تراکنش برگشت خورده است';
							break;
						}

						case 'INVALID_SESSION_EXCEPTION': {
							$body .= 'جلسه کاری سمت سرور منقضی شده است مجددا تلاش کنید';
							break;
						}

						case 'SYSTEM_ERROR': {
							$body .= 'خطای داخلی سرور ، در صورت تکرار با پشتیبانی بانک تماس بگیرید';
							break;
						}
					}

					$body .= ERROR_SHETAB_ERROR_NO . $RefNum;
					break;
				} 
else {
					$pininfo = ostSetOrderStatusToOrder( $orderID, $comStatID, 'Your Online Payment with EGHTESAD NOVIN BANK gateway accepted', 1 );
					$body = STR_SHETAB_THANKS . '<br>';
					$body .= STR_SHETAB_REFNUM . ': ' . $RefNum . '<br>';
					$body .= $modID;
					updateRefNum( $orderID, $RefNum );
				}
			} 
else {
				ostSetOrderStatusToOrder( $orderID, 1 );
				$state = $_POST['State'];
				switch ($state) {
					case 'InvalidAmount': {
						$reson = ERROR_SHETAB_INVALIDAMOUNT;
						break;
					}

					case 'InvalidTransaction': {
						$reson = ERROR_SHETAB_INVALIDTRANSACRION;
						break;
					}

					case 'InvalidCardNumber': {
						$reson = ERROR_SHETAB_INVALIDCARDNO;
						break;
					}

					case 'NoSuchIssuer': {
						$reson = ERROR_SHETAB_NOSUCHISSUER;
						break;
					}

					case 'ExpiredCardPickUp': {
						$reson = ERROR_SHETAB_EXPIREDCARD;
						break;
					}

					case 'AllowablePINTriesExceededPickUp': {
						$reson = ERROR_SHETAB_PIN3TRY;
						break;
					}

					case 'ExpiredAccount': {
						$reson = ERROR_SHETAB_EXPIREDACCOUNT;
						break;
					}

					case 'IncorrectPIN': {
						$reson = ERROR_SHETAB_INCORRETPIN;
						break;
					}

					case 'TransactionCannotBeCompleted': {
						$reson = ERROR_SHETAB_TRCANNOTBECOMP;
						break;
					}

					case 'ResponseReceivedTooLate': {
						$reson = ERROR_SHETAB_RESPONSETOOLATE;
						break;
					}

					case 'SuspectedFraudPickUp': {
						$reson = ERROR_SHETAB_SUSPECTFRAUD;
						break;
					}

					case 'NoSufficientFunds': {
						$reson = ERROR_SHETAB_NOSUFFICIENT;
						break;
					}

					case 'IssuerDown_Slm': {
						$reson = ERROR_SHETAB_ISSUERDOWN;
						break;
					}

					case 'Bad Card Number': {
						$reson = ERROR_SHETAB_INVALIDCARDNO;
						break;
					}

					case 'Canceled By User': {
						$reson = ERROR_SHETAB_CANCELED;
						break;
					}
				}

				$reson = $orderID;
				break;
				$body = ERROR_SHETAB_NOREFNUM . '<br> ';
				$body .= STR_SHETAB_ERROR_RESON . ' ' . $reson;
			}

			$smarty->assign( 'payment_name', 'نتیجه تراکنش' );
			$smarty->assign( 'page_body', $body );
			$smarty->assign( 'main_content_template', 'pay_result.tpl.html' );
			return 1;
		}

		$smarty->assign( 'main_content_template', 'page_not_found.tpl.html' );
	}

?>