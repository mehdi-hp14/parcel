<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function send($url, $api, $amount, $redirect) {
		curl_init(  );
		curl_setopt( $ch, CURLOPT_URL, $url );
		curl_setopt( $ch, CURLOPT_POSTFIELDS, 'api=' . $api . '&amount=' . $amount . '&redirect=' . $redirect );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		$res = $ch = curl_exec( $ch );
		curl_close( $ch );
		return $res;
	}

	function get($url, $api, $trans_id, $id_get) {
		curl_init(  );
		curl_setopt( $ch, CURLOPT_URL, $url );
		curl_setopt( $ch, CURLOPT_POSTFIELDS, 'api=' . $api . '&id_get=' . $id_get . '&trans_id=' . $trans_id );
		curl_setopt( $ch, CURLOPT_SSL_VERIFYPEER, false );
		curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
		$res = $ch = curl_exec( $ch );
		curl_close( $ch );
		return $res;
	}


	if (isset( $_GET['payline'] )) {
		if (( ( isset( $_GET['modID'] ) && isset( $_POST['trans_id'] ) ) && isset( $_POST['id_get'] ) )) {
			$modID = $_GET['modID'];
			$rs = $_GET['pay'];
			$trans_id = $_POST['trans_id'];
			$id_get = $_POST['id_get'];
			$orderID = ordGetordIDbyRefnum( $id_get );
			$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_PAYLINE_MERCHANT_ACCOUNT_' . $modID . '\'' ) );
			$res = db_fetch_row( $q );
			$comStatID = _getSettingOptionValue( 'CONF_COMPLETED_ORDER_STATUS' );

			if (!empty( $res['settings_value'] )) {
				$mid = $res['settings_value'];
			} 
else {
				Redirect( 'index.php' );
			}

			$order = _getOrderById( $orderID );

			if (( $rs == '1' && $order['StatusID'] != $comStatID )) {
				if ($orderID) {
					$amount = $order['order_amount'];
					$url = 'http://payline.ir/payment/gateway-result-second';
					$result = get( $url, $mid, $trans_id, $id_get );

					if ($result == 1) {
						$pininfo = ostSetOrderStatusToOrder( $orderID, $comStatID, 'Your Online Payment with PAYLINE gateway accepted', 1 );
						$body = STR_SHETAB_THANKS . '<br>';
						$body .= STR_SHETAB_REFNUM . ': ' . $id_get . '<br>';
						$body .= $url;
					} 
else {
						ostSetOrderStatusToOrder( $orderID, 1 );
						$body = ERROR_SHETAB_19;
					}
				} 
else {
					$body = ERROR_SHETAB_19;
				}
			} 
else {
				if ($orderID) {
					ostSetOrderStatusToOrder( $orderID, 1 );
				}

				$body = ERROR_SHETAB_19;
			}

			$smarty->assign( 'page_body', $body );
			$smarty->assign( 'main_content_template', 'pay_result.tpl.html' );
			return 1;
		}

		$smarty->assign( 'main_content_template', 'page_not_found.tpl.html' );
	}

?>