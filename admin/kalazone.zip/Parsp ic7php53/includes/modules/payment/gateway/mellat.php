<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$bankerrors = array( 0 => 'تراکنش با موفقیت انجام شد', 11 => 'شماره کارت نامعتبر است', 12 => 'موجودی کافی نیست', 13 => 'رمز نادرست است', 14 => 'تعداد دفعات وارد کردن رمز از حد مجاز بیشتر است', 15 => 'کارت نامعتبر است', 17 => 'کاربر از انجام تراکنش منصرف شده است', 18 => 'تاریخ انتقضای کارت گذشته است', 111 => 'صادر کننده کارت نامعتبر است', 112 => 'خطای سوییچ صادر کننده کارت', 113 => 'پاسخی از صادر کننده کارت دریافت نشد', 114 => 'دارنده کارت مجاز به انجام این تراکنش نیست', 21 => 'پذیرنده نامعتبر است', 22 => 'ترمینال مجوز ارائه سرویس درخواستی را ندارد', 23 => 'خطای امنیتی رخ داده است', 24 => 'اطلاعات کاربری پذیرنده نامعتبر است', 25 => 'مبلغ نامعتبر است', 31 => 'پاسخ نامعتبر است', 32 => 'فرمت اطلاعات وارد شده صحیح نمی باشد', 33 => 'حساب نامعتبر است', 34 => 'خطای سیستمی', 35 => 'تاریخ نامعتبر است', 41 => 'شماره درخواست تکراری است', 42 => 'تراکنش Sale یافت نشد', 43 => 'قبلا درخواست Verify داده شده است', 44 => 'درخواست Verify  یافت نشد', 45 => 'تراکنش Settle  شده است', 46 => 'تراکنش Settle نشده است', 47 => 'تراکنش Settle  یافت نشد', 48 => 'تراکنش Reverse شده است', 49 => 'تراکنش Refound یافت نشد', 412 => 'شناسه قبض نادرست است', 413 => 'شناسه پرداخت نادرست است', 414 => 'سازمان صادر کننده قبض نامعتبر است', 415 => 'زمان جلسه کاری به پایان رسیده است', 416 => 'خطا در ثبت اطلاعات رخ داده است', 417 => 'شناسه پرداخت کننده نامعتبر است', 418 => 'اشکال در تعریف اطلاعات مشتری', 419 => 'تعداد دفعات ورود اطلاعات از حد مجاز گذشته است', 421 => 'IP نامعتبر است', 51 => 'تراکنش تکراری است', 52 => 'سرویس درخواستی موجود نمی باشد', 54 => 'تراکنش مرجع موجود نیست', 55 => 'تراکنش نامعتبر است', 61 => 'خطا در واریز وجود دارد', 80 => 'تراكنش موفق عمل نكرده است' );
	$bankserver = 'https://bpm.shaparak.ir/pgwchannel/services/pgw?wsdl';

	if (isset( $_GET['mellat'] )) {
		if (( ( isset( $_GET['modID'] ) && isset( $_POST['RefId'] ) ) && isset( $_POST['ResCode'] ) )) {
			require_once( './includes/modules/payment/nusoap/nusoap.php' );
			$modID = $_GET['modID'];
			$rs = $_POST['RefId'];
			$orderID = $_POST['SaleOrderId'];
			$rescode = $_POST['ResCode'];
			$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_MELLAT_USERID_' . $modID . '\'' ) );
			$res = db_fetch_row( $q );
			$comStatID = _getSettingOptionValue( 'CONF_COMPLETED_ORDER_STATUS' );

			if (!empty( $res['settings_value'] )) {
				$payment['username'] = $res['settings_value'];
			} 
else {
				Redirect( 'index.php' );
			}

			$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_MELLAT_PASS_' . $modID . '\'' ) );
			$res = db_fetch_row( $q );
			$payment['password'] = $res['settings_value'];
			$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_MELLAT_TERMID_' . $modID . '\'' ) );
			$res = db_fetch_row( $q );
			$payment['terminalid'] = $res['settings_value'];

			if (( $rescode == 0 && $order['StatusID'] != $comStatID )) {
				$order = _getOrderById( $orderID );
				$refID = $_POST['RefId'];
				$saleCode = $_POST['SaleOrderId'];
				$status = $_POST['ResCode'];
				$trnsID = $_POST['SaleReferenceId'];
				$dat = date( 'Y-m-d H:i:s' );
				$parameters = array( 'terminalId' => $payment['terminalid'], 'userName' => $payment['username'], 'userPassword' => $payment['password'], 'orderId' => $saleCode, 'saleOrderId' => $saleCode, 'saleReferenceId' => $trnsID );
				$client = new nusoap_client( $bankserver, 'wsdl' );
				$soapProxy = $client->getProxy(  );
				$err = $client->getError(  );

				if ($err) {
					echo '<h2>Constructor error in part(1)</h2><pre>' . $err . '</pre>';
					exit(  );
				}

				$result = $soapProxy->bpVerifyRequest( $parameters );

				if ($client->fault) {
					echo '<h2>Fault in verify soap</h2><pre>';
					print_r( $result );
					echo '</pre>';
				} 
else {
					$err = $client->getError(  );

					if ($err) {
						$callverify = false;
					} 
else {
						$callverify = $result['return'];
					}
				}


				if ($callverify != 0) {
					$result = $soapProxy->bpInquiryRequest( $parameters );

					if ($client->fault) {
						echo '<h2>Fault in inquiry request</h2><pre>';
						print_r( $result );
						echo '</pre>';
					} 
else {
						$err = $client->getError(  );

						if ($err) {
							echo '<h2>Error</h2><pre>' . $err . '</pre>';
							exit(  );
						} 
else {
							$callinquiry = $result['return'];
						}
					}


					if ($callinquiry == 0) {
						$ResCode = 1088;
						$PaygiryID = $err;
						$result = $soapProxy->bpSettleRequest( $parameters );

						if ($client->fault) {
							echo '<h2>Fault Settle</h2><pre>';
							print_r( $result );
							echo '</pre>';
						} 
else {
							$err = $client->getError(  );

							if ($err) {
								echo '<h2>Error</h2><pre>' . $err . '</pre>';
								exit(  );
							} 
else {
								$callsettle = $result['return'];
							}
						}


						if (( $callsettle == 0 || $callsettle == 45 )) {
							$pininfo = ostSetOrderStatusToOrder( $orderID, $comStatID, 'سفارش شما از طریق بانک ملت پرداخت شد ', 1 );
							$body = '<font color=\'green\'>با تشکر ، پرداخت با موفقیت انجام شد .</font><br> 
شماره پیگیری  : ' . $trnsID . '<br>';
						} 
else {
							$body = 'عملیات تایید واریز نهایی در بانک انجام نگردید.با پشتیبانی تماس حاصل فرمایید';
						}
					} 
else {
						$result = $soapProxy->bpReversalRequest( $parameters );

						if ($client->fault) {
							echo '<h2>Fault in Rerse Money</h2><pre>';
							print_r( $result );
							echo '</pre>';
						} 
else {
							$err = $client->getError(  );

							if ($err) {
								return false;
							}

							$callreverse = $result['return'];
						}

						$body = 'تراکنش با موفقیت انجام نشده است ، در صورتی که پول از حساب شما کسر شده باشد مجددا به حساب شما بازگشت داده خواهد شد<br>' . 'شماره پیگیری:' . $trnsID . '<br>دلیل :' . $bankerrors[$callinquiry];

						if ($callreverse == 0) {
							$body .= ' عملیات بازگشت پول پرداختی انجام گردید ';
						} 
else {
							ostSetOrderStatusToOrder( $orderID, 1 );
							$body = '<font color=\'red\'>&#1582;&#1591;&#1575;&#1740;&#1740; &#1607;&#1606;&#1711;&#1575;&#1605; &#1575;&#1606;&#1580;&#1575;&#1605; &#1593;&#1605;&#1604;&#1740;&#1575;&#1578; &#1662;&#1585;&#1583;&#1575;&#1582;&#1578; &#1585;&#1582; &#1583;&#1575;&#1583;!</font><br><br>&#1593;&#1604;&#1578; &#1582;&#1591;&#1575;: ' . $_POST['tref'];
							$body .= ' پرداخت انجام نیافت ';
						}
					}
				} 
else {
					$result = $soapProxy->bpSettleRequest( $parameters );

					if ($client->fault) {
						echo '<h2>Fault Settle</h2><pre>';
						print_r( $result );
						echo '</pre>';
					} 
else {
						$err = $client->getError(  );

						if ($err) {
							$body .= '<h2>Error</h2><pre>' . $err . '</pre>';
						} 
else {
							$callsettle = $result['return'];
						}
					}


					if ($callsettle == 0) {
						$pininfo = ostSetOrderStatusToOrder( $orderID, $comStatID, 'سفارش شما از طریق بانک ملت پرداخت شد ', 1 );
						$body = '<font color=\'green\'>با تشکر ، پرداخت با موفقیت انجام شد .</font><br> 
شماره پیگیری  : ' . $trnsID . '<br>';
					} 
else {
						$body = 'تراکنش به پیگری نیاز دارد' . ' <br>' . 'لطفا با مدیر سایت مکاتبه نمایید' . '<br>' . 'شماره پیگیری:' . $trnsID;
					}
				}


				if ($ResCode == 0) {
					$pininfo = ostSetOrderStatusToOrder( $orderID, $comStatID, 'سفارش شما از طریق بانک ملت پرداخت شد ', 1 );
					$body = '<font color=\'green\'>با تشکر ، پرداخت با موفقیت انجام شد .</font><br> 
          شماره پیگیری  : ' . $trnsID . '<br>';
				}
			} 
else {
				$body = '<center>عملیات پرداخت با خطا روبرو شد<br>';
				$body .= $bankerrors[$rescode] . '</center>';
			}

			$smarty->assign( 'payment_name', 'پرداخت از طریق بانک ملت' );
			$smarty->assign( 'page_body', $body );
			$smarty->assign( 'main_content_template', 'pay_result.tpl.html' );
			return 1;
		}

		$smarty->assign( 'main_content_template', 'page_not_found.tpl.html' );
	}

?>