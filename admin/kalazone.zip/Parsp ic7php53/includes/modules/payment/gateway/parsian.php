<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_GET['parsian'] )) {
		if (( ( isset( $_GET['modID'] ) && isset( $_GET['au'] ) ) && isset( $_GET['pay'] ) )) {
			$modID = $_GET['modID'];
			$rs = $_GET['pay'];
			$authority = $_GET['au'];
			$orderID = ordGetordIDbyRefnum( $authority );
			$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_PARSIAN_MERCHANT_ACCOUNT_' . $modID . '\'' ) );
			$res = db_fetch_row( $q );
			$comStatID = _getSettingOptionValue( 'CONF_COMPLETED_ORDER_STATUS' );

			if (!empty( $res['settings_value'] )) {
				$mid = $res['settings_value'];
			} 
else {
				Redirect( 'index.php' );
			}

			$order = _getOrderById( $orderID );

			if (( $rs == '1' && $order['statusID'] != $comStatID )) {
				if ($orderID) {
					$amount = $order['order_amount'];
					include( dirname( __FILE__ ) . DIRECTORY_SEPARATOR . '../nusoap/nusoap.php' );
					$soapclient = new nusoap_client( 'https://pec.shaparak.ir/pecpaymentgateway/eshopservice.asmx?wsdl', 'wsdl' );
					$soapclient->getError(  );

					if (( !$soapclient || $err =  )) {
						$body = '<br />' . $err . '<br />';
					} 
else {
						$status = 853;
						$params = array( 'pin' => $mid, 'authority' => $authority, 'status' => $status );
						$sendParams = array( $params );
						$res = $soapclient->call( 'PinPaymentEnquiry', $sendParams );
						$status = $res['status'];

						if ($status == 0) {
							$params = array( 'pin' => $mid, 'status' => $status );
							$res = $soapclient->call( 'PinSettlement', $sendParams );
							$pininfo = ostSetOrderStatusToOrder( $orderID, $comStatID, 'Your Online Payment with PARSIAN BANK gateway accepted', 1 );
							$body = STR_SHETAB_THANKS . '<br>';
							$body .= STR_SHETAB_REFNUM . ': ' . $authority . '<br>';
							$body .= $rs;
						} 
else {
							ostSetOrderStatusToOrder( $orderID, 1, 'پرداخت توسط بانک تایید نشد!' );
							$body = ERROR_SHETAB_19;
						}
					}
				} 
else {
					$body = ERROR_SHETAB_19;
				}
			}

			$smarty->assign( 'payment_name', CPARSIAN_TTL );
			$smarty->assign( 'page_body', $body );
			$smarty->assign( 'main_content_template', 'pay_result.tpl.html' );
		} 
else {
			$smarty->assign( 'main_content_template', 'page_not_found.tpl.html' );
		}

		unset( $_GET );
	}

?>