<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function bankShowStatus($ErrorCode) {
		switch ($ErrorCode) {
			case 110: {
				return ' انصراف دارنده کارت';
			}

			case 120: {
				return '   موجودی کافی نیست';
			}

			case 130: {
			}

			case 131: {
			}

			case 160: {
				return '   اطلاعات کارت اشتباه است';
			}

			case 132: {
			}

			case 133: {
				return '   کارت مسدود یا منقضی می باشد';
			}

			case 140: {
				return ' زمان مورد نظر به پایان رسیده است';
			}

			case 200: {
			}

			case 201: {
			}

			case 202: {
				return ' مبلغ بیش از سقف مجاز';
			}

			case 166: {
				return ' بانک صادر کننده مجوز انجام  تراکنش را صادر نکرده';
			}

			case 150: {
			}
		}

		return  . ' خطا بانک  ' . $resultCode;
	}


	if (isset( $_GET['irankish'] )) {
		if (isset( $_GET['modID'] )) {
			$modID = $_GET['modID'];
			$orderID = $_GET['orderID'];
			$rs = $_GET['pay'];
			$invoiceid = $_POST['resnum'];
			$reference_id = $_POST['refnum'];
			$resultCode = $_POST['resultCode'];
			$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_IRANKISH_MERCHANT_ACCOUNT_' . $modID . '\'' ) );
			$res = db_fetch_row( $q );
			$comStatID = _getSettingOptionValue( 'CONF_COMPLETED_ORDER_STATUS' );

			if (!empty( $res['settings_value'] )) {
				$mid = $res['settings_value'];
			} 
else {
				Redirect( 'index.php' );
			}

			$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_IRANKISH_MERCHANT_SHA1KEY_' . $modID . '\'' ) );
			$res = db_fetch_row( $q );
			$comStatID = _getSettingOptionValue( 'CONF_COMPLETED_ORDER_STATUS' );

			if (!empty( $res['settings_value'] )) {
				$sha1Key = $res['settings_value'];
			} 
else {
				Redirect( 'index.php' );
			}

			$order = _getOrderById( $orderID );

			if (( ( $rs == '1' && $order['StatusID'] != $comStatID ) && $resultCode == '100' )) {
				if ($orderID) {
					$amount = $order['order_amount'];
					$referenceId = (isset( $_POST['referenceId'] ) ? $_POST['referenceId'] : 0);
					$paymentId = (isset( $_POST['paymentId'] ) ? $_POST['paymentId'] : 0);
					@session_start(  );
					$client = new SoapClient( 'https://ikc.shaparak.ir/XVerify/Verify.xml', array( 'soap_version' => SOAP_1_1 ) );
					$params['token'] = $_SESSION['token'];
					$params['merchantId'] = $mid;
					$params['referenceNumber'] = $referenceId;
					$params['sha1Key'] = $sha1Key;
					$result = $client->__soapCall( 'KicccPaymentsVerification', array( $params ) );
					$result = $result->KicccPaymentsVerificationResult;

					if (( floatval( $result ) == floatval( $amount ) && 0 < floatval( $amount ) )) {
						$comStatID = _getSettingOptionValue( 'CONF_COMPLETED_ORDER_STATUS' );
						$pininfo = ostSetOrderStatusToOrder( $orderID, $comStatID, 'Your Online Payment with irankish gateway accepted', 1 );
						$body = STR_SHETAB_THANKS . '<br>';
						$body .= STR_SHETAB_REFNUM . ': ' . $referenceId . '<br>';
						$body .= $sha1Key;
					} 
else {
						ostSetOrderStatusToOrder( $orderID, 1 );
						$body = 'مبلغ واریزی با قیمت محصول برابر نیست';
					}
				} 
else {
					$body = ERROR_SHETAB_14;
				}
			} 
else {
				if ($orderID) {
					ostSetOrderStatusToOrder( $orderID, 1 );
				}

				$body = bankShowStatus( $resultCode );
			}

			$smarty->assign( 'page_body', $body );
			$smarty->assign( 'main_content_template', 'irankish.tpl.html' );
			return 1;
		}

		$smarty->assign( 'main_content_template', 'page_not_found.tpl.html' );
	}

?>