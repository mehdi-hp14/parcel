<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_GET['saman'] )) {
		if (isset( $_GET['modID'] )) {
			$modID = $_GET['modID'];
			$orderID = $_POST['ResNum'];
			$RefNum = $_POST['RefNum'];
			$q = db_query( 'SELECT * FROM ' . SETTINGS_TABLE . ( ' WHERE settings_constant_name=\'CONF_PAYMENTMODULE_SAMAN_MERCHANT_ACCOUNT_' . $modID . '\'' ) );
			$res = db_fetch_row( $q );
			$comStatID = _getSettingOptionValue( 'CONF_COMPLETED_ORDER_STATUS' );

			if (!empty( $res['settings_value'] )) {
				$mid = $res['settings_value'];
			} 
else {
				Redirect( 'index.php' );
			}


			if (!empty( $$RefNum )) {
				$order = _getOrderById( $orderID );
				$amount = $order['order_amount'];
				$State = $_POST['State'];
				$parameters = array( 'RefNum' => $RefNum, 'mid' => $mid );
				include( dirname( __FILE__ ) . DIRECTORY_SEPARATOR . '../nusoap/nusoap.php' );
				$soapclient = new nusoap_client( 'https://verify.sep.ir/Payments/ReferencePayment.asmx?WSDL', 'wsdl' );
				$soapProxy = $soapclient->getProxy(  );
				$res = $soapProxy->VerifyTransaction( $RefNum, $mid );

				if ($res <= 0) {
					ostSetOrderStatusToOrder( $orderID, 1 );
					$body = ERROR_SHETAB_PAYMENTFAILD . '<br> ';
					switch ($res) {
						case -1: {
							$body .= ERROR_SHETAB_1;
							break;
						}

						case -2: {
							$body .= ERROR_SHETAB_2;
							break;
						}

						case -3: {
							$body .= ERROR_SHETAB_3;
							break;
						}

						case -4: {
							$body .= ERROR_SHETAB_4;
							break;
						}

						case -5: {
							$body .= ERROR_SHETAB_5;
							break;
						}

						case -6: {
							$body .= ERROR_SHETAB_6;
							break;
						}

						case -7: {
							$body .= ERROR_SHETAB_7;
							break;
						}

						case -8: {
							$body .= ERROR_SHETAB_8;
							break;
						}

						case -9: {
							$body .= ERROR_SHETAB_9;
							break;
						}

						case -10: {
							$body .= ERROR_SHETAB_10;
							break;
						}

						case -11: {
							$body .= ERROR_SHETAB_11;
							break;
						}

						case -12: {
							$body .= ERROR_SHETAB_12;
							break;
						}

						case -13: {
							$body .= ERROR_SHETAB_13;
							break;
						}

						case -14: {
							$body .= ERROR_SHETAB_14;
							break;
						}

						case -15: {
							$body .= ERROR_SHETAB_15;
							break;
						}

						case -16: {
							$body .= ERROR_SHETAB_16;
							break;
						}

						case -17: {
							$body .= ERROR_SHETAB_17;
							break;
						}

						case -18: {
							$body .= ERROR_SHETAB_18;
							break;
						}
					}

					$body .= ERROR_SHETAB_ERROR_NO . $res;
					break;
				} 
else {
					$pininfo = ostSetOrderStatusToOrder( $orderID, $comStatID, 'Your Online Payment with SAMAN BANK gateway accepted', 1 );
					$body = STR_SHETAB_THANKS . '<br>';
					$body .= STR_SHETAB_REFNUM . ': ' . $RefNum . '<br>';
					$body .= $amount;
					updateRefNum( $orderID, $RefNum );
				}
			} 
else {
				ostSetOrderStatusToOrder( $orderID, 1 );
				$state = $_POST['State'];
				switch ($state) {
					case 'InvalidAmount': {
						$reson = ERROR_SHETAB_INVALIDAMOUNT;
						break;
					}

					case 'InvalidTransaction': {
						$reson = ERROR_SHETAB_INVALIDTRANSACRION;
						break;
					}

					case 'InvalidCardNumber': {
						$reson = ERROR_SHETAB_INVALIDCARDNO;
						break;
					}

					case 'NoSuchIssuer': {
						$reson = ERROR_SHETAB_NOSUCHISSUER;
						break;
					}

					case 'ExpiredCardPickUp': {
						$reson = ERROR_SHETAB_EXPIREDCARD;
						break;
					}

					case 'AllowablePINTriesExceededPickUp': {
						$reson = ERROR_SHETAB_PIN3TRY;
						break;
					}

					case 'ExpiredAccount': {
						$reson = ERROR_SHETAB_EXPIREDACCOUNT;
						break;
					}

					case 'IncorrectPIN': {
						$reson = ERROR_SHETAB_INCORRETPIN;
						break;
					}

					case 'TransactionCannotBeCompleted': {
						$reson = ERROR_SHETAB_TRCANNOTBECOMP;
						break;
					}

					case 'ResponseReceivedTooLate': {
						$reson = ERROR_SHETAB_RESPONSETOOLATE;
						break;
					}

					case 'SuspectedFraudPickUp': {
						$reson = ERROR_SHETAB_SUSPECTFRAUD;
						break;
					}

					case 'NoSufficientFunds': {
						$reson = ERROR_SHETAB_NOSUFFICIENT;
						break;
					}

					case 'IssuerDown_Slm': {
						$reson = ERROR_SHETAB_ISSUERDOWN;
						break;
					}

					case 'Bad Card Number': {
						$reson = ERROR_SHETAB_INVALIDCARDNO;
						break;
					}

					case 'Canceled By User': {
						$reson = ERROR_SHETAB_CANCELED;
						break;
					}
				}

				$reson = $State;
				break;
				$body = ERROR_SHETAB_NOREFNUM . '<br> ';
				$body .= STR_SHETAB_ERROR_RESON . ' ' . $reson;
			}

			$smarty->assign( 'payment_name', CSAMAN_TTL );
			$smarty->assign( 'page_body', $body );
			$smarty->assign( 'main_content_template', 'pay_result.tpl.html' );
			return 1;
		}

		$smarty->assign( 'main_content_template', 'page_not_found.tpl.html' );
	}

?>