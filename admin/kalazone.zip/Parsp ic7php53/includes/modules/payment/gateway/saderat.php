<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_GET['SADERAT'] )) {
		$orderID = $_POST['x_fp_sequence'];
		$saderatpayment = new csaderat(  );
		$result = $saderatpayment->checkReceipt( $_POST, false );

		if ($result == true) {
			$order = _getOrderById( $orderID );
			$status = 747;
			$res = $saderatpayment;
			$pininfo = ostSetOrderStatusToOrder( $orderID, $comStatID, 'سفارش شما از طریق آنلاین پرداخت شد ', 1 );
			$body = '<font color=\'green\'>با تشکر ، پرداخت با موفقیت انجام شد .</font><br> 
شماره پیگیری  : ' . $res . '<br>';
		} 
else {
			ostSetOrderStatusToOrder( $orderID, 1 );
			$body = '<font color=\'red\'>&#1582;&#1591;&#1575;&#1740;&#1740; &#1607;&#1606;&#1711;&#1575;&#1605; &#1575;&#1606;&#1580;&#1575;&#1605; &#1593;&#1605;&#1604;&#1740;&#1575;&#1578; &#1662;&#1585;&#1583;&#1575;&#1582;&#1578; &#1585;&#1582; &#1583;&#1575;&#1583;!</font><br><br>&#1593;&#1604;&#1578; &#1582;&#1591;&#1575;: ' . $res;
		}

		$smarty->assgin( 'payment_name', CSADERAT_TTL );
		$smarty->assign( 'page_body', $body );
		$smarty->assign( 'main_content_template', 'pay_result.tpl.html' );
	}

?>