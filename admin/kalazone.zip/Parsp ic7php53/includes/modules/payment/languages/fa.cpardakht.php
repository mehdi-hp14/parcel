<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CPARDAKHT_TTL', 'خريد پستي (www.pardakht.com)' );
	define( 'CPARDAKHT_DSCR', 'ماژول خريد پستي توسط سايت پرداخت' );
	define( 'CPARDAKHT_CFG_MERCHANT_ACCOUNT_TTL', 'URL ارسال محتويات سبد خريد بر روي سايت پرداخت' );
	define( 'CPARDAKHT_CFG_MERCHANT_ACCOUNT_DSCR', 'URL ارسال محتويات سبد خريد بر روي سايت پرداخت را مشخص نماييد' );
	define( 'CPARDAKHT_CFG_TYPE', 'نوع حمل و نقل' );
	define( 'CPARDAKHT_CFG_TYPE_DSCR', 'لطفا شماره نوع حمل و نقل را مشخص نماييد' );
	define( 'CPARDAKHT_TXT_1', 'ورود به سايت پرداخت (خريد پستي) و تکميل خريد' );
?>