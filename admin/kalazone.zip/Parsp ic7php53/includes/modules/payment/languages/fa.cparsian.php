<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CPARSIAN_TTL', 'پارسيان' );
	define( 'CPARSIAN_DSCR', 'ماژول پرداخت آنلاين پارسيان' );
	define( 'CPARSIAN_CFG_MERCHANT_ACCOUNT_TTL', 'پين کد پارسيان شما' );
	define( 'CPARSIAN_CFG_MERCHANT_ACCOUNT_DSCR', 'لطفا کد پارسيان خود را وارد نماييد' );
	define( 'CPARSIAN_CFG_RIAL_CURRENCY_TTL', 'واحد پول ريال' );
	define( 'CPARSIAN_CFG_RIAL_CURRENCY_DSCR', 'واحد پول ارسالي شما به بانک پارسيان حتما بايد به ريال باشد' );
	define( 'CPARSIAN_TXT_1', 'ورود به سايت بانک پارسيان و پرداخت آنلاين' );
?>