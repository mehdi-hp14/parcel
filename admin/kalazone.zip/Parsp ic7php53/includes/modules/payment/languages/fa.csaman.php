<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CSAMAN_TTL', 'سامان' );
	define( 'CSAMAN_DSCR', 'پرداخت توسط کارتهاي عضو شتاب از طريق بانک سامان' );
	define( 'CSAMAN_CFG_MERCHANT_ACCOUNT_TTL', 'account ID بانک سامان' );
	define( 'CSAMAN_CFG_MERCHANT_ACCOUNT_DSCR', 'اين شماره را از بانک دريافت ميکنيد' );
	define( 'CSAMAN_CFG_RLS_CURRENCY_TTL', 'واحد پول ريال' );
	define( 'CSAMAN_CFG_RLS_CURRENCY_DSCR', 'در صورتي که چند واحد پول اضافه نموده ايد واحد پول ريال را انتخاب نماييد در غير اينصورت واحد پيشفرض پول محاسبه ميشود' );
	define( 'CSAMAN_TXT_1', 'ورود به سايت سامان و انجام پرداخت اينترنتي' );
?>