<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CPASARGAD_TTL', 'پاسارگاد' );
	define( 'CPASARGAD_DSCR', 'پرداخت از طريق درگاه پرداخت الکترونيک بانک پاسارگاد' );
	define( 'CPASARGAD_CFG_TERMINAL_CODE_TTL', 'شماره ترمينال' );
	define( 'CPASARGAD_TERMINAL_CODE_DSCR', 'شماره ترمينال پرداختي' );
	define( 'CPASARGAD_CFG_MERCHANT_ACCOUNT_TTL', 'شماره حساب بانک' );
	define( 'CPASARGAD_CFG_MERCHANT_ACCOUNT_DSCR', 'اين شماره را از بانک دريافت ميکنيد' );
	define( 'CPASARGAD_CFG_RLS_CURRENCY_TTL', 'واحد پول ريال' );
	define( 'CPASARGAD_CFG_RLS_CURRENCY_DSCR', 'در صورتي که چند واحد پول اضافه نموده ايد واحد پول ريال را انتخاب نماييد در غير اينصورت واحد پيشفرض پول محاسبه ميشود' );
	define( 'CPASARGAD_TXT_1', 'ورود به سايت  و انجام پرداخت اينترنتي' );
?>