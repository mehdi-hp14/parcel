<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CUSERACCOUNT_TTL', 'پرداخت از حساب کاربري' );
	define( 'CUSERACCOUNT_DSCR', 'ماژول پرداخت از اعتبار موجود در حساب کاربري اعضا' );
	define( 'CUSERACCOUNT_CFG_RLS_CURRENCY_TTL', 'واحد پول ريال' );
	define( 'CUSERACCOUNT_CFG_RLS_CURRENCY_DSCR', 'واحد اصلي پول که مبلغ به اين واحد از حساب کاربري اعضا کسر خواهد شد' );
	define( 'CUSERACCOUNT_TXT_1', 'انجام پرداخت از حساب کاربري' );
?>