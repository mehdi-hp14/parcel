<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'Cirankish_TTL', 'درگاه شرکت ایران کیش' );
	define( 'Cirankish_DSCR', 'ساخته شده توسط<a href="http://www.softiran.org" target="_blank" > www.softiran.org</a> به سفارش ایران کیش' );
	define( 'Cirankish_CFG_MERCHANT_ACCOUNT_TTL', 'شناسه پرداخت' );
	define( 'Cirankish_CFG_MERCHANT_ACCOUNT_DSCR', 'مرچنت ' );
	define( 'Cirankish_CFG_RIAL_CURRENCY_TTL', 'واحد پول ريال' );
	define( 'Cirankish_CFG_RIAL_CURRENCY_DSCR', 'واحد پول حتما باید ریال باشد' );
	define( 'Cirankish_TXT_1', 'پرداخت آنلاین توسط درگاه شرکت ایران کیش' );
?>