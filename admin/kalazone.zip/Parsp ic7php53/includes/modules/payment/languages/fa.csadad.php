<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CSADAD_TTL', 'ملی - سداد' );
	define( 'CSADAD_DSCR', 'پرداخت از طريق درگاه سداد بانک ملي' );
	define( 'CSADAD_CFG_TRANSACTIONKEY_TTL', 'کليد تراکنش' );
	define( 'CSADAD_CFG_TRANSACTIONKEY_DSCR', 'کد مربوط به شناسایی پذیرنده ، لازم به توضيح است این کد از لحاظ امنيتی دارای.اهميت بالایی است ، به هيچ وجه این کد نبایستی در اختيار اشخاص دیگر باشد' );
	define( 'CSADAD_CFG_CARDACQID_TTL', 'شماره پذیرنده' );
	define( 'CSADAD_CFG_CARDACQID_DSCR', 'شماره یكتا به منظور مشخص شدن پذیرنده' );
	define( 'CSADAD_CFG_TERMINALID_TTL', 'شماره ترمينال' );
	define( 'CSADAD_CFG_TERMINALID_DSCR', 'به منظور تفكيک پایانه های مختلف یک پذیرنده' );
	define( 'CSADAD_CFG_RLS_CURRENCY_TTL', 'واحد پول ريال' );
	define( 'CSADAD_CFG_RLS_CURRENCY_DSCR', 'در صورتي که چند واحد پول اضافه نموده ايد واحد پول ريال را انتخاب نماييد در غير اينصورت واحد پيشفرض پول محاسبه ميشود' );
	define( 'CSADAD_TXT_1', 'ورود به سايت  و انجام پرداخت اينترنتي' );
?>