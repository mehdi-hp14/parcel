<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'SADERAT_TTL', 'بانک صادرات' );
	define( 'SADERAT_DSCR', 'پرداخت از طريق درگاه دامون بانک صادرات' );
	define( 'SADERAT_CFG_DESCRIPTION_TTL', 'توضيحات' );
	define( 'SADERAT_DESCRIPTION_DSCR', 'مي توانيد متني را به عنوان توضيحات به درگاه ارسال کنيد' );
	define( 'SADERAT_CFG_LOGIN_ID_TTL', 'کد حساب' );
	define( 'SADERAT_CFG_LOGIN_ID_DSCR', 'اين شماره را از بانک دريافت ميکنيد' );
	define( 'SADERAT_CFG_TRAN_KEY_TTL', 'کد کليد' );
	define( 'SADERAT_TRAN_KEY_DSCR', 'اين شماره را از بانک دريافت ميکنيد' );
	define( 'SADERAT_CFG_RLS_CURRENCY_TTL', 'واحد پول ريال' );
	define( 'SADERAT_CFG_RLS_CURRENCY_DSCR', 'در صورتي که چند واحد پول اضافه نموده ايد واحد پول ريال را انتخاب نماييد در غير اينصورت واحد پيشفرض پول محاسبه ميشود' );
	define( 'SADERAT_TXT_1', 'ورود به سايت  و انجام پرداخت اينترنتي' );
?>