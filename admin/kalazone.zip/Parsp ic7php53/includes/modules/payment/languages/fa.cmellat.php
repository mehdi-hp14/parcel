<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CMELLAT_TTL', 'ملت' );
	define( 'CMELLAT_DSCR', 'پرداخت توسط کارتهاي عضو شتاب از طريق بانک ملت ' );
	define( 'CMELLAT_CFG_USERID_TTL', 'UserID بانک ملت' );
	define( 'CMELLAT_CFG_USERID_DSCR', 'لطفا UserID دريافتي از بانک ملت را وارد نماييد' );
	define( 'CMELLAT_CFG_TERMID_TTL', 'شماره ترمينال' );
	define( 'CMELLAT_CFG_TERMID_DSCR', 'لطفا شماره ترمينال دريافتي از بانک را وارد نماييد' );
	define( 'CMELLAT_CFG_PASS_TTL', 'رمز عبور' );
	define( 'CMELLAT_CFG_PASS_DSCR', 'لطفا رمز عبور دريافتي از بانک را وارد نماييد' );
	define( 'CMELLAT_CFG_RIAL_CURRENCY_TTL', 'واحد پول ريال' );
	define( 'CMELLAT_CFG_RIAL_CURRENCY_DSCR', 'واحد پول ارسالي به بانک ملت بايد حتما به ريال باشد. لطفا واحد پول ريال را انتخاب نماييد' );
	define( 'CMELLAT_TXT_1', 'ورود به سايت بانک ملت و انجام پرداخت اينترنتي' );
?>