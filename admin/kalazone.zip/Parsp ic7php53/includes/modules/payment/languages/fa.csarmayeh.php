<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CSARMAYEH_TTL', 'سرمایه' );
	define( 'CSARMAYEH_DSCR', 'پرداخت توسط کارتهاي عضو شتاب از طريق بانک سرمایه ' );
	define( 'CSARMAYEH_CFG_USERID_TTL', 'UserID نام کاربری فروشنده - ' );
	define( 'CSARMAYEH_CFG_USERID_DSCR', 'لطفا UserID دريافتي از بانک سرمایه را وارد نماييد (توجه داشته باشید که بانک به حروف کوچک و بزرگ حساس است )' );
	define( 'CSARMAYEH_CFG_PASS_TTL', 'کلمه عبور فروشنده رمز گذاری شده' );
	define( 'CSARMAYEH_CFG_PASS_DSCR', 'لطفا رمز عبور دريافتي از بانک را وارد نماييد  (توجه داشته باشید که بانک به حروف کوچک و بزرگ حساس است )' );
	define( 'CSARMAYEH_CFG_USERIDNET_TTL', 'کد کاربری فروشنده ویژه کار در شبکه' );
	define( 'CSARMAYEH_CFG_USERIDNET_DSCR', 'کد کاربری فروشنده ویژه کار در شبکه (Network Username) (توجه داشته باشید که بانک به حروف کوچک و بزرگ حساس است )' );
	define( 'CSARMAYEH_CFG_PASSNET_TTL', 'کلمه عبور فروشنده ویژه کار در شبکه' );
	define( 'CSARMAYEH_CFG_PASSNET_DSCR', 'کلمه عبور فروشنده ویژه کار در شبکه (Network Password) (توجه داشته باشید که بانک به حروف کوچک و بزرگ حساس است )' );
	define( 'CSARMAYEH_CFG_BANKURL_TTL', 'آدرس وب سرویس بانک' );
	define( 'CSARMAYEH_CFG_BANKURL_DSCR', 'آدرس DNS ای که بانک به شما داده است را اینجا باید وارد کنید.' );
	define( 'CSARMAYEH_CFG_BANKREDIRECT_TTL', 'Redirect Address' );
	define( 'CSARMAYEH_CFG_BANKREDIRECT_DSCR', 'آدرسی که بانک به عنوان ارجاع درگاه پرداخت به شما داده است اینجا وارد کنید' );
	define( 'CSARMAYEH_CFG_SITE_ADDRESS_TTL', 'آدرس سایت فروشنده' );
	define( 'CSARMAYEH_CFG_SITE_ADDRESS_DSCR', 'بانک سرمایه به آدرس سایت فروشنده حساس است ، در اینجا باید عینا آدرسی که سایت به عنوان سایت فروشنده به شما اعلام می کند وارد نمایید. (توجه داشته باشید که بانک به حروف کوچک و بزرگ حساس است )' );
	define( 'CSARMAYEH_CFG_RIAL_CURRENCY_TTL', 'واحد پول ريال' );
	define( 'CSARMAYEH_CFG_RIAL_CURRENCY_DSCR', 'واحد پول ارسالي به بانک سرمایه بايد حتما به ريال باشد. لطفا واحد پول ريال را انتخاب نماييد' );
	define( 'CSARMAYEH_TXT_1', 'ورود به سايت بانک سرمایه و انجام پرداخت اينترنتي' );
	define( 'CSARMAYEH_USERPASS_INVALID', 'اطلاعات وارد شده برای اتصال به درگاه سرمایه اشتباه است مجددا اطلاعات را وارد کنید.' );
?>