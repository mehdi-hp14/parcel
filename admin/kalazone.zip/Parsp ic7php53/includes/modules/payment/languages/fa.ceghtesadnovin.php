<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CEGHTESADNOVIN_TTL', 'اقتصاد نوين' );
	define( 'CEGHTESADNOVIN_DSCR', 'پرداخت توسط کارتهاي عضو شتاب از طريق بانک اقتصاد نوين' );
	define( 'CEGHTESADNOVIN_CFG_MERCHANT_ACCOUNT_TTL', 'account ID بانک اقتصاد نوين' );
	define( 'CEGHTESADNOVIN_CFG_MERCHANT_ACCOUNT_DSCR', 'اين شماره را از بانک دريافت ميکنيد' );
	define( 'CEGHTESADNOVIN_CFG_USERNAME_TTL', 'نام کاربری' );
	define( 'CEGHTESADNOVIN_CFG_USERNAME_DSCR', 'نام کاربری مربوط به درگاه را برای تایید خرید وارد کنید' );
	define( 'CEGHTESADNOVIN_CFG_PASSWORD_TTL', 'رمز عبور' );
	define( 'CEGHTESADNOVIN_CFG_PASSWORD_DSCR', 'رمز عبور مربوط به درگاه را برای تایید خرید وارد کنید' );
	define( 'CEGHTESADNOVIN_CFG_RLS_CURRENCY_TTL', 'واحد پول ريال' );
	define( 'CEGHTESADNOVIN_CFG_RLS_CURRENCY_DSCR', 'در صورتي که چند واحد پول اضافه نموده ايد واحد پول ريال را انتخاب نماييد در غير اينصورت واحد پيشفرض پول محاسبه ميشود' );
	define( 'CEGHTESADNOVIN_TXT_1', 'ورود به سايت اقتصاد نوين و انجام پرداخت اينترنتي' );
?>