<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CWEBSERVICE_IRANMC_TTL', 'وب سرویس ايران مارکت سنتر' );
	define( 'CWEBSERVICE_IRANMC_DSCR', 'خريد پستي توسط وب سرويس ايران مارکت سنتر' );
	define( 'CWEBSERVICE_ACCOUNT_TTL', 'نام کاربر' );
	define( 'CWEBSERVICE_ACCOUNT_DSCR', 'نام کاربري براي ورود به پنل سيستم ايران مارکت سنتر' );
	define( 'CWEBSERVICE_PASSWORD_TTL', 'رمز عبور' );
	define( 'CWEBSERVICE_PASSWORD_DSCR', 'رمز عبور براي ورود به پنل مديريت سيستم ايران مارکت سنتر' );
	define( 'CWEBSERVICE_VENDORID_TTL', 'کد فروشنده' );
	define( 'CWEBSERVICE_VENDORID_DSCR', 'اين کد شناسه يکتايي است (8 رقمي) که قبل از کد محصول قرار گرفته و فروشنده محصول را مشخص مي کند.' . '<br> براي استفاده از سيستم وارد کردن اين کد اجباري است به دليل آنکه از کد محصول موجود در قسمت محصولات براي شناسايي محصول استفاده مي شود و در سيستم ايران مارکت سنتر از ترکيب اين کد و کد محصول کد محصول واقعي مشخص مي گردد وجود اين کد اجباري است' );
	define( 'CWEBSERVICE_WEBSERVICEADDRESS_TTL', 'آدرس وب سرويس ايران مارکت سنتر' );
	define( 'CWEBSERVICE_WEBSERVICEADDRESS_DSCR', 'جهت برقراري ارتباط با ايران مارکت سنتر بايد آدرس وب سرويس را در اين محل قرار دهيد.' );
	define( 'CWEBSERVICE_CURRENCY_TTL', 'واحد پول (ريال)' );
	define( 'CWEBSERVICE_CURRENCY_DSCR', 'از بين واحدهاي پولي معادل ريال را انتخاب کنيد' );
	define( 'CWEBSERVICE_SUCCESS_ORDERSTATUS_TTL', 'وضعيت سفارش' );
	define( 'CWEBSERVICE_SUCCESS_ORDERSTATUS_DSCR', 'پس از تکميل موفق فرآيند خريد ، وضعيت سفارش به چه حالتي تغيير نمايد؟' );
	define( 'CWEBSERVICE_ERRORINCONNECTION', 'خطا در فرآيند پرداخت - ارتباط با سرور برقرار نمي گردد ! مشکلي در ارتباط وجود دارد!' );
?>