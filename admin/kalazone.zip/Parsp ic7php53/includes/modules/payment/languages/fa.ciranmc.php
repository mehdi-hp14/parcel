<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CIRANMC_TTL', 'خريد پستي (www.iranmc.com)' );
	define( 'CIRANMC_DSCR', 'ماژول خريد پستي توسط سايت ايران ماکت سنتر' );
	define( 'CIRANMC_CFG_MERCHANT_ACCOUNT_TTL', 'شناسه ايران مارکت سنتر' );
	define( 'CIRANMC_CFG_MERCHANT_ACCOUNT_DSCR', 'شناسه ايران مارکت سنتر' );
	define( 'CIRANMC_CFG_TYPE', 'کد محصول يا شناسه محصول' );
	define( 'CIRANMC_CFG_TYPE_DSCR', '1 براي کد محصول و 0 براي شناسه محصول' );
	define( 'CIRANMC_TXT_1', 'ورود به سايت ايران ماکت سنتر (خريد پستي) و تکميل خريد' );
	define( 'CIRANMC_TXT_2', 'لطفا صبر کنيد. در حال ارسال اطلاعات ....' );
?>