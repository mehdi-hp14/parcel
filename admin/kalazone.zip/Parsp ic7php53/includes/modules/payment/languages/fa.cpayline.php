<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CPAYLINE_TTL', 'Payline' );
	define( 'CPAYLINE_DSCR', 'ماژول پرداخت آنلاين Payline' );
	define( 'CPAYLINE_CFG_MERCHANT_ACCOUNT_TTL', 'API کد شما در Payline' );
	define( 'CPAYLINE_CFG_MERCHANT_ACCOUNT_DSCR', 'لطفا کد payline خود را وارد نماييد' );
	define( 'CPAYLINE_CFG_RIAL_CURRENCY_TTL', 'واحد پول ريال' );
	define( 'CPAYLINE_CFG_RIAL_CURRENCY_DSCR', 'واحد پول ارسالي شما به payline حتما بايد به ریال باشد' );
	define( 'CPAYLINE_TXT_1', 'ورود به سايت payline و پرداخت آنلاين' );
?>