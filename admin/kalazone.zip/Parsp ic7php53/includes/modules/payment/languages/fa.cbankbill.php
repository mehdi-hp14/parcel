<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'CBANKBILL_TTL', 'پرداخت با فيش بانکي' );
	define( 'CBANKBILL_DSCR', 'ثبت فيش بانکي براي سفارشات' );
	define( 'CBANKBILL_CFG_RLS_CURRENCY_TTL', 'واحد پول ريال' );
	define( 'CBANKBILL_CFG_RLS_CURRENCY_DSCR', 'واحد اصلي پول که مبلغ به اين واحد به اعضا نمايش داده خواهد شد' );
	define( 'CBANKBILL_DESC_1', 'لطفا مبلغ سفارش را به يکي از شماره حسابهاي زير واريز نموده فيش آنرا در بخش <a href="index.php?user_details">حساب من</a> ثبت نماييد. توجه داشته باشيد که براي اين کار حتما بايد عضو باشيد و وارد سايت شده باشيد <br>
در صورت عدم ثبت فيش بانکي تا 72 ساعت سفارش شما حذف ميگردد.
' );
	define( 'CBANKBILL_TXT_2', 'مبلغ قابل پرداخت' );
	define( 'CBANKBILL_TXT_3', 'شماره سفارش' );
	define( 'CBANKBILL_TXT_1', 'ثبت فيش بانکي' );
?>