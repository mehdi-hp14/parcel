<?php
/*****************************************************************************
 *                                                                           *
 * parsp PROFESSIONAL 7.2.2                                                  *
 * Copyright (c) 2014 ParsP.com. All rights reserved.                  *
 *                                                                           *
 *****************************************************************************/
?><?php
	// Saman payment module
	// http://www.sb24.com

/**
 * @connect_module_class_name CSaman
 *
 */

class CSaman extends PaymentModule{
	
	

	
	function _initVars(){
		
		
		$this->title 		= CSAMAN_TTL;
		$this->description 	= CSAMAN_DSCR;
		$this->sort_order 	= 1;
		
		$this->Settings = array( 
			"CONF_PAYMENTMODULE_SAMAN_MERCHANT_ACCOUNT",
			"CONF_PAYMENTMODULE_SAMAN_RLS_CURRENCY"
			);
	}

	function after_processing_html( $orderID ) 
	{
		$order = ordGetOrder( $orderID );
		if ( $this->_getSettingValue('CONF_PAYMENTMODULE_SAMAN_RLS_CURRENCY') > 0 )
		{
			$SAcurr = currGetCurrencyByID ( $this->_getSettingValue('CONF_PAYMENTMODULE_SAMAN_RLS_CURRENCY') );
			$SAcurr_rate = $SAcurr["currency_value"];
		}
		if (!isset($SAcurr) || !$SAcurr)
		{
			$SAcurr_rate = 1;
		}
		
		$modID =  $this ->get_id();
		$order_amount = round(100*$order["order_amount"] * $SAcurr_rate)/100;

		$res = "";

		$res .= 
			"<table width='100%'>\n".
			"	<tr>\n".
			"		<td align='center'>\n".
			"<form method='POST' action='https://sep.shaparak.ir/payment.aspx'>\n".
			"<input type=\"hidden\" name=\"MID\" value=\"".$this->_getSettingValue('CONF_PAYMENTMODULE_SAMAN_MERCHANT_ACCOUNT')."\">\n".
			"<input type=\"hidden\" name=\"Amount\" value=\"".intval($order_amount)."\">\n".
			"<input type=\"hidden\" name=\"RedirectURL\" value=\"".CONF_FULL_SHOP_URL."?saman&modID=$modID"."\">".
			"<input type=\"hidden\" name=\"ResNum\" value=\"".$orderID."\">\n".
			"<input type=\"submit\" name=\"PAYMENT_METHOD\" value=\"".CSAMAN_TXT_1."\">\n".		
			"		</td>\n".
			"	</tr>\n".
			"</table>";
			
		return $res;
	}

	function _initSettingFields(){
		
		$this->SettingsFields['CONF_PAYMENTMODULE_SAMAN_MERCHANT_ACCOUNT'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CSAMAN_CFG_MERCHANT_ACCOUNT_TTL, 
			'settings_description' 	=> CSAMAN_CFG_MERCHANT_ACCOUNT_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);

		$this->SettingsFields['CONF_PAYMENTMODULE_SAMAN_RLS_CURRENCY'] = array(
			'settings_value' 		=> '0', 
			'settings_title' 			=> CSAMAN_CFG_RLS_CURRENCY_TTL, 
			'settings_description' 	=> CSAMAN_CFG_RLS_CURRENCY_DSCR, 
			'settings_html_function' 	=> 'setting_CURRENCY_SELECT(', 
			'sort_order' 			=> 1,
		);
	}
}
?>