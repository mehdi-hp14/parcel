<?php
	// Saderat payment module
	// http://www.bsi.ir

/**
 * @connect_module_class_name csaderat
 *
 */

class csaderat extends PaymentModule{

		private $_webURL;
		private $_webURLTest;
		private $_webURLVerify;
		private $_webURLVerifyTest;
		private $_testMode;
        	
	function _initVars(){
			
		$this->title 		= SADERAT_TTL;
		$this->description 	= SADERAT_DSCR;
		$this->sort_order 	= 1;
		
		$this->_webURL = 'https://Damoon.bsi.ir/DamoonPrePaymentController';
		$this->_webURLTest ='https://Damoon.bsi.ir/MerchantsIntegrationTestController';
		$this->_webURLVerify = 'https://Damoon.bsi.ir/DamoonVerificationController';
		$this->_webURLVerifyTest = 'https://Damoon.bsi.ir/VerificationTestController';

		$this->_testMode=false;
		
		$this->Settings = array( 
      "CONF_PAYMENTMODULE_SADERAT_DESCRIPTION",      		
			"CONF_PAYMENTMODULE_SADERAT_LOGIN_ID",
			"CONF_PAYMENTMODULE_SADERAT_TRAN_KEY",
			"CONF_PAYMENTMODULE_SADERAT_RLS_CURRENCY"
			);
	}

  function hmac ($key, $data)
  {
   $b = 64; // byte length for md5
   if (strlen($key) > $b) {
       $key = pack("H*",md5($key));

   }
   $key  = str_pad($key, $b, chr(0x00));
   $ipad = str_pad('', $b, chr(0x36));
   $opad = str_pad('', $b, chr(0x5c));
   $k_ipad = $key ^ $ipad ;
   $k_opad = $key ^ $opad;
   return md5($k_opad  . pack("H*",md5($k_ipad . $data)));
  }
  
	function after_processing_html( $orderID ) 
	{
		$order = ordGetOrder( $orderID );
		if ( $this->_getSettingValue('CONF_PAYMENTMODULE_SADERAT_RLS_CURRENCY') > 0 )
		{
			$SAcurr = currGetCurrencyByID ( $this->_getSettingValue('CONF_PAYMENTMODULE_SADERAT_RLS_CURRENCY') );
			$SAcurr_rate = $SAcurr["currency_value"];
		}
		if (!isset($SAcurr) || !$SAcurr)
		{
			$SAcurr_rate = 1;
		}
		
		$modID =  $this ->get_id();
		$order_amount = round(100*$order["order_amount"] * $SAcurr_rate)/100;
    
     $x_tran_key = $this->_getSettingValue('CONF_PAYMENTMODULE_SADERAT_TRAN_KEY');
     $x_description=$this->_getSettingValue('CONF_PAYMENTMODULE_SADERAT_DESCRIPTION');
     $loginid =$this->_getSettingValue('CONF_PAYMENTMODULE_SADERAT_LOGIN_ID');
     $x_fp_sequence=$orderID;
     $x_fp_timestamp =time();
     $x_Amount=$order_amount;
     $x_Amount=trim($x_Amount);     
     $x_currency_code ="Rial";
     
     $fingerprint = $this->hmac ($x_tran_key, $loginid . "^" . $x_fp_sequence . "^" .$x_fp_timestamp. "^" . $x_Amount ."^".$x_currency_code );                    

     $res = "";

		 $res .= 
			"<table width='100%'>\n".
			"	<tr>\n".
			"		<td align='center'>\n".
			"<form method='POST' action='".($this->_testMode ? $this->_webURLTest :$this->_webURL)."'>\n".
      "<input type=\"hidden\" name=\"x_description\" value=\"".$this->_getSettingValue('CONF_PAYMENTMODULE_SADERAT_DESCRIPTION')."\">\n".			
			"<input type=\"hidden\" name=\"x_login\" value=\"".$this->_getSettingValue('CONF_PAYMENTMODULE_SADERAT_LOGIN_ID')."\">\n".
			"<input type=\"hidden\" name=\"x_amount\" value=\"".$x_Amount."\">\n".
			"<input type=\"hidden\" name=\"redirectAddress\" value=\"".CONF_FULL_SHOP_URL."?SADERAT&modID=$modID"."\">".
			"<input type=\"hidden\" name=\"x_fp_sequence\" value=\"".$x_fp_sequence."\">\n".
			"<input type=\"hidden\" name=\"x_fp_timestamp\" value=\"".$x_fp_timestamp."\">\n".
			"<input type=\"hidden\" name=\"x_fp_hash\" value=\"".$fingerprint."\">\n".
			"<input type=\"hidden\" name=\"x_currency_code\" value=\"".$x_currency_code."\">\n".
			"<INPUT type=\"hidden\" name=\"x_test_request\" value=\"".$this->_testMode."\">\n".
			"<INPUT type=\"hidden\" name=\"x_show_form\" value=\"PAYMENT_FORM\">\n".
			"<input type=\"submit\" name=\"PAYMENT_METHOD\" value=\"".SADERAT_TXT_1."\">\n".		
			"		</td>\n".
			"	</tr>\n".
			"</table>";
			
		return $res;
	}

  public function checkReceipt($post,$adminpage) 
  {
			if( isset($post['x_trans_id']) )
			{
				$x_trans_id = $post['x_trans_id'];
				$x_response_code = $post['x_response_code'];
				$x_response_subcode = $post['x_response_subcode'];
				$x_response_reason_code = $post['x_response_reason_code'];
				$x_response_reason_text = $post['x_response_reason_text'];
				$x_login = $post['x_login'];
				$x_fp_sequence = $post['x_fp_sequence'];
				$x_fp_timestamp = $post['x_fp_timestamp'];
				$x_amount = $post['x_amount'];
				$x_currency_code = $post['x_currency_code'];
				$x_fp_hash = $post['x_fp_hash'];				
				$x_currency_code = "Rial";	

				
				$x_tran_key = $this->_getSettingValue('CONF_PAYMENTMODULE_SADERAT_TRAN_KEY');
				$fingerprint = $this ->hmac($x_tran_key, $x_trans_id . "^" . $x_response_code . "^" .$x_response_subcode . "^" .$x_response_reason_code . "^" .  $x_response_reason_text . "^" . $x_login . "^" . $x_fp_sequence . "^" . $x_fp_timestamp . "^" . $x_amount . "^" . $x_currency_code);

				$x_fp_hash=rtrim($x_fp_hash);
				if($fingerprint != $x_fp_hash)
				{
					echo 'Error in Fingerprint.';    
				}
				else
				{
					if($x_response_code != 4)						 

					if($x_response_code == 1 )
					{
            echo '<h2>' . "پرداخت تایید شد" . '</h2>';						
						$result = true;
					}
					else
					{
						$result = false;
						switch($x_response_code)
						{
							case "2":
								echo 'RCP-ERR-Transaction Declined';
								break;    
							case "3":
								echo 'RCP-ERR-Error in payment';
								break;
							case "4":
								echo 'RCP-ERR-Ambiguous-Wait for certain response';
								break;
						}
					}
				}
			}
			else 
			{
				echo 'Error in payment, Transaction not exist.';
				$result=false;
			}
			
			return $result;
		}
		
	  private function verificationOrders($sequence)	{
	   $x_tran_key = $this->_getSettingValue('CONF_PAYMENTMODULE_SADERAT_TRAN_KEY');
     $x_description=$this->_getSettingValue('CONF_PAYMENTMODULE_SADERAT_DESCRIPTION');
     $loginid =$this->_getSettingValue('CONF_PAYMENTMODULE_SADERAT_LOGIN_ID');
			
			$x_currency_code = "Rial";
			
			$resultArray = array();


			$incompeleteOrder = $this->checkOrderInfoAll($sequence);

			if(!$incompeleteOrder)
				return false;

			$result = $this->verificationTransactions($incompeleteOrder['sequence'],$incompeleteOrder['time_start'],$incompeleteOrder['total_amount'],$x_currency_code,$x_description);
		
			$result = explode("&",$result);
			foreach ($result AS $temp) 
			{
				$temp = explode("=",$temp);
				$resultArray[$temp[0]] = $temp[1];
			}
			return $this->checkReceipt($resultArray,true);
		}
    
    private function verificationTransactions($x_fp_sequence,$x_fp_timestamp,$x_amount,$x_currency_code,$x_description)	
    {
			$x_tran_key = $this->_TRANSKEY;
			$x_login = $this->_ID;

			$x_fp_hash = $this -> hmac ($x_tran_key, $x_login . "^" . $x_fp_sequence . "^" . $x_fp_timestamp . "^" . $x_amount . "^" . $x_currency_code);
			//return $response=$this->doVerification($x_fp_timestamp,$x_fp_sequence,$x_fp_hash,$x_login,$x_description,$x_amount,$x_currency_code);

			$ch = curl_init();
			if(!$this->_testMode)
				curl_setopt($ch, CURLOPT_URL, $this->_webURLVerify);
			else
				curl_setopt($ch, CURLOPT_URL, $this->_webURLVerifyTest);


			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt ($ch, CURLOPT_POST, 1);
			$post="x_fp_timestamp=$x_fp_timestamp&x_fp_sequence=$x_fp_sequence&x_fp_hash=$x_fp_hash&x_login=$x_login&x_description=$x_description&x_amount=$x_amount&x_currency_code=$x_currency_code";

			curl_setopt ($ch, CURLOPT_POSTFIELDS, $post);
			$estore = curl_exec ($ch);
			curl_close ($ch);
			if(!$estore){
				echo 'Error in verification';
				//$this->displayErrors();
				return false;
			}
			$tagPos = strpos($estore,'<');
			return substr($estore,0,$tagPos);
			return $estore;
		}	


	function _initSettingFields(){
	
		$this->SettingsFields['CONF_PAYMENTMODULE_SADERAT_DESCRIPTION'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> SADERAT_CFG_DESCRIPTION_TTL, 
			'settings_description' 	=> SADERAT_DESCRIPTION_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		
		$this->SettingsFields['CONF_PAYMENTMODULE_SADERAT_LOGIN_ID'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> SADERAT_CFG_LOGIN_ID_TTL, 
			'settings_description' 	=> SADERAT_CFG_LOGIN_ID_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);

    $this->SettingsFields['CONF_PAYMENTMODULE_SADERAT_TRAN_KEY'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> SADERAT_CFG_TRAN_KEY_TTL, 
			'settings_description' 	=> SADERAT_TRAN_KEY_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		$this->SettingsFields['CONF_PAYMENTMODULE_SADERAT_RLS_CURRENCY'] = array(
			'settings_value' 		=> '0', 
			'settings_title' 			=> SADERAT_CFG_RLS_CURRENCY_TTL, 
			'settings_description' 	=> SADERAT_CFG_RLS_CURRENCY_DSCR, 
			'settings_html_function' 	=> 'setting_CURRENCY_SELECT(', 
			'sort_order' 			=> 1,
		);
	}
}
?>