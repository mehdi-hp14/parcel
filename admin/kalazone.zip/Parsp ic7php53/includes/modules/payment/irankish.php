<?php
/*****************************************************************************
* www.softiran.org
*****************************************************************************/

/**
 * @connect_module_class_name Cirankish
 *
 */

class Cirankish extends PaymentModule{

	function _initVars(){
		
		$this->title 		= Cirankish_TTL;
		$this->description 	= Cirankish_DSCR;
		$this->sort_order 	= 1;
		$this->Settings = array( 
			"CONF_PAYMENTMODULE_IRANKISH_MERCHANT_ACCOUNT",
			"CONF_PAYMENTMODULE_IRANKISH_MERCHANT_SHA1KEY",
			"CONF_PAYMENTMODULE_IRANKISH_RIAL_CURRENCY"
			);
	}

	function after_processing_html( $orderID ) 
	{
		$order = ordGetOrder( $orderID );
		if ( $this->_getSettingValue('CONF_PAYMENTMODULE_IRANKISH_RIAL_CURRENCY') > 0 )
		{
			$PAcurr = currGetCurrencyByID ( $this->_getSettingValue('CONF_PAYMENTMODULE_IRANKISH_RIAL_CURRENCY') );
			$PAcurr_rate = $PAcurr["currency_value"];
		}
		if (!isset($PAcurr) || !$PAcurr)
		{
			$PAcurr_rate = 1;
		}
		$order_amount = round($order["order_amount"]);
		$modID =  $this ->get_id();
        $amount = $order_amount; 
		$redirect_url = urlencode(CONF_FULL_SHOP_URL."?irankish&modID=$modID&pay=1&orderID=$orderID");
		$terminal_id = $this->_getSettingValue('CONF_PAYMENTMODULE_IRANKISH_MERCHANT_ACCOUNT');
		
		$client = new SoapClient('https://ikc.shaparak.ir/XToken/Tokens.xml', array('soap_version'   => SOAP_1_1));

		$params['amount'] = $amount;
		$params['merchantId'] = $terminal_id;
		$params['invoiceNo'] = time();
		$params['paymentId'] = time();
		$params['specialPaymentId'] = time();
		$params['revertURL'] = $redirect_url;
		$params['description'] = "";
		$result = $client->__soapCall("MakeToken", array($params));
		$token = $result->MakeTokenResult->token;
		
		@session_start();
		$_SESSION['token'] = $token;
		$data['token'] = $token;
		$data['merchantId'] = $terminal_id;

		 
		$this->redirect_post('https://ikc.shaparak.ir/TPayment/Payment/index',$data);
		exit ;
		return;
	}
	function redirect_post($url, array $data)
{

  echo '<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
	<title>در حال اتصال ...</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <style type="text/css">
	#main {
	    background-color: #F1F1F1;
	    border: 1px solid #CACACA;
	    height: 90px;
	    left: 50%;
	    margin-left: -265px;
	    position: absolute;
	    top: 200px;
	    width: 530px;
	}
	#main p {
	    color: #757575;
	    direction: rtl;
	    font-family: Arial;
	    font-size: 16px;
	    font-weight: bold;
	    line-height: 27px;
	    margin-top: 30px;
	    padding-right: 60px;
	    text-align: right;
	}
    </style>
        <script type="text/javascript">
            function closethisasap() {
                document.forms["redirectpost"].submit();
            }
        </script>
    </head>
    <body onload="closethisasap();">';
   echo '<form name="redirectpost" method="post" action="'.$url.'">';
       
        if ( !is_null($data) ) {
            foreach ($data as $k => $v) {
                echo '<input type="hidden" name="' . $k . '" value="' . $v . '"> ';
            }
        }
       
   echo' </form><div id="main">
<p>درحال اتصال به درگاه بانک</p></div>
    </body>
    </html>';
   
    exit;
}
	function _initSettingFields(){
		
		$this->SettingsFields['CONF_PAYMENTMODULE_IRANKISH_MERCHANT_ACCOUNT'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> Cirankish_CFG_MERCHANT_ACCOUNT_TTL,
			'settings_description' 	=> Cirankish_CFG_MERCHANT_ACCOUNT_DSCR,
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);		
		$this->SettingsFields['CONF_PAYMENTMODULE_IRANKISH_MERCHANT_SHA1KEY'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> 'SHA1KEY',
			'settings_description' 	=> 'SHA1KEY',
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);

		$this->SettingsFields['CONF_PAYMENTMODULE_IRANKISH_RIAL_CURRENCY'] = array(
			'settings_value' 		=> '0', 
			'settings_title' 			=> Cirankish_CFG_RIAL_CURRENCY_TTL,
			'settings_description' 	=> Cirankish_CFG_RIAL_CURRENCY_DSCR,
			'settings_html_function' 	=> 'setting_CURRENCY_SELECT(', 
			'sort_order' 			=> 1,
		);
	}
}
?>