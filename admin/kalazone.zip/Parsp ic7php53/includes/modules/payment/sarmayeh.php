<?php
	// sarmayeh payment module
	// http://www.sarmayebank.com

/**
 * @connect_module_class_name csarmayeh
 *
 */

class csarmayeh extends PaymentModule{
	
	function _initVars(){
		
		$this->title 		= CSARMAYEH_TTL;
		$this->description 	= CSARMAYEH_DSCR;
		$this->sort_order 	= 1;
		$this->_testMode=false;
		$this->Settings = array( 			
			"CONF_PAYMENTMODULE_SARMAYEH_USERID",
			"CONF_PAYMENTMODULE_SARMAYEH_PASS",
			"CONF_PAYMENTMODULE_SARMAYEH_NETUSERID",
			"CONF_PAYMENTMODULE_SARMAYEH_NETPASS",
			"CONF_PAYMENTMODULE_SARMAYEH_BANKURL",
			"CONF_PAYMENTMODULE_SARMAYEH_RIAL_CURRENCY",
			"CONF_PAYMENTMODULE_SARMAYEH_SITE_ADDRESS",
			"CONF_PAYMENTMODULE_SARMAYEH_BANKREDIRECT"
			);
	}

	function after_processing_html( $orderID ) 
	{
    $bankerrors=
      array('00'=>'تراکنش با موفقیت انجام شد','01'=>'خطا در فرمت اطلاعات ارسالی',
      '02'=>'فروشگاه نامعتبر می باشد','03'=>'تراکنش با وقفه ایجاد شده است',
      '04'=>'ای پی فروشگاه مجاز نیست','05'=>'کد سفارش قبلا استفاده شده است',
      '06'=> 'خطای داخلی در سیستم بانکی','07'=> 'تراکنش Void قبلا انجام شده است',
      '08'=> 'وضعیت تراکنش خرید ، وارسی شده نمی باشد.','09'=> 'مبلغ تراکنش خرید با مبلغی که قرار است void شود برابر نیست.',
      '10'=> 'تراکنش خرید یافت نشد.','11'=> 'فروشگاه مجوز تسویه انی ندارد',
      '12'=> 'انصراف از خرید','13'=> 'pac معتبر نمی باشد');
	
	  
		$order = ordGetOrder( $orderID );
		if ( $this->_getSettingValue('CONF_PAYMENTMODULE_SARMAYEH_RIAL_CURRENCY') > 0 )
		{
			$SARMAYEHcurr = currGetCurrencyByID ( $this->_getSettingValue('CONF_PAYMENTMODULE_SARMAYEH_RIAL_CURRENCY') );
			$SARMAYEHcurr_rate = $SARMAYEHcurr["currency_value"];
		}
		if (!isset($SARMAYEHcurr) || !$SARMAYEHcurr)
		{
			$SARMAYEHcurr_rate = 1;
		}

		$order_amount = round(100*$order["order_amount"] * $SARMAYEHcurr_rate)/100;
		
		$modID =  $this ->get_id();
				
		$callbackUrl = CONF_FULL_SHOP_URL."?SARMAYEH&modID=$modID";
		$wsdl=$this->_getSettingValue('CONF_PAYMENTMODULE_SARMAYEH_BANKURL');
		$user=$this->_getSettingValue('CONF_PAYMENTMODULE_SARMAYEH_USERID');
		$pass=$this->_getSettingValue('CONF_PAYMENTMODULE_SARMAYEH_PASS');          
    $net_user=$this->_getSettingValue('CONF_PAYMENTMODULE_SARMAYEH_NETUSERID');
		$net_pass=$this->_getSettingValue('CONF_PAYMENTMODULE_SARMAYEH_NETPASS');
    $shop_name=$this->_getSettingValue('CONF_PAYMENTMODULE_SARMAYEH_SITE_ADDRESS');
    $bankurl=$this->_getSettingValue('CONF_PAYMENTMODULE_SARMAYEH_BANKREDIRECT');		                             
                                 		  
    // start of SARMAYEH code //////////////////////////////////////////////////////////////////////////////////////////////////////////		
 		    require_once("nusoap/nusoap.php");  //'https://Pg.sbank.ir/axis/SpringWS?wsdl'
        try
        {            	          	    
            	$soapclient = new nusoap_client($wsdl,true,false,$wsdl,80,$net_user,$net_pass); //for test use             
            //  $soapclient = new nusoap_client($wsdl,true,false,false,false,false,90,90);                                                              
              $soapclient->setCredentials(urlencode($net_user),urlencode($net_pass),'digest');
              $soapProxy = $soapclient->getProxy();
              
            //  print_r($soapclient);                                                     
    
                                                           
        }
        catch (SoapFault $sf) {
              $error.= $sf->faultcode."\n";
              $error.= $sf->faultstring."\n";                
        }

            if (!isset($soapclient))
            {
              $error .= "خطا در فرآيند پرداخت - ارتباط با سرور برقرار نمي گردد ! مشکلي در ارتباط وجود دارد!";
              return 0;
            }
            
            try{
            
            $parameters = array(			
              'reservationNum' => $orderID,
			        'userName' => $user,
			        'password'=>$pass,
			        'url' => $shop_name,
			        'amount'=>"$order_amount"
             );
                      		     				 	   				   					   
				     $res= $soapclient->call('paymentGatewayMerchantAuthentication',$parameters);                        	                                 
             //$res = $soapProxy->paymentGatewayMerchantAuthentication($orderID,$user,$pass,$shop_name,$order_amount);                             
             list($pac,$status)=explode(';',$res);                                  
             }
              catch (SoapFault $sf) {
                $error.= $sf->faultcode."\n";
                $error.= $sf->faultstring."\n";
            }         	      	      		  		  
      	if ( (!$soapclient) OR ($err = $soapclient->getError()) ) {
		     $error .= $err . "<br />" ;
		     echo '<html xmlns="http://www.w3.org/1999/xhtml" dir="rtl"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /></head><body dir=ltr>';
		     echo $error . ' Line:'.__LINE__;             
				 echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
				 echo '<h2>Debug</h2><pre>' . htmlspecialchars($soapclient->getDebug(), ENT_QUOTES) . '</pre>';				 				 
				 print '<script type="text/javascript">';				        
         print 'alert("The USERID and PASSWORD is invalid.\n - Please Check input Data in sarmayeh module setting. \n'.CSARMAYEH_USERPASS_INVALID.'")';                        
         print '</script>';
         exit();
		  }
			 else
					{					
             			
          list($pac,$status)=explode(';',$res);	  			            
			    $ResCode = $res[0];
			    $Hashcode = $res[1]; 
					if ($status == "00") {					
		$res = "";
		$res .= 
			"<table width='100%'>\n".
			"	<tr>\n".
			"		<td align='center'>\n".
			'<form name="sarpay" id="sarpay" action="'.$bankurl.'" method="post" class="block">
       <input name="pac" type="hidden" value="'.$pac.'">
       <input name="callbackUrl" type="hidden" value="'.$callbackUrl.'">'.
			"<input type=\"submit\" name=\"PAYMENT_METHOD\" value=\"".CSARMAYEH_TXT_1."\">\n".		
			"		</td>\n".
			"	</tr>\n".
			"</table>
      <script>
        setTimeout(' var theForm = document.forms[\'sarpay\'];if (!theForm) theForm = document.sarpay;theForm.submit();', 3000);        
      </script>
      ";
					}else {
					  $res="<p><center>";
						$res.="متاسفانه امکان پرداخت از طریق درگاه بانک سرمایه وجود ندارد ."."<br><br><b>"."دلیل :".$status."-". $bankerrors[$status];
						$res.="</center></b></p>";
					}
				}
			
    // end of SARMAYEH //////////////////////////////////////////////////////////////////////////////////

		return $res;
	}
	

	function _initSettingFields(){
				
		$this->SettingsFields['CONF_PAYMENTMODULE_SARMAYEH_USERID'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CSARMAYEH_CFG_USERID_TTL, 
			'settings_description' 	=> CSARMAYEH_CFG_USERID_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		
		$this->SettingsFields['CONF_PAYMENTMODULE_SARMAYEH_PASS'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CSARMAYEH_CFG_PASS_TTL, 
			'settings_description' 	=> CSARMAYEH_CFG_PASS_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 2,
		);
		$this->SettingsFields['CONF_PAYMENTMODULE_SARMAYEH_NETUSERID'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CSARMAYEH_CFG_USERIDNET_TTL, 
			'settings_description' 	=> CSARMAYEH_CFG_USERIDNET_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 5,
		);
		
		$this->SettingsFields['CONF_PAYMENTMODULE_SARMAYEH_NETPASS'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CSARMAYEH_CFG_PASSNET_TTL, 
			'settings_description' 	=> CSARMAYEH_CFG_PASSNET_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 6,
		); 
		$this->SettingsFields['CONF_PAYMENTMODULE_SARMAYEH_SITE_ADDRESS'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CSARMAYEH_CFG_SITE_ADDRESS_TTL  , 
			'settings_description' 	=> CSARMAYEH_CFG_SITE_ADDRESS_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 0,
		);
		
		$this->SettingsFields['CONF_PAYMENTMODULE_SARMAYEH_BANKREDIRECT'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CSARMAYEH_CFG_BANKREDIRECT_TTL  , 
			'settings_description' 	=> CSARMAYEH_CFG_BANKREDIRECT_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 4,
		);
		
    $this->SettingsFields['CONF_PAYMENTMODULE_SARMAYEH_BANKURL'] = array(
			'settings_value' 		=> 'https://pgtest.sarmayebank.com',     
			'settings_title' 			=> CSARMAYEH_CFG_BANKURL_TTL, 
			'settings_description' 	=> CSARMAYEH_CFG_BANKURL_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 3,
		);
		$this->SettingsFields['CONF_PAYMENTMODULE_SARMAYEH_RIAL_CURRENCY'] = array(
			'settings_value' 		=> '0', 
			'settings_title' 			=> CSARMAYEH_CFG_RIAL_CURRENCY_TTL, 
			'settings_description' 	=> CSARMAYEH_CFG_RIAL_CURRENCY_DSCR, 
			'settings_html_function' 	=> 'setting_CURRENCY_SELECT(', 
			'sort_order' 			=> 1,
		);
	}
}
?>