<?php
/*****************************************************************************
 *                                                                           *
 * www.parsp.com                                                       *
 * Copyright (c) 2008 . All rights reserved.                                 *
 *                                                                           *
 *****************************************************************************/
	// posti payment module
	// http://www.iranmc.com

/**
 * @connect_module_class_name CIranmc
 *
 */

class CIranmc extends PaymentModule{
	
	function _initVars(){
		
		$this->title 		= CIRANMC_TTL;
		$this->description 	= CIRANMC_DSCR;
		$this->sort_order 	= 1;
		
		$this->Settings = array( 
			"CONF_PAYMENTMODULE_IRANMC_MERCHANT_ACCOUNT",
			"CONF_PAYMENTMODULE_IRANMC_TYPE"
			);
	}

	
	
	function after_processing_html( $orderID ) 
	{
		$order = ordGetOrder( $orderID );
		$mid =  $this->_getSettingValue('CONF_PAYMENTMODULE_IRANMC_MERCHANT_ACCOUNT');
		

		$order_amount = round(100*$order["order_amount"])/100;
		
		
		function getCount($orderID){
			$q = mysql_query("SELECT 
		  count(Parsp_ordered_carts.name)
		 FROM
		  Parsp_ordered_carts
		 WHERE
		  (Parsp_ordered_carts.orderID = $orderID)") or die(mysql_error());
			$cnt = mysql_fetch_array($q);
			return $cnt[0];
		}
		

		$test = $mid2;
				
		function getOrder($orderID, $mid){

		$q = mysql_query("SELECT * from Parsp_ordered_carts WHERE orderID =".$orderID) or die(mysql_error());
		
		$var1 .= '<div style="visibility: hidden">';
		while ($res = mysql_fetch_array($q)) {
			$q2 = mysql_query("SELECT productID, product_code FROM Parsp_products WHERE productID=".$res['productID']);
			$res2 = mysql_fetch_array($q2);
			$var1 .= '<embed name="irmc1" id="irmc1" width="0" height="0" src="http://www.30ds.com/Card/add.php?PID='.$mid.$res2['product_code'].'&checker=0">';
			$last = 'http://www.30ds.com/Card/add.php?PID='.$mid.$res2['product_code'].'&checker=0';
		}
		$var1 .= '</div>';

		
		$var1 .= '<script language="javascript">
		function myFunction(){
		window.location = "'.$last.'";
		}
		function doGo(btn){
		btn.disabled = true;
		btn.value = "'.CIRANMC_TXT_2.'";
		setInterval(myFunction, 6000);
		}
		</script>';
		
		
		$var1 .= '<center><input type="button" name="go" id="do" value="'.CIRANMC_TXT_1.'" onclick="doGo(this);"></center>';
		return $var1;
		
		}
		$cnt =  getCount($orderID);
		$res = getOrder($orderID,$mid);

		return $res;
	}

	function _initSettingFields(){
		
		$this->SettingsFields['CONF_PAYMENTMODULE_IRANMC_MERCHANT_ACCOUNT'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CIRANMC_CFG_MERCHANT_ACCOUNT_TTL, 
			'settings_description' 	=> CIRANMC_CFG_MERCHANT_ACCOUNT_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);

		$this->SettingsFields['CONF_PAYMENTMODULE_IRANMC_TYPE'] = array(
			'settings_value' 		=> '1', 
			'settings_title' 			=> CIRANMC_CFG_TYPE, 
			'settings_description' 	=> CIRANMC_CFG_TYPE_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 2,
		);
	}
}
?>