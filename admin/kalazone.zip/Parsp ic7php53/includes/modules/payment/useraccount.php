<?php
/*****************************************************************************
 *                                                                           *
 * parsp PROFESSIONAL 7.2.2                                                  *
 * Copyright (c) 2014 ParsP.com. All rights reserved.                  *
 *                                                                           *
 *****************************************************************************/
?><?php
	
/**
 * @connect_module_class_name CUseraccount
 *
 */

class Cuseraccount extends PaymentModule{
	
	function _initVars(){
		
		$this->title 		= CUSERACCOUNT_TTL;
		$this->description 	= CUSERACCOUNT_DSCR;
		$this->sort_order 	= 1;
		
		$this->Settings = array( 
			"CONF_PAYMENTMODULE_USERACCOUNT_RLS_CURRENCY"
			);
	}

	function after_processing_html( $orderID ) 
	{
		$order = ordGetOrder( $orderID );
		if ( $this->_getSettingValue('CONF_PAYMENTMODULE_USERACCOUNT_RLS_CURRENCY') > 0 )
		{
			$EGcurr = currGetCurrencyByID ( $this->_getSettingValue('CONF_PAYMENTMODULE_USERACCOUNT_RLS_CURRENCY') );
			$EGcurr_rate = $EGcurr["currency_value"];
		}
		if (!isset($EGcurr) || !$EGcurr)
		{
			$EGcurr_rate = 1;
		}

		$order_amount = round(100*$order["order_amount"] * $EGcurr_rate)/100;

		$res = "";

		if ($order['statusID'] != CONF_COMPLETED_ORDER_STATUS) {
				
				if (!$_SESSION['log']) {
					ostSetOrderStatusToOrder($orderID,1);
					$res = USERACCOUNT_NOT_LOGGEDIN;
				}else {
					
					$userCredit = getUcreditByLogin($_SESSION['log']);
					
					$login = $_SESSION['log'];
					
					if ($order_amount > $userCredit) {
						ostSetOrderStatusToOrder($orderID,1);
						$res = USERACCOUNT_ISNT_ENOUGH;
					}elseif ($order_amount == $userCredit || $order_amount < $userCredit){
		
						$newCredit = $userCredit - $order_amount;
						updateUserCreditByLogin($login, $newCredit);
            $res = STR_SHETAB_THANKS.'<br><br>'.USERACCOUNT_ORDERID_IS.': <b>'.$orderID.'</b><br>'.USERACCOUNT_REMAINING_CREDIT.": <b>".show_price($newCredit, 1)."</b><br>".$pininfo;
            $pininfo =  ostSetOrderStatusToOrder($orderID, CONF_COMPLETED_ORDER_STATUS,$res,1);
						
						
					}
			
				}
		}else {
			
			$res = USERACCOUNT_ORDER_IS_COMP;
		}
		
		
		

		return "<center><div style=\"border: 1px solid #CCCCCC; background-color: #EEEEEE; width: 60%; padding: 10px\" align=\"center\">".$res."</div></center>";
	}

	function _initSettingFields(){
		
		$this->SettingsFields['CONF_PAYMENTMODULE_USERACCOUNT_RLS_CURRENCY'] = array(
			'settings_value' 		=> '0', 
			'settings_title' 			=> CUSERACCOUNT_CFG_RLS_CURRENCY_TTL, 
			'settings_description' 	=> CUSERACCOUNT_CFG_RLS_CURRENCY_DSCR, 
			'settings_html_function' 	=> 'setting_CURRENCY_SELECT(', 
			'sort_order' 			=> 0,
		);
	}
}
?>