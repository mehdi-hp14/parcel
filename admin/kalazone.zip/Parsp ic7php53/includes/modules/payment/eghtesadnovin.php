<?php
	// EghtesadNovin payment module
	// http://www.enbank.ir

/**
 * @connect_module_class_name CEghtesadNovin
 *
 */

class CEghtesadNovin extends PaymentModule{
	
	

	
	function _initVars(){
		
		
		$this->title 		= CEGHTESADNOVIN_TTL;
		$this->description 	= CEGHTESADNOVIN_DSCR;
		$this->sort_order 	= 1;
		
		$this->Settings = array( 
			"CONF_PAYMENTMODULE_EGHTESADNOVIN_MERCHANT_ACCOUNT",
      "CONF_PAYMENTMODULE_EGHTESADNOVIN_USERNAME",
      "CONF_PAYMENTMODULE_EGHTESADNOVIN_PASSWORD",
			"CONF_PAYMENTMODULE_EGHTESADNOVIN_RLS_CURRENCY"
			);
	}

	function after_processing_html( $orderID ) 
	{
		$order = ordGetOrder( $orderID );
		if ( $this->_getSettingValue('CONF_PAYMENTMODULE_EGHTESADNOVIN_RLS_CURRENCY') > 0 )
		{
			$ENcurr = currGetCurrencyByID ( $this->_getSettingValue('CONF_PAYMENTMODULE_EGHTESADNOVIN_RLS_CURRENCY') );
			$ENcurr_rate = $ENcurr["currency_value"];
		}
		if (!isset($ENcurr) || !$ENcurr)
		{
			$ENcurr_rate = 1;
		}
		
		$modID =  $this ->get_id();
		$order_amount = round(100*$order["order_amount"] * $ENcurr_rate)/100;

		$res = "";

		$res .= 			
			"<table width='100%'>\n".
			"	<tr>\n".
			"		<td align='center'>\n".
			"<form id=\"eghtesadPay\" name=\"eghtesadPay\" method='POST' action='https://pna.shaparak.ir/CardServices/controller'>\n".
			"<input type=\"hidden\" name=\"MID\" value=\"".$this->_getSettingValue('CONF_PAYMENTMODULE_EGHTESADNOVIN_MERCHANT_ACCOUNT')."\">\n".
			"<input type=\"hidden\" name=\"Amount\" value=\"".$order_amount."\">\n".
			"<input type=\"hidden\" name=\"RedirectURL\" value=\"".CONF_FULL_SHOP_URL."?eghtesadnovin&modID=$modID"."\">\n".
			"<input type=\"hidden\" name=\"ResNum\" value=\"".$orderID."\">\n".
			"<input type=\"submit\" name=\"PAYMENT_METHOD\" value=\"".CEGHTESADNOVIN_TXT_1."\">\n".		
			"</form>\n".		
			"		</td>\n".
			"	</tr>\n".
			"</table>";
			
		return $res;
	}

	function _initSettingFields(){
		
		$this->SettingsFields['CONF_PAYMENTMODULE_EGHTESADNOVIN_MERCHANT_ACCOUNT'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CEGHTESADNOVIN_CFG_MERCHANT_ACCOUNT_TTL, 
			'settings_description' 	=> CEGHTESADNOVIN_CFG_MERCHANT_ACCOUNT_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
    $this->SettingsFields['CONF_PAYMENTMODULE_EGHTESADNOVIN_USERNAME'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CEGHTESADNOVIN_CFG_USERNAME_TTL, 
			'settings_description' 	=> CEGHTESADNOVIN_CFG_USERNAME_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
    $this->SettingsFields['CONF_PAYMENTMODULE_EGHTESADNOVIN_PASSWORD'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CEGHTESADNOVIN_CFG_PASSWORD_TTL, 
			'settings_description' 	=> CEGHTESADNOVIN_CFG_PASSWORD_DSCR, 
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);
		$this->SettingsFields['CONF_PAYMENTMODULE_EGHTESADNOVIN_RLS_CURRENCY'] = array(
			'settings_value' 		=> '0', 
			'settings_title' 			=> CEGHTESADNOVIN_CFG_RLS_CURRENCY_TTL, 
			'settings_description' 	=> CEGHTESADNOVIN_CFG_RLS_CURRENCY_DSCR, 
			'settings_html_function' 	=> 'setting_CURRENCY_SELECT(', 
			'sort_order' 			=> 1,
		);
	}
}
?>