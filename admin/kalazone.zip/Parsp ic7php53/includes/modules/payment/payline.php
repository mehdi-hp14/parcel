<?php
	// mellat payment module
	// http://www.payline.ir

/**
 * @connect_module_class_name CPAYLINE
 *
 */

class CPAYLINE extends PaymentModule{



    public function send($url,$api,$amount,$redirect){
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_POSTFIELDS,"api=$api&amount=$amount&redirect=$redirect");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        $res = curl_exec($ch);
        curl_close($ch);
        return $res;
    }
    public function get($url,$api,$trans_id,$id_get){
        $ch = curl_init();
        curl_setopt($ch,CURLOPT_URL,$url);
        curl_setopt($ch,CURLOPT_POSTFIELDS,"api=$api&id_get=$id_get&trans_id=$trans_id");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
        $res = curl_exec($ch);
        curl_close($ch);
        return $res;
    }

	function _initVars(){
		
		$this->title 		= CPAYLINE_TTL;
		$this->description 	= CPAYLINE_DSCR;
		$this->sort_order 	= 1;
		$this->Settings = array( 
			"CONF_PAYMENTMODULE_PAYLINE_MERCHANT_ACCOUNT",
			"CONF_PAYMENTMODULE_PAYLINE_RIAL_CURRENCY"
			);
	}

	function after_processing_html( $orderID ) 
	{
		
		
		$order = ordGetOrder( $orderID );
		if ( $this->_getSettingValue('CONF_PAYMENTMODULE_PAYLINE_RIAL_CURRENCY') > 0 )
		{
			$PAcurr = currGetCurrencyByID ( $this->_getSettingValue('CONF_PAYMENTMODULE_PAYLINE_RIAL_CURRENCY') );
			$PAcurr_rate = $PAcurr["currency_value"];
		}
		if (!isset($PAcurr) || !$PAcurr)
		{
			$PAcurr_rate = 1;
		}
		$order_amount = round(100*$order["order_amount"] * $PAcurr_rate)/100;
		$modID =  $this ->get_id();
		
		
		$url = 'http://payline.ir/payment/gateway-send';

        $amount = $order_amount;  // here is the posted amount
	    //$orderID = $_POST["ResNum"]; // this function is internal which will get order id

    $callbackUrl = urlencode(CONF_FULL_SHOP_URL."?payline&modID=$modID&pay=1");
    $pin = $this->_getSettingValue('CONF_PAYMENTMODULE_PAYLINE_MERCHANT_ACCOUNT');


	$result = $this->send($url,$pin,$amount,$callbackUrl);


    if($result > 0 && is_numeric($result)){
	   // this is a succcessfull connection
		db_query( "update ".ORDERS_TABLE." set refnum='".$result."' where orderID=".$orderID);
	   $go = "http://payline.ir/payment/gateway-$result";
        header("Location: $go");
	   exit() ;
	   die() ;
	   return;

    } else {
	   // this is unsucccessfull connection
	  echo "<p align=center>";
	  echo "err<br />" ;
	  echo "$result <br />" ;
	  echo "$orderID <br />" ;
	  
	  echo "</p>";

    }

  echo "UNSUCCSESSFUL!";

	}

	function _initSettingFields(){
		
		$this->SettingsFields['CONF_PAYMENTMODULE_PAYLINE_MERCHANT_ACCOUNT'] = array(
			'settings_value' 		=> '', 
			'settings_title' 			=> CPAYLINE_CFG_MERCHANT_ACCOUNT_TTL,
			'settings_description' 	=> CPAYLINE_CFG_MERCHANT_ACCOUNT_DSCR,
			'settings_html_function' 	=> 'setting_TEXT_BOX(0,', 
			'sort_order' 			=> 1,
		);

		$this->SettingsFields['CONF_PAYMENTMODULE_PAYLINE_RIAL_CURRENCY'] = array(
			'settings_value' 		=> '0', 
			'settings_title' 			=> CPAYLINE_CFG_RIAL_CURRENCY_TTL,
			'settings_description' 	=> CPAYLINE_CFG_RIAL_CURRENCY_DSCR,
			'settings_html_function' 	=> 'setting_CURRENCY_SELECT(', 
			'sort_order' 			=> 1,
		);
	}
}
?>