<?php
	
/**
 * @connect_module_class_name CBankbill
 *
 */

class Cbankbill extends PaymentModule{
	
	function _initVars(){
  				
		$this->title 		= CBANKBILL_TTL;
		$this->description 	= CBANKBILL_DSCR;
		$this->sort_order 	= 1;
		
		$this->Settings = array( 
			"CONF_PAYMENTMODULE_BANKBILL_RLS_CURRENCY"
			);
	}

	function after_processing_html( $orderID ) 
	{
	$order = ordGetOrder( $orderID );
	
	$order_amount = show_price($order['order_amount'],$this->_getSettingValue('CONF_PAYMENTMODULE_BANKBILL_RLS_CURRENCY'));
	$q = db_query("SELECT * FROM ".BANKBILL_ACCOUNTS_TABLE);
	$res .= CBANKBILL_TXT_3.': <b>'.$orderID.'</b><br>';
	$res .= CBANKBILL_TXT_2.': <b>'.$order_amount.'</b><br><br>';
	
	$res .= CBANKBILL_DESC_1.'<br><br>';
	$res .= '<table cellpadding="4" cellspacing="1" bgcolor="#'.CONF_DARK_COLOR.'" width="100%">';
	$res .= '<tr bgcolor="#'.CONF_MIDDLE_COLOR.'">
			 <td>'.ADMIN_BANK_BILLS_BANKNAME.'</td>
			 <td>'.ADMIN_BANK_BILLS_ACCOUNTNO.'</td>
			 <td>'.ADMIN_BANK_BILLS_ACCOUNTHOLDER.'</td>
			 
			</tr>';
	while ($result = db_fetch_row($q)) {
		$res .= "<tr bgcolor=#ffffff>";
		$res .=  "<td>".$result['bankname']."</td><td>".$result['accountno']."</td><td>".$result['holder']."</td>";
		$res .= "</tr>";
	}
	$res .= "</table>";
	
		
		
		

		return "<center><div style=\"border: 1px solid #CCCCCC; background-color: #EEEEEE; width: 60%; padding: 10px\" align=\"center\">".$res."</div></center>";
	}

	function _initSettingFields(){
    
      if(!db_table_exists(CBANKBILL_DB_TABLE)){
			$sql = 'CREATE TABLE '.CBANKBILL_DB_TABLE.' 
    		(`id` int(11) NOT NULL AUTO_INCREMENT,
      `customerID` int(11) DEFAULT NULL,
      `billfor` varchar(255) DEFAULT NULL,
      `Account` varchar(255) DEFAULT NULL,
      `date` varchar(255) DEFAULT NULL,
      `billno` varchar(255) DEFAULT NULL,
      `amount` varchar(255) DEFAULT NULL,
      `status` varchar(255) DEFAULT NULL,
      PRIMARY KEY (`id`)
		) DEFAULT CHARSET=utf8';
			db_query($sql);
		}
		
		if(!db_table_exists(BANKBILL_ACCOUNTS_TABLE)){
			$sql = 'CREATE TABLE '.BANKBILL_ACCOUNTS_TABLE.' (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `bankname` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
      `accountno` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
      `holder` varchar(255) COLLATE utf8_persian_ci DEFAULT NULL,
      PRIMARY KEY (`id`)
		) DEFAULT CHARSET=utf8';
			db_query($sql);
		}
		
    		
		$this->SettingsFields['CONF_PAYMENTMODULE_BANKBILL_RLS_CURRENCY'] = array(
			'settings_value' 		=> '0', 
			'settings_title' 			=> CBANKBILL_CFG_RLS_CURRENCY_TTL, 
			'settings_description' 	=> CBANKBILL_CFG_RLS_CURRENCY_DSCR, 
			'settings_html_function' 	=> 'setting_CURRENCY_SELECT(', 
			'sort_order' 			=> 0,
		);
	}
}
?>