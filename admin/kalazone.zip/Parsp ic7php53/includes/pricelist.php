<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function pricessCategories($parent, $level) {
		$out = array(  );
		$cnt = 959;

		if (!( $q1 = db_query( 'select categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name from ' . CATEGORIES_TABLE . ( ' where parent=' . $parent . ' order by sort_order, name' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q1 )) {
			$r = hexdec( substr( CONF_MIDDLE_COLOR, 0, 2 ) );
			$g = hexdec( substr( CONF_MIDDLE_COLOR, 2, 2 ) );
			$b = hexdec( substr( CONF_MIDDLE_COLOR, 4, 2 ) );
			$r = round( ( 190 + 20 * min( $level, 3 ) ) * $r / $m );
			$g = round( ( 190 + 20 * min( $level, 3 ) ) * $g / $m );
			round( ( 190 + 20 * min( $level, 3 ) ) * $b / $m );
			$b = $m = (double)max( $r, max( $g, $b ) );
			$c = dechex( $r ) . dechex( $g ) . dechex( $b );
			$out[$cnt][0] = $row[0];
			$out[$cnt][1] = $row[1];
			$out[$cnt][2] = $level;
			$out[$cnt][3] = $c;
			$out[$cnt][4] = 0;
			++$cnt;

			if (!isset( $_GET['sort'] )) {
				$order_clause = 'order by sort_order';
			} 
else {
				jmp;
				$_GET['sort'] = 'name';
				jmp;
				switch ($_GET['sort']) {
					case 'name': {
					}

					case 'Price': {
					}

					case 'customers_rating': {
						break;
						$order_clause = ' order by ' . $_GET['sort'];

						if (isset( $_GET['direction'] )) {
							if (!strcmp( $_GET['direction'], 'DESC' )) {
								$order_clause .= ' DESC ';
								break;
							} 
else {
								$order_clause .= ' ASC ';
							}
						}
					}
				}
			}

			$sql = '
				select productID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS name, Price, in_stock from ' . PRODUCTS_TABLE . ' where categoryID=' . $row[0] . ' and Price>0 and enabled=1 ' . $order_clause . '
			';

			if (!( $q = db_query( $sql ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if ($row1 = db_fetch_row( $q )) {
				if ($row1[2] <= 0) {
					$row1[2] = 'n/a';
				} 
else {
					$row1[2] = show_price( $row1[2] );
				}

				$out[$cnt][0] = $row1[0];
				$out[$cnt][1] = $row1[1];
				$out[$cnt][2] = $level;
				$out[$cnt][3] = 'FFFFFF';
				$out[$cnt][4] = 1;
				$out[$cnt][5] = $row1[2];
				$out[$cnt][6] = $row1[3];
				++$cnt;
			}

			$sub_out = pricessCategories( $row[0], $level + 1 );
			$j = 959;

			while ($j < count( $sub_out )) {
				$out[] = $sub_out[$j];
				++$cnt;
				++$j;
			}
		}

		jmp;
		return $out;
	}

	function _sortPriceListSetting($smarty, $urlToSort) {
		$sort_url = renderURL( $urlToSort . '&sort=name&direction=ASC' );
		$sort_string = str_replace( '{ASC_NAME}', '<a href=\'' . $sort_url . '\'>' . STRING_ASC . '</a>', $sort_string );
		$sort_url = renderURL( $urlToSort . '&sort=name&direction=DESC' );
		$sort_string = str_replace( '{DESC_NAME}', '<a href=\'' . $sort_url . '\'>' . STRING_DESC . '</a>', $sort_string );
		$sort_url = renderURL( $urlToSort . '&sort=Price&direction=ASC' );
		$sort_string = str_replace( '{ASC_PRICE}', '<a href=\'' . $sort_url . '\'>' . STRING_ASC . '</a>', $sort_string );
		renderURL( $urlToSort . '&sort=Price&direction=DESC' );
		$sort_url = $sort_string = STRING_PRICELIST_ITEM_SORT;
		$sort_string = str_replace( '{DESC_PRICE}', '<a href=\'' . $sort_url . '\'>' . STRING_DESC . '</a>', $sort_string );
		$smarty->assign( 'string_product_sort', $sort_string );
	}


	if (isset( $_GET['show_price'] )) {
		_sortPriceListSetting( &$smarty, 'ukey=show_price' );
		$pricelist_elements = pricessCategories( 1, 0 );
		$smarty->assign( 'pricelist_elements', $pricelist_elements );
		$smarty->assign( 'main_content_template', 'pricelist.tpl.html' );
	}

?>