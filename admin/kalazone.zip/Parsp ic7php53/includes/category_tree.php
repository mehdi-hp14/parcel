<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (empty( $$categoryID )) {
		$out = catGetCategoryCompactCList( $categoryID );
	} 
else {
		$out = catGetCategoryCompactCList( 1 );
	}

	$smarty->assign( 'categories_tree', $out );
?>