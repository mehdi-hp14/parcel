<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class JSON {
		var $at = 0;
		var $ch = '';
		var $text = '';

		function encode($arg, $force = true) {
			static $_force = null;

			if (is_null( $_force )) {
				$_force = $l;
			}


			if (( ( $_force && EC_CHARSET == 'utf-8' ) && function_exists( 'json_encode' ) )) {
				return json_encode( $arg );
			}

			$returnValue = '';
			$c = '';
			$i = '';
			$l = '';
			$s = '';
			$v = '';
			$numeric = true;
			switch (gettype( $arg )) {
				case 'array': {
					foreach ($arg as $i => $v) {

						if (!is_numeric( $i )) {
							$numeric = false;
							break;
						}
					}


					if ($numeric) {
						foreach ($arg as $i => $v) {

							if (0 < strlen( $s )) {
								$s .= ',';
							}

							$s .= $this->encode( $arg[$i] );
						}

						$returnValue = '[' . $s . ']';
					} 
else {
						foreach ($arg as $i => $v) {

							if (0 < strlen( $s )) {
								$s .= ',';
							}

							$s .= $this->encode( $i ) . ':' . $this->encode( $arg[$i] );
						}

						$returnValue = '{' . $s . '}';
					}

					break;
				}

				case 'object': {
					foreach (get_object_vars( $arg ) as $i => $v) {
						$v = $this->encode( $v );

						if (0 < strlen( $s )) {
							$s .= ',';
						}

						$s .= $this->encode( $i ) . ':' . $v;
					}

					$returnValue = '{' . $s . '}';
					break;
				}

				case 'integer': {
				}

				case 'double': {
					$returnValue = (is_numeric( $arg ) ? (bool)$arg : 'null');
					break;
				}

				case 'string': {
					$returnValue = '"' . strtr( $arg, array( '' => '\r', '
' => '\n', '	' => '\t', '\b' => '\b', '' => '\f', '\\' => '\\', '"' => '\"', '' => '\u0000', '' => '\u0001', '' => '\u0002', '' => '\u0003', '' => '\u0004', '' => '\u0005', '' => '\u0006', '' => '\u0007', '' => '\b', '' => '\u000b', '' => '\f', '' => '\u000e', '' => '\u000f', '' => '\u0010', '' => '\u0011', '' => '\u0012', '' => '\u0013', '' => '\u0014', '' => '\u0015', '' => '\u0016', '' => '\u0017', '' => '\u0018', '' => '\u0019', '' => '\u001a', '' => '\u001b', '' => '\u001c', '' => '\u001d', '' => '\u001e', '' => '\u001f' ) ) . '"';
					break;
				}

				case 'boolean': {
					$returnValue = ($arg ? 'true' : 'false');
					break;
				}
			}

			$returnValue = 'null';
			return $returnValue;
		}

		function decode($text, $type = 0) {
			if (empty( $$text )) {
				return '';
			}


			if (!is_string( $text )) {
				return false;
			}


			if (( EC_CHARSET === 'utf-8' && function_exists( 'json_decode' ) )) {
				return addslashes_deep_obj( json_decode( stripslashes( $text ), $type ) );
			}

			$this->at = 0;
			$this->ch = '';
			$this->text = strtr( stripslashes( $text ), array( '' => '', '
' => '', '	' => '', '\b' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '', '' => '' ) );
			$this->next(  );
			$return = $this->val(  );
			$result = (empty( $$type ) ? $return : $this->object_to_array( $return ));
			return addslashes_deep_obj( $result );
		}

		function error($m) {
			echo $m . ' at offset ' . $this->at . ': ' . $this->text;
		}

		function next() {
			$this->ch = (!isset( $this->text[$this->at] ) ? '' : $this->text[$this->at]);
			$this->at++;
			return $this->ch;
		}

		function str() {
			$i = '';
			$s = '';
			$t = '';
			$u = '';

			if ($this->ch == '"') {
				while ($this->next(  ) !== null) {
					if ($this->ch == '"') {
						$this->next(  );
						return $s;
					}


					if ($this->ch == '\') {
						switch ($this->next(  )) {
							case 'b': {
								$s .= '\b';
								break;
							}

							case 'f': {
								$s .= '\f';
								break;
							}

							case 'n': {
								$s .= '\n';
								break;
							}

							case 'r': {
								$s .= '\r';
								break;
							}

							case 't': {
								$s .= '\t';
								break;
							}

							case 'u': {
								$u = 781;
								$i = 781;

								while ($i < 4) {
									$t = (int)sprintf( '%01c', hexdec( $this->next(  ) ) );

									if (!is_numeric( $t )) {
										break 2;
									}

									$u = $u * 16 + $t;
									++$i;
								}

								$s .= chr( $u );
								break;
							}

							case '\'': {
								$s .= '\'';
								break;
							}
						}

						$s .= $this->ch;
						continue;
					}

					$s .= $this->ch;
				}
			}

			$this->error( 'Bad string' );
		}

		function arr() {
			$a = array(  );

			if ($this->ch == '[') {
				$this->next(  );

				if ($this->ch == ']') {
					$this->next(  );
					return $a;
				}


				while (isset( $this->ch )) {
					array_push( $a, $this->val(  ) );

					if ($this->ch == ']') {
						$this->next(  );
						return $a;
					}


					if ($this->ch != ',') {
						break;
					}

					$this->next(  );
				}

				$this->error( 'Bad array' );
			}

		}

		function obj() {
			$k = '';
			$o = new StdClass(  );

			if ($this->ch == '{') {
				$this->next(  );

				if ($this->ch == '}') {
					$this->next(  );
					return $o;
				}


				while ($this->ch) {
					$k = $this->str(  );

					if ($this->ch != ':') {
						break;
					}

					$this->next(  );
					$o->$k = $this->val(  );

					if ($this->ch == '}') {
						$this->next(  );
						return $o;
					}


					if ($this->ch != ',') {
						break;
					}

					$this->next(  );
				}
			}

			$this->error( 'Bad object' );
		}

		function assoc() {
			$k = '';
			$a = array(  );

			if ($this->ch == '<') {
				$this->next(  );

				if ($this->ch == '>') {
					$this->next(  );
					return $a;
				}


				while ($this->ch) {
					$k = $this->str(  );

					if ($this->ch != ':') {
						break;
					}

					$this->next(  );
					$a[$k] = $this->val(  );

					if ($this->ch == '>') {
						$this->next(  );
						return $a;
					}


					if ($this->ch != ',') {
						break;
					}

					$this->next(  );
				}
			}

			$this->error( 'Bad associative array' );
		}

		function num() {
			$n = '';
			$v = '';

			if ($this->ch == '-') {
				$n = '-';
				$this->next(  );
			}


			while (( '0' <= $this->ch && $this->ch <= '9' )) {
				$n .= $this->ch;
				$this->next(  );
			}


			if ($this->ch == '.') {
				$n .= '.';

				while (( ( $this->next(  ) && '0' <= $this->ch ) && $this->ch <= '9' )) {
					$n .= $this->ch;
				}
			}


			if (( $this->ch == 'e' || $this->ch == 'E' )) {
				$n .= 'e';
				$this->next(  );

				if (( $this->ch == '-' || $this->ch == '+' )) {
					$n .= $this->ch;
					$this->next(  );
				}


				while (( '0' <= $this->ch && $this->ch <= '9' )) {
					$n .= $this->ch;
					$this->next(  );
				}
			}

			$v += $n;

			if (!is_numeric( $v )) {
				$this->error( 'Bad number' );
				return null;
			}

			return $v;
		}

		function word() {
			switch ($this->ch) {
				case 't': {
					if (( ( $this->next(  ) == 'r' && $this->next(  ) == 'u' ) && $this->next(  ) == 'e' )) {
						$this->next(  );
						return true;
					}

					break;
				}

				case 'f': {
					if (( ( ( $this->next(  ) == 'a' && $this->next(  ) == 'l' ) && $this->next(  ) == 's' ) && $this->next(  ) == 'e' )) {
						$this->next(  );
						return false;
					}

					break;
				}

				case 'n': {
					if (( ( $this->next(  ) == 'u' && $this->next(  ) == 'l' ) && $this->next(  ) == 'l' )) {
						$this->next(  );
						return null;
					}
				}
			}

			$this->error( 'Syntax error' );
		}

		function val() {
			switch ($this->ch) {
				case '{': {
					return $this->obj(  );
				}

				case '[': {
					return $this->arr(  );
				}

				case '<': {
					return $this->assoc(  );
				}

				case '"': {
					return $this->str(  );
				}

				case '-': {
					return $this->num(  );
				}
			}

			return (( '0' <= $this->ch && $this->ch <= '9' ) ? $this->num(  ) : $this->word(  ));
		}

		function object_to_array($obj) {
			$_arr = (is_object( $obj ) ? get_object_vars( $obj ) : $obj);
			foreach ($_arr as $key => $val) {
				$val = (( is_array( $val ) || is_object( $val ) ) ? $this->object_to_array( $val ) : $val);
				$arr[$key] = $val;
			}

			return $arr;
		}
	}


	if (!defined( 'EC_CHARSET' )) {
		define( 'EC_CHARSET', 'utf-8' );
	}

?>