<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$POLLIZ = new Polliz(  );
	$polls = $POLLIZ->getPolls(  );

	if (isset( $_POST['save_voting_results'] )) {
		foreach ($_POST as $key => $value) {

			if (strstr( $key, 'answer' )) {
				$keyv = explode( '_', $key );
				$POLLIZ->setVote( $keyv[1], $value );
				continue;
			}
		}


		if (( ( ( !isset( $_SESSION['vote_completed'][$key] ) || $_SESSION['vote_completed'][$key] != 1 ) && isset( $_GET['answer'] ) ) && isset( $survey_results[$_GET['answer']] ) )) {
			++$survey_results[$key][$_GET['answer']];
		}

		$_SESSION['vote_completed'][$keyv[1]] = 1;
	}

	foreach ($polls as $key => $value) {
		$survey[$key]['question'] = $value['pollQuestion'];
		$survey[$key]['answers'] = $value['pollAnswers'];
		$survey[$key]['results'] = $POLLIZ->getPollVotes( $key );
		$survey[$key]['maxresults'] = array_sum( $POLLIZ->getPollVotes( $key ) );

		if (is_null( $survey[$key]['maxresults'] )) {
			$survey[$key]['maxresults'] = 0;
		}

		$survey[$key]['pollID'] = $key;
		$pollVotes[$key] = $POLLIZ->getPollVotes( $key );
		$pollData[$key] = $POLLIZ->getPoll( $key );
		$survey[$key]['pollData'] = $pollData;
		$survey[$key]['showresult'] = 0;

		if ($_SESSION['vote_completed'][$key] == 1) {
			$survey[$key]['showresult'] = 1;
		}

		$pollData = '';
	}

	$smarty->assign( 'survey', $survey );
	$voters_count[$key] = 0;
	$i = 842;

	while ($i < count( $survey_results[$key] )) {
		$voters_count += $survey_results[$i];
		++$i;
	}

	$smarty->assign( 'voters_count', $voters_count );
?>