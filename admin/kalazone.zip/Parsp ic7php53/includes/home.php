<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/


	if (!( $q = db_query( 'SELECT categoryID, ' . LanguagesManager::sql_constractSortField( CATEGORIES_TABLE, 'name' ) . ',' . LanguagesManager::sql_prepareField( 'name' ) . ', products_count, picture FROM ' . CATEGORIES_TABLE . ' WHERE categoryID<>0 and parent=1 and enabled<>0 ORDER BY sort_order, _name_sort' ))) {
		exit( db_error(  ) );
		(bool)true;
	}

	$root = array(  );

	if ($row = db_fetch_row( $q )) {
		if (!file_exists( './uploads/products_pictures/' . $row['picture'] )) {
			$row[picture] = '';
		}

		$root[] = $row;
	}

	$result = array(  );
	$i = 873;

	while ($i < count( $root )) {
		$query = 'SELECT categoryID, ' . LanguagesManager::sql_constractSortField( CATEGORIES_TABLE, 'name' ) . ' ,' . LanguagesManager::sql_prepareField( 'name' ) . ' as name,parent, products_count, picture FROM ' . CATEGORIES_TABLE . ' WHERE categoryID<>0 and parent=' . $root[$i]['categoryID'] . ' and enabled<>0 ORDER BY sort_order, _name_sort ';

		if (!( $q = db_query( $query ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			$result[] = $row;
			$query2 = 'SELECT categoryID, ' . LanguagesManager::sql_constractSortField( CATEGORIES_TABLE, 'name' ) . ' ,' . LanguagesManager::sql_prepareField( 'name' ) . ' as name,parent, products_count, picture FROM ' . CATEGORIES_TABLE . ' WHERE categoryID<>0 and parent=' . $row['categoryID'] . ' and enabled<>0 ORDER BY sort_order, _name_sort ';

			if (!( $q2 = db_query( $query2 ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if ($row2 = db_fetch_row( $q2 )) {
				$result2[] = $row2;
				$query3 = 'SELECT categoryID, ' . LanguagesManager::sql_constractSortField( CATEGORIES_TABLE, 'name' ) . ' ,' . LanguagesManager::sql_prepareField( 'name' ) . ' as name,parent, products_count, picture FROM ' . CATEGORIES_TABLE . ' WHERE categoryID<>0 and parent=' . $row2['categoryID'] . ' and enabled<>0 ORDER BY sort_order, _name_sort ';

				if (!( $q3 = db_query( $query3 ))) {
					exit( db_error(  ) );
					(bool)true;
				}


				if ($row3 = db_fetch_row( $q3 )) {
					$result3[] = $row3;
				}
			}
		}

		++$i;
	}

	$smarty->assign( 'root_categories', $root );
	$smarty->assign( 'root_categories_subs', $result );
	$smarty->assign( 'root_categories_subs2', $result2 );
	$smarty->assign( 'root_categories_subs3', $result3 );
?>