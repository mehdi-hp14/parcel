<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	error_reporting( 0 );
	ini_set( 'display_errors', 0 );

	if (( $_GET['f'] == 'json' && isset( $_GET['region'] ) )) {
		$result = array(  );

		if (( $_GET['region'] == 'zones' && isset( $_GET['countryid'] ) )) {
			$country = cnGetCountryById( $_GET['countryid'] );
			$zones = znGetZones( $country['country_iso_2'] );
			foreach ($zones as $row) {
				$ret['title'] = $row['zone_name'];
				$ret['id'] = $row['zoneID'];
				$result[] = $ret;
			}

			$retval['zones'] = $result;
		}

		$result = array(  );

		if (( ( $_GET['region'] == 'cities' && isset( $_GET['countryid'] ) ) && isset( $_GET['zoneid'] ) )) {
			$country = cnGetCountryById( $_GET['countryid'] );
			$cities = ctGetCitys( $country['country_iso_2'], $_GET['zoneid'] );
			$sql = 'SELECT *, ' . LanguagesManager::sql_prepareField( 'city_name' ) . ' AS city_name FROM ' . CITY_TABLE . ' WHERE country_iso_2="' . $country['country_iso_2'] . '" and zoneID=' . $_GET['zoneid'];
			$cities = db_query( $sql );

			if ($row = db_fetch_assoc( $cities )) {
				$ret['title'] = $row['city_name'];
				$ret['id'] = $row['cityID'];
				$result[] = $ret;
			}

			$retval['cities'] = $result;
		}

		echo json_encode( $retval );
		exit(  );
	}

?>