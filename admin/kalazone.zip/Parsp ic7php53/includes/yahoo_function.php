<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function yahoo($id) {
		$sockets = fsockopen( 'opi.yahoo.com', 80, $errno, $errstr, 40 );

		if ($sockets) {
			$head = 'GET http://opi.yahoo.com/online?m=t&t=2&u=' . $id . ' HTTP/1.1
';
			$head .= 'HOST: opi.yahoo.com
';
			$head .= 'Content-Type: application/x-www-form-urlencoded
';
			$head .= 'Connection: close

';
			$result = '';
			fwrite( $sockets, $head );

			while (!feof( $sockets )) {
				$result .= fgets( $sockets, 128 );
			}

			fclose( $sockets );

			if (strpos( $result, 'NOT ONLINE' ) == false) {
				$status = 'online';
			} 
else {
				if (strpos( $result, 'NOT ONLINE' ) != false) {
					$status = 'offline';
				} 
else {
					$status = 'nothing';
				}
			}

			return $status;
		}

	}

	$id = _getSettingOptionValue( 'CONF_YAHOO_ID' );

	if ($id) {
		$status = yahoo( $id );
	}

	$smarty->assign( 'yid', $id );
	$smarty->assign( 'ystatus', $status );
?>