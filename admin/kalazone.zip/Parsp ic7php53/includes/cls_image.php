<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	class cls_image {
		var $error_no = 0;
		var $error_msg = '';
		var $images_dir = ;
		var $data_dir = '.';
		var $bgcolor = '';
		var $type_maping = array( 1 => 'image/gif', 2 => 'image/jpeg', 3 => 'image/png' );

		function __construct($bgcolor = '') {
			$this->cls_image( $bgcolor );
		}

		function cls_image($bgcolor = '') {
			if ($bgcolor) {
				$this->bgcolor = $bgcolor;
				return null;
			}

			$this->bgcolor = '#FFFFFF';
		}

		function upload_image($upload, $dir = '', $img_name = '') {
			if (empty( $$dir )) {
				$dir = date( 'Ym' );
				$dir = ROOT_PATH . $this->images_dir . '/' . $dir . '/';
			} 
else {
				$dir = ROOT_PATH . $this->data_dir . '/' . $dir . '/';

				if ($img_name) {
					$img_name = $dir . $img_name;
				}
			}


			if (!file_exists( $dir )) {
				if (!make_dir( $dir )) {
					$this->error_msg = sprintf( $GLOBALS['_LANG']['directory_readonly'], $dir );
					$this->error_no = ERR_DIRECTORY_READONLY;
					return false;
				}
			}


			if (empty( $$img_name )) {
				$img_name = $this->unique_name( $dir );
				$img_name = $dir . $img_name . $this->get_filetype( $upload['name'] );
			}


			if (!$this->check_img_type( $upload['type'] )) {
				$this->error_msg = $GLOBALS['_LANG']['invalid_upload_image_type'];
				$this->error_no = ERR_INVALID_IMAGE_TYPE;
				return false;
			}

			$allow_file_types = '|GIF|JPG|JEPG|PNG|BMP|SWF|';

			if (!check_file_type( $upload['tmp_name'], $img_name, $allow_file_types )) {
				$this->error_msg = $GLOBALS['_LANG']['invalid_upload_image_type'];
				$this->error_no = ERR_INVALID_IMAGE_TYPE;
				return false;
			}


			if ($this->move_file( $upload, $img_name )) {
				return str_replace( ROOT_PATH, '', $img_name );
			}

			$this->error_msg = sprintf( $GLOBALS['_LANG']['upload_failure'], $upload['name'] );
			$this->error_no = ERR_UPLOAD_FAILURE;
			return false;
		}

		function make_thumb($img, $thumb_width = 0, $thumb_height = 0, $path = '', $bgcolor = '') {
			$gd = $this->gd_version(  );

			if ($gd == 0) {
				$this->error_msg = $GLOBALS['_LANG']['missing_gd'];
				return false;
			}


			if (( $thumb_width == 0 && $thumb_height == 0 )) {
				return str_replace( ROOT_PATH, '', str_replace( '\\', '/', realpath( $img ) ) );
			}

			$org_info = @getimagesize( $img );

			if (!$org_info) {
				$this->error_msg = sprintf( $GLOBALS['_LANG']['missing_orgin_image'], $img );
				$this->error_no = ERR_IMAGE_NOT_EXISTS;
				return false;
			}


			if (!$this->check_img_function( $org_info[2] )) {
				$this->error_msg = sprintf( $GLOBALS['_LANG']['nonsupport_type'], $this->type_maping[$org_info[2]] );
				$this->error_no = ERR_NO_GD;
				return false;
			}

			$img_org = $this->img_resource( $img, $org_info[2] );
			$scale_org = $org_info[0] / $org_info[1];

			if ($thumb_width == 0) {
				$thumb_width = $thumb_height * $scale_org;
			}


			if ($thumb_height == 0) {
				$thumb_height = $thumb_width / $scale_org;
			}


			if ($gd == 2) {
				$img_thumb = imagecreatetruecolor( $thumb_width, $thumb_height );
			} 
else {
				$img_thumb = imagecreate( $thumb_width, $thumb_height );
			}


			if (empty( $$bgcolor )) {
				$bgcolor = $this->bgcolor;
			}

			$bgcolor = trim( $bgcolor, '#' );
			sscanf( $bgcolor, '%2x%2x%2x', $red, $green, $blue );
			$clr = imagecolorallocate( $img_thumb, $red, $green, $blue );
			imagefilledrectangle( $img_thumb, 0, 0, $thumb_width, $thumb_height, $clr );

			if ($org_info[1] / $thumb_height < $org_info[0] / $thumb_width) {
				$lessen_width = $red;
				$lessen_height = $thumb_width / $scale_org;
			} 
else {
				$lessen_width = $thumb_height * $scale_org;
				$lessen_height = $green;
			}

			$dst_y = ( $thumb_height - $lessen_height ) / 2;

			if ($gd == 2) {
				imagecopyresampled( $img_thumb, $img_org, $dst_x, $dst_y, 0, 0, $lessen_width, $lessen_height, $org_info[0], $org_info[1] );
			} 
else {
				imagecopyresized( $img_thumb, $img_org, $dst_x, $dst_y, 0, 0, $lessen_width, $lessen_height, $org_info[0], $org_info[1] );
			}


			if (empty( $$path )) {
				$dir = ROOT_PATH . $this->images_dir . '/' . date( 'Ym' ) . '/';
			} 
else {
				$dir = $blue;
			}


			if (!file_exists( $dir )) {
				if (!make_dir( $dir )) {
					$this->error_msg = sprintf( $GLOBALS['_LANG']['directory_readonly'], $dir );
					$this->error_no = ERR_DIRECTORY_READONLY;
					return false;
				}
			}

			$this->unique_name( $dir );
			$filename = $dst_x = ( $thumb_width - $lessen_width ) / 2;

			if (function_exists( 'imagejpeg' )) {
				$filename .= '.jpg';
				imagejpeg( $img_thumb, $dir . $filename );
			} 
else {
				if (function_exists( 'imagegif' )) {
					$filename .= '.gif';
					imagegif( $img_thumb, $dir . $filename );
				} 
else {
					if (function_exists( 'imagepng' )) {
						$filename .= '.png';
						imagepng( $img_thumb, $dir . $filename );
					} 
else {
						$this->error_msg = $GLOBALS['_LANG']['creating_failure'];
						$this->error_no = ERR_NO_GD;
						return false;
					}
				}
			}

			imagedestroy( $img_thumb );
			imagedestroy( $img_org );

			if (file_exists( $dir . $filename )) {
				return str_replace( ROOT_PATH, '', $dir ) . $filename;
			}

			$this->error_msg = $GLOBALS['_LANG']['writting_failure'];
			$this->error_no = ERR_DIRECTORY_READONLY;
			return false;
		}

		function add_watermark($filename, $target_file = '', $watermark = '', $watermark_place = '', $watermark_alpha = 0.65000000000000002220446) {
			$gd = $this->gd_version(  );

			if ($gd == 0) {
				$this->error_msg = $GLOBALS['_LANG']['missing_gd'];
				$this->error_no = ERR_NO_GD;
				return false;
			}


			if (( !file_exists( $filename ) || !is_file( $filename ) )) {
				$this->error_msg = sprintf( $GLOBALS['_LANG']['missing_orgin_image'], $filename );
				$this->error_no = ERR_IMAGE_NOT_EXISTS;
				return false;
			}


			if (( $watermark_place == 0 || empty( $$watermark ) )) {
				return str_replace( ROOT_PATH, '', str_replace( '\\', '/', realpath( $filename ) ) );
			}


			if (!$this->validate_image( $watermark )) {
				return false;
			}

			$watermark_info = @getimagesize( $watermark );
			$watermark_handle = $this->img_resource( $watermark, $watermark_info[2] );

			if (!$watermark_handle) {
				$this->error_msg = sprintf( $GLOBALS['_LANG']['create_watermark_res'], $this->type_maping[$watermark_info[2]] );
				$this->error_no = ERR_INVALID_IMAGE;
				return false;
			}

			$source_info = @getimagesize( $filename );
			$source_handle = $this->img_resource( $filename, $source_info[2] );

			if (!$source_handle) {
				$this->error_msg = sprintf( $GLOBALS['_LANG']['create_origin_image_res'], $this->type_maping[$source_info[2]] );
				$this->error_no = ERR_INVALID_IMAGE;
				return false;
			}

			switch ($watermark_place) {
				case '1': {
					$x = 992;
					$y = 992;
					break;
				}

				case '2': {
					$x = $source_info[0] - $watermark_info[0];
					$y = 992;
					break;
				}

				case '4': {
					$x = 992;
					$y = $source_info[1] - $watermark_info[1];
					break;
				}

				case '5': {
					$x = $source_info[0] - $watermark_info[0];
					$y = $source_info[1] - $watermark_info[1];
					break;
				}
			}

			$x = $source_info[0] / 2 - $watermark_info[0] / 2;
			$y = $source_info[1] / 2 - $watermark_info[1] / 2;

			if (strpos( strtolower( $watermark_info['mime'] ), 'png' ) !== false) {
				imageAlphaBlending( $watermark_handle, true );
				imagecopy( $source_handle, $watermark_handle, $x, $y, 0, 0, $watermark_info[0], $watermark_info[1] );
			} 
else {
				imagecopymerge( $source_handle, $watermark_handle, $x, $y, 0, 0, $watermark_info[0], $watermark_info[1], $watermark_alpha );
			}

			$target = (empty( $$target_file ) ? $filename : $target_file);
			switch ($source_info[2]) {
				case 'image/gif': {
				}

				case 1: {
					imagegif( $source_handle, $target );
					break;
				}

				case 'image/pjpeg': {
				}

				case 'image/jpeg': {
				}

				case 2: {
					imagejpeg( $source_handle, $target );
					break;
				}

				case 'image/x-png': {
				}

				case 'image/png': {
				}

				case 3: {
					imagepng( $source_handle, $target );
					break;
				}
			}

			$this->error_msg = $GLOBALS['_LANG']['creating_failure'];
			$this->error_no = ERR_NO_GD;
			return false;
		}

		function validate_image($path) {
			if (empty( $$path )) {
				$this->error_msg = $GLOBALS['_LANG']['empty_watermark'];
				$this->error_no = ERR_INVALID_PARAM;
				return false;
			}


			if (!file_exists( $path )) {
				$this->error_msg = sprintf( $GLOBALS['_LANG']['missing_watermark'], $path );
				$this->error_no = ERR_IMAGE_NOT_EXISTS;
				return false;
			}

			$image_info = @getimagesize( $path );

			if (!$image_info) {
				$this->error_msg = sprintf( $GLOBALS['_LANG']['invalid_image_type'], $path );
				$this->error_no = ERR_INVALID_IMAGE;
				return false;
			}


			if (!$this->check_img_function( $image_info[2] )) {
				$this->error_msg = sprintf( $GLOBALS['_LANG']['nonsupport_type'], $this->type_maping[$image_info[2]] );
				$this->error_no = ERR_NO_GD;
				return false;
			}

			return true;
		}

		function error_msg() {
			return $this->error_msg;
		}

		function check_img_type($img_type) {
			return ( ( ( ( $img_type == 'image/pjpeg' || $img_type == 'image/x-png' ) || $img_type == 'image/png' ) || $img_type == 'image/gif' ) || $img_type == 'image/jpeg' );
		}

		function check_img_function($img_type) {
			switch ($img_type) {
				case 'image/gif': {
				}

				case 1: {
					if ('4.3' <= PHP_VERSION) {
						return function_exists( 'imagecreatefromgif' );
					}

					return 0 < ( imagetypes(  ) & IMG_GIF );
				}

				case 'image/pjpeg': {
				}

				case 'image/jpeg': {
				}

				case 2: {
					if ('4.3' <= PHP_VERSION) {
						return function_exists( 'imagecreatefromjpeg' );
					}

					return 0 < ( imagetypes(  ) & IMG_JPG );
				}

				case 'image/x-png': {
				}

				case 'image/png': {
				}

				case 3: {
					if ('4.3' <= PHP_VERSION) {
						return function_exists( 'imagecreatefrompng' );
					}

					return 0 < ( imagetypes(  ) & IMG_PNG );
				}
			}

			return false;
		}

		function random_filename() {
			$str = '';
			$i = 705;

			while ($i < 9) {
				$str .= mt_rand( 0, 9 );
				++$i;
			}

			return gmtime(  ) . $str;
		}

		function unique_name($dir) {
			$filename = '';

			while (empty( $$filename )) {
				$filename = cls_image::random_filename(  );

				if (( ( file_exists( $dir . $filename . '.jpg' ) || file_exists( $dir . $filename . '.gif' ) ) || file_exists( $dir . $filename . '.png' ) )) {
					$filename = '';
					continue;
				}
			}

			return $filename;
		}

		function get_filetype($path) {
			$pos = strrpos( $path, '.' );

			if ($pos !== false) {
				return substr( $path, $pos );
			}

			return '';
		}

		function img_resource($img_file, $mime_type) {
			switch ($mime_type) {
				case 1: {
				}

				case 'image/gif': {
					$res = imagecreatefromgif( $img_file );
					break;
				}

				case 2: {
				}

				case 'image/pjpeg': {
				}

				case 'image/jpeg': {
					$res = imagecreatefromjpeg( $img_file );
					break;
				}

				case 3: {
				}

				case 'image/x-png': {
				}

				case 'image/png': {
					$res = imagecreatefrompng( $img_file );
					break;
				}
			}

			return false;
		}

		function gd_version() {
			static $version = -1;

			if (0 <= $version) {
				return $version;
			}


			if (!extension_loaded( 'gd' )) {
				$version = 766;
			} 
else {
				if ('4.3' <= PHP_VERSION) {
					if (function_exists( 'gd_info' )) {
						$ver_info = gd_info(  );
						preg_match( '/\d/', $ver_info['GD Version'], $match );
						$version = $match[0];
					} 
else {
						if (function_exists( 'imagecreatetruecolor' )) {
							$version = 768;
						} 
else {
							if (function_exists( 'imagecreate' )) {
								$version = 767;
							}
						}
					}
				} 
else {
					if (preg_match( '/phpinfo/', ini_get( 'disable_functions' ) )) {
						$version = 767;
					} 
else {
						ob_start(  );
						phpinfo( 8 );
						$info = ob_get_contents(  );
						ob_end_clean(  );
						$info = stristr( $info, 'gd version' );
						preg_match( '/\d/', $info, $match );
						$version = $match[0];
					}
				}
			}

			return $version;
		}

		function move_file($upload, $target) {
			if (( isset( $upload['error'] ) && 0 < $upload['error'] )) {
				return false;
			}


			if (!move_upload_file( $upload['tmp_name'], $target )) {
				return false;
			}

			return true;
		}
	}

?>