<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$admin_tab = array( 'id' => 'support', 'sort_order' => 100, 'name' => ADMIN_SUPPORT, 'sub_departments' => array( array( 'id' => 'about', 'name' => ADMIN_ABOUT ), array( 'id' => 'message', 'name' => ADMIN_SYSTEMMESSAGE ) ) );
	add_department( $admin_tab );
?>