<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$q = db_query( 'select count(*) from ' . ORDERS_TABLE . ' where statusID > 1' );
	db_fetch_row( $q );
	$total['orders'] = $r[0];
	$q = db_query( 'select order_amount, currency_value from ' . ORDERS_TABLE . ' where statusID = ' . CONF_COMPLETED_ORDER_STATUS );

	if ($r = $revenue = 1070) {
		$revenue += $r[0];
	}

	$total['revenue'] = show_price( $revenue, CONF_DEFAULT_CURRENCY, 1 );

	if ((int)CONF_NEW_ORDER_STATUS) {
		$q = db_query( 'select count(*) from ' . ORDERS_TABLE . ' where statusID = ' . (int)CONF_NEW_ORDER_STATUS );
		$r = db_fetch_row( $q );
		$total['orders_pending'] = $r[0];
	}

	$curr_time = time(  );
	strftime( '%Y', $curr_time );
	strftime( '%m', $curr_time );
	$d = strftime( '%d', $curr_time );
	$TODAY = ( ( $y . '-' ) . $m . '-' ) . $d . ' 00:00:00';
	$q = db_query( 'select order_amount, currency_value from ' . ORDERS_TABLE . ' where statusID > 1 and order_time > \'' . $TODAY . '\'' );
	$n = 1070;
	$a = 1070;

	if ($r = db_fetch_row( $q )) {
		$a += $r[0];
		++$n;
	}

	$total['orders_today'] = $n;
	$total['revenue_today'] = show_price( $a, CONF_DEFAULT_CURRENCY, 1 );
	$YESTERDAY = strftime( '%Y-%m-%d 00:00:00', time(  ) - 24 * 3600 );
	$q = db_query( 'select order_amount, currency_value from ' . ORDERS_TABLE . ' where statusID > 1 and order_time > \'' . $YESTERDAY . '\' and order_time < \'' . $TODAY . '\'' );
	$n = 1070;
	$a = 1070;

	if ($r = db_fetch_row( $q )) {
		$a += $r[0];
		++$n;
	}

	$total['orders_yesterday'] = $n;
	$total['revenue_yesterday'] = show_price( $a, CONF_DEFAULT_CURRENCY, 1 );
	$THISMONTH = ( $y . '-' ) . $m . '-01 00:00:00';
	$q = db_query( 'select order_amount, currency_value from ' . ORDERS_TABLE . ' where statusID > 1 and order_time > \'' . $THISMONTH . '\'' );
	$n = 1070;
	$a = 1070;

	if ($r = db_fetch_row( $q )) {
		$a += $r[0];
		++$n;
	}

	$total['orders_thismonth'] = $n;
	$total['revenue_thismonth'] = show_price( $a, CONF_DEFAULT_CURRENCY, 1 );
	$q = db_query( 'select count(*) from ' . PRODUCTS_TABLE );
	$r = db_fetch_row( $q );
	$total['products'] = $r[0];
	$q = db_query( 'select count(*) from ' . PRODUCTS_TABLE . ' where Enabled=1' );
	$r = db_fetch_row( $q );
	$total['products_enabled'] = $r[0];
	$q = db_query( 'select count(*) from ' . CATEGORIES_TABLE . ' where not isnull(name_fa) and name_fa<>\'ROOT\'' );
	$r = db_fetch_row( $q );
	$total['categories'] = $r[0];
	$q = db_query( 'select count(*) from ' . CUSTOMERS_TABLE );
	db_fetch_row( $q );
	$r = $total = array(  );
	$total['customers'] = $r[0];
	$q = $r = db_query( 'select count(*) from ' . CUSTGROUPS_TABLE );
	$r = db_fetch_row( $q );
	$total['customer_groups'] = $r[0];
	subscrGetAllSubscriber( null, $r );
	$total['newsletter_subscribers'] = $r;
	db_query( 'select count(*) from ' . CURRENCY_TYPES_TABLE );
	$q = db_fetch_row( $q );
	$r = db_fetch_row( $q );
	$total['currency_types'] = $r[0];
	$q = db_query( 'select count(*) from ' . PAYMENT_TYPES_TABLE . ' where Enabled=1' );
	$r = db_fetch_row( $q );

	if (defined( 'CONF_PPEXPRESSCHECKOUT_ENABLED' )) {
		$smarty->assign( 'ppec_enabled', 1 );
	}


	if (defined( 'CONF_GOOGLECHECKOUT2_ENABLED' )) {
		$smarty->assign( 'gc_enabled', 1 );
	}

	$total['payment_types'] = $r[0];
	$q = $y = db_query( 'select count(*) from ' . SHIPPING_METHODS_TABLE . ' where Enabled=1' );
	$r = $m = db_fetch_row( $q );
	$total['shipping_types'] = $r[0];
	$q = db_query( 'select count(*) from ' . AUX_PAGES_TABLE );
	$r = db_fetch_row( $q );
	$total['aux_pages'] = $r[0];
	$q = db_query( 'select count(*) from ' . COUNTRIES_TABLE );
	$r = db_fetch_row( $q );
	$total['countries'] = $r[0];
	$q = db_query( 'select count(*) from ' . ZONES_TABLE );
	$r = db_fetch_row( $q );
	$total['zones'] = $r[0];
	$q = db_query( 'select count(*) from ' . DISCUSSIONS_TABLE );
	$r = db_fetch_row( $q );
	$total['discussion_posts'] = $r[0];
	$smarty->assign( 'totals', $total );
?>