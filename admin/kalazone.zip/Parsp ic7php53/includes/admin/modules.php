<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$admin_tab = array( 'id' => 'modules', 'sort_order' => 40, 'name' => ADMIN_MODULES, 'sub_departments' => array( array( 'id' => 'shipping', 'name' => STRING_SHIPPING_MODULES ), array( 'id' => 'payment', 'name' => STRING_PAYMENT_MODULES ), array( 'id' => 'smsmail', 'name' => STRING_SMSMAIL ) ) );
	add_department( $admin_tab );
?>