<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$admin_tab = array( 'id' => 'reports', 'sort_order' => 50, 'name' => ADMIN_REPORTS, 'sub_departments' => array( array( 'id' => 'category_viewed_times', 'name' => ADMIN_CATEGORY_VIEWED_TIMES ), array( 'id' => 'customer_log', 'name' => ADMIN_CUSTOMER_LOG ), array( 'id' => 'product_report', 'name' => ADMIN_PRODUCT_REPORT ), array( 'id' => 'sale_report', 'name' => ADMIN_SALE_REPORT ) ) );
	add_department( $admin_tab );
?>