<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$admin_tab = array( 'id' => 'layout', 'sort_order' => 35, 'name' => ADMIN_LAYOUT, 'sub_departments' => array( array( 'id' => 'templates', 'name' => TEMPLATE ), array( 'id' => 'logo', 'name' => STRING_LOGO ), array( 'id' => 'icon', 'name' => STRING_ICON ), array( 'id' => 'languages', 'name' => ADMIN_LANGUAGES ) ) );
	add_department( $admin_tab );
?>