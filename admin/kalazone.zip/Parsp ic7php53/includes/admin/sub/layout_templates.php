<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'templates' )) {
		$dir = './templates/frontend/';

		if (( isset( $_GET['edit'] ) && !empty( $_GET['edit'] ) )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=templates&safemode' );
			}

			$editmode = 1254;
			$editfile = $_GET['edit'] . '.tpl.html';
			$filetoedit = $dir . $templateDirectory . '/' . $editfile;

			if (is_file( $filetoedit )) {
				$fileSource = htmlspecialchars( file_get_contents( $filetoedit ) );
			} 
else {
				header( 'Location: back;' );
			}


			if (isset( $_POST['SaveChanges'] )) {
				if (CONF_BACKEND_SAFEMODE) {
					Redirect( 'admincp.php?tab=layout&sub=templates&safemode' );
				}

				$newHtml = $_POST['htmlCode'];
				$editfile = $_POST['editfile'];
				$filetoedit = $dir . $templateDirectory . '/' . $editfile;
				$f = fopen( $filetoedit, 'w' );
				$newHtml = ', '
				stripslashes( str_replace( '
', $newHtml ) );

				fputs( $f, $newHtml );
				fclose( $f );
			}

			$smarty->assign( 'editfile', $editfile );
			$smarty->assign( 'editmode', $editmode );
			$smarty->assign( 'filesource', $fileSource );
		} 
else {
			if (isset( $_POST['UploadTemplate'] )) {
				$upfile = DIR_COMPILEDTEMPLATES . $_FILES['datafile']['name'];
				move_uploaded_file( $_FILES['datafile']['tmp_name'], $upfile );

				if (( !extension_loaded( 'zip' ) || !file_exists( $upfile ) )) {
					echo '<center>Error in Upload Templates</center>';
				}

				$zip = new ZipArchive(  );
				$res = $zip->open( $upfile );

				if (( $res === true && is_numeric( $zip->locateName( 'config.xml' ) ) )) {
					if (trim( $_POST['selectmethod'] ) == 'template_replace') {
						$zip->extractTo( $dir . $templateDirectory . '/' );
						$zip->close(  );
						echo '<br><br><p style=\'font-family:tahoma;font-size:8.5px;\'><center>' . ADMIN_TEMPLATE_UPLOADED . '</centrt></p>';
						echo '<script type="text/javascript"><!--parent.location = "admincp.php?tab=layout&sub=templates&save_successful";       // --></script>';
					} 
else {
						$newtempname = 'templates/themes/' . $_POST['templatename'];
						mkdir( $newtempname );
						$zip->extractTo( $newtempname, array( 'config.xml', 'preview.gif' ) );
						$zip->close(  );
						rename( $upfile, $newtempname . '/' . $_FILES['datafile']['name'] );
						unlink( $upfile );
						echo '<br><br><p style=\'font-family:tahoma;font-size:8.5px;\'><center>' . ADMIN_TEMPLATE_UPLOADED . '</centrt></p>';
						echo '<script type="text/javascript"><!--
                    parent.location = "admincp.php?tab=layout&sub=templates&save_successful";        
                    // -->
                    </script>';
					}
				} 
else {
					echo 'Read File Failed, code:' . $res;
				}

				exit(  );
			}


			if (isset( $_GET['save_successful'] )) {
				$smarty->assign( 'save_successful', ADMIN_UPDATE_SUCCESSFUL );
			}


			if (isset( $_GET['curtemplateupload'] )) {
				$smarty->display( 'backend/layout_template_upload.tpl.html' );
				exit(  );
			}


			if (isset( $_GET['curtemplatedownload'] )) {
				$zipname = DIR_COMPILEDTEMPLATES . $templateDirectory . '.zip';
				Zip( $dir . $templateDirectory, $zipname );
				header( 'location:' . $zipname );
				exit(  );
			}


			if ($_GET['download']) {
				header( 'Content-Type: application/force-download' );
				$filetodownload = $dir . $templateDirectory . '/' . $_GET['download'] . '.tpl.html';
				header( 'Content-Disposition: attachment; filename=' . $_GET['download'] . '.tpl.html' );
				echo file_get_contents( $filetodownload );
				exit(  );
			}

			include( './cfg/template_directory.php' );
			$dir = './templates/frontend/';
			$S_dir = './templates/themes/';

			if (is_dir( $S_dir )) {
				$theme_dir = opendir( $S_dir );

				if ($inc_folder = readdir( $theme_dir )) {
					if (file_exists( $S_dir . $inc_folder . '/config.xml' )) {
						$xmlTemplate = new XmlNode(  );
						$xmlTemplate->LoadInnerXmlFromFile( $S_dir . $inc_folder . '/config.xml' );
						$array = $xmlTemplate->SelectNodes( 'TemplateStructure/config/param' );
						foreach ($array as $xmlParam) {
							$attributes = $xmlParam->GetXmlNodeAttributes(  );
							$templ[$attributes['TYPE']] = $attributes['VALUE'];
						}

						$templ['selected'] = 0;

						if (is_dir( $dir . $templ['Dirname'] )) {
							$templ['installed'] = 1;

							if ($templ['Dirname'] == CONF_TEMPLATES_DIR) {
								$templ['selected'] = 1;
							} 
else {
								$templ['selected'] = 0;
							}
						} 
else {
							$templ['installed'] = 0;
						}

						$templ['org_folder'] = $S_dir . $inc_folder;
						$templates[] = $templ;
					}
				}
			}


			if (( isset( $_POST['save_template'] ) || isset( $_GET['selecttemplate'] ) )) {
				if (CONF_BACKEND_SAFEMODE) {
					Redirect( 'admincp.php?tab=layout&sub=templates&safemode' );
				}


				if (isset( $_GET['selecttemplate'] )) {
					$tmplDir = $templates[$_GET['selecttemplate']]['Dirname'];
				} 
else {
					$tmplDir = $_POST['templDirectory'];
				}

				_setSettingOptionValue( 'CONF_TEMPLATES_DIR', $tmplDir );
				echo '<script type="text/javascript"><!--
          parent.location = "admincp.php?tab=layout&sub=templates&save_successful";        
            // -->
        </script>';
				exit(  );
			}


			if (is_dir( $dir )) {
				$templates_dir = opendir( $dir );

				if ($inc_file = readdir( $templates_dir )) {
					if (( $inc_file != '.' && $inc_file != '..' )) {
						$tmplDir[] = $inc_file;
					}
				}


				if (is_file( $dir . $templateDirectory . '/preview.gif' )) {
					$preview = $dir . $templateDirectory . '/preview.gif';
				} 
else {
					$preview = 'images/nopreview.gif';
				}


				if (file_exists( $dir . $templateDirectory . '/config.xml' )) {
					$xmlTemplate = new XmlNode(  );
					$xmlTemplate->LoadInnerXmlFromFile( $dir . $templateDirectory . '/config.xml' );
					$array = $xmlTemplate->SelectNodes( 'TemplateStructure/config/param' );
					foreach ($array as $xmlParam) {
						$attributes = $xmlParam->GetXmlNodeAttributes(  );
						$curtpl[$attributes['TYPE']] = $attributes['VALUE'];
					}

					$curtpl['org_folder'] = $S_dir . $inc_folder;
				}

				$templates_dir = opendir( $dir . $templateDirectory );

				if ($inc_file2 = readdir( $templates_dir )) {
					if (strstr( $inc_file2, '.tpl.html' )) {
						$filemanager[] = str_replace( '.tpl.html', '', $inc_file2 );
					}
				}
			}
		}


		if (isset( $_GET['uninstalltemplate'] )) {
			$templid = $_GET['uninstalltemplate'];
			$templdir = $templates[$templid]['Dirname'];
			$templodir = $templates[$templid]['org_folder'];
			$Filename = $templates[$templid]['Filename'];
			destroy( $dir . $templdir . '/' );
			rmdir( $dir . $templdir . '/' );
			echo '<script type="text/javascript"><!--
          parent.location = "admincp.php?tab=layout&sub=templates&save_successful";        
            // -->
        </script>';
		}


		if (isset( $_GET['installtemplate'] )) {
			$templid = $_GET['installtemplate'];
			$templdir = $templates[$templid]['Dirname'];
			$templodir = $templates[$templid]['org_folder'];
			$Filename = $templates[$templid]['Filename'];
			$zip = new ZipArchive(  );
			$res = $zip->open( $templodir . '/' . $Filename );

			if (( $res === true && is_numeric( $zip->locateName( 'config.xml' ) ) )) {
				$zip->extractTo( $dir . $templdir );
				$zip->close(  );
			}

			$templates[$templid]['installed'] = 1;
		}


		if ($_GET['deletetemplate']) {
			$templid = $_GET['deletetemplate'];
			$templates[$templid]['Dirname'];
		}

		$smarty->assign( 'curtpl', $curtpl );
		$smarty->assign( 'Templates', $templates );
		$smarty->assign( 'tmplDir', $tmplDir );
		$smarty->assign( 'filemanager', $filemanager );
		$smarty->assign( 'preview', $preview );
		$smarty->assign( 'selected', $templateDirectory );
		$smarty->assign( 'admin_sub_tab', 'layout_template.tpl.html' );

		if ($editfile) {
			$smarty->display( 'backend/layout_template.tpl.html' );
			exit(  );
		}
	}

?>