<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'excel_import_accounts' )) {
		$smarty->assign( 'admin_sub_tab', 'catalog_excel_import_accounts.tpl.html' );
	}

?>