<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'shipping' )) {
		$moduleFiles = GetFilesInDirectory( './includes/modules/shipping', 'php' );
		foreach ($moduleFiles as $fileName) {
			include( $fileName );
		}


		if (isset( $_GET['save_successful'] )) {
			$smarty->assign( 'configuration_saved', 1 );
		}


		if (isset( $_GET['delete'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=shipping&safemode' );
			}

			shDeleteShippingMethod( $_GET['delete'] );
			Redirect( 'admincp.php?tab=conf&sub=shipping' );
		}


		if (isset( $_POST['save_shipping'] )) {
			$_POST = array_merge( $_FILES, $_POST );

			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=shipping&safemode' );
			}

			$values = scanArrayKeysForID( $_POST, array( 'name_\w{2}', 'description_\w{2}', 'email_comments_text_\w{2}', 'Enabled', 'sort_order', 'module', 'thumbnail_logo', 'thumbnaillogo' ) );
			foreach ($values as $key => $value) {

				if (( isset( $value['thumbnaillogo'] ) && $value['thumbnail_logo']['name'] == '' )) {
					$thumnaillogo = $value['thumbnaillogo'];
				} 
else {
					$thumnaillogo = $value['thumbnail_logo']['name'];
					$r = move_uploaded_file( $value['thumbnail_logo']['tmp_name'], './uploads/logos/' . $thumnaillogo );
				}

				shUpdateShippingMethod( $key, $value, (isset( $value['Enabled'] ) ? 1 : 0), (int)$value['sort_order'], $value['module'], $thumnaillogo );
			}


			if (!LanguagesManager::ml_isEmpty( 'new_name', $_POST )) {
				$r = move_uploaded_file( $_FILES['new_thumbnail_logo']['tmp_name'], './uploads/logos/' . $_FILES['new_thumbnail_logo']['name'] );
				shAddShippingMethod( $_POST, (isset( $_POST['new_Enabled'] ) ? 1 : 0), (int)$_POST['new_sort_order'], $_POST['new_module'], $_FILES['new_thumbnail_logo']['name'] );
			}

			Redirect( 'admincp.php?tab=conf&sub=shipping&save_successful' );
			exit(  );
		}

		$smarty->assign( 'shipping_types', shGetAllShippingMethods(  ) );
		$smarty->assign( 'shipping_modules', modGetAllInstalledModuleObjs( SHIPPING_RATE_MODULE ) );
		$smarty->assign( 'admin_sub_tab', 'conf_shipping.tpl.html' );
	}

?>