<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'reg_fields' )) {
		if (isset( $_GET['delete'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=users&sub=reg_fields&safemode' );
			}

			DeleteRegField( $_GET['delete'] );
			Redirect( 'admincp.php?tab=users&sub=reg_fields' );
		}


		if (isset( $_POST['save_fields'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=users&sub=reg_fields&safemode' );
			}


			if (!LanguagesManager::ml_isEmpty( 'new_reg_field_name', $_POST )) {
				$new_reg_field_required = 860;

				if (isset( $_POST['new_reg_field_required'] )) {
					$new_reg_field_required = 861;
				}

				AddRegField( $_POST, $new_reg_field_required );
			}

			$data = scanArrayKeysForID( $_POST, array( 'reg_field_name_\w{2}', 'reg_field_required', 'sort_order' ) );
			foreach ($data as $key => $val) {

				if (!isset( $val['reg_field_required'] )) {
					$val['reg_field_required'] = 0;
				}

				UpdateRegField( $key, $val, $val['reg_field_name'], $val['reg_field_required'], $val['sort_order'] );
			}

			Redirect( 'admincp.php?tab=users&sub=reg_fields' );
		}


		if (isset( $_POST['save_address_form'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=users&sub=reg_fields&safemode' );
			}

			db_query( 'update ' . SETTINGS_TABLE . ' set settings_value = \'' . (int)$_POST['addr_state'] . '\' where settings_constant_name = \'CONF_ADDRESSFORM_STATE\'' );
			db_query( 'update ' . SETTINGS_TABLE . ' set settings_value = \'' . (int)$_POST['addr_zip'] . '\' where settings_constant_name = \'CONF_ADDRESSFORM_ZIP\'' );
			db_query( 'update ' . SETTINGS_TABLE . ' set settings_value = \'' . (int)$_POST['addr_city'] . '\' where settings_constant_name = \'CONF_ADDRESSFORM_CITY\'' );
			db_query( 'update ' . SETTINGS_TABLE . ' set settings_value = \'' . (int)$_POST['addr_address'] . '\' where settings_constant_name = \'CONF_ADDRESSFORM_ADDRESS\'' );
			db_query( 'update ' . SETTINGS_TABLE . ' set settings_value = \'' . (int)$_POST['addr_phone'] . '\' where settings_constant_name = \'CONF_ADDRESSFORM_PHONE_NUMBER\'' );
			db_query( 'update ' . SETTINGS_TABLE . ' set settings_value = \'' . (int)$_POST['addr_mobile'] . '\' where settings_constant_name = \'CONF_ADDRESSFORM_MOBILE\'' );
			Redirect( 'admincp.php?tab=users&sub=reg_fields' );
		}

		$fields = GetRegFields(  );
		$smarty->assign( 'fields', $fields );
		$smarty->assign( 'admin_sub_tab', 'users_reg_fields.tpl.html' );
	}

?>