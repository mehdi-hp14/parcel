<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'message' )) {
		$s = curl_init(  );
		curl_setopt( $s, CURLOPT_URL, 'http://www.parsp.com/message.php' );
		curl_setopt( $s, CURLOPT_HTTPHEADER, array( 'Expect:' ) );
		curl_setopt( $s, CURLOPT_RETURNTRANSFER, true );
		$_webpage = curl_exec( $s );
		curl_close( $s );
		$smarty->assign( 'MessageBlock', $_webpage );
		$smarty->assign( 'admin_sub_tab', 'support_message.tpl.html' );
	}

?>