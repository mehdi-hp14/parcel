<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'customer_log' )) {
		if (isset( $_POST['clear'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=reports&sub=customer_log&safemode' );
			}

			stClearCustomerLogReport( $_POST['groupID'] );
		}

		$customer_groups = GetAllCustGroups(  );
		$smarty->assign( 'groupID', $_POST['groupID'] );
		$smarty->assign( 'customer_groups', $customer_groups );
		$customer_log_report = stGetCustomerLogReport( $_POST['groupID'] );
		$smarty->assign( 'customer_log_report', $customer_log_report );
		$smarty->assign( 'admin_sub_tab', 'reports_customer_log.tpl.html' );
	}

?>