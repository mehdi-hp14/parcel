<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function _search_products($searchstring) {
		$searchstring = trim( $searchstring );

		if (!$searchstring) {
			return null;
		}

		$e_searchstring = preg_replace( '/\%/u', '\%', xEscapeSQLstring( $searchstring ) );
		$fl_names = LanguagesManager::ml_getLangFieldNames( 'name' );
		require_once( './classes/class.grid.php' );
		$gridEntry = ClassManager::getInstance( 'grid' );
		$qr_where = '
			WHERE (LOWER(p.product_code) LIKE LOWER("%' . $searchstring . '%")) OR
			( LOWER(p.' . implode( ') LIKE LOWER("%' . $e_searchstring . '%") OR LOWER(p.', $fl_names ) . ') LIKE LOWER("%' . $e_searchstring . '%") )
			';
		$qr_from = '
			FROM ?#PRODUCTS_TABLE p 			
		';
		$gridEntry->query_total_rows_num = 'SELECT COUNT(DISTINCT p.productID) ' . $qr_from . $qr_where;
		$gridEntry->query_select_rows = 'SELECT p.productID, p.Price, p.enabled, p.meta_keywords, ' . LanguagesManager::sql_prepareField( 'p.name' ) . ' AS p_name ' . $qr_from . $qr_where . '	GROUP BY p.productID';
		$gridEntry->show_rows_num_select = false;
		$gridEntry->default_sort_direction = 'ASC';
		$gridEntry->rows_num = 20;
		$gridEntry->registerHeader( translate( 'prdset_product_name' ), 'p_name', true, 'asc' );
		$smart = $gridEntry->prepare(  );
		$rows = $smart['GridRows'];
		$k = count( $rows ) - 1;

		while (0 <= $k) {
			$rows[$k]['name'] = $rows[$k]['p_name'];
			$rows[$k]['price_str'] = show_price( $rows[$k]['Price'], CONF_DEFAULT_CURRENCY, 1 );
			--$k;
		}

		return $rows;
	}

	function save_order() {
		$scan_result = scanArrayKeysForID( $_POST, array( 'list_name', 'priority', 'postbtn' ) );
		$sql = '
			UPDATE ?#TBL_PRODUCT_LIST_ITEM SET priority=? WHERE list_id=? AND productID=?
		';
		foreach ($scan_result as $productID => $scan_info) {
			db_phquery( $sql, $scan_info['priority'], $_GET['list_id'], $productID );
		}

		return true;
	}


	if ($_GET['action'] == 'delete_product') {
		$res = loadproductlistById( $_GET['list_id'] );

		if (!$res) {
			Redirect( '?action=product_lists' );
		}

		deleteProductfromlist( $_GET['productID'], $_GET['list_id'] );
		$_GET['action'] = 'edit_list';
	}


	if ($_GET['action'] == 'add_product') {
		$res = loadproductlistById( $_GET['list_id'] );

		if (!$res) {
			Redirect( '?action=product_lists' );
		}

		addProducttolist( $_GET['productID'], $_GET['list_id'] );
	}


	if ($_GET['action'] == 'delete_list') {
		productlistdelete( $_GET['list_id'] );
	}


	if ($_GET['action'] == 'edit_list') {
		renderURL( 'action=edit_list', '', true );
		$PostVars = $_POST;
		$GetVars = $_GET;

		if (isset( $_POST['searchstring'] )) {
			renderURL( 'searchstring=', urlencode( $PostVars['searchstring'] ), '', true );
			$GetVars['searchstring'] = urlencode( $PostVars['searchstring'] );
		}

		$searchstring = (isset( $GetVars['searchstring'] ) ? urldecode( $GetVars['searchstring'] ) : '');
		$res = loadproductlistById( $_GET['list_id'] );

		if (!$res) {
			Redirect( '?action=product_lists' );
		}

		$objectEntry = _search_products( $searchstring );

		if ($searchstring) {
			$smarty->assign( 'searchstring', $searchstring );
		}

		$smarty->assign( 'GridRows', $objectEntry );
		$smarty->assign( 'productList', $res );
		$smarty->assign( 'products', getProductsbyproductlistid( 1, $_GET['list_id'] ) );
		$smarty->assign( 'editproductList', 1 );
	}


	if (isset( $_POST['save_order'] )) {
		$r = save_order(  );
		$smarty->assign( 'MessageBlock', '<p class="success" id="messge"> <font color="green"><b>' . MSG_INFORMATION_SAVED . '</b></font> </p>' );
	}


	if ($_POST['action'] == 'save_lists') {
		$data = scanArrayKeysForID( $_POST, array( 'list_name', 'orderbtn', 'postbtn' ) );
		foreach ($data as $list_id => $_values) {
			$res = loadproductlistById( $list_id );

			if (!$res) {
				continue;
			}

			$prd['list_id'] = $list_id;
			$prd['list_name'] = $_values['list_name'];
			$prd['orderbtn'] = $_values['orderbtn'];
			$prd['postbtn'] = $_values['postbtn'];

			if ($res = productlistupdate( $prd )) {
				$smarty->assign( 'MessageBlock', '<p class="warning" id="messge"> <font color="green"><b>' . $res . '</b></font> </p>' );
				continue;
			}

			$smarty->assign( 'MessageBlock', '<p class="success" id="messge"> <font color="green"><b>' . MSG_INFORMATION_SAVED . '</b></font> </p>' );
		}


		if (( $_POST['list_id'] || $_POST['list_name'] )) {

			if ($res = productlistadd( $_POST )) {
				$smarty->assign( 'MessageBlock', '<p class="warning" id="messge"> <font color="green"><b>' . $res . '</b></font> </p>' );
			} 
else {
				$smarty->assign( 'MessageBlock', '<p class="success" id="messge"> <font color="green"><b>' . MSG_INFORMATION_SAVED . '</b></font> </p>' );
			}
		}
	}

	$product_lists = stc_getLists(  );
	$smarty->assign( 'product_list', $product_lists );
	$smarty->assign( 'admin_sub_tab', 'product_lists.tpl.html' );
?>