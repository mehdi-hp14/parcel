<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'bank_bills' )) {
		if (isset( $_POST['submitbank'] )) {
			if (( ( !empty( $_POST['bankname'] ) && !empty( $_POST['accountno'] ) ) && !empty( $_POST['holder'] ) )) {
				$bankName = $_POST['bankname'];
				$accNo = $_POST['accountno'];
				$holder = $_POST['holder'];

				if (CONF_BACKEND_SAFEMODE) {
					Redirect( 'admincp.php?tab=custord&sub=bank_bills&safemode' );
				}

				submitNewBankAcc( $bankName, $accNo, $holder );
				$smarty->assign( 'sucmsg', 1 );
			} 
else {
				$smarty->assign( 'sucmsg', 2 );
			}
		}


		if (isset( $_GET['dellacc'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=custord&sub=bank_bills&safemode' );
			}

			delbankAcc( $_GET['dellacc'] );
		}

		$allaccounts = getBankAccounts(  );

		if (isset( $_GET['page'] )) {
			$page = $_GET['page'];
		} 
else {
			$page = 817;
		}


		if (isset( $_GET['confirmbill'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=custord&sub=bank_bills&safemode' );
			}

			confirmbill( $_GET['confirmbill'] );
		}


		if (isset( $_GET['dellbill'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=custord&sub=bank_bills&safemode' );
			}

			dellbill( $_GET['dellbill'] );
		}

		$billList = bankbillsList( $page );
		$pager = pager( $page );
		$smarty->assign( 'pager', $pager );
		$smarty->assign( 'all_bills', $billList );
		$smarty->assign( 'all_accounts', $allaccounts );
		$smarty->assign( 'admin_sub_tab', 'custord_bank_bills.tpl.html' );
	}

?>