<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$ob_per_list = 1287;

	if (( CONF_BACKEND_SAFEMODE && $_POST['fACTION'] )) {
		Redirect( ($_POST['fREDIRECT'] ? set_query( '&safemode', $_POST['fREDIRECT'] ) : set_query( '&safemode' )) );
	}

	$msg = '';
	switch ($_POST['fACTION']) {
		case 'NEW_LINK_CATEGORY': {
			$_ncID = le_addCategory( $_POST['LINK_CATEGORY'] );

			if ($_ncID) {
				$_POST['fREDIRECT'] = set_query( 'categoryID=' . $_ncID, $_POST['fREDIRECT'] );
				$msg = 'ok';
			} 
else {
				$error_message = STRING_ERROR_LE_LINK_CATEGORY_EXISTS;
			}

			break;
		}

		case 'SAVE_LINK_CATEGORY': {
			if (le_saveCategory( $_POST['LINK_CATEGORY'] )) {
				$msg = 'ok';
			} 
else {
				$error_message = STRING_ERROR_LE_LINK_CATEGORY_EXISTS;
			}

			break;
		}

		case 'DELETE_LINK_CATEGORY': {
			if (!isset( $_POST['LINK_CATEGORY']['le_cID'] )) {
				break;
			}

			le_deleteCategory( $_POST['LINK_CATEGORY']['le_cID'] );
			$_links = le_getLinks( 0, le_getLinksNumber( 'le_lCategoryID = ' . $_POST['LINK_CATEGORY']['le_cID'] ), $_POST['LINK_CATEGORY']['le_cID'], 'le_lID', 'le_lVerified ASC, le_lURL ASC' );
			foreach ($_links as $__link) {
				le_SaveLink( array( 'le_lID' => $__link['le_lID'], 'le_lCategoryID' => 0 ) );
			}

			$_POST['fREDIRECT'] = set_query( 'categoryID=', $_POST['fREDIRECT'] );
			$msg = 'ok';
			break;
		}

		case 'NEW_LINK': {
			if (!strlen( str_replace( 'http://', '', $_POST['LINK']['le_lURL'] ) )) {
				$error_message = STRING_ERROR_LE_ENTER_LINK;
				$show_new_link = true;
				break;
			}


			if (!strlen( $_POST['LINK']['le_lText'] )) {
				$error_message = STRING_ERROR_LE_ENTER_TEXT;
				$show_new_link = true;
				break;
			}


			if (strpos( $_POST['LINK']['le_lURL'], 'http://' )) {
				$_POST['LINK']['le_lURL'] = 'http://' . $_POST['LINK']['le_lURL'];
			}

			$_POST['LINK']['le_lVerified'] = date( 'Y-m-d H:i:s' );

			if (!le_addLink( $_POST['LINK'] )) {
				$show_new_link = true;
				$error_message = STRING_ERROR_LE_LINK_EXISTS;
				break;
			}

			$msg = 'ok';
			break;
		}

		case 'MOVE_LINKS': {
			if (isset( $_POST['LINKS_IDS'] )) {
				foreach ($_POST['LINKS_IDS'] as $_linkID) {
					le_SaveLink( array( 'le_lID' => $_linkID, 'le_lCategoryID' => $_POST['new_le_lCategoryID'] ) );
				}
			}

			$msg = 'ok';
			break;
		}

		case 'SAVE_LINKS': {
			if (isset( $_POST['LINKS_IDS'] )) {
				foreach ($_POST['LINKS_IDS'] as $_linkID) {
					$_POST['LINK'][$_linkID]['le_lID'] = $_linkID;

					if (!le_SaveLink( $_POST['LINK'][$_linkID] )) {
						$error_message = STRING_ERROR_LE_LINK_EXISTS;
						continue;
					}
				}
			}


			if (!empty( $$error_message )) {
				$msg = 'ok';
			}

			break;
		}

		case 'VERIFY_LINKS': {
			if (isset( $_POST['LINKS_IDS'] )) {
				foreach ($_POST['LINKS_IDS'] as $_linkID) {
					le_SaveLink( array( 'le_lID' => $_linkID, 'le_lVerified' => date( 'Y-m-d H:i:s' ) ) );
				}
			}

			$msg = 'ok';
			break;
		}

		case 'UNVERIFY_LINKS': {
			if (isset( $_POST['LINKS_IDS'] )) {
				foreach ($_POST['LINKS_IDS'] as $_linkID) {
					le_SaveLink( array( 'le_lID' => $_linkID, 'le_lVerified' => 'NULL' ) );
				}
			}

			$msg = 'ok';
			break;
		}

		case 'DELETE_LINKS': {
			if (isset( $_POST['LINKS_IDS'] )) {
				foreach ($_POST['LINKS_IDS'] as $_le_lID) {
					le_DeleteLink( $_le_lID );
				}
			}

			$msg = 'ok';
		}
	}


	if (( $_POST['fREDIRECT'] && $msg == 'ok' )) {
		Redirect( set_query( 'action=' . $msg, $_POST['fREDIRECT'] ) );
	}


	if (empty( $_GET['categoryID'] )) {
		$_GET['categoryID'] = 0;
	} 
else {
		$_GET['categoryID'] = intval( $_GET['categoryID'] );
	}

	$TotalPages = ceil( le_getLinksNumber( ($_GET['categoryID'] ? array( 'le_lCategoryID' => $_GET['categoryID'] ) : '1') ) / $ob_per_list );

	if (empty( $_GET['p'] )) {
		$_GET['p'] = 1;
	} 
else {
		$_GET['p'] = ($TotalPages < intval( $_GET['p'] ) ? $TotalPages : intval( $_GET['p'] ));
	}

	$linkexchangeenabled = _getSettingOptionValue( 'CONF_LINKEXCHANGE_ENABLED' );
	$smarty->assign( 'linkexchangeenabled', $linkexchangeenabled );

	if (isset( $_POST['thisdisabled'] )) {
		if ($_POST['thisdisabled'] == 0) {
			_setSettingOptionValue( 'CONF_LINKEXCHANGE_ENABLED', 0 );
			$smarty->assign( 'linkexchangeenabled', 0 );
		} 
else {
			_setSettingOptionValue( 'CONF_LINKEXCHANGE_ENABLED', 1 );
			$smarty->assign( 'linkexchangeenabled', 1 );
		}
	}


	if (( isset( $_GET['show_all'] ) || isset( $_POST['show_all'] ) )) {
		$ob_per_list = $ob_per_list * $TotalPages;
		$smarty->assign( 'showAllLinks', '1' );
		$_GET['p'] = 1;
	}

	$lister = getListerRange( $_GET['p'], $TotalPages );

	if (empty( $$show_new_link )) {
		$smarty->assign( 'show_new_link', 'yes' );

		if (isset( $_POST['LINK'] )) {
			$smarty->assign( 'pst_LINK', html_spchars( xStripSlashesGPC( $_POST['LINK'] ) ) );
		}
	}


	if (empty( $$error_message )) {
		$smarty->assign( 'error_message', $error_message );
	}


	if (isset( $_GET['safemode'] )) {
		$error_message = ADMIN_SAFEMODE_WARNING;
	}

	$_SERVER['REQUEST_URI'] = set_query( 'safemode=&action=' );
	$le_Categories = html_spchars( le_getCategories(  ) );
	foreach ($le_Categories as $_ind => $_val) {
		$le_Categories[$_ind]['links_num'] = le_getLinksNumber( 'le_lCategoryID = ' . $_val['le_cID'] );
	}

	$smarty->assign( 'le_LinksNumInCategories', le_getLinksNumber(  ) );
	$smarty->assign( 'REQUEST_URI', $_SERVER['REQUEST_URI'] );
	$smarty->assign( 'url_allcategories', set_query( 'categoryID=' ) );
	$smarty->assign( 'le_categories', $le_Categories );
	$smarty->assign( 'le_categories_num', count( $le_Categories ) );
	$smarty->assign( 'le_CategoryID', $_GET['categoryID'] );
	$smarty->assign( 'curr_page', $_GET['p'] );
	$smarty->assign( 'last_page', $TotalPages );
	$smarty->assign( 'le_links', html_spchars( le_getLinks( $_GET['p'], $ob_per_list, ($_GET['categoryID'] ? array( 'le_lCategoryID' => $_GET['categoryID'] ) : '1'), 'le_lID, le_lText, le_lURL, le_lCategoryID, le_lVerified', 'le_lVerified ASC, le_lURL ASC' ) ) );
	$smarty->assign( 'le_lister_range', range( $lister['start'], $lister['end'] ) );
	$smarty->assign( 'admin_sub_tab', 'content_linkexchange.tpl.html' );
?>