<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'aux_pages' )) {
		if (isset( $_GET['delete'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=content&sub=aux_pages&safemode' );
			}

			auxpgDeleteAuxPage( $_GET['delete'] );
			Redirect( 'admincp.php?tab=content&sub=aux_pages' );
		}


		if (isset( $_GET['add_new'] )) {
			if (isset( $_POST['save'] )) {
				if (CONF_BACKEND_SAFEMODE) {
					Redirect( 'admincp.php?tab=content&sub=aux_pages&safemode' );
				}


				if (CONF_BACKEND_SAFEMODE) {
					Redirect( 'admincp.php?tab=content&sub=aux_pages&safemode' );
				}

				auxpgAddAuxPage( $_POST );
				header( 'Location: admincp.php?tab=content&sub=aux_pages' );
			}

			$smarty->assign( 'add_new', 1 );
		} 
else {
			if (isset( $_GET['edit'] )) {
				if (isset( $_POST['save'] )) {
					if (CONF_BACKEND_SAFEMODE) {
						Redirect( 'admincp.php?tab=content&sub=aux_pages&safemode&edit=' . $_GET['edit'] );
					}

					auxpgUpdateAuxPage( $_GET['edit'], $_POST );
					header( 'Location: admincp.php?tab=content&sub=aux_pages' );
				}

				$aux_page = auxpgGetAuxPage( $_GET['edit'] );
				$smarty->assign( 'aux_page', $aux_page );
				$smarty->assign( 'edit', 1 );
			} 
else {
				if (isset( $_POST['SAVE_AUXORDER'] )) {
					$data = scanArrayKeysForID( $_POST, array( 'Enabled', 'aux_page_ID' ) );
					foreach ($data as $key => $val) {
						aux_en_di_page( $key, (isset( $val['Enabled'] ) ? 1 : 0) );
					}
				}

				$aux_pages = auxpgGetAllPageAttributes(  );
				$smarty->assign( 'aux_pages', $aux_pages );
			}
		}

		$smarty->assign( 'admin_sub_tab', 'content_aux_pages.tpl.html' );
	}

?>