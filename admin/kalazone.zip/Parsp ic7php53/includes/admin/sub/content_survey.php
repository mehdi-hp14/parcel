<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'survey' )) {
		error_reporting( true );
		$POLLIZ = new PollizAdmin(  );
		$ADMIN_URL = 'admincp.php?tab=content&sub=survey';
		switch ($_GET['pollCmd']) {
			case 'edit': {
				$oldPoll = $POLLIZ->getPoll( $_GET['pollId'] );
				$smarty->assign( 'start_new_poll', 'yes' );

				if ($oldPoll['startTime'] != '0000-00-00 00:00:00') {
					$oldPoll['startTime'] = TransformDATEToTemplate( $oldPoll['startTime'] );
				} 
else {
					$oldPoll['startTime'] = '';
				}


				if ($oldPoll['endTime'] != '0000-00-00 00:00:00') {
					$oldPoll['endTime'] = TransformDATEToTemplate( $oldPoll['endTime'] );
				} 
else {
					$oldPoll['endTime'] = '';
				}

				$smarty->assign( 'oldPoll', $oldPoll );
			}

			case 'add': {
				$smarty->assign( 'start_new_poll', 'yes' );

				if ($_GET['save'] == 'save') {
					$dateex = explode( '/', $_POST['startTime'] );
					$startTime = gregorian( $dateex[0], $dateex[1], $dateex[2] ) . date( ' H:i:s' );
					$dateex = explode( '/', $_POST['endTime'] );
					$endTime = gregorian( $dateex[0], $dateex[1], $dateex[2] ) . date( ' H:i:s' );

					if ($POLLIZ->savePoll( $_POST['pollId'], $_POST['pollTitle'], $_POST['pollQuestion'], $_POST['answer'], $_POST['comment'], $startTime, $endTime )) {
						echo '<p class=\'checkOk\'>������� ����� ��!</p>
';
						echo '<script type=\'text/javascript\'>location.replace(\'' . $ADMIN_URL . '&cmd=polls\');</script>
';
					} 
else {
						echo '<p class=\'checkKo\'>Error adding new poll.</p>
';
					}
				}

				break;
			}

			case 'del': {
				$POLLIZ->deletePoll( $_GET['pollId'] );
				echo '<h2>�� ������ ��� ��.</h2>
';
				echo '<p class=\'checkOk\'>��� ���� ��!</p>
';
				echo '<script type=\'text/javascript\'>location.replace(\'' . $ADMIN_URL . '&cmd=polls\');</script>
';
				break;
			}

			case 'act': {
				echo '<h2>����� ����� �������</h2>
';

				if (2 < $USER_LEVEL) {
					exit( 'You cannot enter this area.' );
				}

				$POLLIZ->changePollStatus( $_GET['pollId'], $_GET['newStatus'] );
				echo '<p class=\'checkOk\'>����� ������� ����� ���!</p>
';
				echo '<script type=\'text/javascript\'>location.replace(\'' . $ADMIN_URL . '&cmd=polls\');</script>
';
				break;
			}

			case 'pollsResults': {
				echo '<head><link rel=STYLESHEET href="style/admin_style.css" type="text/css">
          <script src="./js/imagemap.js" type="text/javascript"></script>
          </head>
          <body dir=rtl>
        <div id="min_header" dir="rtl">              
          <font color="purple"><b>            
' . ADMIN_POLL_RESULT . '</b></div>
';
				echo '<div style=\'background-color:#CCC; padding:3px 5px; margin:10px 0;\'><b>' . ADMIN_POLL_SELECT . '</b>: <select onchange=\'javascript:if(this.value > 0) location.replace("' . $ADMIN_URL . '&amp;cmd=polls&pollCmd=pollsResults&amp;pollId=" + this.value);\'><option value=\'0\'>' . ADMIN_POLL_SELECT . '</option>
';
				$timeNow = date( 'Y-m-d H:i:s' );
				foreach ($POLLIZ->getPolls(  ) as $poll) {
					echo '<option value=\'' . $poll['pollId'] . '\' ' . ($poll['pollId'] == $_GET['pollId'] ? 'selected=\'selected\'' : '') . '>#' . $poll['pollId'] . ' - ' . $poll['pollTitle'] . ' (' . (( ( $poll['active'] && $poll['startTime'] <= $timeNow ) && $timeNow <= $poll['endTime'] ) ? STR_ACTIVATED : STR_NOTACTIVATED) . ')</option>
';
				}

				echo '</select></div>';

				if ($_GET['pollId']) {
					$pollData = $POLLIZ->getPoll( $_GET['pollId'] );

					if (is_array( $pollData )) {
						$pollVotes = $POLLIZ->getPollVotes( $_GET['pollId'] );

						if (intval( $poll['startTime'] )) {
							$poll['startTime'] = ADMIN_ORDER_SEARCH_FDATE . ' <b> ' . TransformDATEToTemplate( $poll['startTime'] ) . '</b>';
						}


						if (intval( $poll['endTime'] )) {
							$poll['endTime'] = ADMIN_ORDER_SEARCH_TDATE . TransformDATEToTemplate( $poll['endTime'] );
						} 
else {
							$poll['endTime'] = STRING_UNLIMITED;
						}

						echo '<h2>' . $pollData['pollTitle'] . '</h2>              
                <i><b>' . ($poll['active'] ? STR_ACTIVATED : STR_NOTACTIVATED) . '</b>';

						if ($poll['startTime']) {
							echo ',  ' . STR_ACTIVATED . ' ' . $poll['startTime'] . ' ' . ADMIN_ORDER_SEARCH_TDATE . ' <b> ' . $poll['endTime'] . '</b></i>';
						}

						echo '<h3>' . $pollData['pollQuestion'] . '</h3>
                <table>
                <tr><td>
                <table border=\'0\' cellspacing=\'1\' cellpadding=\'4\' bgcolor=#DBDFE1>
                  <thead>
                    <tr class=\'tableheader\'>
                      <th><p>' . ADMIN_POLL_OPTIONS . '</p></th>
                      <th><p>' . ADMIN_PRODUCT_RATING . '</p></th>
                      <th><p>' . STRING_PERCENT . '</p></th>
                      <td style=\'width:200px;\'>&nbsp;</td>
                    </tr>
                  </thead>
                  <tbody>
              ';

						if (is_array( $pollData['pollAnswers'] )) {
							foreach ($pollData['pollAnswers'] as $ansOrder => $ansData) {
								$votes = ($pollVotes[$ansData['id']] ? $pollVotes[$ansData['id']] : 0);
								echo '<tr bgcolor=white>
                  <td>' . $ansData['answer'] . ( '</td>
                  <td>' . $votes . '</td>
                  <td>' ) . round( $votes / array_sum( $pollVotes ) * 100 ) . '%</td>
                  <td><div style=\'width:' . 170 * $votes / array_sum( $pollVotes ) . 'px; background-color:#00F;\'>&nbsp;</div></td>
                </tr>
';
							}
						}

						echo '</tbody></table></td><td><img src="draw.php?cmd=polldata&pollId=' . $_GET['pollId'] . '" id="chart" alt="" class="pChartPicture"/></td></tr></table>';
						echo '</body><script>
   addImage("chart","pictureMap","draw.php?ImageMap=get");
</script>';
					}
				}

				exit(  );
			}
		}

		$timeNow = date( 'Y-m-d H:i:s' );
		$pollis = $POLLIZ->getPolls(  );
		foreach ($pollis as ) {
			$poll = &;

			if (( intval( $poll['startTime'] ) == 0 && intval( $poll['endTime'] ) == 0 )) {
				$poll['online'] = ($poll['active'] ? '<span class=\'checkOk\'>' . STR_ACTIVATED . '</span>' : '<span class=\'checkKo\'>' . STR_NOTACTIVATED . '</span>');
			} 
else {
				if (intval( $poll['endTime'] ) == 0) {
					$poll['online'] = (( $poll['active'] && $poll['startTime'] <= $timeNow ) ? '
            <span class=\'checkOk\'>' . STR_ACTIVATED . '</span>' : '<span class=\'checkKo\'>' . STR_NOTACTIVATED . '</span>');
				} 
else {
					if (intval( $poll['startTime'] ) == 0) {
						$poll['online'] = (( $poll['active'] && $timeNow <= $poll['endTime'] ) ? '
            <span class=\'checkOk\'>' . STR_ACTIVATED . '</span>' : '<span class=\'checkKo\'>' . STR_NOTACTIVATED . '</span>');
					} 
else {
						$poll['online'] = (( ( $poll['active'] && $poll['startTime'] <= $timeNow ) && $timeNow <= $poll['endTime'] ) ? '
            <span class=\'checkOk\'>' . STR_ACTIVATED . '</span>' : '<span class=\'checkKo\'>' . STR_NOTACTIVATED . '</span>');
					}
				}
			}


			if (intval( $poll['startTime'] )) {
				$poll['startTime'] = TransformDATEToTemplate( $poll['startTime'] );
			} 
else {
				$poll['startTime'] = '';
			}


			if (intval( $poll['endTime'] )) {
				$poll['endTime'] = TransformDATEToTemplate( $poll['endTime'] );
				continue;
			}

			$poll['endTime'] = '';
		}

		$smarty->assign( 'pollis', $pollis );
		$smarty->assign( 'ADMIN_URL', $ADMIN_URL );
		$smarty->assign( 'admin_sub_tab', 'content_polls.tpl.html' );
	}

?>