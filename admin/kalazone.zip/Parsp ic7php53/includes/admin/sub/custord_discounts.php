<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'discounts' )) {
		if (isset( $_GET['delete'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=custord&sub=discounts&safemode' );
			}

			dscDeleteOrderPriceDiscount( $_GET['delete'] );
			Redirect( 'admincp.php?tab=custord&sub=discounts' );
		}


		if (isset( $_GET['error'] )) {
			$smarty->assign( 'error', 1 );
		}


		if (isset( $_POST['discount_type_save'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=custord&sub=discounts&safemode' );
			}

			$_POST['savesetting'] = 1;
		}

		$control = settingCallHtmlFunction( 'CONF_DISCOUNT_TYPE' );

		if (isset( $_POST['discount_type_save'] )) {
			Redirect( 'admincp.php?tab=custord&sub=discounts' );
		}

		$smarty->assign( 'control', $control );

		if (isset( $_POST['save_order_price_discounts'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=custord&sub=discounts&safemode' );
			}

			$error = false;
			$data = ScanPostVariableWithId( array( 'percent_discount', 'price_range' ) );
			foreach ($data as $discount_id => $val) {

				if (!dscUpdateOrderPriceDiscount( $discount_id, $val['price_range'], (double)$val['percent_discount'] )) {
					$error = true;
					continue;
				}
			}


			if (trim( $_POST['new_price_range'] ) != '') {
				if (!dscAddOrderPriceDiscount( (double)$_POST['new_price_range'], (double)$_POST['new_percent_discount'] )) {
					$error = true;
				}
			}


			if ($error) {
				Redirect( 'admincp.php?tab=custord&sub=discounts&error' );
			} 
else {
				Redirect( 'admincp.php?tab=custord&sub=discounts' );
			}
		}

		$discounts = dscGetAllOrderPriceDiscounts(  );
		$smarty->assign( 'discounts', $discounts );
		$smarty->assign( 'admin_sub_tab', 'custord_discounts.tpl.html' );
	}

?>