<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'COUPONS_PER_PAGE', 20 );

	if (!strcmp( $sub, 'coupons' )) {
		function _add_prefix_to_errors($a) {
			return 'STRING_COUPON_' . strtoupper( $a );
		}

		$PV = $_POST;
		$GV = $_GET;
		$page = (array_key_exists( 'offset', $GV ) ? $GV['offset'] / COUPONS_PER_PAGE + 1 : null);
		$new_coupon_data = array( 'code' => genRandomCouponCode(  ), 'is_active' => 'Y', 'type' => 'SU', 'expire_date' => now, 'discount_type' => 'P', 'discount_percent' => '0', 'discount_absolute' => '0', 'comment' => '' );
		$_errors = array(  );
		switch ($PV['coupon_action']) {
			case 'add_new': {
				$new_coupon_data = $PV['new_coupon'];
				$new_coupon_data['is_active'] = (array_key_exists( 'is_active', $new_coupon_data ) ? 'Y' : 'N');
				$add_result = addCoupon( $new_coupon_data );

				if (!$add_result['status']) {
					$_errors = array_merge( $_errors, $add_result['errors'] );
				} 
else {
					$new_coupon_data['code'] = genRandomCouponCode(  );
					$new_coupon_data['comment'] = '';
					$page = FIRST_PAGE;
				}

				break;
			}

			case 'del_coupons': {
				$coupons_ids = explode( '|', $PV['coupons_ids'] );
				$del_result = delCoupons( $coupons_ids );

				if (!$del_result['status']) {
					$_errors = array_merge( $_errors, $del_result['errors'] );
				}

				break;
			}

			case 'upd_coupons': {
				$inactive_ids_str = explode( '-', $PV['coupons_ids'] )[1];
				[0];
				$active_ids_str = ;
				$active_coupons = explode( '|', $active_ids_str );
				$inactive_coupons = explode( '|', $inactive_ids_str );
				$coupons_data = array(  );
				$PV['coupons_discounts'] = explode( '|', $PV['coupons_discounts'] );
				foreach ($PV['coupons_discounts'] as $dsc) {
					$discount_value = explode( '-', $dsc )[1];
					[0];
					$coupon_id = ;
					$coupons_data[$coupon_id] = array( 'is_active' => in_array( $coupon_id, $active_coupons ), 'discount_value' => $discount_value );
				}

				$PV['discount_types'] = explode( '|', $PV['discount_types'] );
				foreach ($PV['discount_types'] as $dsc) {
					$discount_type = explode( '-', $dsc )[1];
					[0];
					$coupon_id = ;
					$coupons_data[$coupon_id]['discount_type'] = $discount_type;
				}

				updateCoupons( $coupons_data );
			}
		}

		$currency_sign = (isset( $_SESSION['current_currency'] ) ? $_SESSION['current_currency'] : CONF_DEFAULT_CURRENCY);

		if (!( $q = db_query( 'select * from ' . CURRENCY_TYPES_TABLE . ( ' where CID=' . $currency_sign ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
			$smarty->assign( 'currency_name', $row['code'] );
			$selected_currency_details = $GV;
		} 
else {

			if (!( $q = db_query( 'select * from ' . CURRENCY_TYPES_TABLE ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if ($row = db_fetch_row( $q )) {
				LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
				$smarty->assign( 'currency_name', $row['code'] );
				$selected_currency_details = $GV;
			}
		}

		$new_coupon_data['expire_date'] = TransformDATEToTemplate( $new_coupon_data['expire_date'] );
		$get_res = getCoupons( $page );

		if (!$get_res['status']) {
			$_errors = array_merge( $_errors, $get_res['errors'] );
			$coupons = array(  );
			$pagination = array( 'page' => 0, 'pages' => 0 );
		} 
else {
			$coupons = $get_res['coupons'];
			$pagination = $get_res['pagination'];
		}

		foreach ($coupons as $k => $coupon) {
			$coupons[$k]['show_abs_discount'] = show_price( $coupon['discount_absolute'], CONF_DEFAULT_CURRENCY, 1 );

			if ($coupon['coupon_type'] != 'SU') {
				$coupons[$k]['expire_info'] = (date( 'Y-m-d' ) < $coupon['expire_date'] ? STRING_COUPON_VALID_TO . ' ' . TransformDATEToTemplate( $coupon['expire_date'] ) : STRING_COUPON_EXPIRED . ' ' . TransformDATEToTemplate( $coupon['expire_date'] ));
				$coupons[$k]['is_disabled'] = ( $coupon['coupon_type'] != 'MN' && $coupon['expire_date'] < date( 'Y-m-d' ) );
			} 
else {
				$coupons[$k]['expire_info'] = '';
				$coupons[$k]['is_disabled'] = $coupon['expire_date'] == 0;
			}

			$coupons[$k]['orders'] = getCouponOrders( $coupon['coupon_id'] );
			$coupons[$k]['orders_count'] = count( $coupons[$k]['orders'] );
		}

		$smarty->assign( 'base_uri', preg_replace( '/&page=\d+/', '', $_SERVER['QUERY_STRING'] ) );
		$smarty->assign( '_errors', array_map( '_add_prefix_to_errors', $_errors ) );
		$smarty->assign( 'new_coupon_data', $new_coupon_data );
		$smarty->assign( 'currency_sign', $currency_sign );
		$smarty->assign( 'coupons_list', $coupons );
		$smarty->assign( 'coupons_pagination', $pagination );
		ShowNavigator( $pagination['items_count'], ( $pagination['page'] - 1 ) * COUPONS_PER_PAGE, COUPONS_PER_PAGE, 'admincp.php?tab=custord&sub=coupons&', $coupons_nav );
		$smarty->assign( 'coupons_nav', $coupons_nav );
		$smarty->assign( 'admin_sub_tab', 'custord_manage_coupons.tpl.html' );
	}

?>