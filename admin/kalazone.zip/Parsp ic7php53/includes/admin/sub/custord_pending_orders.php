<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'pending_orders' )) {
		$noaff = '';
		$nodel = '';
		$counter1 = '';
		$counter2 = '';
		$pendingID = _getSettingOptionValue( 'CONF_NEW_ORDER_STATUS' );
		$pendingName = ostGetOrderStatusName( $pendingID );

		if (!empty( $_POST['days'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=custord&sub=pending_orders&safemode' );
			}

			$days = $_POST['days'];

			if (!( $q = db_query( 'SELECT orderID FROM ' . ORDERS_TABLE . ( ' WHERE statusID= ' . $pendingID . ' AND DATE_ADD(order_time,INTERVAL ' . $days . ' DAY)<now()' ) ))) {
				exit( mysql_error(  ) );
				(bool)true;
			}

			$counter1 = 831;

			if ($result = db_fetch_row( $q )) {
				ostSetOrderStatusToOrder( $result['orderID'], 1 );
				++$counter1;
			}


			if ($counter1 <= 0) {
				$noaff = ADMIN_NO_AFF;
			} 
else {
				$noaff = '';
			}
		}


		if (( isset( $_POST['delete'] ) && $_POST['deldays'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=custord&sub=pending_orders&safemode' );
			}

			$deldays = $_POST['deldays'];

			if (!( $q2 = db_query( 'SELECT orderID FROM ' . ORDERS_TABLE . ( ' WHERE statusID= 1 AND DATE_ADD(order_time,INTERVAL ' . $deldays . ' DAY)<now()' ) ))) {
				exit( mysql_error(  ) );
				(bool)true;
			}

			$counter2 = 831;

			if ($result2 = db_fetch_row( $q2 )) {
				ordDeleteOrder( $result2['orderID'] );
				++$counter2;
			}


			if ($counter2 <= 0) {
				$nodel = ADMIN_NO_DEL;
			} 
else {
				$nodel = '';
			}
		}

		$smarty->assign( 'noaff', $noaff );
		$smarty->assign( 'nodel', $nodel );
		$smarty->assign( 'pending', $pendingName );
		$smarty->assign( 'affected', $counter1 );
		$smarty->assign( 'deleted', $counter2 );
		$smarty->assign( 'admin_sub_tab', 'custord_pending_orders.tpl.html' );
	}

?>