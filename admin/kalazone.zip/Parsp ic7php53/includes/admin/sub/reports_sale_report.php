<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'sale_report' )) {
		if (isset( $_POST['report'] )) {
			$content = '<p><b><a href=\'admincp.php?tab=reports&sub=sale_report\'><<' . STRING_BACKTO . ' ' . ADMIN_SALE_REPORT . '</a> </b></p>';
			$content .= '<link rel=STYLESHEET href="style/admin_style.css" type="text/css">
          <script src="./js/imagemap.js" type="text/javascript"></script>                    
        <div id="min_header" dir="rtl">              
          <font color="purple"><b>            
' . ADMIN_SALE_REPORT . '</b></div>
';
			$callBackParam['from_date'] = gregorian( $_POST['from_year'], $_POST['from_month'], $_POST['from_day'] );
			$callBackParam['till_date'] = gregorian( $_POST['till_year'], $_POST['till_month'], $_POST['till_day'] );
			$orderStatuses = array(  );
			$data = ScanPostVariableWithId( array( 'checkbox_order_status' ) );
			foreach ($data as $key => $val) {

				if ($val['checkbox_order_status'] == '1') {
					$orderStatuses[] = $key;
					continue;
				}
			}

			$callBackParam['orderStatuses'] = $orderStatuses;
			$statusstr = implode( ',', $orderStatuses );
			$salesdata = ordGetreports( $callBackParam );

			if ($salesdata) {
				if (is_array( $salesdata )) {
					$content .= '<table>
                            <tr><td>
                            <table border=\'0\' cellspacing=\'1\' cellpadding=\'4\' bgcolor=#DBDFE1>
                              <thead>
                                <tr class=\'tableheader\'>
                                  <th><p>' . ADMIN_CURRENT_DATE . '</p></th>
                                  <th><p>' . TABLE_PRODUCT_QUANTITY . '</p></th>
                                  <th><p>' . ADMIN_SALE_AMOUNT . '</p></th>                                  
                                </tr>
                              </thead>
                              <tbody>';
					foreach ($salesdata as $key => $value) {
						$content .= '<tr bgcolor=white>
                              <td>' . $value['cur_date'] . '</td>
                              <td>' . $value['order_count'] . '</td>
                              <td>' . show_price( $value['order_amount'], CONF_DEFAULT_CURRENCY, 1 ) . '</td>                                                            
                              </tr>
';
					}

					$content .= '</tbody></table></td><td><img src="draw.php?cmd=reprtdata&fromdate=' . $callBackParam['from_date'] . '&tilldate=' . $callBackParam['till_date'] . '&status=' . $statusstr . '" id="chart" alt="" class="pChartPicture"/></td></tr></table>
                        </body><script>addImage("chart","pictureMap","draw.php?ImageMap=get");
                        </script>';
					$smarty->assign( 'content', $content );
				}
			} 
else {
				$smarty->assign( 'notfound', STRING_NO_ORDERS );
			}
		}

		$order_statuses = ostGetOrderStatues(  );

		if (isset( $callBackParam['from_date'] )) {
			$seldate = explode( '/', jdate( 'Y/m/d', strtotime( $callBackParam['from_date'] ) ) );
		} 
else {
			$seldate = explode( '/', jdate( 'Y/m/d' ) );
		}


		if (isset( $callBackParam['till_date'] )) {
			$sel2date = explode( '/', jdate( 'Y/m/d', strtotime( $callBackParam['till_date'] ) ) );
		} 
else {
			$sel2date = explode( '/', jdate( 'Y/m/d' ) );
		}

		$data = array( '', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند' );
		$smarty->assign( 'months', $data );
		$j = $seldate[0] - 5;

		while ($j < $seldate[0] + 5) {
			$ydata[] = $j;
			++$j;
		}

		$smarty->assign( 'seldate', $seldate );
		$smarty->assign( 'sel2date', $sel2date );
		$smarty->assign( 'years', $ydata );
		$smarty->assign( 'order_statuses', $order_statuses );
		$smarty->assign( 'admin_sub_tab', 'reports_sale_report.tpl.html' );
	}

?>