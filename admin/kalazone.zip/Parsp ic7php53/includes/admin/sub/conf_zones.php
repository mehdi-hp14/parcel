<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'zones' )) {
		if (isset( $_GET['delete'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=zones&countryID=' . $_GET['countryID'] . '&safemode' );
			}

			znDeleteZone( $_GET['delete'] );
			Redirect( 'admincp.php?tab=conf&sub=zones&countryID=' . $_GET['countryID'] );
		}


		if (isset( $_POST['save_zones'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=zones&countryID=' . $_GET['countryID'] . '&safemode' );
			}

			$data = scanArrayKeysForID( $_POST, array( 'zone_name_\w{2}', 'zone_code' ) );
			$countryID = $_GET['countryID'];
			foreach ($data as $key => $val) {
				znUpdateZone( $key, $val, $data[$key]['zone_code'], $countryID );
			}

			$code = $_POST['new_zone_code'];

			if (!LanguagesManager::ml_isEmpty( 'new_zone_name', $_POST )) {
				znAddZone( $_POST, $code, $countryID );
			}

			Redirect( 'admincp.php?tab=conf&sub=zones&countryID=' . $_GET['countryID'] );
		}


		if (!isset( $_GET['countryID'] )) {
			Redirect( 'admincp.php?tab=conf&sub=zones&countryID=' . CONF_COUNTRY );
		}

		$callBackParam = null;
		$count_row = 829;
		$navigatorParams = null;
		$countries = cnGetCountries( $callBackParam, $count_row, $navigatorParams );
		$smarty->assign( 'countries', $countries );
		$zones = znGetZones( $_GET['countryID'] );
		$smarty->assign( 'zones', $zones );
		$smarty->assign( 'zones_count', count( $zones ) );
		$smarty->assign( 'country_iso_2', $_GET['countryID'] );
		$smarty->assign( 'admin_sub_tab', 'conf_zones.tpl.html' );
	}

?>