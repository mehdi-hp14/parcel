<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'affiliate' )) {
		require_once( './core_functions/affiliate_functions.php' );
		$sub_page = (isset( $_GET['sub_page'] ) ? $_GET['sub_page'] : '');
		$smarty->assign( 'CurrencyISO3', currGetAllCurrencies(  ) );
		$error_date_format = false;

		if (isset( $_POST['fACTION'] )) {
			switch ($_POST['fACTION']) {
				case 'ENABLE_AFFILIATE': {
					settingCallHtmlFunction( 'CONF_AFFILIATE_PROGRAM_ENABLED' );
					Redirect( $_POST['fREDIRECT'] );
					break;
				}

				case 'SAVE_SETTINGS': {
					$_POST['settingCONF_AFFILIATE_AMOUNT_PERCENT'] = floatval( $_POST['settingCONF_AFFILIATE_AMOUNT_PERCENT'] );

					if (!( 0 <= $_POST['settingCONF_AFFILIATE_AMOUNT_PERCENT'] && $_POST['settingCONF_AFFILIATE_AMOUNT_PERCENT'] <= 100 )) {
						$smarty->assign( 'ErrorPercent', true );
						unset( $_POST[savesetting] );
						break;
					}

					settingCallHtmlFunction( 'CONF_AFFILIATE_EMAIL_NEW_COMMISSION' );
					settingCallHtmlFunction( 'CONF_AFFILIATE_EMAIL_NEW_PAYMENT' );
					settingCallHtmlFunction( 'CONF_AFFILIATE_AMOUNT_PERCENT' );
					break;
				}

				case 'NEW_PAYMENT': {
					$dateex = explode( '/', $_POST['NEW_PAYMENT']['xDate'] );
					$xDateTime = gregorian( $dateex[0], $dateex[1], $dateex[2] ) . date( ' H:i:s' );
					$p_customerID = regGetIdByLogin( $_POST['NEW_PAYMENT']['customerID'] );

					if (!$p_customerID) {
						$smarty->assign( 'error_new_payment', ERROR_INPUT_LOGIN );
						$smarty->assign( 'NEW_PAYMENT', html_spchars( xStripSlashesGPC( $_POST['NEW_PAYMENT'] ) ) );
						break;
					}

					$_POST['NEW_PAYMENT']['xDate'] = $xDateTime;
					$_POST['NEW_PAYMENT']['customerID'] = $p_customerID;
					affp_addPayment( $_POST['NEW_PAYMENT'] );
					Redirect( set_query( 'tab=custord&sub=affiliate&new_pay=ok', $_POST['fREDIRECT'] ) );
					break;
				}

				case 'DELETE_PAYMENT': {
					if (!isset( $_POST['PAYMENT']['pID'] )) {
						break;
					}

					affp_deletePayment( $_POST['PAYMENT']['pID'] );
					Redirect( set_query( 'delete_pay=ok', $_POST['fREDIRECT'] ) );
					break;
				}

				case 'SAVE_PAYMENT': {
					if (!isTemplateDate( $_POST['PAYMENT']['xDate'], CONF_DATE_FORMAT )) {
						$error_message = AFFP_MSG_ERROR_DATE_FORMAT;
						break;
					}

					$xDate = TransformTemplateToDATE( $_POST['PAYMENT']['xDate'], CONF_DATE_FORMAT );

					if (!regGetIdByLogin( $_POST['PAYMENT']['customerLogin'] )) {
						$error_message = ERROR_INPUT_LOGIN;
						break;
					}

					$_POST['PAYMENT']['customerID'] = regGetIdByLogin( $_POST['PAYMENT']['customerLogin'] );
					unset( $_POST['PAYMENT'][customerLogin] );
					$_POST['PAYMENT']['Amount'] = (isset( $_POST['PAYMENT']['Amount'] ) ? round( $_POST['PAYMENT']['Amount'], 2 ) : 0);
					$_POST['PAYMENT']['xDate'] = $xDate;
					affp_savePayment( $_POST['PAYMENT'] );
					echo '
						<script language="javascript" type="text/javascript">
					  parent.TINY.box.hide;
						window.opener.document.location.href = window.opener.reloadURL;
						window.opener.focus();
						window.close();									
						</script>
						<center><a onclick="parent.TINY.hide;" href="#" >' . MSG_INFORMATION_SAVED . '</a></center>';
					exit( 1 );
					break;
				}

				case 'NEW_COMMISSION': {
					$dateex = explode( '/', $_POST['NEW_COMMISSION']['xDate'] );
					$xDateTime = gregorian( $dateex[0], $dateex[1], $dateex[2] ) . date( ' H:i:s' );
					$_POST['NEW_COMMISSION']['customerID'] = regGetIdByLogin( $_POST['NEW_COMMISSION']['customerLogin'] );
					$tLogin = $_POST['NEW_COMMISSION']['customerLogin'];
					unset( $_POST['NEW_COMMISSION'][customerLogin] );
					$_POST['NEW_COMMISSION']['Amount'] = (isset( $_POST['NEW_COMMISSION']['Amount'] ) ? sprintf( '%.0f', $_POST['NEW_COMMISSION']['Amount'] ) : 0);
					$_POST['NEW_COMMISSION']['xDateTime'] = $xDateTime;
					unset( $_POST['NEW_COMMISSION'][xDate] );
					$t = '';
					$Email = '';
					$FirstName = '';
					regGetContactInfo( $tLogin, $t, $Email, $FirstName, $t, $t, $t );
					xMailTxt( $Email, AFFP_NEW_COMMISSION, 'customer.affiliate.commission_notifi.tpl.html', array( 'customer_firstname' => $FirstName, '_AFFP_MAIL_NEW_COMMISSION' => str_replace( '{MONEY}', $_POST['NEW_COMMISSION']['Amount'] . ' ' . $_POST['NEW_COMMISSION']['CurrencyISO3'], AFFP_MAIL_NEW_COMMISSION ) ) );
					affp_addCommission( $_POST['NEW_COMMISSION'] );
					Redirect( set_query( 'tab=custord&sub=affiliate&new_commission=ok', $_POST['fREDIRECT'] ) );
					break;
				}

				case 'DELETE_COMMISSION': {
					if (!isset( $_POST['COMMISSION']['cID'] )) {
						break;
					}

					affp_deleteCommission( $_POST['COMMISSION']['cID'] );
					Redirect( set_query( 'delete_commission=ok', $_POST['fREDIRECT'] ) );
					break;
				}

				case 'SAVE_COMMISSION': {
					if (!isTemplateDate( $_POST['COMMISSION']['xDateTime'], CONF_DATE_FORMAT )) {
						$error_message = AFFP_MSG_ERROR_DATE_FORMAT;
						break;
					}

					$xDateTime = TransformTemplateToDATE( $_POST['COMMISSION']['xDateTime'], CONF_DATE_FORMAT ) . date( ' H:i:s' );

					if (!regGetIdByLogin( $_POST['COMMISSION']['customerLogin'] )) {
						$error_message = ERROR_INPUT_LOGIN;
						break;
					}

					$_POST['COMMISSION']['customerID'] = regGetIdByLogin( $_POST['COMMISSION']['customerLogin'] );
					unset( $_POST['COMMISSION'][customerLogin] );
					$_POST['COMMISSION']['Amount'] = (isset( $_POST['COMMISSION']['Amount'] ) ? round( $_POST['COMMISSION']['Amount'], 2 ) : 0);
					$_POST['COMMISSION']['xDateTime'] = $xDateTime;
					affp_saveCommission( $_POST['COMMISSION'] );
					print '
					<html>
					<head>
						<script language="javascript" type="text/javascript">						
						window.opener.document.location.href = window.opener.reloadURL;
						window.opener.focus();
						window.close();						
						</script>
					</head>
					<body><center><a href="reload">بستن این صفحه</a></center></body>
						';
					exit( 1 );
				}
			}
		}

		switch ($sub_page) {
			case 'edit_payment': {
				if (empty( $$error_message )) {
					$smarty->assign( 'Payment', html_spchars( xStripSlashesGPC( $_POST['PAYMENT'] ) ) );
					$smarty->assign( 'error_message', $error_message );
				} 
else {
					$Payment = affp_getPayments( '', $_GET['pID'] );
					$Payment[0]['xDate'] = $Payment[0]['xDate'];
					$Payment[0]['customerLogin'] = regGetLoginById( $Payment[0]['customerID'] );
					$smarty->assign( 'Payment', html_spchars( $Payment[0] ) );
				}

				$smarty->display( 'backend/custord_edit_payment.tpl.html' );
				exit( 1 );
				break;
			}

			case 'edit_commission': {
				if (empty( $$error_message )) {
					$smarty->assign( 'Commission', html_spchars( xStripSlashesGPC( $_POST['COMMISSION'] ) ) );
					$smarty->assign( 'error_message', $error_message );
				} 
else {
					$Commission = affp_getCommissions( '', $_GET['cID'] );
					$Commission[0]['xDateTime'] = $Commission[0]['xDateTime'];
					$Commission[0]['customerLogin'] = regGetLoginById( $Commission[0]['customerID'] );
					$smarty->assign( 'Commission', html_spchars( $Commission[0] ) );
				}

				$smarty->display( 'backend/custord_edit_commission.tpl.html' );
				exit( 1 );
				break;
			}
		}


		if (( ( isset( $_POST['from_day'] ) && isset( $_POST['from_month'] ) ) && isset( $_POST['from_year'] ) )) {
			$_GET['fromdate'] = gregorian( $_POST['from_year'], $_POST['from_month'], $_POST['from_day'] );
		}


		if (( ( isset( $_POST['from_day'] ) && isset( $_POST['from_month'] ) ) && isset( $_POST['from_year'] ) )) {
			$_GET['tilldate'] = gregorian( $_POST['till_year'], $_POST['till_month'], $_POST['till_day'] );
		}


		if (isset( $_POST['tilldate'] )) {
			$_GET['tilldate'] = xStripSlashesGPC( $_POST['tilldate'] );
		}


		if (!isset( $_GET['fromdate'] )) {
			$_GET['fromdate'] = '';
		} 
else {
			$_GET['fromdate'] = xStripSlashesGPC( rawurldecode( $_GET['fromdate'] ) );
		}


		if (!isset( $_GET['tilldate'] )) {
			$_GET['tilldate'] = '';
		} 
else {
			$_GET['tilldate'] = xStripSlashesGPC( rawurldecode( $_GET['tilldate'] ) );
		}

		$show_tables = false;
		$CurrDate = jdate( 'Y/m/d' );

		if ($_GET['fromdate'] != '') {
			$show_tables = true;
		} 
else {
			if (!isset( $_POST['dfrom'] )) {
				$_GET['fromdate'] = TransformDATEToTemplate( date( 'Y-m-01' ) );
			} 
else {
				$error_date_format = true;
			}
		}


		if ($_GET['tilldate'] != '') {
			$show_tables = if ($show_tables);
		} 
else {
			if (!isset( $_POST['till'] )) {
				$_GET['tilldate'] = $CurrDate;
				$show_tables = false;
			} 
else {
				$show_tables = false;
				$error_date_format = true;
			}
		}

		$XREQUEST_URI = set_query( '&edCustomerID=&safemode=&new_commission=&delete_pay=&delete_commission=&new_pay=&till=' . rawurlencode( $_GET['tilldate'] ) . '&dfrom=' . rawurlencode( $_GET['fromdate'] ) );

		if (empty( $$show_tables )) {
			if (!isset( $_GET['OrderField'] )) {
				$_GET['OrderField'] = 'pID';
			}


			if (!isset( $_GET['OrderDiv'] )) {
				$_GET['OrderDiv'] = 'ASC';
			}


			if ($_GET['OrderField'] == 'Amount') {
				$_GET['OrderField'] = ' CurrencyISO3 ' . $_GET['OrderDiv'] . ', ' . $_GET['OrderField'];
			}

			$customerid = regGetIdByLogin( $_POST['customerLogin'] );
			$Payments = affp_getPayments( $customerid, '', $_GET['fromdate'] . ' 00:00:00', $_GET['tilldate'] . ' 23:59:59', TransformStringToDataBase( $_GET['OrderField'] . ' ' . $_GET['OrderDiv'] ) );

			if (!isset( $_GET['OrderFieldC'] )) {
				$_GET['OrderFieldC'] = 'cID';
			}


			if (!isset( $_GET['OrderDivC'] )) {
				$_GET['OrderDivC'] = 'ASC';
			}


			if ($_GET['OrderFieldC'] == 'Amount') {
				$_GET['OrderFieldC'] = ' CurrencyISO3 ' . $_GET['OrderDivC'] . ', ' . $_GET['OrderFieldC'];
			}

			$Commissions = affp_getCommissions( $customerid, '', $_GET['fromdate'] . ' 00:00:00', $_GET['tilldate'] . ' 23:59:59', TransformStringToDataBase( $_GET['OrderFieldC'] . ' ' . $_GET['OrderDivC'] ) );
			$smarty->assign( 'Payments', html_spchars( $Payments ) );
			$smarty->assign( 'PaymentsNumber', count( $Payments ) );
			$smarty->assign( 'Commissions', html_spchars( $Commissions ) );
			$smarty->assign( 'CommissionsNumber', count( $Commissions ) );
		}


		if (isset( $_GET['new_pay'] )) {
			$smarty->assign( 'newPayStatus', '1' );
		}


		if (isset( $_GET['new_commission'] )) {
			$smarty->assign( 'newCommissionStatus', '1' );
		}


		if (isset( $_GET['delete_pay'] )) {
			$smarty->assign( 'delete_payment', 1 );
		}


		if (isset( $_GET['delete_commission'] )) {
			$smarty->assign( 'delete_commission', 1 );
		}


		if ($_GET['fromdate'] != '') {
			$seldate = explode( '/', jdate( 'Y/m/d', strtotime( $_GET['fromdate'] ) ) );
		} 
else {
			$seldate = explode( '/', jdate( 'Y/m/d' ) );
		}


		if ($_GET['tilldate'] != '') {
			$sel2date = explode( '/', jdate( 'Y/m/d', strtotime( $_GET['tilldate'] ) ) );
		} 
else {
			$sel2date = explode( '/', jdate( 'Y/m/d' ) );
		}

		$data = array( '', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند' );
		$smarty->assign( 'months', $data );
		$j = 3170;

		while ($j < 1411) {
			$ydata[] = $j;
			++$j;
		}

		$smarty->assign( 'years', $ydata );
		$smarty->assign( 'fromdate', $seldate );
		$smarty->assign( 'tilldate', $sel2date );
		$smarty->assign( 'CurrDate', $CurrDate );
		$smarty->assign( 'show_tables', $show_tables );
		$smarty->assign( 'Error_DateFormat', $error_date_format );
		$smarty->assign( 'REQUEST_URI', $XREQUEST_URI );
		$smarty->assign( 'CONF_AFFILIATE_PROGRAM_ENABLED', CONF_AFFILIATE_PROGRAM_ENABLED );
		$smarty->assign( 'htmlEmailNewCommission', settingCallHtmlFunction( 'CONF_AFFILIATE_EMAIL_NEW_COMMISSION' ) );
		$smarty->assign( 'htmlEmailNewPayment', settingCallHtmlFunction( 'CONF_AFFILIATE_EMAIL_NEW_PAYMENT' ) );
		$smarty->assign( 'htmlEnabledSettings', settingCallHtmlFunction( 'CONF_AFFILIATE_PROGRAM_ENABLED' ) );
		$smarty->assign( 'htmlAmountPercent', settingCallHtmlFunction( 'CONF_AFFILIATE_AMOUNT_PERCENT' ) );
		$smarty->assign( 'admin_sub_tab', 'custord_affiliate.tpl.html' );

		if (!isset( $_POST['NEW_PAYMENT'] )) {
			$smarty->assign( 'NEW_PAYMENT', array( 'xDate' => $CurrDate ) );
		}


		if (!isset( $_POST['NEW_COMMISSION'] )) {
			$smarty->assign( 'NEW_COMMISSION', array( 'xDate' => $CurrDate ) );
		}


		if (isset( $_GET['edCustomerID'] )) {
			$smarty->assign( 'edCustomerLogin', regGetLoginById( intval( $_GET['edCustomerID'] ) ) );
		}

		break;
	}

?>