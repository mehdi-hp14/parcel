<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'custlist' )) {
		function _getUrlToSort() {
			$res = 'admincp.php?tab=users&sub=custlist';

			if (isset( $_GET['login'] )) {
				$res .= '&login=' . $_GET['login'];
			}


			if (isset( $_GET['first_name'] )) {
				$res .= '&first_name=' . $_GET['first_name'];
			}


			if (isset( $_GET['last_name'] )) {
				$res .= '&last_name=' . $_GET['last_name'];
			}


			if (isset( $_GET['email'] )) {
				$res .= '&email=' . $_GET['email'];
			}


			if (isset( $_GET['groupID'] )) {
				$res .= '&groupID=' . $_GET['groupID'];
			}


			if (isset( $_GET['search'] )) {
				$res .= '&search=' . $_GET['search'];
			}


			if (isset( $_GET['offset'] )) {
				$res .= $_GET['offset'];
			}


			if (isset( $_GET['show_all'] )) {
				$res .= '&show_all=' . $_GET['show_all'];
			}

			return $res;
		}

		function _getUrlToNavigate() {
			$res = 'admincp.php?tab=users&sub=custlist';

			if (isset( $_GET['login'] )) {
				$res .= '&login=' . $_GET['login'];
			}


			if (isset( $_GET['first_name'] )) {
				$res .= '&first_name=' . $_GET['first_name'];
			}


			if (isset( $_GET['last_name'] )) {
				$res .= '&last_name=' . $_GET['last_name'];
			}


			if (isset( $_GET['email'] )) {
				$res .= '&email=' . $_GET['email'];
			}


			if (isset( $_GET['groupID'] )) {
				$res .= '&groupID=' . $_GET['groupID'];
			}


			if (isset( $_GET['search'] )) {
				$res .= '&search=' . $_GET['search'];
			}


			if (isset( $_GET['sort'] )) {
				$res .= '&sort=' . $_GET['sort'];
			}


			if (isset( $_GET['direction'] )) {
				$res .= '&direction=' . $_GET['direction'];
			}


			if (isset( $_GET['fActState'] )) {
				$res .= '&fActState=' . $_GET['fActState'];
			}

			return $res;
		}

		function _getUrlToReturn() {
			$res = 'admincp.php?tab=users&sub=custlist';

			if (isset( $_GET['login'] )) {
				$res .= '&login=' . $_GET['login'];
			}


			if (isset( $_GET['first_name'] )) {
				$res .= '&first_name=' . $_GET['first_name'];
			}


			if (isset( $_GET['last_name'] )) {
				$res .= '&last_name=' . $_GET['last_name'];
			}


			if (isset( $_GET['email'] )) {
				$res .= '&email=' . $_GET['email'];
			}


			if (isset( $_GET['groupID'] )) {
				$res .= '&groupID=' . $_GET['groupID'];
			}


			if (isset( $_GET['fActState'] )) {
				$res .= '&fActState=' . $_GET['fActState'];
			}


			if (isset( $_GET['search'] )) {
				$res .= '&search=' . $_GET['search'];
			}


			if (isset( $_GET['sort'] )) {
				$res .= '&sort=' . $_GET['sort'];
			}


			if (isset( $_GET['direction'] )) {
				$res .= '&direction=' . $_GET['direction'];
			}


			if (isset( $_GET['offset'] )) {
				$res .= $_GET['offset'];
			}


			if (isset( $_GET['show_all'] )) {
				$res .= '&show_all=' . $_GET['show_all'];
			}

			return $res;
		}

		function _copyFromGetVarsToPage($smarty) {
			if (isset( $_GET['login'] )) {
				$smarty->assign( 'login', $_GET['login'] );
			}


			if (isset( $_GET['first_name'] )) {
				$smarty->assign( 'first_name', $_GET['first_name'] );
			}


			if (isset( $_GET['last_name'] )) {
				$smarty->assign( 'last_name', $_GET['last_name'] );
			}


			if (isset( $_GET['email'] )) {
				$smarty->assign( 'email', $_GET['email'] );
			}


			if (isset( $_GET['groupID'] )) {
				$smarty->assign( 'groupID', $_GET['groupID'] );
			}


			if (isset( $_GET['fActState'] )) {
				$smarty->assign( 'ActState', $_GET['fActState'] );
			}

		}

		function _getUrlToNavigate_ORDER_HISTORY() {
			$res = 'admincp.php?tab=users&sub=custlist&customer_details=order_history';

			if (isset( $_GET['encodedReturnUrl'] )) {
				$res .= '&encodedReturnUrl=' . $_GET['encodedReturnUrl'];
			}


			if (isset( $_GET['customerID'] )) {
				$res .= '&customerID=' . $_GET['customerID'];
			}


			if (isset( $_GET['sort'] )) {
				$res .= '&sort=' . $_GET['sort'];
			}


			if (isset( $_GET['direction'] )) {
				$res .= '&direction=' . $_GET['direction'];
			}

			return $res;
		}

		function _getUrlToSort_ORDER_HISTORY() {
			$res = 'admincp.php?tab=users&sub=custlist&customer_details=order_history';

			if (isset( $_GET['encodedReturnUrl'] )) {
				$res .= '&encodedReturnUrl=' . $_GET['encodedReturnUrl'];
			}


			if (isset( $_GET['customerID'] )) {
				$res .= '&customerID=' . $_GET['customerID'];
			}


			if (isset( $_GET['offset'] )) {
				$res .= '&offset=' . $_GET['offset'];
			}


			if (isset( $_GET['show_all'] )) {
				$res .= '&show_all=' . $_GET['show_all'];
			}

			return $res;
		}

		function _getUrlToSubmit_ORDER_HISTORY() {
			$res = 'admincp.php?tab=users&sub=custlist&customer_details=order_history';

			if (isset( $_GET['encodedReturnUrl'] )) {
				$res .= '&encodedReturnUrl=' . $_GET['encodedReturnUrl'];
			}


			if (isset( $_GET['customerID'] )) {
				$res .= '&customerID=' . $_GET['customerID'];
			}


			if (isset( $_GET['offset'] )) {
				$res .= '&offset=' . $_GET['offset'];
			}


			if (isset( $_GET['show_all'] )) {
				$res .= '&show_all=' . $_GET['show_all'];
			}


			if (isset( $_GET['sort'] )) {
				$res .= '&sort=' . $_GET['sort'];
			}


			if (isset( $_GET['direction'] )) {
				$res .= '&direction=' . $_GET['direction'];
			}

			return $res;
		}

		function _getUrlToNavigate_VISIT_LOG() {
			$res = 'admincp.php?tab=users&sub=custlist&customer_details=visit_log';

			if (isset( $_GET['encodedReturnUrl'] )) {
				$res .= '&encodedReturnUrl=' . $_GET['encodedReturnUrl'];
			}


			if (isset( $_GET['customerID'] )) {
				$res .= '&customerID=' . $_GET['customerID'];
			}

			return $res;
		}


		if (isset( $_GET['activateID'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( set_query( '&activateID=&safemode' ) );
			}

			regActivateCustomer( $_GET['activateID'] );
			Redirect( set_query( 'activateID=' ) );
		}


		if (isset( $_GET['deleteCustomerID'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( set_query( '&safemode&deleteCustomerID=' ) );
			}

			regDeleteCustomer( $_GET['deleteCustomerID'] );

			if (isset( $_GET['encodedReturnUrl'] )) {
				Redirect( base64_decode( $_GET['encodedReturnUrl'] ) );
			} 
else {
				Redirect( 'admincp.php?tab=users&sub=custlist' );
			}
		}


		if (!isset( $_GET['customer_details'] )) {
			if (( isset( $_GET['search'] ) || isset( $_GET['export_to_excel'] ) )) {
				$_GET['search'] = 1;
				_copyFromGetVarsToPage( $smarty );
				$encodedReturnUrl = base64_encode( _getUrlToReturn(  ) );
				$callBackParam = array(  );
				$customers = array(  );

				if (trim( $_GET['login'] ) != '') {
					$callBackParam['Login'] = trim( $_GET['login'] );
				}


				if (trim( $_GET['first_name'] ) != '') {
					$callBackParam['first_name'] = trim( $_GET['first_name'] );
				}


				if (trim( $_GET['last_name'] ) != '') {
					$callBackParam['last_name'] = trim( $_GET['last_name'] );
				}


				if (trim( $_GET['email'] ) != '') {
					$callBackParam['email'] = trim( $_GET['email'] );
				}


				if (trim( $_GET['groupID'] ) != '') {
					$callBackParam['groupID'] = $_GET['groupID'];
				}


				if (( isset( $_GET['fActState'] ) && trim( $_GET['fActState'] ) != '' )) {
					$callBackParam['ActState'] = $_GET['fActState'];
				}


				if (isset( $_GET['sort'] )) {
					$callBackParam['sort'] = trim( $_GET['sort'] );

					if (isset( $_GET['direction'] )) {
						$callBackParam['direction'] = trim( $_GET['direction'] );
					}
				}

				$count = 1307;

				if (isset( $_GET['export_to_excel'] )) {
					$number2showNexport = (int)$_GET['count_to_export'];
				} 
else {
					$number2showNexport = 1327;
				}

				$navigatorHtml = GetNavigatorHtml( _getUrlToNavigate(  ), $number2showNexport, 'regGetCustomers', $callBackParam, $customers, $offset, $count );

				if (isset( $_GET['export_to_excel'] )) {
					serExportCustomersToExcel( $customers );
					$smarty->assign( 'customers_has_been_exported_succefully', 1 );
					$smarty->assign( 'urlToDownloadResult', 'index.php?page=file&getFileParam=' . cryptFileParamCrypt( 'GetCustomerExcelSqlScript', null ) );
					$smarty->assign( 'file_size', filesize( './temp_c/customers.csv' ) );
				}

				$smarty->assign( 'encodedReturnUrl', $encodedReturnUrl );
				$smarty->assign( 'search_result_string', str_replace( '{N}', $count, ADMIN_N_RECORD_IS_SEARCHED ) );
				$smarty->assign( 'count_to_export', count( $customers ) );
				$smarty->assign( 'customers', $customers );
				$smarty->assign( 'navigator', $navigatorHtml );
			}

			$smarty->assign( 'urlToSort', _getUrlToSort(  ) );
			$customer_groups = GetAllCustGroups(  );
			$smarty->assign( 'customer_groups', $customer_groups );
		} 
else {
			$c_login = regGetLoginById( $_GET['customerID'] );

			if (!$c_login) {
				$smarty->assign( 'customerID', null );
				$smarty->assign( 'customer_details', $_GET['customer_details'] );
			} 
else {
				if (isset( $_GET['encodedReturnUrl'] )) {
					$smarty->assign( 'encodedReturnUrl', $_GET['encodedReturnUrl'] );
					$returnUrl = base64_decode( $_GET['encodedReturnUrl'] );
					$smarty->assign( 'returnUrl', $returnUrl );
				}


				if ($_GET['customer_details'] == 'contact_info') {
					if (isset( $_POST['subscribed4news_submit'] )) {
						if (CONF_BACKEND_SAFEMODE) {
							Redirect( 'admincp.php?tab=users&sub=custlist&customer_details=contact_info&customerID=' . $_GET['customerID'] . '&encodedReturnUrl=' . $_GET['encodedReturnUrl'] . '&safemode' );
						}

						regSetSubscribed4news( $_GET['customerID'], (isset( $_POST['subscribed4news'] ) ? 1 : 0) );
						$smarty->assign( 'message', MOD_NEWS_TXT_EDIT_OK );
					}


					if (isset( $_POST['custgroupID'] )) {
						if (CONF_BACKEND_SAFEMODE) {
							Redirect( 'admincp.php?tab=users&sub=custlist&customer_details=contact_info&customerID=' . $_GET['customerID'] . '&encodedReturnUrl=' . $_GET['encodedReturnUrl'] . '&safemode' );
						}

						regSetCustgroupID( $_GET['customerID'], $_POST['custgroupID'] );
						$smarty->assign( 'message', MOD_NEWS_TXT_EDIT_OK );
					}

					$log1 = regGetLoginById( $_GET['customerID'] );
					regGetCustomerInfo2( $log1 );
					$customerInfo = ;
					$reg_fields_values = GetRegFieldsValues( $log1 );
					$customer_groups = GetAllCustGroups(  );
					$smarty->assign( 'customer_groups', $customer_groups );
					$smarty->assign( 'reg_fields_values', $reg_fields_values );
					$smarty->assign( 'customerInfo', $customerInfo );
				}


				if ($_GET['customer_details'] == 'address_book') {
					$log1 = regGetLoginById( $_GET['customerID'] );
					$addresses = regGetAllAddressesByLogin( $log1 );
					$i = 1307;

					while ($i < count( $addresses )) {
						$addresses[$i]['addressStr'] = regGetAddressStr( $addresses[$i]['addressID'] );
						++$i;
					}

					$defaultAddressID = regGetDefaultAddressIDByLogin( $log1 );
					$smarty->assign( 'addresses', $addresses );
					$smarty->assign( 'defaultAddressID', $defaultAddressID );
				}


				if ($_GET['customer_details'] == 'order_history') {
					$data = ScanPostVariableWithId( array( 'set_order_status' ) );
					foreach ($data as $orderID => $value) {
						ostSetOrderStatusToOrder( $orderID, $_POST['order_status_in_table_' . $orderID] );
					}

					$orders = array(  );
					$callBackParam = array(  );
					$callBackParam['customerID'] = $_GET['customerID'];

					if (isset( $_GET['sort'] )) {
						$callBackParam['sort'] = $_GET['sort'];
					}


					if (isset( $_GET['direction'] )) {
						$callBackParam['direction'] = $_GET['direction'];
					}

					$count = 1307;
					$navigatorHtml = GetNavigatorHtml( _getUrlToNavigate_ORDER_HISTORY(  ), 20, 'ordGetOrders', $callBackParam, $orders, $offset, $count );
					$smarty->assign( 'urlToSubmit', _getUrlToSubmit_ORDER_HISTORY(  ) );
					$smarty->assign( 'urlToSort', _getUrlToSort_ORDER_HISTORY(  ) );
					$smarty->assign( 'navigator', $navigatorHtml );
					$smarty->assign( 'order_statuses', ostGetOrderStatues(  ) );
					$smarty->assign( 'orders', $orders );
					$smarty->assign( 'urlToReturn', base64_encode( set_query( '___tttt=' ) ) );
				}


				if ($_GET['customer_details'] == 'visit_log') {
					$callBackParam = array(  );
					$visits = array(  );
					$callBackParam['log'] = regGetLoginById( $_GET['customerID'] );
					$count = 1307;
					$navigatorHtml = GetNavigatorHtml( _getUrlToNavigate_VISIT_LOG(  ), 20, 'stGetVisitsByLogin', $callBackParam, $visits, $offset, $count );
					$smarty->assign( 'navigator', $navigatorHtml );
					$smarty->assign( 'visits', $visits );
				}


				if ($_GET['customer_details'] == 'affiliate') {
					$customerID = $_GET['customerID'];
					require( './includes/admin/sub/users_custlist_affiliate.php' );
				}

				$smarty->assign( 'customerID', $_GET['customerID'] );
				$smarty->assign( 'customer_details', $_GET['customer_details'] );
			}
		}

		$smarty->assign( 'admin_sub_tab', 'users_custlist.tpl.html' );
	}

?>