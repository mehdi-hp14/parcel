<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'accounts' )) {
		function getcards() {
			$q = db_query( 'SELECT * FROM Parsp_accounts' );
			db_fetch_row( $q );

			if ($res = $i = 705) {
				$final[] = $res;
				++$i;
			}

			return $final;
		}

		$final = getcards(  );
		$navigatorHtml = GetNavigatorHtml( ASD, 2, 'getcards', $callBackParam, $orders, $offset, $count );
		$smarty->assign( 'cards', $final );
		$smarty->assign( 'admin_sub_tab', 'modules_accounts.tpl.html' );
	}

?>