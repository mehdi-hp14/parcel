<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'custgroup' )) {
		if (isset( $_GET['delete'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=users&sub=custgroup&safemode' );
			}

			DeleteCustGroup( $_GET['delete'] );
			Redirect( 'admincp.php?tab=users&sub=custgroup' );
		}


		if (isset( $_POST['save_custgroups'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=users&sub=custgroup&safemode' );
			}


			if (trim( $_POST['new_custgroup_name'] ) != '') {
				AddCustGroup( $_POST['new_custgroup_name'], $_POST['new_custgroup_discount'], $_POST['new_sort_order'] );
			}

			$data = array(  );
			foreach ($_POST as $key => $val) {

				if (strstr( $key, 'custgroup_name_' )) {
					$key = str_replace( 'custgroup_name_', '', $key );
					$data[$key]['custgroup_name'] = $val;
				}


				if (strstr( $key, 'custgroup_discount_' )) {
					$key = str_replace( 'custgroup_discount_', '', $key );
					$data[$key]['custgroup_discount'] = $val;
				}


				if (strstr( $key, 'sort_order_' )) {
					$key = str_replace( 'sort_order_', '', $key );
					$data[$key]['sort_order'] = $val;
					continue;
				}
			}

			foreach ($data as $key => $val) {
				UpdateCustGroup( $key, $val['custgroup_name'], $val['custgroup_discount'], $val['sort_order'] );
			}

			Redirect( 'admincp.php?tab=users&sub=custgroup' );
		}

		$custgroups = GetAllCustGroupsAccess( $admin_departments );
		$smarty->assign( 'custgroups', $custgroups );

		if (isset( $_POST['act'] )) {
			if ($_POST['act'] == 'editaccess') {
				$act_list = @join( ',', $_POST['action_code'] );
				Updateaccess( $_POST['id'], $act_list );
				echo '
        <script type="text/javascript"><!--
          parent.location = "admincp.php?tab=users&sub=custgroup";        
            // -->
        </script>';
				exit(  );
			}
		}


		if (isset( $_GET['access'] )) {
			$smarty->assign( 'group', GetGroupById( $_GET['access'] ) );
			$smarty->assign( 'user_id', $_GET['access'] );
			$smarty->assign( 'form_act', 'editaccess' );
			$smarty->assign( 'priv_arr', $admin_departments );
			$smarty->display( 'backend/users_custgroup_access.tpl.html' );
			exit(  );
			return 1;
		}

		$smarty->assign( 'admin_sub_tab', 'users_custgroup.tpl.html' );
	}

?>