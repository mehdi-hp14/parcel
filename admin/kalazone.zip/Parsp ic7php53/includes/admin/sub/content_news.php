<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'news' )) {
		$smarty->assign( 'NewsEdit', 0 );
		require_once( './includes/modules/news/class.newsmodule.php' );
		$NewsObj = new News(  );
		$NewsObj->generatePage( 'admin news list' );
	}

?>