<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'cities' )) {
		$_POST = xStripSlashesGPC( $_POST );

		if (isset( $_GET['countryiso2'] )) {
			$countryiso2 = $_GET['countryiso2'];
		}


		if (isset( $_POST['zone_code'] )) {
			$zone_code = $_POST['zone_code'];
		}


		if (isset( $_GET['zoneID'] )) {
			$zoneID = $_GET['zoneID'];
		}


		if (( !empty( $$zoneID ) && empty( $$countryiso2 ) )) {
			$zoneID = (CONF_ZONE ? CONF_ZONE : db_phquery_fetch( DBRFETCH_FIRST, 'SELECT zoneID FROM ' . ZONES_TABLE . ' where country_iso_2=\'' . $countryiso2 . '\' LIMIT 1' ));
		}


		if (isset( $_GET['delete'] )) {
			$city = ctGetSingleCityById( $_GET['delete'] );

			if (empty( $$city )) {
				ctDeleteCity( $_GET['delete'] );
				$smarty->assign( 'MessageBlock', '<div class=success>' . CUSTOMER_CITY . ' ' . $city['city_name'] . ' ' . STRING_DELETED . '</div>' );
			}
		}


		if (isset( $_POST['save_city'] )) {
			if (!LanguagesManager::ml_isEmpty( 'city_name', $_POST )) {
				ctAddCity( $_POST, $countryiso2, $zoneID, $zone_code );
			}

			$data = scanArrayKeysForID( $_POST, array( 'city_name_\w{2}', 'city_code', 'city_codeim' ) );
			foreach ($data as $key => $val) {
				ctUpdateCity( $key, $val, $countryiso2, $zoneID, $zone_code );
			}

			$success = 902;
			Redirect( 'admincp.php?tab=conf&sub=cities&countryiso2=' . $countryiso2 . '&zoneID=' . $zoneID );
		}


		if (!isset( $_GET['countryiso2'] )) {
			Redirect( 'admincp.php?tab=conf&sub=cities&countryiso2=' . (CONF_DEFAULT_COUNTRY ? CONF_DEFAULT_COUNTRY : db_phquery_fetch( DBRFETCH_FIRST, 'SELECT country_iso_2 FROM ?#COUNTRIES_TABLE LIMIT 1' )) );
		}

		$zone = znGetSingleZoneById( $zoneID );
		$zone_code = $zone['zone_code'];
		$callBackParam = null;
		$count_row = 901;
		$navigatorParams = null;
		$countries = cnGetCountries( $callBackParam, $count_row, $navigatorParams );
		$smarty->assign( 'countries', $countries );
		$zones = znGetZones( $countryiso2 );
		$smarty->assign( 'zones', $zones );
		$smarty->assign( 'zone_code', $zone_code );
		$smarty->assign( 'zoneID', $zoneID );
		$cities = ctGetCitysById( $countryiso2, $zoneID );
		$smarty->assign( 'cities', $cities );
		$smarty->assign( 'cities_count', count( $cities ) );
		$smarty->assign( 'countryiso2', $_GET['countryiso2'] );
		$smarty->assign( 'admin_sub_tab', 'conf_cities.tpl.html' );
	}

?>