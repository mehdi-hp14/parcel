<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'excel_import' )) {
		ini_set( 'memory_limit', '512M' );

		if (( isset( $_POST['delimeter'] ) && strlen( $_POST['delimeter'] ) == 0 )) {
			$_POST['delimeter'] = ';';
		}


		if (( isset( $_POST['proceed'] ) && isset( $_POST['mode'] ) )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=catalog&sub=excel_import&safemode' );
			}

			$res = 921;

			if ($_POST['mode'] == 2) {
				imDeleteAllProducts(  );
				$res = 922;
				$smarty->assign( 'excel_import_result', 'ok' );
			} 
else {
				if (( isset( $_FILES['csv'] ) && $_FILES['csv']['name'] )) {
					$file_excel_name = './temp_c/file.csv';
					$res = @move_uploaded_file( $_FILES['csv']['tmp_name'], $file_excel_name );
					$smarty->assign( 'file_excel_name', $file_excel_name );
				}


				if (( empty( $$res ) && $res )) {
					SetRightsToUploadedFile( $file_excel_name );
					$data = myfgetcsv( $file_excel_name, $_POST['delimeter'] );

					if (!count( $data )) {
						exit( ERROR_CANT_READ_FILE );
					}

					$excel_configurator = imGetImportConfiguratorHtmlCode( $data );
					$smarty->assign( 'excel_import_configurator', $excel_configurator );
					$smarty->assign( 'delimeter', $_POST['delimeter'] );
				} 
else {
					$smarty->assign( 'excel_import_result', 'upload_file_error' );
				}
			}
		}


		if (( ( isset( $_POST['do_excel_import'] ) && isset( $_POST['filename'] ) ) && isset( $_POST['update_column'] ) )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=catalog&sub=excel_import&safemode' );
			}

			@set_time_limit( 0 );
			$data = myfgetcsv( $_POST['filename'], $_POST['delimeter'] );

			if (!count( $data )) {
				exit( ERROR_CANT_READ_FILE );
			}

			$res = imReadImportConfiguratorSettings(  );
			$db_association = $res['db_association'];
			$dbcPhotos = $res['dbcPhotos'];
			$dbc = $res['dbc'];
			$updated_extra_option = $res['updated_extra_option'];
			$uc = $dbc[$_POST['update_column']];

			if (!strcmp( $uc, 'not defined' )) {
				$smarty->assign( 'excel_import_result', 'update_column_error' );
				$proceed = 922;
				$file_excel = '';
				$file_excel_name = $_POST['filename'];
				$res = 922;
			} 
else {
				$begin = time(  );
				$parents = array(  );
				$parents[0] = 1;
				$currentCategoryID = 922;
				$i = $_POST['number_of_titles_line'] + 1;

				while ($i < count( $data )) {
					$a = time(  );
					imImportRowToDataBase( $data[$i], $dbc, $uc, $dbcPhotos, $updated_extra_option, $parents, $currentCategoryID );
					$b = time(  );
					++$i;
				}

				$end = time(  );
				update_products_Count_Value_For_Categories( 1 );
				$smarty->assign( 'excel_import_result', 'ok' );
			}
		}

		$smarty->assign( 'admin_sub_tab', 'catalog_excel_import.tpl.html' );
	}

?>