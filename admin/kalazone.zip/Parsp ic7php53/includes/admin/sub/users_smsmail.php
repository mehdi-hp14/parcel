<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (strcmp( $sub, 'smsmail' )) {
		return 0;
	}

	$_POST = xStripSlashesGPC( $_POST );
	$xREQUEST_URI = set_query( '&install=&setting_up=&uninstall=&enableSMSNotify=&msg=&disableSMSNotify=' );
	$moduleFiles = GetFilesInDirectory( './includes/modules/smsmail/gateways', 'php' );
	foreach ($moduleFiles as $fileName) {
		include( $fileName );
	}

	$ModuleObjects = modGetModuleObjects( $moduleFiles );
	$MSGInfo = array( 'status' => 0, 'message' => '' );

	if (isset( $_GET['setting_up'] )) {
		$xREQUEST_URI = set_query( '&setting_up=' . $_GET['setting_up'], $xREQUEST_URI );

		if (( isset( $_POST ) && 0 < count( $_POST ) )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=modules&sub=payment&setting_up=' . $_GET['setting_up'] . '&safemode' );
			}
		}

		$ModuleObject = null;
		$ModuleConfig = modGetModuleConfig( $_GET['setting_up'] );

		if ($ModuleConfig['ModuleClassName']) {
			eval( '$ModuleObject = new ' . $ModuleConfig['ModuleClassName'] . '(' . $_GET['setting_up'] . ');' );
		}

		$constants = $ModuleObject->settings_list(  );
		$settings = array(  );
		$controls = array(  );
		foreach ($constants as $constant) {
			$settings[] = settingGetSetting( $constant );
			$controls[] = settingCallHtmlFunction( $constant );
			$smarty->assign( 'settings', $settings );
			$smarty->assign( 'controls', $controls );
		}

		$smarty->assign( 'ModuleObject', $ModuleObject );
		$smarty->assign( 'constant_managment', 1 );
	} 
else {
		$ModuleConfigs = array(  );
		$NotifyObject = new SMSNotify(  );
		$_TC = count( $ModuleObjects ) - 1;

		while (0 <= $_TC) {
			$_tMConfigs = modGetModuleConfigs( get_class( $ModuleObjects[$_TC] ) );

			if (!count( $_tMConfigs )) {
				continue;
			}

			$ModuleConfigs = array_merge( $ModuleConfigs, $_tMConfigs );
			--$_TC;
		}

		$smarty->assign( 'ModuleObjects', $ModuleObjects );
		$smarty->assign( 'ModuleConfigs', $ModuleConfigs );
		$smarty->assign( 'SMSNotifyEnabled', ( $NotifyObject->is_installed(  ) && CONF_SMSNOTIFY_ENABLED ) );

		if ($NotifyObject->is_installed(  )) {
			$smarty->assign( 'ConfigIDHTML', settingCallHtmlFunction( 'CONF_SMSNOTIFY_SMSSENDER_CONFIG_ID' ) );
			$smarty->assign( 'PhoneNumbersHTML', settingCallHtmlFunction( 'CONF_GROUPSMS_PHONES' ) );
		}
	}


	if ($_POST['sendsms']) {
		$SMSsender = modGetModuleObj( $_POST['setting_CONF_SMSNOTIFY_SMSSENDER_CONFIG_ID'], SMSMAIL_MODULE );

		if ($_POST['SENDTO'] == 'CUSTOM') {
			$Phones = array_slice( $_POST['CONF_GROUPSMS_PHONES'], 0, -1 );
		} 
else {
			$sql = 'SELECT mobile FROM ' . CUSTOMERS_TABLE;
			$Phones = @db_fetch_row( @db_query( $sql ) )[0];
		}

		$_Message = $_POST['smsmessage'];
		$SMSMessage = '<p class="success" id="messge"> <font color="green"><b>' . STRING_SMSMAIL_SENDSUCCESS . '</b></font> </p>';

		if (( !$SMSsender || !count( $Phones ) )) {
			$SMSMessage = '<p class="failed" id="messge"> <font color="red"><b>' . STRING_SMSMAIL_SENDFAILED . '</b></font> </p>';
		}

		$SMSsender->sendSMS( $_Message, $Phones );
	}

	$smarty->assign( 'SMSMessage', $SMSMessage );
	$smarty->assign( 'xREQUEST_URI', $xREQUEST_URI );
	$smarty->assign( 'admin_sub_tab', 'users_smsmail.tpl.html' );
	$smarty->assign( 'MSGInfo', $MSGInfo );
?>