<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'addtolist' )) {
		if (isset( $_GET['save_successful'] )) {
			$smarty->assign( 'save_successful', ADMIN_UPDATE_SUCCESSFUL );
		}


		if (isset( $_POST['save_offers'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=catalog&sub=addtolist&safemode' );
			}


			if (!( db_query( 'delete from ' . TBL_PRODUCT_LIST_ITEM . ' where productID=' . $_GET['new_offer'] ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			$offers = array(  );
			foreach ($_POST as $key => $val) {

				if (strstr( $key, 'list_' ) != false) {
					$a = str_replace( 'list_', '', $key );
					$offers[$a]['productID'] = $val;
					continue;
				}
			}

			foreach ($offers as $key => $value) {
				addProducttolist( $_GET['new_offer'], $key );
			}

			echo '<br><br><p style=\'font-family:tahoma;font-size:8.5px;\'><center>' . SAVE_CHANGES_BUTTON . '</centrt></p>';
			echo '<script type="text/javascript"><!--
          parent.location = "admincp.php?tab=catalog&sub=products_categories&categoryID=' . $_GET['categoryID'] . '&expandCat=' . $_GET['categoryID'] . '";        
            // -->
        </script>';
			exit(  );
		}

		$product_lists = stc_getLists(  );
		$mproduct_lists = productlist_getlistsid( $_GET['new_offer'] );
		$myprd = ',' . implode( ',', $mproduct_lists ) . ',';
		$product = GetProduct( $_GET['new_offer'] );
		echo '<style type="text/css">
        .container { border:2px solid #ccc; width:220px; height: 75px; overflow-y: scroll; }
        #min_header {
font-weight: bold;
font-size: 12px;
color: #111;
text-shadow: 1px 1px 0 white;
padding: 8px 10px 5px 10px;
background: #F6F8F8;
background: -moz-linear-gradient(#F6F8F8, #E9EEEE);
background: -webkit-linear-gradient(#F6F8F8, #E9EEEE);
background: linear-gradient(#F6F8F8, #E9EEEE);
border-bottom: 1px solid #F0F3F3;
border-top-left-radius: 4px;
border-top-right-radius: 4px;
font-family:tahoma;
font-size:8.5px;
height:10px;
}
.button {
cursor: pointer;
background: #6E8BAC;
border: none;
width: auto;
overflow: visible;
line-height: 1.4em;
color: white;
padding: 2px 2px 3px 2px;
border-radius: 4px;
-webkit-border-radius: 4px;
-moz-border-radius: 4px;
margin-top: 5px;
font-weight: normal;
text-shadow: 0 1px 0 rgba(0, 0, 0, 0.4);
}
        </style>';
		echo '<body style="margin:0px;" dir="rtl" ><div id="min_header" dir="rtl">              
        <font color="purple"><b>            
           ' . $product['name'] . '</b>        
        </font></div>';
		echo ' 
    
    <form method=POST name="addtolist_form" action="admincp.php?tab=catalog&sub=addtolist&categoryID=' . $_GET['categoryID'] . '&new_offer=' . $_GET['new_offer'] . '" ><div align="center" style="padding-top:2px;"> <div class="container" align="right" dir="rtl" style="font-family:tahoma;font-size:10px;">';
		foreach ($product_lists as $key => $value) {
			echo '<input name="list_' . $value['list_id'] . '" type="checkbox"';

			if (0 < strpos( $myprd, $value['list_id'] . ',' )) {
				echo 'checked';
			}

			echo ' /> ' . $value['list_name'] . ' <br />';
		}

		echo '</div>';
		echo '<center><input class="button" type=hidden name="save_offers"><input type="submit" value="' . OK_BUTTON . '"></center></div></form>';
		exit(  );
	}

?>