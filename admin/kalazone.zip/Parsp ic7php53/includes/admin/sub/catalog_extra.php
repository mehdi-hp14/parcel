<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'extra' )) {
		if (isset( $_GET['save_successful'] )) {
			$smarty->assign( 'save_successful', ADMIN_UPDATE_SUCCESSFUL );
		}


		if (isset( $_POST['save_values'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=catalog&sub=extra&optionID=' . $_POST['optionID'] . '&safemode' );
			}

			$updateOptions = scanArrayKeysForID( $_POST, array( 'sort_order', 'option_value_\w{2}' ) );
			optUpdateOptionValues( $updateOptions );

			if (!LanguagesManager::ml_isEmpty( 'option_value', $_POST )) {
				optAddOptionValue( $_POST );
			}

			Redirect( 'admincp.php?tab=catalog&sub=extra&optionID=' . $_POST['optionID'] );
		}


		if (isset( $_POST['save_options'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=catalog&sub=extra&safemode' );
			}

			$updateOptions = scanArrayKeysForID( $_POST, array( 'extra_option_\w{2}', 'extra_sort' ) );
			optUpdateOptions( $updateOptions );

			if (!LanguagesManager::ml_isEmpty( 'name', $_POST )) {
				$__params = array(  );
				$__params['sort_order'] = $_POST['sort_order'];
				optAddOption( $_POST );
			}

			Redirect( 'admincp.php?tab=catalog&sub=extra&save_successful' );
		}


		if (isset( $_GET['kill_value'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=catalog&sub=extra&optionID=' . $_GET['optionID'] . '&safemode' );
			}

			db_query( 'delete from ' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . ' where variantID=\'' . $_GET['kill_value'] . '\' ' );
			Redirect( 'admincp.php?tab=catalog&sub=extra&optionID=' . $_GET['optionID'] );
		}


		if (isset( $_GET['kill_option'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=catalog&sub=extra&safemode' );
			}


			if (!( db_query( 'delete from ' . PRODUCT_OPTIONS_TABLE . ' where optionID=\'' . $_GET['kill_option'] . '\'' ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if (!( db_query( 'delete from ' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . ' where optionID=\'' . $_GET['kill_option'] . '\'' ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if (!( db_query( 'delete from ' . PRODUCTS_OPTIONS_SET_TABLE . ' where optionID=\'' . $_GET['kill_option'] . '\'' ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if (!( db_query( 'delete from ' . PRODUCT_OPTIONS_VALUES_TABLE . ' where optionID=\'' . $_GET['kill_option'] . '\'' ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			Redirect( 'admincp.php?tab=catalog&sub=extra' );
		}


		if (!isset( $_GET['optionID'] )) {
			$options = optGetOptions(  );
			$smarty->assign( 'options', $options );
		} 
else {
			$option = optGetOptionById( $_GET['optionID'] );
			$values = optGetOptionValues( $_GET['optionID'] );
			$smarty->assign( 'optionID', $_GET['optionID'] );
			$smarty->assign( 'values', $values );
			$smarty->assign( 'option_name', $option['name'] );
			$smarty->assign( 'value_count', count( $values ) );
		}

		$smarty->assign( 'admin_sub_tab', 'catalog_extra.tpl.html' );
	}

?>