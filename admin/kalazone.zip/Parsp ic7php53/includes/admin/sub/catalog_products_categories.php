<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'products_categories' )) {
		function _getUrlToSubmit() {
			$res = 'admincp.php?tab=catalog&sub=products_categories';

			if (isset( $_GET['categoryID'] )) {
				$res .= '&categoryID=' . $_GET['categoryID'];
			}


			if (isset( $_GET['offset'] )) {
				$res .= '&offset=' . $_GET['offset'];
			}


			if (isset( $_GET['sort'] )) {
				$res .= '&sort=' . $_GET['sort'];
			}


			if (isset( $_GET['sort_dir'] )) {
				$res .= '&sort_dir=' . $_GET['sort_dir'];
			}


			if (isset( $_GET['search_criteria'] )) {
				$res .= '&search_criteria=' . $_GET['search_criteria'];
			}


			if (isset( $_GET['search_value'] )) {
				$res .= '&search_value=' . $_GET['search_value'];
			}


			if (isset( $_POST['search_criteria'] )) {
				$res .= '&search_criteria=' . $_POST['search_criteria'];
			}


			if (isset( $_POST['search_value'] )) {
				$res .= '&search_value=' . $_POST['search_value'];
			}


			if (isset( $_GET['search'] )) {
				$res .= '&search=' . $_GET['search'];
			}


			if (isset( $_GET['show_all'] )) {
				$res .= '&show_all=' . $_GET['show_all'];
			}

			return $res;
		}

		function _getUrlToDelete() {
			return _getUrlToSubmit(  );
		}

		function _getUrlToCategoryTreeExpand() {
			return _getUrlToSubmit(  );
		}

		function _getUrlToNavigate() {
			return _getUrlToSubmit(  );
		}

		function _getUrlToSort() {
			return _getUrlToSubmit(  );
		}

		$callBackParam = array(  );

		if (isset( $_GET['search'] )) {
			if (isset( $_POST['search_value'] )) {
				$search_value = $_POST['search_value'];
			} 
else {
				if (isset( $_GET['search_value'] )) {
					$search_value = $_GET['search_value'];
				}
			}

			$array = explode( ' ', $search_value );
			$search_value_array = array(  );
			foreach ($array as $val) {

				if ($val != '') {
					$search_value_array[] = $val;
					continue;
				}
			}


			if (isset( $_POST['search_criteria'] )) {
				$search_criteria = $_POST['search_criteria'];
			} 
else {
				if (isset( $_GET['search_criteria'] )) {
					$search_criteria = $_GET['search_criteria'];
				}
			}


			if ($search_criteria == 'name') {
				$callBackParam['name'] = $search_value_array;
			}


			if ($search_criteria == 'product_code') {
				$callBackParam['product_code'] = $search_value_array;
			}

			$smarty->assign( 'search_criteria', $search_criteria );
			$smarty->assign( 'search_value', $search_value );
			$smarty->assign( 'searched_done', 1 );
		}


		if (isset( $_GET['expandCat'] )) {
			catExpandCategory( $_GET['expandCat'], 'expandedCategoryID_Array' );
		}


		if (isset( $_GET['shrinkCat'] )) {
			catShrinkCategory( $_GET['shrinkCat'], 'expandedCategoryID_Array' );
		}


		if (isset( $_GET['delete_show_price'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( _getUrlToSubmit(  ) . '&safemode' );
			}


			if (DeleteAllProductsOfThisCategory( (int)$_GET['categoryID'] )) {
				Redirect( 'admincp.php?tab=catalog&sub=products_categories&categoryID=' . $_GET['categoryID'] );
			} 
else {
				Redirect( 'admincp.php?tab=catalog&sub=products_categories&categoryID=' . $_GET['categoryID'] . '&couldntToDeleteThisProducts=1' );
			}
		} 
else {
			if (isset( $_POST['products_update'] )) {
				if (CONF_BACKEND_SAFEMODE) {
					Redirect( _getUrlToSubmit(  ) . '&safemode' );
				}

				$data = ScanPostVariableWithId( array( 'price', 'enable', 'left', 'sort_order' ) );
				foreach ($data as $key => $val) {

					if (isset( $val['price'] )) {
						$temp = $val['price'];
						$temp = round( $temp * 100 ) / 100;
						db_query( 'UPDATE ' . PRODUCTS_TABLE . ( ' SET Price=\'' . $temp . '\' ' ) . ' WHERE productID=' . $key );
					}


					if (isset( $val['enable'] )) {
						db_query( 'update ' . PRODUCTS_TABLE . ' set enabled=' . $val['enable'] . ' ' . ' WHERE productID=' . $key );
					}


					if (isset( $val['left'] )) {
						db_query( 'UPDATE ' . PRODUCTS_TABLE . ' SET in_stock = \'' . $val['left'] . '\' WHERE productID=' . $key );
					}


					if (isset( $val['sort_order'] )) {
						db_query( 'UPDATE ' . PRODUCTS_TABLE . ' SET sort_order = \'' . $val['sort_order'] . '\' WHERE productID=' . $key );
						continue;
					}
				}


				if (CONF_UPDATE_GCV == '1') {
					update_products_Count_Value_For_Categories( 1 );
				}

				Redirect( _getUrlToSubmit(  ) );
			} 
else {
				if (isset( $_GET['terminate'] )) {
					if (CONF_BACKEND_SAFEMODE) {
						Redirect( _getUrlToSubmit(  ) . '&safemode' );
					}


					if (DeleteProduct( $_GET['terminate'] )) {
						Redirect( _getUrlToSubmit(  ) );
					} 
else {
						Redirect( _getUrlToSubmit(  ) . '&couldntToDelete=1' );
					}
				}
			}
		}


		if (isset( $_POST['update_gc_value'] )) {
			@set_time_limit( 60 * 4 );
			update_products_Count_Value_For_Categories( 1 );
			Redirect( 'admincp.php?tab=catalog&sub=products_categories&categoryID=' . $_POST['categoryID'] );
		}


		if (!( $q = db_query( 'SELECT count(*) FROM ' . PRODUCTS_TABLE . ' WHERE categoryID=1' ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$cnt = db_fetch_row( $q );
		$smarty->assign( 'products_in_root_category', $cnt[0] );

		if (!isset( $_SESSION['expandedCategoryID_Array'] )) {
			$_SESSION['expandedCategoryID_Array'] = array( 1 );
		}

		$c = catGetCategoryCList( $_SESSION['expandedCategoryID_Array'] );
		$smarty->assign( 'categories', $c );
		$row = array(  );

		if (( !isset( $_GET['categoryID'] ) && !isset( $_POST['categoryID'] ) )) {
			$categoryID = 1209;
			$row[0] = ADMIN_CATEGORY_ROOT;
		} 
else {
			$categoryID = (isset( $_GET['categoryID'] ) ? $_GET['categoryID'] : $_POST['categoryID']);

			if (!( $q = db_query( 'SELECT ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS name FROM ' . CATEGORIES_TABLE . ( ' WHERE categoryID<>0 and categoryID=\'' . $categoryID . '\'' ) ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			$row = db_fetch_row( $q );

			if (!$row) {
				$categoryID = 1208;
				$row[0] = ADMIN_CATEGORY_ROOT;
			}
		}

		$smarty->assign( 'categoryID', $categoryID );
		$smarty->assign( 'category_name', $row[0] );
		$count_row = 1208;
		$offset = 1208;
		$products = null;

		if (isset( $_GET['sort'] )) {
			$callBackParam['sort'] = $_GET['sort'];

			if (isset( $_GET['sort_dir'] )) {
				$callBackParam['direction'] = $_GET['sort_dir'];
			}
		}

		$callBackParam['categoryID'] = $categoryID;
		$callBackParam['searchInSubcategories'] = false;
		$count = 1208;
		$navigatorHtml = GetNavigatorHtml( _getUrlToNavigate(  ), 20, 'prdSearchProductByTemplate', $callBackParam, $products, $offset, $count );
		$i = 1208;

		while ($i < count( $products )) {
			_setPictures( $products[$i] );
			$products[$i]['picture_count'] = GetPictureCount( $products[$i]['productID'] );
			$products[$i]['thumbnail_count'] = GetThumbnailCount( $products[$i]['productID'] );
			$products[$i]['enlarged_count'] = GetEnlargedPictureCount( $products[$i]['productID'] );
			$products[$i]['lists'] = productlist_getlists( $products[$i]['productID'] );
			$products[$i]['Price'] = round( 100 * $products[$i]['Price'] ) / 100;
			++$i;
		}

		$smarty->assign( 'navigatorHtml', $navigatorHtml );
		$smarty->assign( 'urlToSort', _getUrlToSort(  ) );
		$smarty->assign( 'urlToSubmit', _getUrlToSubmit(  ) );
		$smarty->assign( 'urlToDelete', _getUrlToDelete(  ) );
		$smarty->assign( 'urlToCategoryTreeExpand', _getUrlToCategoryTreeExpand(  ) );
		$smarty->assign( 'searched_count', str_replace( '{N}', count( $products ), ADMIN_N_RECORD_IS_SEARCHED ) );
		$smarty->assign( 'products', $products );
		$smarty->assign( 'admin_sub_tab', 'catalog_products_categories.tpl.html' );
	}

?>