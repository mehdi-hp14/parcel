<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'googlesitemap' )) {
		$enable_gs = CONF_GOOGLE_SITEMAP_ENABLED;
		$settings_groupID = 766;

		if (( isset( $_POST ) && 0 < count( $_POST ) )) {
			_setSettingOptionValue( 'CONF_GOOGLE_SITEMAP_ENABLED', $_POST['enable_gs'] );
			$enable_gs = $_POST['enable_gs'];
			$smarty->assign( 'MessageBlock', '<p class="success" id="messge"> <font color="green"><b>' . MOD_NEWS_TXT_EDIT_OK . '</b></font> </p>' );
		}

		$sitemapurl = BASE_URL . 'sitemap.php';
		$settings = settingGetSettings( $settings_groupID );
		$smarty->assign( 'sitemapurl', $sitemapurl );
		$smarty->assign( 'settings', $settings );
		$smarty->assign( 'enable_gs', $enable_gs );
		$smarty->assign( 'controls', settingCallHtmlFunctions( $settings_groupID ) );
		$smarty->assign( 'admin_sub_tab', 'conf_googlesitemap.tpl.html' );
	}

?>