<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'DIR_FLAGS', './images/flags/' );

	if (!strcmp( $sub, 'languages' )) {
		if ($_GET['success']) {
			$MessageBlock = ADMIN_UPDATE_SUCCESSFUL;
		}

		$GetVars = array_merge( $_POST, $_GET );

		if ($GetVars['lang_id']) {
			$origLanguageEntry = new Language(  );
			$origLanguageEntry->loadById( $GetVars['lang_id'] );
			$lang = $origLanguageEntry->iso2;
		} 
else {
			$lang = LanguagesManager::getDefaultLanguage(  )->iso2;
		}

		define( 'CONF_DEFAULT_LANG', $lang );
		function save_order() {
			$scan_result = scanArrayKeysForID( $_POST, 'priority' );
			$uLanguage = new Language(  );
			foreach ($scan_result as $lang_id => $scan_info) {
				$uLanguage->loadById( $lang_id );
				$uLanguage->setPriority( $scan_info['priority'] );
				$uLanguage->save(  );
			}

		}


		if (( ( isset( $GetVars['act'] ) && $GetVars['act'] == 'dellang' ) && isset( $GetVars['lang_id'] ) )) {
			$del_lang_id = trim( $GetVars['lang_id'] );
			renderURL( 'act=&lang_id=', '', true );

			if (CONF_DEFAULT_LANG == $del_lang_id) {
				throwMessage( 'ADMIN_LANGUAGES_DEL_NOTALLOW' );
			}

			$DelLang = &ClassManager::getInstance( 'Language' );

			$DelLang->loadById( $del_lang_id );
			$res = $DelLang->delete(  );
			Redirect( 'admincp.php?tab=layout&sub=languages&success=1' );
		}


		if (( ( isset( $GetVars['act'] ) && $GetVars['act'] == 'setdef_language' ) && isset( $GetVars['lang_id'] ) )) {
			$languageEntry = new Language(  );
			$languageEntry->loadById( $GetVars['lang_id'] );
			$languageEntry->enabled( true );
			$languageEntry->setdefault( true );
			$res = $languageEntry->save(  );
			_setSettingOptionValue( 'CONF_DEFAULT_LANG', $GetVars['lang_id'] );
			Redirect( 'admincp.php?tab=layout&sub=languages' );
		}


		if (( ( isset( $GetVars['act'] ) && $GetVars['act'] == 'setting' ) && isset( $GetVars['lang_id'] ) )) {
			$defaultLanguage = &LanguagesManager::getDefaultLanguage(  );

			if (isset( $GetVars['addmodlang'] )) {
				$aLanguage = &ClassManager::getInstance( 'Language' );

				$required_fields = array( 'lang_name', 'lang_iso2' );
				foreach ($required_fields as $field_key) {
					$GetVars[$field_key] = trim( $GetVars[$field_key] );

					if (!strlen( $GetVars[$field_key] )) {
						Message::raiseMessageRedirectSQ( MSG_ERROR, '', 'msg_fill_required_fields', '', array( 'lang_data' => $GetVars, 'error_field' => $field_key ) );
						continue;
					}
				}

				$GetVars['lang_iso2'] = strtolower( $GetVars['lang_iso2'] );

				if (!preg_match( '/^[a-z]{2}$/', $GetVars['lang_iso2'] )) {
					Message::raiseMessageRedirectSQ( MSG_ERROR, '', 'loc_iso2_should_be', '', array( 'lang_data' => $GetVars, 'error_field' => 'lang_iso2' ) );
				}

				$aLanguage->loadById( $GetVars['lang_id'] );
				$aLanguage->setName( $GetVars['lang_name'] );
				$aLanguage->setISO2( $GetVars['lang_iso2'] );
				$aLanguage->enabled( ($defaultLanguage->id == $aLanguage->id ? true : isset( $GetVars['lang_enabled'] )) );
				$aLanguage->direction = (( isset( $GetVars['direction'] ) && $GetVars['direction'] ) ? 1 : 0);
				$res = $aLanguage->save(  );
				$FilesVars = $FilesVars;

				if (( isset( $FilesVars['upload_thumbnail'] ) && $FilesVars['upload_thumbnail']['name'] )) {
					$new_thumbnail = $FilesVars['upload_thumbnail'];

					if ($new_thumbnail['error']) {
						Message::raiseMessageRedirectSQ( MSG_ERROR, '', translate( 'loc_error_file_upload' ) . ' (' . $new_thumbnail['error'] . ')' );
					}


					if (!preg_match( '/\.(\w{3})$/', $new_thumbnail['name'], $subpatterns )) {
						Message::raiseMessageRedirectSQ( MSG_ERROR, '', 'loc_notsupported_filetype' );
					}

					$extension = $subpatterns[1];

					if (!in_array( $extension, array( 'gif', 'jpeg', 'jpg', 'png' ) )) {
						Message::raiseMessageRedirectSQ( MSG_ERROR, '', 'loc_notsupported_filetype' );
					}

					$res = Functions::exec( 'file_move_uploaded', array( $new_thumbnail['tmp_name'], DIR_FLAGS . '/' . $aLanguage->iso2 . '.' . $extension ) );
					$aLanguage->setThumbnail( $aLanguage->id . '.' . $extension );
					$aLanguage->save(  );
				}

				Redirect( 'admincp.php?tab=layout&sub=languages&success=1' );
			}

			$lang_id = (isset( $GetVars['lang_id'] ) ? $GetVars['lang_id'] : 0);
			$aLanguage = &ClassManager::getInstance( 'Language' );

			$aLanguage->loadById( $lang_id );
			$r_language = array( 'id' => $aLanguage->id, 'iso2' => $aLanguage->iso2, 'enabled' => $aLanguage->enabled(  ), 'name' => $aLanguage->getName(  ), 'thumbnail_url' => (( file_exists( DIR_FLAGS . '/' . $aLanguage->getThumbnail(  ) ) && $aLanguage->getThumbnail(  ) ) ? URL_FLAGS . '/' . $aLanguage->getThumbnail(  ) : ''), 'is_default' => $aLanguage->id == $defaultLanguage->id, 'direction' => $aLanguage->direction );
			$smarty->assign( 'lang_id', $lang_id );
			$smarty->assign( 'language', $r_language );
			$smarty->assign( 'admin_sub_tab', 'layout_addmodlanguage.tpl.html' );
			return 1;
		}

		$a_languages = LanguagesManager::getLanguages(  );
		$r_languages = array(  );
		foreach ($a_languages as $Language) {
			$r_languages[] = array( 'id' => $Language->id, 'iso2' => $Language->iso2, 'enabled' => $Language->enabled(  ), 'priority' => $Language->getPriority(  ), 'direction' => $Language->direction, 'name' => $Language->getName(  ), 'thumbnail_url' => $Language->getThumbnailURL(  ) );
		}

		$smarty->assign_by_ref( 'languages', $r_languages );
		$smarty->assign( 'languages_num', count( $r_languages ) );

		if (( isset( $GetVars['act'] ) && $GetVars['act'] == 'locals' )) {
			$local_groups = array( 'general' => array( 'name' => 'GENERAL', 'id' => 'general', 'sub_groups' => array( 'GENERAL' ) ), 'admin' => array( 'name' => 'ADMIN', 'id' => 'admin', 'sub_groups' => array( 'ADMIN' ) ), 'discussion' => array( 'name' => 'DISCUSSION', 'id' => 'discussion', 'sub_groups' => array( 'DISCUSSION' ) ), 'email' => array( 'name' => 'EMAIL', 'id' => 'email', 'sub_groups' => array( 'EMAIL' ) ), 'errors' => array( 'name' => 'ERRORS', 'id' => 'errors', 'sub_groups' => array( 'ERRORS' ) ), 'quesions' => array( 'name' => 'QUESIONS', 'id' => 'quesions', 'sub_groups' => array( 'QUESIONS' ) ), 'shopping_c' => array( 'name' => 'CART', 'id' => 'shopping_c', 'sub_groups' => array( 'CART' ) ), 'table' => array( 'name' => 'TABLE', 'id' => 'table', 'sub_groups' => array( 'TABLE' ) ), 'warning' => array( 'name' => 'WARNING', 'id' => 'warning', 'sub_groups' => array( 'WARNING' ) ) );
			$locals_type = (isset( $GetVars['locals_type'] ) ? $GetVars['locals_type'] : 'GENERAL');

			if ($locals_type == 'GENERAL') {
				if (!array_key_exists( $sub_group, $local_groups[$locals_type]['sub_groups'] )) {
					$sub_group = 'GENERAL';
				} 
else {
					if (!array_key_exists( $sub_group, $local_groups[$locals_type]['sub_groups'] )) {
						$sub_group = 'ADMIN';
					}
				}
			}

			$sub_group = (isset( $GetVars['sub_group'] ) ? $GetVars['sub_group'] : $GetVars['locals_type']);
			$lang_id = (isset( $GetVars['lang_id'] ) ? $GetVars['lang_id'] : '');

			if (!$lang_id) {
				Redirect( 'admincp.php?tab=layout&sub=languages' );
			}

			$LanguageEntry = &ClassManager::getInstance( 'Language' );

			$res = $LanguageEntry->loadById( $lang_id );
			$lang_id = $LanguageEntry->iso2;
			$smarty->assign( 'CURRLANG_LOCALS', $locals );
			$smarty->assign( 'CURR_LANGUAGE', $LanguageEntry );
			$smarty->assign( 'searchstr', '' );
			$DefLanguageEntry = &ClassManager::getInstance( 'Language' );

			$res = $DefLanguageEntry->loadByISO2( CONF_DEFAULT_LANG );

			if (( ( isset( $GetVars['subact'] ) && $GetVars['subact'] == 'delloc' ) && isset( $GetVars['local_id'] ) )) {
				$res = $LanguageEntry->deleteLocal( $GetVars['local_id'] );
			}


			if (isset( $GetVars['save_locals'] )) {
				$error_str = '';
				$error_field = '';

				do {
					if (isset( $GetVars['locals'] )) {
						foreach ($GetVars['locals'] as $local_key => $local_value) {
							$LanguageEntry->updateLocal( $local_key, $local_value );
						}
					}


					if (isset( $GetVars['newlocal_key'] )) {
						$highlight_empty_defstrings = false;
						foreach ($GetVars['newlocal_key'] as $sub_group => $r_newlocal_key) {
							$r_newlocal_key = $GetVars['newlocal_key'][$sub_group];
							$__keys = array(  );
							foreach ($r_newlocal_key as $i => $newlocal_key) {
								$newlocal_key = trim( $GetVars['newlocal_key'][$sub_group][$i] );
								$newlocal_value = trim( $GetVars['newlocal_value'][$sub_group][$i] );
								$newlocal_defvalue = trim( $GetVars['newlocal_defvalue'][$sub_group][$i] );

								if ($DefLanguageEntry->getLocal( $newlocal_key )) {
									$error_str = 'loc_reserved_loc_id';
									$error_field = $i;
									break;
								}


								if (( ( $LanguageEntry->iso2 != $DefLanguageEntry->iso2 && !$newlocal_defvalue ) && !$error_str )) {
									$error_str = 'loc_empty_loc_defvalue';
									$error_field = $i;
									$highlight_empty_defstrings = true;
								}


								if (( ( $LanguageEntry->iso2 == $DefLanguageEntry->iso2 && !$newlocal_value ) && !$error_str )) {
									$error_str = 'loc_empty_loc_defvalue';
									$error_field = $i;
									$highlight_empty_defstrings = true;
								}

								$__keys[$newlocal_key] = 1;
							}
						}


						if ($error_str) {
							break;
						}

						foreach ($GetVars['newlocal_key'] as $sub_group => $r_newlocal_key) {
							$r_newlocal_key = &$GetVars['newlocal_key'][$sub_group];

							foreach ($r_newlocal_key as $i => $newlocal_key) {
								$newlocal_key = trim( $r_newlocal_key[$i] );
								$newlocal_value = trim( $GetVars['newlocal_value'][$sub_group][$i] );
								$newlocal_defvalue = trim( $GetVars['newlocal_defvalue'][$sub_group][$i] );

								if ($LanguageEntry->getLocal( $newlocal_key )) {
									$error_str = 'loc_reserved_loc_id';
									$error_field = $i;
									break;
								}


								if (!$newlocal_key) {
									continue;
								}


								if ($LanguageEntry->iso2 != $DefLanguageEntry->iso2) {
									$res = $DefLanguageEntry->addLocal( $newlocal_key, $newlocal_defvalue, $GetVars['local_group'], $sub_group );
								}

								$res = $LanguageEntry->addLocal( $newlocal_key, $newlocal_value, $GetVars['local_group'], $sub_group );
							}
						}
					}
				}while (!( 0));


				if ($add_local_flag) {
					$DefLanguageEntry->addLocal( $add_local_id, $add_local_defvalue, $GetVars['local_group'], $add_local_subgroup );
					$LanguageEntry->addLocal( $add_local_id, $add_local_value, $GetVars['local_group'], $add_local_subgroup );
				}

				$smarty->assign( 'MSG_SUCCESS', 'msg_information_save' );
			}

			$localstrings = $LanguageEntry->getLocals( $locals_type, false, false );
			$deflocalstrings = $DefLanguageEntry->getLocals( $locals_type, true, true );
			$smarty->assign( 'sub_group', $sub_group );
			$smarty->assign( 'local_groups', $local_groups );
			$smarty->assign( 'locals_type', $locals_type );
			$smarty->assign( 'LocalStrings', $localstrings );
			$smarty->assign( 'DefLocalStrings', $deflocalstrings );
			$smarty->assign( 'Language', $LanguageEntry );
			$smarty->assign( 'DefLanguage', $DefLanguageEntry );
			$smarty->assign( 'is_deflang', $LanguageEntry->id == $DefLanguageEntry->id );
			$smarty->assign( 'highlight_empty_defstrings', STRING_HIGHLIGHT_EMPTY_DEFSTRINGS );
			$smarty->assign( 'reserved_loc_id', '' );
			$smarty->assign( 'admin_sub_tab', 'layout_locals.tpl.html' );
			return 1;
		}

		$newlang = count( $r_languages ) + 1;
		$smarty->assign( 'MessageBlock', $MessageBlock );
		$smarty->assign( 'newlang', $newlang );
		$smarty->assign( 'admin_sub_tab', 'languages_list.tpl.html' );
	}

?>