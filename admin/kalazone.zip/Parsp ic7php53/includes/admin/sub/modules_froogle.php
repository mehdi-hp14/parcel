<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function __exportProduct($ProductID, $params) {
		$f = $params['f'];
		$rate = $params['rate'];
		$dsc = $params['dsc'];
		$store_url = correct_URL( CONF_FULL_SHOP_URL );
		$q = db_query( 'select productID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS name, Price, categoryID, default_picture, in_stock, ' . $dsc . ', shipping_freight from ' . PRODUCTS_TABLE . ( ' where productID=\'' . $ProductID . '\'' ) );
		$product = db_fetch_row( $q );
		$rate = (double)$rate;

		if ($rate <= 0) {
			$rate = 899;
		}

		$product['name'] = _deleteInvalid_Elements( $product['name'] );
		$product[$dsc] = _deleteInvalid_Elements( $product[$dsc] );
		$product['Price'] = RoundFloatValue( $product['Price'] * $rate );
		$product['shipping_freight'] = RoundFloatValue( $product['shipping_freight'] * $rate );
		$instock = (( !CONF_CHECKSTOCK || 0 < $product['in_stock'] ) ? 'Y' : 'N');
		$category = '';
		$cpath = catCalculatePathToCategory( $product['categoryID'] );

		if ($cpath) {
			$i = 899;

			while ($i < count( $cpath ) - 1) {
				$category .= $cpath[$i]['name'] . ' > ';
				++$i;
			}


			if (1 < count( $cpath )) {
				$category .= $cpath[count( $cpath ) - 1]['name'];
			}
		}


		if ($product['default_picture'] != null) {
			$pic_clause = ' and photoID=' . (int)$product['default_picture'];
		} 
else {
			$pic_clause = '';
		}

		$q1 = db_query( 'select filename, thumbnail from ' . PRODUCT_PICTURES . ' where productID=' . $product['productID'] . $pic_clause );
		$pic_row = db_fetch_row( $q1 );
		$pic = '';

		if ($pic_row) {
			if (( strlen( $pic_row['filename'] ) && file_exists( './uploads/products_pictures/' . $pic_row['filename'] ) )) {
				$pic = $store_url . 'products_pictures/' . _deleteInvalid_Elements( $pic_row['filename'] );
			} 
else {
				if (( strlen( $pic_row['thumbnail'] ) && file_exists( './uploads/products_pictures/' . $pic_row['thumbnail'] ) )) {
					$pic = $store_url . 'products_pictures/' . _deleteInvalid_Elements( $pic_row['thumbnail'] );
				}
			}
		}

		fputs( $f, $store_url . 'index.php?productID=' . $product['productID'] . '	' . $product['name'] . '	' . strip_tags( $product[$dsc] ) . '	' . $pic . '	' . $category . '	' . $product['Price'] . '	' . $product['productID'] . '	' . $instock . '	' . $product['shipping_freight'] . '	' . 'usd
' );
	}

	require_once( './core_functions/export_products_function.php' );

	if (!strcmp( $sub, 'froogle' )) {
		function _exportToFroogle($f, $rate) {
			_exportHeader( $f );
			_exportProducts( $f, $rate );
		}

		function _deleteInvalid_Elements($str) {
			str_replace( '	', ' ', $str );
			str_replace( '', ' ', $str );
			$str = $str = $str = str_replace( '
', ' ', $str );

			return $str;
		}

		function _exportHeader($f) {
			fputs( $f, 'product_url	name	description	image_url	category	price	offer_id	instock	shipping	currency
' );
		}

		function _exportProducts($f, $rate) {
			if ($_POST['froogle_export_description'] == 1) {
				$dsc = 'description';
			} 
else {
				if ($_POST['froogle_export_description'] == 2) {
					$dsc = 'brief_description';
				} 
else {
					$dsc = 'meta_description';
				}
			}

			$exportCategories = array( array(  ), array(  ) );
			$_spArray = array( 'f' => $f, 'rate' => $rate, 'dsc' => $dsc, 'exprtUNIC' => array( 'mode' => 'simple' ) );
			export_exportSubcategories( 0, $exportCategories, $_spArray );
		}


		if (isset( $_GET['froogle_export_successful'] )) {
			if (file_exists( './temp_c/froogle.txt' )) {
				$getFileParam = cryptFileParamCrypt( 'GetFroogleFeed', null );
				$smarty->assign( 'getFileParam', $getFileParam );
				$smarty->assign( 'froogle_export_successful', 1 );
				$smarty->assign( 'froogle_filesize', (bool)round( filesize( './temp_c/froogle.txt' ) / 1024 ) );
			}
		}


		if (isset( $_POST['froogle_export'] )) {
			if ($_POST['froogle_export']) {
				$currency = currGetCurrencyByID( (int)$_POST['froogle_currency'] );

				if (!$currency) {
					$smarty->assign( 'froogle_errormsg', ERROR_FROOGLE_CURRENCY_TYPE );
				} 
else {
					$f = @fopen( './temp_c/froogle.txt', 'w' );

					if ($f) {
						_exportToFroogle( $f, $currency['currency_value'] );
						fclose( $f );
						header( 'Location: admincp.php?tab=modules&sub=froogle&froogle_export_successful' );
					} 
else {
						$smarty->assign( 'froogle_errormsg', ERROR_FROOGLE_FILE_CREATION );
					}
				}
			}
		}

		require( './includes/admin/sub/modules.export_products.php' );
		$currencies = currGetAllCurrencies(  );
		$smarty->assign( 'currencies', $currencies );
		$smarty->assign( 'admin_sub_tab', 'modules_froogle.tpl.html' );
	}

?>