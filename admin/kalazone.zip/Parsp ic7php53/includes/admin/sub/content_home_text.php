<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'home_text' )) {
		$langs = LanguagesManager::getLanguages(  );
		foreach ($langs as $languageEntry) {
			file( './cfg/homepage_' . $languageEntry->iso2 );
			$out = $f = implode( '', $f );
			$home['home_text_' . $languageEntry->iso2] = $out;
		}

		$smarty->assign( 'home', $home );

		if (isset( $_GET['save_successful'] )) {
			$smarty->assign( 'save_successful', ADMIN_UPDATE_SUCCESSFUL );
		}


		if (isset( $_POST['save_hmtxt'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=content&sub=home_text&safemode' );
			}

			$langs = LanguagesManager::getLanguages(  );
			foreach ($langs as $languageEntry) {
				$f = fopen( './cfg/homepage_' . $languageEntry->iso2, 'w' );
				$str = ', '
				stripslashes( str_replace( '
', $_POST['home_text_' . $languageEntry->iso2] ) );

				fputs( $f, $str );
				fclose( $f );
			}

			header( 'Location: admincp.php?tab=content&sub=home_text&save_successful=yes' );
		}

		$smarty->assign( 'admin_sub_tab', 'content_home_text.tpl.html' );
	}

?>