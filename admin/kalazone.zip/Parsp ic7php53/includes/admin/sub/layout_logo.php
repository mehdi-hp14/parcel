<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'logo' )) {
		$CONF_MAIN_LOGO = CONF_MAIN_LOGO;

		if ($_FILES['newlogo']['name']) {
			$tmp = $_FILES['newlogo']['tmp_name'];
			$r = false;

			if (( $_FILES['newlogo']['size'] != 0 && preg_match( '/\.(jpg|jpeg|gif|jpe|pcx|bmp|png)$/i', $_FILES['newlogo']['name'] ) )) {
				SetRightsToUploadedFile( './uploads/logos/' . $_FILES['newlogo']['name'] );
				$r = move_uploaded_file( $tmp, './uploads/logos/' . $_FILES['newlogo']['name'] );

				if (( $_POST['logoWidth'] && $_POST['logoHeight'] )) {
					copy( './uploads/logos/' . $_FILES['newlogo']['name'], './uploads/logos/resized_' . $_FILES['newlogo']['name'] );
					SetImgSize( './uploads/logos/resized_' . $_FILES['newlogo']['name'], $_POST['logoWidth'], $_POST['logoHeight'] );
					_setSettingOptionValue( 'CONF_MAIN_LOGO', './uploads/logos/resized_' . $_FILES['newlogo']['name'] );
					$CONF_MAIN_LOGO = './uploads/logos/resized_' . $_FILES['newlogo']['name'];
					unlink( './uploads/logos/' . $_FILES['newlogo']['name'] );
				} 
else {
					_setSettingOptionValue( 'CONF_MAIN_LOGO', './uploads/logos/' . $_FILES['newlogo']['name'] );
					$CONF_MAIN_LOGO = './uploads/logos/' . $_FILES['newlogo']['name'];
				}
			}
		}

		$smarty->assign( 'CONF_MAIN_LOGO', $CONF_MAIN_LOGO );
		$smarty->assign( 'admin_sub_tab', 'layout_logo.tpl.html' );
	}

?>