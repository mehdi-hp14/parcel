<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'order_statuses' )) {
		if (isset( $_GET['delete'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=custord&sub=order_statuses&safemode' );
			}


			if (!ostDeleteOrderStatus( $_GET['delete'] )) {
				$smarty->assign( 'prompt', ADMIN_COULDNT_DELETE_ORDER_STATUS );
			}

			Redirect( 'admincp.php?tab=custord&sub=order_statuses' );
		}


		if (isset( $_POST['save'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=custord&sub=order_statuses&safemode' );
			}


			if (!LanguagesManager::ml_isEmpty( 'new_status_name', $_POST )) {
				ostAddOrderStatus( $_POST, $_POST['new_sort_order'] );
			}

			$updateData = scanArrayKeysForID( $_POST, array( 'status_name_\w{2}', 'sort_order' ) );
			foreach ($updateData as $key => $value) {
				ostUpdateOrderStatus( $key, $value, $value['sort_order'] );
			}

			Redirect( 'admincp.php?tab=custord&sub=order_statuses' );
		}

		$order_statues = ostGetOrderStatues( false, 'html' );
		$smarty->assign( 'order_statues', $order_statues );
		$smarty->assign( 'admin_sub_tab', 'custord_order_statuses.tpl.html' );
	}

?>