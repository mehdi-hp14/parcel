<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'contactus' )) {
		$langs = LanguagesManager::getLanguages(  );
		foreach ($langs as $out) {
			$f = file( './cfg/contactus_' . $languageEntry->iso2 );
			implode( '', $f );

			if ($out) {
				$contactus['contactus_text_' . $languageEntry->iso2] = $out;
				continue;
			}

			$contactus['contactus_text_' . $languageEntry->iso2] = '';
		}

		$smarty->assign( 'contactus', $contactus );

		if (isset( $_GET['save_successful'] )) {
			$smarty->assign( 'save_successful', ADMIN_UPDATE_SUCCESSFUL );
		}


		if (isset( $_POST['save_hmtxt'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=content&sub=contactus&safemode' );
			}

			$langs = LanguagesManager::getLanguages(  );
			foreach ($langs as $languageEntry) {
				fopen( './cfg/contactus_' . $languageEntry->iso2, 'w' );
				$str = $f = ', '
				stripslashes( str_replace( '
', $_POST['contactus_text_' . $languageEntry->iso2] ) );

				fputs( $f, $str );
				fclose( $f );
			}

			header( 'Location: admincp.php?tab=content&sub=contactus&save_successful=yes' );
		}

		$smarty->assign( 'admin_sub_tab', 'content_contactus.tpl.html' );
	}

?>