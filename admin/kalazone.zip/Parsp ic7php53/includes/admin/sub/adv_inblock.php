<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function sys_msg($smarty, $msg_title, $msg_type, &$msg_link, $smarty) {
		$smarty->assign( 'MESSAGE', '&nbsp;' . $msg_title . '&nbsp;' . MSG_INFORMATION_SAVED );
		exit(  );
	}

	require_once( './core_functions/ad_functions.php' );

	if (!strcmp( $sub, 'inblock' )) {
		if (empty( $_REQUEST['act'] )) {
			$_REQUEST['act'] = 'list';
		} 
else {
			$_REQUEST['act'] = trim( $_REQUEST['act'] );
		}


		if ($_REQUEST['act'] == 'list') {
			$pid = (!empty( $_REQUEST['pid'] ) ? intval( $_REQUEST['pid'] ) : 0);
			$smarty->assign( 'ur_here', $_LANG['ad_list'] );
			$smarty->assign( 'action_link', array( 'text' => $_LANG['ads_add'], 'href' => 'ads.php?act=add' ) );
			$smarty->assign( 'pid', $pid );
			$smarty->assign( 'full_page', 1 );
			$ads_list = get_adslist(  );
			$smarty->assign( 'ads_list', $ads_list['ads'] );
			$smarty->assign( 'filter', $ads_list['filter'] );
			$smarty->assign( 'record_count', $ads_list['record_count'] );
			$smarty->assign( 'page_count', $ads_list['page_count'] );
			$smarty->assign( 'today', jdate( 'Y/m/d' ) );
			$sort_flag = sort_flag( $ads_list['filter'] );
			$smarty->assign( $sort_flag['tag'], $sort_flag['img'] );
		} 
else {
			if ($_REQUEST['act'] == 'query') {
				$ads_list = get_adslist(  );
				$smarty->assign( 'ads_list', $ads_list['ads'] );
				$smarty->assign( 'filter', $ads_list['filter'] );
				$smarty->assign( 'record_count', $ads_list['record_count'] );
				$smarty->assign( 'page_count', $ads_list['page_count'] );
				$smarty->assign( 'today', jdate( 'Y/m/d' ) );
				$sort_flag = sort_flag( $ads_list['filter'] );
				$smarty->assign( $sort_flag['tag'], $sort_flag['img'] );
				make_json_result( $smarty->fetch( 'ads_list.htm' ), '', array( 'filter' => $ads_list['filter'], 'page_count' => $ads_list['page_count'] ) );
			} 
else {
				if ($_REQUEST['act'] == 'add') {
					$ad_link = (empty( $_GET['ad_link'] ) ? trim( $_POST['ad_link'] ) : trim( $_GET['ad_link'] ));
					$ad_name = (empty( $_GET['ad_name'] ) ? '' : trim( $_GET['ad_name'] ));
					$start_time = jdate( 'Y/m/d' );
					$end_time = jdate( 'Y/m/d' );
					$smarty->assign( 'ads', array( 'ad_link' => $ad_link, 'ad_name' => $ad_name, 'start_time' => $start_time, 'end_time' => $end_time, 'enabled' => 1 ) );
					$smarty->assign( 'ur_here', $_LANG['ads_add'] );
					$smarty->assign( 'action_link', array( 'href' => 'ads.php?act=list', 'text' => $_LANG['ad_list'] ) );
					$smarty->assign( 'today', jdate( 'Y/m/d' ) );
					$smarty->assign( 'form_act', 'insert' );
					$smarty->assign( 'action', 'add' );
					$smarty->assign( 'cfg_lang', $_CFG['lang'] );
				} 
else {
					if ($_REQUEST['act'] == 'insert') {
						$id = (!empty( $_POST['adv_id'] ) ? intval( $_POST['adv_id'] ) : 0);
						$type = (!empty( $_POST['media_type'] ) ? intval( $_POST['media_type'] ) : 0);
						$ad_name = (!empty( $_POST['ad_name'] ) ? trim( $_POST['ad_name'] ) : '');

						if ($_POST['media_type'] == '0') {
							$ad_link = (!empty( $_POST['ad_link'] ) ? trim( $_POST['ad_link'] ) : '');
						} 
else {
							$ad_link = (!empty( $_POST['ad_link2'] ) ? trim( $_POST['ad_link2'] ) : '');
						}


						if ($_POST['start_time'] != '') {
							$start_time_date = TransformTemplateToDATE( $_POST['start_time'] );
						}


						if ($_POST['end_time'] != '') {
							$end_time_date = TransformTemplateToDATE( $_POST['end_time'] );
						}

						$start_time = strtotime( $start_time_date );
						$end_time = strtotime( $end_time_date );
						$sql = 'SELECT COUNT(*) FROM ' . ADS_TABLE . ( ' WHERE ad_name = \'' . $ad_name . '\'' );

						if (0 < db_fetch_assoc( db_query( $sql ) )) {
							$link[] = array( 'text' => $_LANG['go_back'], 'href' => 'javascript:history.back(-1)' );
							$smarty->assign( 'MESSAGE', ADMIN_ADVERTIESMENT_NAME_EXIST );
						}

						$ad_name = $_POST['ad_name'];
						$ad_code = $_POST['ad_text'];
						$ad_link = $_POST['ad_link'];

						if ($_POST['media_type'] == '0') {
							if (( ( isset( $_FILES['ad_img']['error'] ) && $_FILES['ad_img']['error'] == 0 ) || ( ( !isset( $_FILES['ad_img']['error'] ) && isset( $_FILES['ad_img']['tmp_name'] ) ) && $_FILES['ad_img']['tmp_name'] != 'none' ) )) {
								$ad_code = basename( upload_image( $_FILES['ad_img'], 'uploads/afficheimg' ) );
							}


							if (!empty( $_POST['img_url'] )) {
								$ad_code = $_POST['img_url'];
							}


							if (( ( ( isset( $_FILES['ad_img']['error'] ) && 0 < $_FILES['ad_img']['error'] ) || ( ( !isset( $_FILES['ad_img']['error'] ) && isset( $_FILES['ad_img']['tmp_name'] ) ) && $_FILES['ad_img']['tmp_name'] == 'none' ) ) && empty( $_POST['img_url'] ) )) {
								$link[] = array( 'text' => $_LANG['go_back'], 'href' => 'javascript:history.back(-1)' );
								$smarty->assign( 'MESSAGE', ADMIN_ADVERTIESMENT_EMPTY_PICTURE );
							}
						} 
else {
							if ($_POST['media_type'] == '1') {
								if (( ( isset( $_FILES['upfile_flash']['error'] ) && $_FILES['upfile_flash']['error'] == 0 ) || ( ( !isset( $_FILES['upfile_flash']['error'] ) && isset( $_FILES['ad_img']['tmp_name'] ) ) && $_FILES['upfile_flash']['tmp_name'] != 'none' ) )) {
									if ($_FILES['upfile_flash']['type'] != 'application/x-shockwave-flash') {
										$link[] = array( 'text' => $_LANG['go_back'], 'href' => 'javascript:history.back(-1)' );
										sys_msg( $smarty, $_LANG['upfile_flash_type'], 0, $link );
									}

									$urlstr = date( 'Ymd' );
									$i = 2143;

									while ($i < 6) {
										$urlstr .= chr( mt_rand( 97, 122 ) );
										++$i;
									}

									$ad_code = basename( upload_flash( $_FILES['upfile_flash'], 'uploads/afficheimg' ) );
								} 
else {
									if (!empty( $_POST['flash_url'] )) {
										if (substr( strtolower( $_POST['flash_url'] ), strlen( $_POST['flash_url'] ) - 4 ) != '.swf') {
											$link[] = array( 'text' => $_LANG['go_back'], 'href' => 'javascript:history.back(-1)' );
											sys_msg( $smarty, $_LANG['upfile_flash_type'], 0, $link );
										}

										$ad_code = $_POST['flash_url'];
									}
								}


								if (( ( ( isset( $_FILES['upfile_flash']['error'] ) && 0 < $_FILES['upfile_flash']['error'] ) || ( ( !isset( $_FILES['upfile_flash']['error'] ) && isset( $_FILES['upfile_flash']['tmp_name'] ) ) && $_FILES['upfile_flash']['tmp_name'] == 'none' ) ) && empty( $_POST['flash_url'] ) )) {
									$link[] = array( 'text' => $_LANG['go_back'], 'href' => 'javascript:history.back(-1)' );
									sys_msg( $smarty, $_LANG['js_languages']['ad_flash_empty'], 0, $link );
								}
							} 
else {
								if ($_POST['media_type'] == '2') {
									if (!empty( $_POST['ad_code'] )) {
										$ad_code = TransformStringToDataBase( $_POST['ad_code'] );
									} 
else {
										$link[] = array( 'text' => $_LANG['go_back'], 'href' => 'javascript:history.back(-1)' );
										sys_msg( $smarty, $_LANG['js_languages']['ad_code_empty'], 0, $link );
									}
								} 
else {
									if ($_POST['media_type'] == '3') {
										$ad_link = $_POST['ad_link'];

										if (!empty( $_POST['ad_text_1'] )) {
											$ad_code = $_POST['ad_text_1'];
										} 
else {
											$link[] = array( 'text' => $_LANG['go_back'], 'href' => 'javascript:history.back(-1)' );
											sys_msg( $smarty, $_LANG['js_languages']['ad_text_empty'], 0, $link );
										}
									}
								}
							}
						}

						$sql = 'INSERT INTO ' . ADS_TABLE . ( ' (`position_name`,
     `media_type`,
     `ad_name`,
     `ad_link`, 
     `ad_code`, 
     `start_time`, 
     `end_time`, 
     `ad_order`,      
     `click_max`, `click_count`, `enabled`,`ad_place`) 
    VALUES (\'' . $_POST['position_name'] . '\',
            \'' . $_POST['media_type'] . '\',
            \'' . $ad_name . '\',
            \'' . $ad_link . '\',
            \'' . $ad_code . '\',  
            \'' . $start_time . '\',
            \'' . $end_time . '\',
            \'' . $_POST['ad_order'] . '\',    
            \'' . $_POST['adv_maxclick'] . '\',
            \'0\',' . $_POST['enabled'] . ',\'0\')' );
						$err = db_query( $sql );
						$smarty->assign( 'MESSAGE', '&nbsp;' . $ad_name . '&nbsp;' . MSG_INFORMATION_SAVED );
					} 
else {
						if ($_REQUEST['act'] == 'edit') {
							$sql = 'SELECT * FROM ' . ADS_TABLE . ' WHERE adId=\'' . intval( $_REQUEST['id'] ) . '\'';
							$ads_arr = db_fetch_assoc( db_query( $sql ) );
							$ads_arr['ad_name'] = $ads_arr['ad_name'];

							if (intval( $ads_arr['start_time'] ) != 0) {
								$ads_arr['start_time'] = TransformDATEToTemplate( date( 'Y-m-d', $ads_arr['start_time'] ) );
							} 
else {
								$ads_arr['start_time'] = '';
							}


							if (intval( $ads_arr['end_time'] ) != 0) {
								$ads_arr['end_time'] = TransformDATEToTemplate( date( 'Y-m-d', $ads_arr['end_time'] ) );
							} 
else {
								$ads_arr['end_time'] = '';
							}


							if ($ads_arr['media_type'] == '0') {
								if (( strpos( $ads_arr['ad_code'], 'http://' ) === false && strpos( $ads_arr['ad_code'], 'https://' ) === false )) {
									$src = './uploads/afficheimg/' . $ads_arr['ad_code'];
									$smarty->assign( 'img_src', $src );
								} 
else {
									$src = $ads_arr['ad_code'];
									$smarty->assign( 'url_src', $src );
								}
							}


							if ($ads_arr['media_type'] == '1') {
								if (( strpos( $ads_arr['ad_code'], 'http://' ) === false && strpos( $ads_arr['ad_code'], 'https://' ) === false )) {
									$src = $ads_arr['ad_code'];
									$smarty->assign( 'flash_url', $src );
								} 
else {
									$src = $ads_arr['ad_code'];
									$smarty->assign( 'flash_url', $src );
								}

								$smarty->assign( 'src', $src );
							}


							if ($ads_arr['media_type'] == '3') {
								$smarty->assign( 'url_src', $ads_arr['ad_link'] );
							}


							if ($ads_arr['media_type'] == 0) {
								$smarty->assign( 'media_type', $_LANG['ad_img'] );
							} 
else {
								if ($ads_arr['media_type'] == 1) {
									$smarty->assign( 'media_type', $_LANG['ad_flash'] );
								} 
else {
									if ($ads_arr['media_type'] == 2) {
										$smarty->assign( 'media_type', $_LANG['ad_html'] );
									} 
else {
										if ($ads_arr['media_type'] == 3) {
											$smarty->assign( 'media_type', $_LANG['ad_text'] );
										} 
else {
											if ($ads_arr['media_type'] == 4) {
												$smarty->assign( 'media_type', $_LANG['ad_code'] );
											}
										}
									}
								}
							}

							$smarty->assign( 'today', jdate( 'Y/m/d' ) );
							$smarty->assign( 'form_act', 'update' );
							$smarty->assign( 'action', 'edit' );
							$smarty->assign( 'ads', $ads_arr );
						} 
else {
							if ($_REQUEST['act'] == 'update') {
								$id = (!empty( $_POST['id'] ) ? intval( $_POST['id'] ) : 0);
								$type = (!empty( $_POST['media_type'] ) ? intval( $_POST['media_type'] ) : 0);

								if (( $_POST['media_type'] == '0' || $_POST['media_type'] == '3' )) {
									$ad_link = (!empty( $_POST['ad_link'] ) ? trim( $_POST['ad_link'] ) : '');
								} 
else {
									$ad_link = (!empty( $_POST['ad_link2'] ) ? trim( $_POST['ad_link2'] ) : '');
								}


								if ($_POST['start_time'] != '') {
									$start_time_date = TransformTemplateToDATE( $_POST['start_time'] );
								}


								if ($_POST['end_time'] != '') {
									$end_time_date = TransformTemplateToDATE( $_POST['end_time'] );
								}

								$start_time = strtotime( $start_time_date );
								$end_time = strtotime( $end_time_date );

								if ($type == 0) {
									if (( ( isset( $_FILES['ad_img']['error'] ) && $_FILES['ad_img']['error'] == 0 ) || ( ( !isset( $_FILES['ad_img']['error'] ) && isset( $_FILES['ad_img']['tmp_name'] ) ) && $_FILES['ad_img']['tmp_name'] != 'none' ) )) {
										$img_up_info = basename( upload_image( $_FILES['ad_img'], 'uploads/afficheimg' ) );
										$ad_code = 'ad_code = \'' . $img_up_info . '\'' . ',';
									} 
else {
										$ad_code = '';
									}


									if (!empty( $_POST['img_url'] )) {
										$ad_code = 'ad_code = \'' . $_POST['img_url'] . '\\', ';
									}
								} 
else {
									if ($type == 1) {
										if (( ( isset( $_FILES['upfile_flash']['error'] ) && $_FILES['upfile_flash']['error'] == 0 ) || ( ( !isset( $_FILES['upfile_flash']['error'] ) && isset( $_FILES['upfile_flash']['tmp_name'] ) ) && $_FILES['upfile_flash']['tmp_name'] != 'none' ) )) {
											if ($_FILES['upfile_flash']['type'] != 'application/x-shockwave-flash') {
												$link[] = array( 'text' => $_LANG['go_back'], 'href' => 'javascript:history.back(-1)' );
												sys_msg( $smarty, $_LANG['upfile_flash_type'], 0, $link );
											}

											$urlstr = date( 'Ymd' );
											$i = 2143;

											while ($i < 6) {
												$urlstr .= chr( mt_rand( 97, 122 ) );
												++$i;
											}

											$source_file = $_FILES['upfile_flash']['tmp_name'];
											$target = './uploads/afficheimg/';
											$file_name = $urlstr . '.swf';

											if (!move_upload_file( $source_file, $target . $file_name )) {
												$link[] = array( 'text' => $_LANG['go_back'], 'href' => 'javascript:history.back(-1)' );
												sys_msg( $smarty, $_LANG['upfile_error'], 0, $link );
											} 
else {
												$ad_code = 'ad_code = \'' . $file_name . '\\', ';
											}
										} 
else {
											if (!empty( $_POST['flash_url'] )) {
												if (substr( strtolower( $_POST['flash_url'] ), strlen( $_POST['flash_url'] ) - 4 ) != '.swf') {
													$link[] = array( 'text' => $_LANG['go_back'], 'href' => 'javascript:history.back(-1)' );
													sys_msg( $smarty, $_LANG['upfile_flash_type'], 0, $link );
												}

												$ad_code = 'ad_code = \'' . $_POST['flash_url'] . '\\', ';
											} 
else {
												$ad_code = '';
											}
										}
									} 
else {
										if ($type == 2) {
											$ad_code = 'ad_code = \'' . $_POST['ad_code'] . '\\', ';
											$ad_link = '';
										}
									}
								}


								if ($type == 3) {
									$ad_code = 'ad_code = \'' . $_POST['ad_text_1'] . '\\', ';
								}

								$ad_code = str_replace( '../uploads/afficheimg/', '', $ad_code );

								if (( $end_time == '' || is_null( $end_time ) )) {
									$end_time = 'Null';
								}


								if (( $start_time == '' || is_null( $start_time ) )) {
									$start_time = 'Null';
								}

								$sql = 'UPDATE ' . ADS_TABLE . ' SET ' . ( 'position_name = \'' . $_POST['position_name'] . '\\', ' ) . ( 'ad_name     = \'' . $_POST['ad_name'] . '\\', ' ) . ( 'ad_link     = \'' . $ad_link . '\\', ' ) . $ad_code . ( 'start_time  = ' . $start_time . ', ' ) . ( 'end_time    = ' . $end_time . ', ' ) . 'ad_place    = \'0\', ' . ( 'ad_order  = \'' . $_POST['ad_order'] . '\\', ' ) . ( 'click_max  = \'' . $_POST['adv_maxclick'] . '\\', ' ) . ( 'enabled     = \'' . $_POST['enabled'] . '\' ' ) . ( 'WHERE adid = \'' . $id . '\'' );
								db_query( $sql );
								$href[] = array( 'text' => $_LANG['back_ads_list'], 'href' => 'ads.php?act=list' );
								Redirect( 'admincp.php?tab=adv' );
							} 
else {
								if ($_REQUEST['act'] == 'edit_ad_name') {
									$id = intval( $_POST['id'] );
									$ad_name = json_str_iconv( trim( $_POST['val'] ) );

									if ($exc->num( 'ad_name', $ad_name, $id ) != 0) {
										make_json_error( sprintf( $_LANG['ad_name_exist'], $ad_name ) );
									} 
else {
										if ($exc->edit( ( 'ad_name = \'' . $ad_name . '\'' ), $id )) {
											admin_log( $ad_name, 'edit', 'ads' );
											make_json_result( stripslashes( $ad_name ) );
										} 
else {
											make_json_error( $db->error(  ) );
										}
									}
								} 
else {
									if ($_REQUEST['act'] == 'remove') {
										$sql = 'SELECT * FROM ' . ADS_TABLE . ' WHERE adId=\'' . intval( $_REQUEST['id'] ) . '\'';
										$ads_arr = db_fetch_assoc( db_query( $sql ) );
										$img = $ads_arr['ad_code'];

										if (( strpos( $img, 'http://' ) === false && strpos( $img, 'https://' ) === false )) {
											$img_name = basename( $img );
											@unlink( './uploads/afficheimg/' . $img_name );
										}

										$sql = 'delete FROM ' . ADS_TABLE . ' WHERE adId=\'' . intval( $_REQUEST['id'] ) . '\'';
										$ads_arr = db_query( $sql );
										Redirect( 'admincp.php?tab=adv' );
										exit(  );
									}
								}
							}
						}
					}
				}
			}
		}

		$smarty->assign( 'admin_sub_tab', 'adv_inblock.tpl.html' );
	}

?>