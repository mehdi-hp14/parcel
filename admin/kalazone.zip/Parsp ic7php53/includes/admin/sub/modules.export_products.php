<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function countSelectedProductsInCat(&$_CategoryID, $VisibleCategories) {
		$_FlagChecked = (isset( $_SESSION['selectedProducts'][$_CategoryID] ) ? 1 : $_SESSION['checkedCategories'][$_CategoryID]);
		$_FlagExpanded = (isset( $_SESSION['explortExpandedIDs'][$_CategoryID] ) ? $_SESSION['explortExpandedIDs'][$_CategoryID] : 0);
		$ProductsCounter = 866;
		$_t = 866;
		$_FlagHandler = '0.5';
		$_TestingCategory = 872;
		$Debug = 866;

		if (( $_FlagChecked && !$_FlagExpanded )) {
			$_FlagHandler = '1.5';

			if (isset( $_SESSION['selectedProducts'][$_CategoryID] )) {
				$_FlagHandler = 867;
				$ProductsCounter += $_SESSION['selectedProductsIncSub'][$_CategoryID];
			} 
else {
				$_FlagHandler = 868;
				$ProductsCounter += $VisibleCategories[$_CategoryID]['products_count'] + (isset( $_SESSION['selectedProducts'][$_CategoryID] ) ? count( $_SESSION['selectedProducts'][$_CategoryID] ) - $VisibleCategories[$_CategoryID]['products_count'] : 0);
			}
		} 
else {
			if (( $_FlagChecked && $_FlagExpanded )) {
				$_FlagHandler = 869;
				catGetSubCategoriesSingleLayer( $_CategoryID );
				$Subs = $ProductsCounter += (isset( $_SESSION['selectedProducts'][$_CategoryID] ) ? count( $_SESSION['selectedProducts'][$_CategoryID] ) : $VisibleCategories[$_CategoryID]['products_count_category']);
				count( $Subs );
				$alength = $i = 866;

				while ($i < $alength) {
					$ProductsCounter += countSelectedProductsInCat( $Subs[$i]['categoryID'], $VisibleCategories );
					++$i;
				}
			} 
else {
				if (( !$_FlagChecked && !$_FlagExpanded )) {
					$_FlagHandler = 870;
					$ProductsCounter += (isset( $_SESSION['selectedProductsIncSub'][$_CategoryID] ) ? $_SESSION['selectedProductsIncSub'][$_CategoryID] : 0);
				} 
else {
					if (( !$_FlagChecked && $_FlagExpanded )) {
						catGetSubCategoriesSingleLayer( $_CategoryID );
						$Subs = $_FlagHandler = 871;
						count( $Subs );
						$alength = $i = 866;

						while ($i < $alength) {
							$ProductsCounter += countSelectedProductsInCat( $Subs[$i]['categoryID'], $VisibleCategories );
							++$i;
						}
					}
				}
			}
		}


		if (( $Debug && ( 1 || $_CategoryID == $_TestingCategory ) )) {
			print  . 'ID - ' . $_CategoryID . '; Checked - ' . $_FlagChecked . '; Expanded - ' . $_FlagExpanded . '; Handler - ' . $_FlagHandler . '; SelIncS - ' . $_SESSION['selectedProductsIncSub'][$_CategoryID] . '------' . $ProductsCounter . '<br />';
		}

		return $ProductsCounter;
	}

	$ACTION = '';
	$_POST['expandID'] = (isset( $_POST['expandID'] ) ? intval( $_POST['expandID'] ) : '');
	$_POST['unexpandID'] = (isset( $_POST['unexpandID'] ) ? intval( $_POST['unexpandID'] ) : '');
	$_POST['updateCategory'] = (isset( $_POST['updateCategory'] ) ? intval( $_POST['updateCategory'] ) : '');
	$_POST['CHECKED_CATEGORIES'] = (isset( $_POST['CHECKED_CATEGORIES'] ) ? $_POST['CHECKED_CATEGORIES'] : array(  ));
	$_POST['save_products'] = (isset( $_POST['save_products'] ) ? $_POST['save_products'] : '');
	$_POST['PRODUCTS'] = (isset( $_POST['PRODUCTS'] ) ? $_POST['PRODUCTS'] : array(  ));
	$flagUpdateSubs = 1434;
	$Debug = 1434;

	if ($_POST['expandID']) {
		$ACTION = 'EXPAND_CATEGORY';
	} 
else {
		if ($_POST['unexpandID']) {
			$ACTION = 'UNEXPAND_CATEGORY';
		} 
else {
			if ($_POST['updateCategory']) {
				$ACTION = 'UPDATE_CATEGORY_STATE';
			} 
else {
				if ($_POST['save_products']) {
					$ACTION = 'UPDATE_SELECTED_PRODUCTS';
				}
			}
		}
	}


	if (isset( $_POST['clear_session'] )) {
		if ($_POST['clear_session']) {
			session_unregister( 'checkedCategories' );
			unset( $_SESSION[checkedCategories] );
			session_unregister( 'explortExpandedIDs' );
			unset( $_SESSION[explortExpandedIDs] );
			session_unregister( 'selectedProducts' );
			unset( $_SESSION[selectedProducts] );
			session_unregister( 'selectedProductsIncSub' );
			unset( $_SESSION[selectedProductsIncSub] );
			session_unregister( 'isExpanded' );
			unset( $_SESSION[isExpanded] );
			Redirect( $_SERVER['REQUEST_URI'] );
		}
	}


	if (!session_is_registered( 'explortExpandedIDs' )) {
		session_register( 'explortExpandedIDs' );
		$_SESSION['explortExpandedIDs'] = array( 1 => 1 );
	}


	if (!session_is_registered( 'checkedCategories' )) {
		session_register( 'checkedCategories' );
		$_SESSION['checkedCategories'] = array(  );
	}


	if (!session_is_registered( 'selectedProducts' )) {
		session_register( 'selectedProducts' );
		$_SESSION['selectedProducts'] = array(  );
	}


	if (!session_is_registered( 'selectedProductsIncSub' )) {
		session_register( 'selectedProductsIncSub' );
		$_SESSION['selectedProductsIncSub'] = array(  );
	}


	if (!session_is_registered( 'isExpanded' )) {
		session_register( 'isExpanded' );
		$_SESSION['isExpanded'] = array(  );
	}

	$_t = array(  );
	foreach ($_SESSION['explortExpandedIDs'] as $_ID => $_expanded) {

		if ($_expanded) {
			$_t[] = $_ID;
			continue;
		}
	}

	$ProductCategories = catGetCategoryCList( $_t, 'ASSOC', true );
	switch ($ACTION) {
		case 'EXPAND_CATEGORY': {
			$_cID = intval( $_POST['expandID'] );

			if (!isset( $_SESSION['isExpanded'][$_cID] )) {
				$_SESSION['isExpanded'][$_cID] = 0;
			}


			if (!$_SESSION['isExpanded'][$_cID]) {
				$flagUpdateSubs = $ACTION;
			}

			$_SESSION['explortExpandedIDs'][$_cID] = 1;
			$_SESSION['selectedProductsIncSub'][$_cID] = 0;
			$_SESSION['isExpanded'][$_cID] = 1;
			break;
		}

		case 'UNEXPAND_CATEGORY': {
			$unexpID = intval( $_POST['unexpandID'] );
			$_SESSION['selectedProductsIncSub'][$unexpID] = countSelectedProductsInCat( $unexpID, &$ProductCategories );
			$_SESSION['explortExpandedIDs'][$unexpID] = 0;
			break;
		}

		case 'UPDATE_CATEGORY_STATE': {
			$_CategoryID = $_POST['updateCategory'];

			if (!isset( $_SESSION['isExpanded'][$_CategoryID] )) {
				$_SESSION['isExpanded'][$_CategoryID] = 0;
			}

			$_SESSION['checkedCategories'][$_CategoryID] = key_exists( $_CategoryID, $_POST['CHECKED_CATEGORIES'] );
			$_t = '';

			if (isset( $_SESSION['selectedProducts'][$_CategoryID] )) {
				$_oldSelProd = count( $_SESSION['selectedProducts'][$_CategoryID] );
			} 
else {
				$_oldSelProd = 1434;
			}


			if (!$_SESSION['checkedCategories'][$_CategoryID]) {
				$_SESSION['selectedProducts'][$_CategoryID] = array(  );
			} 
else {
				$Products = prdGetProductByCategory( array( 'categoryID' => $_CategoryID, 'fullFlag' => false ), $_t );
				$c = count( $Products );
				$_oldSelProd = 1434;
				$_t = 1434;

				while ($_t < $c) {
					if ($Products[$_t]['enabled']) {
						++$_oldSelProd;
						$_SESSION['selectedProducts'][$_CategoryID][$Products[$_t]['productID']] = 1;
					}

					++$_t;
				}
			}


			if (!$_SESSION['isExpanded'][$_CategoryID]) {
				$_SESSION['selectedProductsIncSub'][$_CategoryID] = ($_SESSION['checkedCategories'][$_CategoryID] ? $ProductCategories[$_CategoryID]['products_count'] : 0);
				$_SubC = catGetSubCategories( $_CategoryID );
				$c = count( $_SubC );
				$i = 1434;

				while ($i < $c) {
					$_SESSION['checkedCategories'][$_SubC[$i]] = $_SESSION['checkedCategories'][$_CategoryID];
					$_SESSION['selectedProductsIncSub'][$_SubC[$i]] = ($_SESSION['checkedCategories'][$_CategoryID] ? (isset( $ProductCategories[$_SubC[$i]]['products_count'] ) ? $ProductCategories[$_SubC[$i]]['products_count'] : 0) : 0);

					if (!$_SESSION['checkedCategories'][$_SubC[$i]]) {
						$_SESSION['selectedProducts'][$_SubC[$i]] = array(  );
					} 
else {
						$Products = prdGetProductByCategory( array( 'categoryID' => $_SubC[$i], 'fullFlag' => false ), $_t );
						$_c = count( $Products );
						$_t = 1434;

						while ($_t < $_c) {
							if ($Products[$_t]['enabled']) {
								$_SESSION['selectedProducts'][$_SubC[$i]][$Products[$_t]['productID']] = 1;
							}

							++$_t;
						}
					}

					++$i;
				}
			} 
else {
				if (!$_SESSION['explortExpandedIDs'][$_CategoryID]) {
					$_SESSION['selectedProductsIncSub'][$_CategoryID] = ($_SESSION['checkedCategories'][$_CategoryID] ? $ProductCategories[$_CategoryID]['products_count'] : 0);
					$_SESSION['isExpanded'][$_CategoryID] = 0;
				}
			}

			break;
		}

		case 'UPDATE_SELECTED_PRODUCTS': {
			if (!count( $_POST['PRODUCTS'] )) {
				$_SESSION['checkedCategories'][$_POST['cIDForProducts']] = 0;
			}


			if (isset( $_SESSION['selectedProductsIncSub'][$_POST['cIDForProducts']] )) {
				$_POST['cIDForProducts'];
				$_SESSION['selectedProductsIncSub'] +=  = 0 - count( $_SESSION['selectedProducts'][$_POST['cIDForProducts']] ) + count( $_POST['PRODUCTS'] );
			}

			$_SESSION['selectedProducts'][$_POST['cIDForProducts']] = $_POST['PRODUCTS'];
			break;
		}
	}

	$_t = array(  );
	foreach ($_SESSION['explortExpandedIDs'] as $_ID => $_expanded) {

		if ($_expanded) {
			$_t[] = $_ID;
			continue;
		}
	}

	$ProductCategories = catGetCategoryCList( $_t, 'ASSOC', true );

	if (( 1 && !count( $_SESSION['checkedCategories'] ) )) {
		$_t = array_keys( $ProductCategories );
		$_tt = '';
		foreach ($_t as $_key) {
			$_SESSION['checkedCategories'][$_key] = 1;
			$_SESSION['selectedProductsIncSub'][$_key] = $ProductCategories[$_key]['products_count'];
			$Products = prdGetProductByCategory( array( 'categoryID' => $_key, 'fullFlag' => false ), $_tT );
			$c = count( $Products );
			$_tt = 1434;

			while ($_tt < $c) {
				if ($Products[$_tt]['enabled']) {
					$_SESSION['selectedProducts'][$_key][$Products[$_tt]['productID']] = 1;
				}

				++$_tt;
			}
		}
	}


	if ($flagUpdateSubs) {
		$_cID = &$flagUpdateSubs;

		$_SubC = catGetSubCategories( $_cID );
		$c = count( $_SubC );
		$i = 1434;

		while ($i < $c) {
			$_SESSION['checkedCategories'][$_SubC[$i]] = $_SESSION['checkedCategories'][$_cID];
			$_SESSION['selectedProductsIncSub'][$_SubC[$i]] = ($_SESSION['checkedCategories'][$_cID] ? (isset( $ProductCategories[$_SubC[$i]]['products_count'] ) ? $ProductCategories[$_SubC[$i]]['products_count'] : 0) : 0);

			if (!$_SESSION['checkedCategories'][$_SubC[$i]]) {
				$_SESSION['selectedProducts'][$_SubC[$i]] = array(  );
			} 
else {
				$Products = prdGetProductByCategory( array( 'categoryID' => $_SubC[$i], 'fullFlag' => false ), $_t );
				$_c = count( $Products );
				$_t = 1434;

				while ($_t < $_c) {
					if ($Products[$_t]['enabled']) {
						$_SESSION['selectedProducts'][$_SubC[$i]][$Products[$_t]['productID']] = 1;
					}

					++$_t;
				}
			}

			++$i;
		}
	}


	if (isset( $_POST['showProducts'] )) {
		$_POST['showProducts'] = intval( $_POST['showProducts'] );
		$Products = prdGetProductByCategory( array( 'categoryID' => intval( $_POST['showProducts'] ), 'fullFlag' => false ), $_t );
		foreach ($Products as $_ind => $_Product) {

			if (!$_Product['enabled']) {
				unset( $Products[$_ind] );
				continue;
			}
		}

		$smarty->assign( 'showProducts', $_POST['showProducts'] );
		$smarty->assign( 'Products', $Products );
		$cnt = count( $Products );
		$smarty->assign( 'ProductsNum', $cnt );
	}

	$smarty->assign( 'ProductCategories', $ProductCategories );
?>