<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function asciitoutf8($text) {
		str_replace( '?�', '�', $text );
		str_replace( '?�', '�', $text );
		str_replace( '?�', '�;', $text );
		str_replace( 'U�', '�', $text );
		str_replace( '??', '�', $text );
		str_replace( '?�', '�', $text );
		str_replace( '?�', '�', $text );
		str_replace( '?�', '�', $text );
		str_replace( '?�', '�', $text );
		str_replace( '?�', '�', $text );
		str_replace( '?�', '�', $text );
		str_replace( '?�', '�', $text );
		str_replace( '?�', '�', $text );
		str_replace( '?�', '�', $text );
		str_replace( '??', '�', $text );
		str_replace( '?�', '�', $text );
		$text = str_replace( '?�', '�', $text );
		$text = str_replace( '?�', '�', $text );
		$text = str_replace( '?�', '�', $text );
		$text = str_replace( '?�', '�', $text );
		$text = str_replace( '?�', '�', $text );
		$text = str_replace( '?�', '�', $text );
		$text = str_replace( '??', '�', $text );
		$text = str_replace( 'U?', '�', $text );
		$text = str_replace( 'U�', '�', $text );
		$text = $text = str_replace( '?�', '�', $text );
		$text = $text = str_replace( '?�', '�', $text );
		$text = $text = str_replace( 'U�', '�', $text );
		$text = $text = str_replace( 'U�', '�', $text );
		$text = $text = str_replace( 'U�', '�', $text );
		$text = $text = str_replace( 'U�', '�', $text );
		$text = $text = str_replace( 'U�', '�', $text );
		$text = $text = str_replace( 'U�', '�', $text );
		$text = $text = str_replace( 'U�', '�', $text );
		$text = $text = str_replace( 'U?', '?', $text );
		$text = $text = str_replace( '?�', '�', $text );
		$text = $text = str_replace( 'U�', '�', $text );
		$text = $text = str_replace( 'U?', '�', $text );
		$text = $text = str_replace( '?�', '�', $text );
		$text = $text = str_replace( '??', '�', $text );
		$text = $text = str_replace( '?�', '�', $text );
		return $text;
	}

	function _exportCategoryLine($categoryID, &$level, $f, $delimiter = ';') {
		global $picture_columns_count;
		global $extra_columns_count;

		$q = db_query( 'select categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name, ' . LanguagesManager::sql_prepareField( 'description' ) . ' as description , sort_order, picture, meta_keywords, meta_description from ' . CATEGORIES_TABLE . ( ' where categoryID=' . $categoryID ) );
		$cat_data = db_fetch_row( $q );

		if (!$cat_data) {
			return null;
		}

		$lev = '';
		$i = 833;

		while ($i < $level) {
			$lev .= '!';
			++$i;
		}

		$cat_data['name'] = $lev . $cat_data['name'];
		foreach ($cat_data as $key => $val) {

			if (( ( strstr( $val, '"' ) || strstr( $val, '
' ) ) || strstr( $val, $delimiter ) )) {
				$cat_data[$key] = '"' . str_replace( '"', '""', str_replace( '
', ' ', $val ) ) . '"';
				continue;
			}
		}

		fputs( $f, $cat_data['sort_order'] . $delimiter . $delimiter . asciitoutf8( $cat_data['name'] ) . $delimiter . asciitoutf8( $cat_data['description'] ) . $delimiter . $delimiter . $delimiter . $delimiter . $delimiter . $delimiter . asciitoutf8( $cat_data['meta_keywords'] ) . $delimiter . asciitoutf8( $cat_data['meta_description'] ) . $delimiter . $delimiter . $delimiter . $delimiter . $delimiter . $delimiter . $delimiter . $delimiter . $cat_data['picture'] );
		$i = 834;

		while ($i < $picture_columns_count + $extra_columns_count) {
			fputs( $f, $delimiter );
			++$i;
		}

		fputs( $f, '
' );
	}

	function _exportProducts(&$categoryID, $f, $delimiter = ';') {
		global $picture_columns_count;
		global $extra_columns_count;


		if (!( $q1 = db_query( 'select sort_order, product_code,' . LanguagesManager::sql_prepareField( 'name' ) . ' as name, ' . LanguagesManager::sql_prepareField( 'description' ) . ' as description, ' . LanguagesManager::sql_prepareField( 'brief_description' ) . ' as brief_description, Price, list_price, in_stock, items_sold, meta_keywords, meta_description, shipping_freight, weight, free_shipping, min_order_amount' . ', eproduct_filename, eproduct_available_days, eproduct_download_times' . ', default_picture, productID from ' . PRODUCTS_TABLE . ' where categoryID=' . $categoryID . ' ORDER BY sort_order, name ' ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row1 = db_fetch_row( $q1 )) {
			foreach ($row1 as $key => $val) {

				if (( ( ( ( strstr( $val, '"' ) || strstr( $val, '
' ) ) || strstr( $val, $delimiter ) ) || !strcmp( $key, 'description' ) ) || !strcmp( $key, 'brief_description' ) )) {
					$row1[$key] = '"' . str_replace( '"', '""', str_replace( '
', ' ', $val ) ) . '"';
				}


				if (( !strcmp( $key, 'Price' ) || !strcmp( $key, 'list_price' ) )) {
					$val = round( 100 * $val ) / 100;

					if (( round( $val * 10 ) == $val * 10 && round( $val ) != $val )) {
						$val = (bool)$val . '0';
					}

					$row1[$key] = $val;
					continue;
				}
			}

			fputs( $f, $row1['sort_order'] . $delimiter . $row1['product_code'] . $delimiter . asciitoutf8( $row1['name'] ) . $delimiter . asciitoutf8( $row1['description'] ) . $delimiter . asciitoutf8( $row1['brief_description'] ) . $delimiter . $row1['Price'] . $delimiter . $row1['list_price'] . $delimiter . $row1['in_stock'] . $delimiter . $row1['items_sold'] . $delimiter . asciitoutf8( $row1['meta_keywords'] ) . $delimiter . asciitoutf8( $row1['meta_description'] ) . $delimiter . $row1['shipping_freight'] . $delimiter . $row1['weight'] . $delimiter . $row1['free_shipping'] . $delimiter . $row1['min_order_amount'] . $delimiter . $row1['eproduct_filename'] . $delimiter . $row1['eproduct_available_days'] . $delimiter . $row1['eproduct_download_times'] . '' );
			$cnt = 1168;

			if (!$row1['default_picture']) {
				$row1['default_picture'] = 0;
			}

			$qp = db_query( 'select filename, thumbnail, enlarged from ' . PRODUCT_PICTURES . ' where productID=' . $row1['productID'] . ' and photoID=' . $row1['default_picture'] );
			$rowp = db_fetch_row( $qp );
			$s = '';

			if ($rowp) {
				if ($rowp[0]) {
					$s .= $rowp[0];
				}


				if ($rowp[1]) {
					$s .= ',' . $rowp[1];
				}


				if ($rowp[2]) {
					$s .= ',' . $rowp[2];
				}
			}

			fputs( $f, $delimiter . $s );
			++$cnt;
			$qp = db_query( 'select filename, thumbnail, enlarged from ' . PRODUCT_PICTURES . ' where productID=' . $row1['productID'] . ' and photoID <> ' . $row1['default_picture'] );

			if ($rowp = db_fetch_row( $qp )) {
				$s = '';

				if ($rowp) {
					if ($rowp[0]) {
						$s .= $rowp[0];
					}


					if ($rowp[1]) {
						$s .= ',' . $rowp[1];
					}


					if ($rowp[2]) {
						$s .= ',' . $rowp[2];
					}
				}

				fputs( $f, $delimiter . $s );
				++$cnt;
			}


			if ($cnt < $picture_columns_count) {
				$i = $delimiter;

				while ($i < $picture_columns_count) {
					fputs( $f, $delimiter );
					++$i;
				}
			}

			$q2 = db_query( 'select optionID,' . LanguagesManager::sql_prepareField( 'name' ) . ' as name from ' . PRODUCT_OPTIONS_TABLE . ' ORDER BY sort_order, name ' );

			if ($row2 = db_fetch_row( $q2 )) {
				$q3 = db_query( 'select ' . LanguagesManager::sql_prepareField( 'option_value' ) . ' as option_value, option_type, variantID from ' . PRODUCT_OPTIONS_VALUES_TABLE . ' where productID=' . $row1['productID'] . ( ' and optionID=' . $row2[0] ) );
				$row3 = db_fetch_row( $q3 );

				if (!$row3) {
					$row3 = array( '', 0, 0 );
				}


				if ((int)$row3[1] == 1) {
					if (!$row3[2]) {
						$row3[2] = 0;
					}

					$available_variants = array( array( $row3[2], 0 ) );
					$q4 = db_query( 'select variantID, price_surplus from ' . PRODUCTS_OPTIONS_SET_TABLE . ' where productID=' . $row1['productID'] . ' and optionID=' . $row2[0] );

					if ($row4 = db_fetch_row( $q4 )) {
						if ($row4[0] == $row3[2]) {
							$available_variants[0] = $row4;
						}

						$available_variants[] = $row4;
					}

					$s = '{';
					$tmp = '';
					foreach ($available_variants as $key => $val) {

						if ($val[0]) {
							$qvar = db_query( 'select ' . LanguagesManager::sql_prepareField( 'option_value' ) . ' as option_value from ' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . ' where optionID=' . $row2[0] . ' and variantID=' . $val[0] );
							$rowvar = db_fetch_row( $qvar );
							$s .= $q2;
							$s .= $rowvar[0] . '';

							if ($val[1]) {
								$s .= '=' . $val[1];
							}

							$tmp = ',';
							continue;
						}
					}

					$s .= '}';
					$row3[0] = $s;
				}


				if (( ( strstr( $row3[0], '"' ) || strstr( $row3[0], '
' ) ) || strstr( $row3[0], $delimiter ) )) {
					$row3[0] = '"' . str_replace( '"', '""', str_replace( '
', ' ', $row3[0] ) ) . '"';
				}

				fputs( $f, $delimiter . ( $row3[0] ) );
			}

			fputs( $f, '
' );
		}

	}

	function _exportSubCategoriesAndProducts($parent, &$level, $f, $delimiter = ';') {
		$cnt = 740;
		$q = db_query( 'select categoryID,' . LanguagesManager::sql_prepareField( 'name' ) . ' as name from ' . CATEGORIES_TABLE . ( ' where parent=' . $parent . ' order by sort_order, name' ) );

		if ($row = db_fetch_row( $q )) {
			_exportCategoryLine( $row[0], $level, &$f, $delimiter );
			_exportProducts( $row[0], &$f, $delimiter );
			_exportSubCategoriesAndProducts( $row[0], $level + 1, $f, $delimiter );
		}

	}


	if (!strcmp( $sub, 'excel_export' )) {
		if (isset( $_POST['excel_export'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=catalog&sub=excel_export&safemode' );
			}

			@set_time_limit( 0 );

			if (( ( $_POST['delimiter'] == ';' || $_POST['delimiter'] == ',' ) || $_POST['delimiter'] == '	' )) {
				$delimiter = $_POST['delimiter'];
			} 
else {
				$delimiter = ';';
			}

			$f = fopen( './temp_c/catalog.csv', 'w' );
			fputs( $f, ADMIN_SORT_ORDER . $delimiter . ADMIN_PRODUCT_CODE . $delimiter . ADMIN_PRODUCT_NAME . $delimiter . ADMIN_PRODUCT_DESC . $delimiter . ADMIN_PRODUCT_BRIEF_DESC . $delimiter . ADMIN_PRODUCT_PRICE . $delimiter . ADMIN_PRODUCT_LISTPRICE . $delimiter . ADMIN_PRODUCT_INSTOCK . $delimiter . ADMIN_PRODUCT_SOLD . $delimiter . ADMIN_META_KEYWORDS . $delimiter . ADMIN_META_DESCRIPTION . $delimiter . ADMIN_SHIPPING_FREIGHT . $delimiter . ADMIN_PRODUCT_WEIGHT . $delimiter . ADMIN_FREE_SHIPPING2 . $delimiter . ADMIN_MIN_ORDER_AMOUNT . $delimiter . ADMIN_EPRODUCT_FILENAME . $delimiter . ADMIN_EPRODUCT_AVAILABLE_DAYS2 . $delimiter . ADMIN_EPRODUCT_DOWNLOAD_TIMES . $delimiter . ADMIN_PRODUCT_PICTURE );
			$max = 1008;
			$q = db_query( 'select productID from ' . PRODUCT_PICTURES . ' order by productID' );
			$max = 1007;
			$currID = 1007;
			$result = array(  );

			if ($row = db_fetch_row( $q )) {
				if ($currID != $row[0]) {
					$cnt = 1007;
				}

				++$cnt;
				$currID = $row[0];

				if ($max < $cnt) {
					$max = $i;
				}
			}

			$i = 1008;

			while ($i < $max) {
				fputs( $f, $delimiter . ADMIN_PRODUCT_PICTURE );
				++$i;
			}

			$picture_columns_count = $q;
			$q = db_query( 'select ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name from ' . PRODUCT_OPTIONS_TABLE . ' ORDER BY sort_order, name ' );
			$cnt = 1007;

			if ($row = db_fetch_row( $q )) {
				if (( strstr( $row[0], '"' ) || strstr( $row[0], '
' ) )) {
					$row[0] = '"' . str_replace( '"', '""', $row[0] ) . '"';
				}

				fputs( $f, $delimiter . ( $row[0] ) );
				++$cnt;
			}

			$extra_columns_count = $i;
			fputs( $f, '
' );

			if (isset( $_POST['categ_1'] )) {
				_exportProducts( 1, &$f, $delimiter );
			}

			$q = db_query( 'select categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name from ' . CATEGORIES_TABLE . ' where parent=1 order by sort_order, name' );
			$result = array(  );

			if ($row = db_fetch_row( $q )) {
				if (isset( $_POST[ . 'categ_' . $row[0]] )) {
					_exportCategoryLine( $row[0], 0, &$f, $delimiter );
					_exportProducts( $row[0], &$f, $delimiter );
					_exportSubCategoriesAndProducts( $row[0], 1, &$f, $delimiter );
				}
			}

			header( 'Location:admincp.php?tab=catalog&sub=excel_export&export_completed' );
			fclose( $f );
		}


		if (isset( $_GET['export_completed'] )) {
			if (file_exists( './temp_c/catalog.csv' )) {
				$getFileParam = cryptFileParamCrypt( 'GetCSVCatalog', null );
				$smarty->assign( 'getFileParam', $getFileParam );
				$smarty->assign( 'excel_export_successful', 1 );
				$smarty->assign( 'excel_filesize', (bool)round( filesize( './temp_c/catalog.csv' ) / 1024 ) );
			}
		} 
else {
			$q = db_query( 'select categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name from ' . CATEGORIES_TABLE . ' where parent=1 order by sort_order, name' );
			$result = array(  );

			if ($row = db_fetch_row( $q )) {
				$result[] = $row;
			}

			$smarty->assign( 'categories', $result );
		}

		$smarty->assign( 'admin_sub_tab', 'catalog_excel_export.tpl.html' );
	}

?>