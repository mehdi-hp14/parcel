<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'googleanalytic' )) {
		$enable_ga = CONF_GOOGLE_ANALYSTICS_ENABLED;
		$settings_groupID = 758;

		if (( isset( $_POST ) && 0 < count( $_POST ) )) {
			_setSettingOptionValue( 'CONF_GOOGLE_ANALYSTICS_ENABLED', $_POST['enable_ga'] );
			$enable_ga = $_POST['enable_ga'];
			$smarty->assign( 'MessageBlock', '<p class="success" id="messge"> <font color="green"><b>' . MOD_NEWS_TXT_EDIT_OK . '</b></font> </p>' );
		}

		$settings = settingGetSettings( $settings_groupID );
		$smarty->assign( 'settings', $settings );
		$smarty->assign( 'enable_ga', $enable_ga );
		$smarty->assign( 'controls', settingCallHtmlFunctions( $settings_groupID ) );
		$smarty->assign( 'admin_sub_tab', 'conf_googleanalytic.tpl.html' );
	}

?>