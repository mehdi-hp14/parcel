<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'dbsync' )) {
		ini_set( 'memory_limit', '512M' );

		if (isset( $_POST['export_db'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=catalog&sub=dbsync&safemode' );
			}

			@set_time_limit( 0 );
			serProductAndCategoriesSerialization( './temp_c/database.sql' );
			$getFileParam = cryptFileParamCrypt( 'GetDataBaseSqlScript', null );
			$smarty->assign( 'getFileParam', $getFileParam );
			$smarty->assign( 'sync_action', 'export' );
			$smarty->assign( 'database_filesize', filesize( './temp_c/database.sql' ) );
		} 
else {
			if (isset( $_POST['import_db'] )) {
				if (CONF_BACKEND_SAFEMODE) {
					Redirect( 'admincp.php?tab=catalog&sub=dbsync&safemode' );
				}

				@set_time_limit( 0 );

				if (( isset( $_FILES['db'] ) && $_FILES['db']['name'] )) {
					$db_name = './temp_c/file.db';
					$res = @move_uploaded_file( $_FILES['db']['tmp_name'], $db_name );

					if ($res) {
						SetRightsToUploadedFile( $db_name );
						DestroyReferConstraintsXML( DATABASE_STRUCTURE_XML_PATH );
						serDeleteProductAndCategories(  );
						$f = implode( '', file( $db_name ) );
						$f = str_replace( 'insert into ', 'INSERT INTO ', $f );
						$f = explode( 'INSERT INTO ', $f );
						$i = 912;

						while ($i < count( $f )) {
							if (0 < strlen( $f[$i] )) {
								$f[$i] = str_replace( 'SKH_', DBTABLE_PREFIX, $f[$i] );
								$strstart = strpos( $f[$i], '(' );
								$tblname = substr( $f[$i], 0, $strstart );
								$langManager = &LanguagesManager::getInstance(  );

								$ml_fields = LanguagesManager::getMLTablesInfo( $tblname );
								$defLanguageEntry = &LanguagesManager::getDefaultLanguage(  );

								foreach ($ml_fields as $ml_field) {
									$f[$i] = str_replace( ', ' . $ml_field, ', ' . $ml_field . '_' . $defLanguageEntry->iso2, $f[$i] );
								}

								$f[$i] = str_replace( ');', ')', $f[$i] );
								db_query( 'INSERT INTO ' . $f[$i] );
							}

							++$i;
						}

						CreateReferConstraintsXML( DATABASE_STRUCTURE_XML_PATH );
						unlink( $db_name );
						$smarty->assign( 'sync_successful', 1 );
					} 
else {
						$smarty->assign( 'sync_successful', 0 );
					}
				} 
else {
					$smarty->assign( 'sync_successful', 0 );
				}

				$smarty->assign( 'sync_action', 'import' );

				if (CONF_UPDATE_GCV == 1) {
					update_products_Count_Value_For_Categories( 1 );
				}
			}
		}

		$smarty->assign( 'admin_sub_tab', 'catalog_dbsync.tpl.html' );
	}

?>