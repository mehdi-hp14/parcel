<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'about' )) {
		$system_info = get_system_info(  );
		$system_info[] = array( ADMIN_MEMORY_LIMIT, ini_get( 'memory_limit' ) );
		$curl = curl_version(  );
		$system_info[] = array( 'cURL', $curl['version'] );
		$system_info[] = array( 'Server IP', $_SERVER['SERVER_ADDR'] );
		$system_info[] = array( ADMIN_VERSION, STRING_VERSION );
		$smarty->assign( 'system_info', $system_info );
		$smarty->assign( 'admin_sub_tab', 'support_about.tpl.html' );
	}

?>