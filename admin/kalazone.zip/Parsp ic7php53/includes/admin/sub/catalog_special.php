<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'special' )) {
		if (isset( $_GET['save_successful'] )) {
			$smarty->assign( 'save_successful', ADMIN_UPDATE_SUCCESSFUL );
		}


		if (isset( $_POST['save_offers'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=catalog&sub=special&safemode' );
			}


			if (!( db_query( 'delete from ' . SPECIAL_OFFERS_TABLE ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			$offers = array(  );
			foreach ($_POST as $key => $val) {

				if (strstr( $key, 'offer_productID_' ) != false) {
					$a = str_replace( 'offer_productID_', '', $key );
					$offers[$a]['productID'] = $val;
				}


				if (strstr( $key, 'offer_sort_' ) != false) {
					$a = str_replace( 'offer_sort_', '', $key );
					$offers[$a]['sort'] = $val;
					continue;
				}
			}

			foreach ($offers as $key => $value) {
				$value['sort'] = (int)$value['sort'];

				if (!( db_query( 'insert into ' . SPECIAL_OFFERS_TABLE . ' (offerID, productID, sort_order) ' . ( ' values (\'' . $key . '\', \'' ) . $value['productID'] . '\', \'' . $value['sort'] . '\')' ))) {
					exit( db_error(  ) );
					(bool)true;
				}
			}

			Redirect( 'admincp.php?tab=catalog&sub=special&save_successful' );
		}


		if (isset( $_GET['new_offer'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=catalog&sub=special&safemode' );
			}


			if (!( db_query( 'insert into ' . SPECIAL_OFFERS_TABLE . ' (productID, sort_order) values (\'' . $_GET['new_offer'] . '\',0)' ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			Redirect( 'admincp.php?tab=catalog&sub=special' );
		}


		if (isset( $_GET['delete'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=catalog&sub=special&safemode' );
			}


			if (!( db_query( 'delete from ' . SPECIAL_OFFERS_TABLE . ' where offerID=\'' . $_GET['delete'] . '\'' ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			Redirect( 'admincp.php?tab=catalog&sub=special' );
		}


		if (!( $q = db_query( 'select offerID, productID, sort_order from ' . SPECIAL_OFFERS_TABLE . ' order by sort_order' ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$result = array(  );

		if ($row = db_fetch_row( $q )) {

			if (!( $q1 = db_query( 'select categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name from ' . PRODUCTS_TABLE . ( ' where productID=' . $row[1] ) ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if ($row1 = db_fetch_row( $q1 )) {
				$row[3] = $row1[0];
				$row[4] = $row1[1];
				$result[] = $row;
			}
		}

		$smarty->assign( 'offers', $result );
		$smarty->assign( 'admin_sub_tab', 'catalog_special.tpl.html' );
	}

?>