<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'icon' )) {
		if (isset( $_POST['do'] )) {
			if ($_POST['do'] == 'create') {
				if (isset( $_POST['savesetting'] )) {
					$postvars = array( 'image' => trim( $_FILES['image']['name'] ), 'image_tmp' => $_FILES['image']['tmp_name'], 'image_size' => (int)$_FILES['image']['size'], 'image_dimensions' => (int)$_POST['image_dimensions'] );
					$generate_favicon = '<p class="success" id="messge"> <font color="green"><b>' . generate_favicon( $postvars, './favicon' ) . '</b></font> </p>';
					$smarty->assign( 'MessageBlock', $generate_favicon );
				}
			}
		}

		$smarty->assign( 'admin_sub_tab', 'layout_icon.tpl.html' );
	}

?>