<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'countries' )) {
		$_POST = xStripSlashesGPC( $_POST );
		function _getUrlToDelete() {
			$res = 'admincp.php?tab=conf&sub=countries';

			if (isset( $_GET['offset'] )) {
				$res .= '&offset=' . $_GET['offset'];
			}


			if (isset( $_GET['show_all'] )) {
				$res .= '&show_all=' . $_GET['show_all'];
			}

			return $res;
		}

		function _getUrlToSubmit() {
			return _getUrlToDelete(  );
		}


		if (isset( $_GET['delete'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( _getUrlToDelete(  ) . '&safemode' );
			}

			cnDeleteCountry( $_GET['delete'] );
			Redirect( _getUrlToDelete(  ) );
		}


		if (isset( $_POST['save_countries'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( _getUrlToSubmit(  ) . '&safemode' );
			}

			$data = scanArrayKeysForID( $_POST, array( 'country_name_\w{2}', 'country_iso2', 'country_iso3' ) );
			foreach ($data as $key => $val) {
				cnUpdateCountry( $key, $val, $val['country_iso2'], $val['country_iso3'] );
			}

			$iso2 = $_POST['new_country_iso2'];
			$iso3 = $_POST['new_country_iso3'];

			if (!LanguagesManager::ml_isEmpty( 'new_country_name', $_POST )) {
				cnAddCountry( $_POST, $iso2, $iso3 );
			}

			Redirect( _getUrlToSubmit(  ) );
		}

		$callBackParam = array( 'raw data' => true );
		$countries = array(  );
		$count = 832;
		$navigatorHtml = GetNavigatorHtml( 'admincp.php?tab=conf&sub=countries', 20, 'cnGetCountries', $callBackParam, $countries, $offset, $count );

		if (isset( $_POST['save_countries'] )) {
			Redirect( _getUrlToSubmit(  ) );
		}

		$smarty->assign( 'urlToDelete', _getUrlToDelete(  ) );
		$smarty->assign( 'urlToSubmit', _getUrlToSubmit(  ) );
		$smarty->assign( 'countries', $countries );
		$smarty->assign( 'navigator', $navigatorHtml );
		$smarty->assign( 'admin_sub_tab', 'conf_countries.tpl.html' );
	}

?>