<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'setting' )) {
		$setting_groups = settingGetAllSettingGroup(  );
		$smarty->assign( 'setting_groups', $setting_groups );

		if (( isset( $_POST ) && 0 < count( $_POST ) )) {
			if (CONF_BACKEND_SAFEMODE) {
				if (isset( $_GET['settings_groupID'] )) {
					Redirect( 'admincp.php?tab=conf&sub=setting&settings_groupID=' . $_GET['settings_groupID'] . '&safemode' );
				} 
else {
					Redirect( 'admincp.php?tab=conf&sub=setting&safemode' );
				}
			}
		}


		if (isset( $_GET['settings_groupID'] )) {
			$settings = settingGetSettings( $_GET['settings_groupID'] );
			$smarty->assign( 'settings', $settings );
			$smarty->assign( 'controls', settingCallHtmlFunctions( $_GET['settings_groupID'] ) );
			$smarty->assign( 'settings_groupID', $_GET['settings_groupID'] );
		}


		if (( isset( $_POST['savesetting'] ) && $_POST['mainsetting'] == 1 )) {
			$markerline1 = '';

			if (( $_POST['settingCONF_DEFAULT_TURBO'] == 1 || $_POST['def_settingCONF_DEFAULT_TURBO'] == 1 )) {
				$markerline1 = '
                        # compress text, html, javascript, css, xml: 
                        AddOutputFilterByType DEFLATE text/plain 
                        AddOutputFilterByType DEFLATE text/html
                        AddOutputFilterByType DEFLATE text/xml
                        AddOutputFilterByType DEFLATE text/css
                        AddOutputFilterByType DEFLATE application/xml
                        AddOutputFilterByType DEFLATE application/xhtml+xml
                        AddOutputFilterByType DEFLATE application/rss+xml
                        AddOutputFilterByType DEFLATE application/javascript
                        AddOutputFilterByType DEFLATE application/x-javascript

                        # Or, compress certain file types by extension:
                        <files *.html>
                        SetOutputFilter DEFLATE
                        </files>

                        #php_flag display_errors 0
                        AddDefaultCharset UTF-8
                        Options -Indexes
                        ';
			}


			if (( $_POST['settingCONF_DEFAULT_SEO'] == 1 || $_POST['def_settingCONF_DEFAULT_SEO'] == 1 )) {
				$markerline1 = (empty( $$markerline1 ) ? $markerline1 : '') . ' 
            # FastCGI http authorization
                       # FastCGI http authorization

            <IfModule mod_rewrite.c>            
            RewriteEngine on
            RewriteRule ^category/([0-9]+)/([^/]+)/(.*)$ index.php?categoryID=$1&name=$2&$3 [L] 
            RewriteRule ^category/([0-9]+)/([^/]+)/(.*)$ index.php?categoryID=$1&name=$2&$3 [L]
            RewriteRule ^product/([0-9]+)/([^/]+)/(.*)$ index.php?productID=$1&name=$2&$3 [L]
            RewriteRule ^page/([0-9]+)/([^/]+)/(.*)$ index.php?view_content=$1&name=$2&$3 [L]
            RewriteRule ^MyAccount/(.*)$ index.php?user_details=1&$1 [L]
            RewriteRule ^Price-List/([^/]+)/([^/]+) index.php?show_price=1&sort=$1&direction=$2 [NC]
            RewriteRule ^Price-List/ index.php?show_price=1 [NC]            
            RewriteRule ^Contact-Us/(.*)$ index.php?feedback=1&$1 [L]
            RewriteRule ^links_exchange/(.*)$ index.php?links_exchange=1&$1 [L]                                    
            RewriteRule ^register/(.*)$ index.php?register=1&$1 [L]            
            </IfModule>
            ';
			}

			$filename = '.htaccess';

			if ($markerline1 != '') {
				file_put_contents( $filename, $markerline1 );
			}
		}


		if (( !isset( $_GET['settings_groupID'] ) && 0 < count( $setting_groups ) )) {
			header( 'Location: admincp.php?tab=conf&sub=setting&settings_groupID=' . $setting_groups[0]['settings_groupID'] );
		}
	}

	$smarty->assign( 'admin_sub_tab', 'conf_setting.tpl.html' );
?>