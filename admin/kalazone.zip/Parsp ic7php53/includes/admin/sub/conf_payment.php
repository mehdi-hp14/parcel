<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'payment' )) {
		$shipping_methods = shGetAllShippingMethods(  );
		$moduleFiles = GetFilesInDirectory( './includes/modules/payment', 'php' );
		foreach ($moduleFiles as $fileName) {
			include( $fileName );
		}


		if (isset( $_GET['save_successful'] )) {
			$smarty->assign( 'configuration_saved', 1 );
		}


		if (isset( $_GET['delete'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=payment&safemode' );
			}

			payDeletePaymentMethod( $_GET['delete'] );
			Redirect( 'admincp.php?tab=conf&sub=payment' );
		}


		if (isset( $_POST['save_payment'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=payment&safemode' );
			}

			$_POST = array_merge( $_POST, $_FILES );
			$values = scanArrayKeysForID( $_POST, array( 'name_\w{2}', 'description_\w{2}', 'email_comments_text_\w{2}', 'Enabled', 'sort_order', 'module', 'thumbnail_logo', 'thumbnaillogo' ) );
			foreach ($values as $PID => $value) {

				if (( isset( $value['thumbnaillogo'] ) && $value['thumbnail_logo']['name'] == '' )) {
					$thumnaillogo = $value['thumbnaillogo'];
				} 
else {
					$thumnaillogo = $value['thumbnail_logo']['name'];
					$r = move_uploaded_file( $value['thumbnail_logo']['tmp_name'], './uploads/logos/' . $thumnaillogo );
				}

				payUpdatePaymentMethod( $PID, $value, (isset( $value['Enabled'] ) ? 1 : 0), (int)$value['sort_order'], $value['module'], (isset( $value['calculate_tax'] ) ? 1 : 0), $thumnaillogo );
				payResetPaymentShippingMethods( $PID );
				foreach ($shipping_methods as $shipping_method) {

					if (isset( $_POST['ShippingMethodsToAllow_' . $PID . '_' . $shipping_method['SID']] )) {
						paySetPaymentShippingMethod( $PID, $shipping_method['SID'] );
						continue;
					}
				}
			}


			if (!LanguagesManager::ml_isEmpty( 'new_name', $_POST )) {
				$r = move_uploaded_file( $_FILES['new_thumbnail_logo']['tmp_name'], './uploads/logos/' . $_FILES['new_thumbnail_logo']['name'] );
				$PID = payAddPaymentMethod( $_POST, (isset( $_POST['new_Enabled'] ) ? 1 : 0), (int)$_POST['new_sort_order'], $_POST['new_module'], (isset( $_POST['new_calculate_tax'] ) ? 1 : 0), $_FILES['new_thumbnail_logo']['name'] );
				foreach ($shipping_methods as $shipping_method) {

					if (isset( $_POST['new_ShippingMethodsToAllow_' . $shipping_method['SID']] )) {
						paySetPaymentShippingMethod( $PID, $shipping_method['SID'] );
						continue;
					}
				}
			}

			Redirect( 'admincp.php?tab=conf&sub=payment&save_successful' );
		}

		$smarty->assign( 'payment_types', payGetAllPaymentMethods(  ) );
		$smarty->assign( 'payment_modules', modGetAllInstalledModuleObjs( PAYMENT_MODULE ) );
		$smarty->assign( 'shipping_methods', $shipping_methods );
		$smarty->assign( 'admin_sub_tab', 'conf_payment.tpl.html' );
	}

?>