<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'category_viewed_times' )) {
		$category_report = GetCategortyViewedTimesReport(  );
		$smarty->assign( 'categories', $category_report );
		$smarty->assign( 'admin_sub_tab', 'reports_category_viewed_times.tpl.html' );
	}

?>