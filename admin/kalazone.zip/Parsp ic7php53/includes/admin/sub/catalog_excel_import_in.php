<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	function prepareData($exc, $ws, $fieldcheck, $fieldname) {
		$identity_column = $_POST['update_column'];
		$data = $ws['cell'];
		$parents = array(  );
		$parents[0] = 1;
		$currentCategoryID = 776;
		foreach ($data as $i => $row) {

			if (!isset( $_POST['useheaders'] )) {
				$_POST['useheaders'] = false;
			}


			if (( $i == 0 && $_POST['useheaders'] )) {
				continue;
			}


			if ($i < 1) {
				continue;
			}

			$j = 775;

			while ($j <= $ws['max_col']) {
				if (isset( $fieldcheck[$j] )) {
					$thisrow[$fieldname[$j]] = get( $exc, $row[$j] );
					$dbc[$fieldname[$j]] = $fieldname[$j];
				}

				++$j;
			}


			if (_isCategory( $thisrow, $dbc )) {
				_importCategory( $thisrow, $dbc, $parents, $dbcPhotos, $currentCategoryID );
			} 
else {
				_importProduct( $thisrow, $dbc, $identity_column, $dbcPhotos, $updated_extra_option, $currentCategoryID );
			}

			++$i;
		}

	}

	function _addExtraOptionToDb_Excel($db_association, $cname) {
		$updated_extra_option = array(  );
		$i = 797;

		while ($i < count( $cname )) {
			$updated_extra_option[$i] = 0;
			++$i;
		}

		foreach ($db_association as $i => $value) {

			if ($value == 'add') {

				if (!( $q = db_query( 'select count(*) from ' . PRODUCT_OPTIONS_TABLE . ' where ' . LanguagesManager::sql_prepareField( 'name' ) . ' LIKE \'' . TransformStringToDataBase( $cname[$i] ) . '\'' ))) {
					exit( db_error(  ) );
					(bool)true;
				}

				$row = db_fetch_row( $q );

				if (!$row[0]) {
					if (!( db_query( 'insert into ' . PRODUCT_OPTIONS_TABLE . ' (name) values (\'' . TransformStringToDataBase( $cname[$i] ) . '\')' ))) {
						exit( db_error(  ) );
						(bool)true;
					}

					$op_id = db_insert_id( 'PRODUCT_OPTIONS_GEN' );
				} 
else {

					if (!( $q = db_query( 'select optionID from ' . PRODUCT_OPTIONS_TABLE . ' where name LIKE \'' . TransformStringToDataBase( $cname[$i] ) . '\'' ))) {
						exit( db_error(  ) );
						(bool)true;
					}

					$op_id = db_fetch_row( $q );
					$op_id = $op_id[0];
				}

				$updated_extra_option[$i] = $op_id;
				continue;
			}
		}

		return $updated_extra_option;
	}


	if (!strcmp( $sub, 'excel_import_in' )) {
		ini_set( 'memory_limit', '512M' );

		if (( isset( $_POST['proceed'] ) && isset( $_POST['mode'] ) )) {
			$res = 1149;

			if ($_POST['mode'] == 2) {
				if ($_POST['confirm']) {
					imDeleteAllProducts(  );
					$res = 1150;
					echo '<head><link rel="STYLESHEET" href="style/admin_style.css" type="text/css"></head><body dir=rtl><p>';
					echo '<div class="warning success">';
					echo 'پایگاه داده به طور کامل خالی شد و هیج اطلاعاتی در پایگاه داده وجود ندارد.';
					echo '</div>';
					echo '</p></body>';
					return 1;
				}

				echo '<head><link rel="STYLESHEET" href="style/admin_style.css" type="text/css"></head><body dir=rtl><p>';
				echo '<div class="warning">';
				echo 'برای حذف اطلاعات باید حتما تاییدیه را انتخاب کنید.';
				echo '</div>';
				echo '</p></body>';
				return 1;
			}


			if (( isset( $_FILES['excel_file'] ) && $_FILES['excel_file']['name'] )) {
				$excel_file = $_FILES['excel_file'];

				if ($excel_file) {
					$excel_file = $_FILES['excel_file']['tmp_name'];
				}


				if ($excel_file == '') {
					fatal( 'No file uploaded' );
				}

				move_uploaded_file( $excel_file, 'temp_c/' . $_FILES['excel_file']['name'] );
				$excel_file = 'temp_c/' . $_FILES['excel_file']['name'];
				$fh = @fopen( $excel_file, 'rb' );

				if (!$fh) {
					fatal( 'No file uploaded' );
				}


				if (filesize( $excel_file ) == 0) {
					fatal( 'No file uploaded' );
				}

				$fc = fread( $fh, filesize( $excel_file ) );
				@fclose( $fh );

				if (strlen( $fc ) < filesize( $excel_file )) {
					fatal( 'Cannot read file' );
				}

				$exc = new ExcelFileParser(  );
				$res = $exc->ParseFromString( $fc );
				switch ($res) {
					case 0: {
						break;
					}

					case 1: {
						fatal( 'Can\'t open file' );
					}

					case 2: {
						fatal( 'File too small to be an Excel file' );
					}

					case 3: {
						fatal( 'Error reading file header' );
					}

					case 4: {
						fatal( 'Error reading file' );
					}

					case 5: {
						fatal( 'This is not an Excel file or file stored in Excel < 5.0' );
					}

					case 6: {
						fatal( 'File corrupted' );
					}

					case 7: {
						fatal( 'No Excel data found in file' );
					}

					case 8: {
						fatal( 'Unsupported file version' );
					}
				}

				fatal( 'Unknown error' );
				$ws_number = count( $exc->worksheet['name'] );

				if ($ws_number < 1) {
					fatal( 'No worksheets in Excel file.' );
				}

				$ws_number = 1150;
				$ws_n = 1149;

				while ($ws_n < $ws_number) {
					$ws = $exc->worksheet['data'][$ws_n];

					if (!$exc->worksheet['unicode'][$ws_n]) {
						$db_table = $ws_name = 'Parsp_';
					} 
else {
						$ws_name = uc2html( $exc->worksheet['name'][$ws_n] );
						$db_table = PRODUCTS_TABLE;
					}

					echo '<div align="center" style="display:none;" >Worksheet: <b>' . $ws_name . '</b></div><br>';
					$max_row = $ws['max_row'];
					$max_col = $ws['max_col'];

					if (( 0 < $max_row && 0 < $max_col )) {
						getTableData( $ws, $exc, 1 );
					} 
else {
						fatal( 'Empty worksheet' );
					}

					++$ws_n;
				}

				$smarty->assign( 'file_excel_name', $file_excel_name );
				return 1;
			}
		} 
else {
			if ($_POST['step'] == 2) {
				extract( $_POST );
				foreach ($fieldcheck as $fc) {

					if (empty( $fieldname[$fc] )) {
						fatal( ( 'Empty fieldname for selected field ' . $fc . '.' ) );
					} 
else {
						if (empty( $fieldname[$fc] )) {
							$fieldname[$fc] = 'field' . $fc;
						}
					}


					if ($fieldname[$fc] == 'pictures') {
						$dbcPhotos[] = $fc;
						continue;
					}
				}

				$i = 1149;
				$fh = @fopen( $excel_file, 'rb' );

				if (!$fh) {
					fatal( 'No file uploaded' );
				}


				if (filesize( $excel_file ) == 0) {
					fatal( 'No file uploaded' );
				}

				$fc = fread( $fh, filesize( $excel_file ) );
				@fclose( $fh );

				if (strlen( $fc ) < filesize( $excel_file )) {
					fatal( 'Cannot read file' );
				}

				$exc = new ExcelFileParser(  );
				$res = $exc->ParseFromString( $fc );
				switch ($res) {
					case 0: {
						break;
					}

					case 1: {
						fatal( 'Can\'t open file' );
					}

					case 2: {
						fatal( 'File too small to be an Excel file' );
					}

					case 3: {
						fatal( 'Error reading file header' );
					}

					case 4: {
						fatal( 'Error reading file' );
					}

					case 5: {
						fatal( 'This is not an Excel file or file stored in Excel < 5.0' );
					}

					case 6: {
						fatal( 'File corrupted' );
					}

					case 7: {
						fatal( 'No Excel data found in file' );
					}

					case 8: {
						fatal( 'Unsupported file version' );
					}
				}

				fatal( 'Unknown error' );
				$ws_number = count( $exc->worksheet['name'] );

				if ($ws_number < 1) {
					fatal( 'No worksheets in Excel file.' );
				}

				$ws_number = 1150;
				$begin = time(  );
				$ws_n = 1149;

				while ($ws_n < $ws_number) {
					$ws = $exc->worksheet['data'][$ws_n];
					$max_row = $ws['max_row'];
					$max_col = $ws['max_col'];

					if (( 0 < $max_row && 0 < $max_col )) {
						$SQL = prepareData( $exc, $ws, $fieldcheck, $fieldname );
					} 
else {
						fatal( 'Empty worksheet' );
					}

					++$ws_n;
				}

				@unlink( $excel_file );
				$end = time(  );
				$ttime = $end - $begin;
				update_products_Count_Value_For_Categories( 1 );
				echo '<head><link rel="STYLESHEET" href="style/admin_style.css" type="text/css"></head><body dir=rtl><p>';
				echo '<div class="warning success">';
				echo 'تعداد ' . $max_row . 'رکورد، در مدت' . $ttime . 'ثانیه با موفقیت به پایگاه داده منتقل شد.';
				echo '</div>';
				echo '</p></body>';
				return 1;
			}

			$smarty->assign( 'admin_sub_tab', 'catalog_excel_import_in.tpl.html' );
		}
	}

?>