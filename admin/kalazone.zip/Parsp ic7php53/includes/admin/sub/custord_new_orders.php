<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	ini_set( 'memory_limit', '64M' );

	if (!strcmp( $sub, 'new_orders' )) {
		if (!isset( $_GET['urlToReturn'] )) {
			$_GET['urlToReturn'] = '';
		}

		$order_detailes = ( isset( $_POST['orders_detailed'] ) || isset( $_GET['orders_detailed'] ) );

		if (!$order_detailes) {
			$order_statuses = ostGetOrderStatues(  );
			function _setCallBackParamsToSearchOrders($callBackParam) {
				if (isset( $_GET['sort'] )) {
					$callBackParam['sort'] = $_GET['sort'];
				}


				if (isset( $_GET['direction'] )) {
					$callBackParam['direction'] = $_GET['direction'];
				}


				if ($_GET['order_search_type'] == 'SearchByOrderID') {
					$callBackParam['orderID'] = (int)$_GET['orderID_textbox'];
					return null;
				}


				if ($_GET['order_search_type'] == 'SearchByStatusID') {
					$orderStatuses = array(  );
					$data = ScanGetVariableWithId( array( 'checkbox_order_status' ) );
					foreach ($data as $key => $val) {

						if ($val['checkbox_order_status'] == '1') {
							$orderStatuses[] = $key;
							continue;
						}
					}

					$callBackParam['orderStatuses'] = $orderStatuses;
					return null;
				}


				if ($_GET['order_search_type'] == 'SearchByCondition') {
					$callBackParam['from_date'] = gregorian( $_GET['from_year'], $_GET['from_month'], $_GET['from_day'] );
					$callBackParam['till_date'] = gregorian( $_GET['till_year'], $_GET['till_month'], $_GET['till_day'] );
					$callBackParam['customer_name'] = $_GET['c_name'];
					$callBackParam['customer_lname'] = $_GET['c_lastname'];
					$callBackParam['customer_email'] = $_GET['c_email'];

					if (( isset( $_GET['c_ip'] ) && $_GET['c_ip'] != '' )) {
						$callBackParam['customer_ip'] = $_GET['c_ip'];
					}
				}

			}

			function _copyDataFromGetToPage(&$smarty, $order_statuses) {
				if (isset( $_GET['order_search_type'] )) {
					$smarty->assign( 'order_search_type', $_GET['order_search_type'] );
				}


				if (isset( $_GET['orderID_textbox'] )) {
					$smarty->assign( 'orderID', (int)$_GET['orderID_textbox'] );
				}

				$data = ScanGetVariableWithId( array( 'checkbox_order_status' ) );
				$i = 756;

				while ($i < count( $order_statuses )) {
					$order_statuses[$i]['selected'] = 0;
					++$i;
				}

				foreach ($data as $key => $val) {

					if ($val['checkbox_order_status'] == '1') {
						$i = 756;

						while ($i < count( $order_statuses )) {
							if ((int)$order_statuses[$i]['statusID'] == (int)$key) {
								$order_statuses[$i]['selected'] = 1;
							}

							++$i;
						}

						continue;
					}
				}

			}

			function _getReturnUrl() {
				$url = 'admincp.php?tab=custord&sub=new_orders';

				if (isset( $_GET['order_search_type'] )) {
					$url .= '&order_search_type=' . $_GET['order_search_type'];
				}


				if (isset( $_GET['orderID_textbox'] )) {
					$url .= '&orderID_textbox=' . $_GET['orderID_textbox'];
				}

				$data = ScanGetVariableWithId( array( 'checkbox_order_status' ) );
				foreach ($data as $key => $val) {
					$url .= '&checkbox_order_status_' . $key . '=' . $val['checkbox_order_status'];
				}


				if (isset( $_GET['offset'] )) {
					$url .= '&offset=' . $_GET['offset'];
				}


				if (isset( $_GET['show_all'] )) {
					$url .= '&show_all=' . $_GET['show_all'];
				}

				$data = ScanGetVariableWithId( array( 'set_order_status' ) );
				$changeStatusIsPressed = count( $data ) != 0;

				if (( isset( $_GET['search'] ) || $changeStatusIsPressed )) {
					$url .= '&search=1';
				}


				if (isset( $_GET['sort'] )) {
					$url .= '&sort=' . $_GET['sort'];
				}


				if (isset( $_GET['direction'] )) {
					$url .= '&direction=' . $_GET['direction'];
				}

				return base64_encode( $url );
			}

			function _getUrlToNavigate() {
				$url = 'admincp.php?tab=custord&sub=new_orders';

				if (isset( $_GET['order_search_type'] )) {
					$url .= '&order_search_type=' . $_GET['order_search_type'];
				}


				if (isset( $_GET['orderID_textbox'] )) {
					$url .= '&orderID_textbox=' . $_GET['orderID_textbox'];
				}

				$data = ScanGetVariableWithId( array( 'checkbox_order_status' ) );
				foreach ($data as $key => $val) {
					$url .= '&checkbox_order_status_' . $key . '=' . $val['checkbox_order_status'];
				}

				$data = ScanGetVariableWithId( array( 'set_order_status' ) );
				$changeStatusIsPressed = count( $data ) != 0;

				if (( isset( $_GET['search'] ) || $changeStatusIsPressed )) {
					$url .= '&search=1';
				}


				if (isset( $_GET['sort'] )) {
					$url .= '&sort=' . $_GET['sort'];
				}


				if (isset( $_GET['direction'] )) {
					$url .= '&direction=' . $_GET['direction'];
				}

				return $url;
			}

			function _getUrlToSort() {
				$url = 'admincp.php?tab=custord&sub=new_orders';

				if (isset( $_GET['order_search_type'] )) {
					$url .= '&order_search_type=' . $_GET['order_search_type'];
				}


				if (isset( $_GET['orderID_textbox'] )) {
					$url .= '&orderID_textbox=' . $_GET['orderID_textbox'];
				}

				$data = ScanGetVariableWithId( array( 'checkbox_order_status' ) );
				foreach ($data as $key => $val) {
					$url .= '&checkbox_order_status_' . $key . '=' . $val['checkbox_order_status'];
				}


				if (isset( $_GET['offset'] )) {
					$url .= '&offset=' . $_GET['offset'];
				}


				if (isset( $_GET['show_all'] )) {
					$url .= '&show_all=' . $_GET['show_all'];
				}

				$data = ScanGetVariableWithId( array( 'set_order_status' ) );
				$changeStatusIsPressed = count( $data ) != 0;

				if (( isset( $_GET['search'] ) || $changeStatusIsPressed )) {
					$url .= '&search=1';
				}

				return $url;
			}

			$data = ScanGetVariableWithId( array( 'set_order_status' ) );
			$changeStatusIsPressed = count( $data ) != 0;

			if (( isset( $_GET['search'] ) || $changeStatusIsPressed )) {
				_copyDataFromGetToPage( $smarty, $order_statuses );
				$callBackParam = array(  );
				_setCallBackParamsToSearchOrders( $callBackParam );
				$orders = array(  );
				$count = 1106;
				$navigatorHtml = GetNavigatorHtml( _getUrlToNavigate(  ), 20, 'ordGetOrders', $callBackParam, $orders, $offset, $count );
				$smarty->assign( 'orders', $orders );
				$smarty->assign( 'navigator', $navigatorHtml );
			}


			if (isset( $_GET['offset'] )) {
				$smarty->assign( 'offset', $_GET['offset'] );
			}


			if (isset( $_GET['show_all'] )) {
				$smarty->assign( 'show_all', $_GET['show_all'] );
			}

			$smarty->assign( 'urlToSort', _getUrlToSort(  ) );
			$smarty->assign( 'urlToReturn', _getReturnUrl(  ) );
			$smarty->assign( 'order_statuses', $order_statuses );
		} 
else {
			if (isset( $_GET['delete'] )) {
				if (CONF_BACKEND_SAFEMODE) {
					Redirect( 'admincp.php?tab=custord&sub=new_orders&orders_detailed&orderID=' . $_GET['orderID'] . '&urlToReturn=' . $_GET['urlToReturn'] . '&safemode' );
				}

				ordDeleteOrder( $_GET['orderID'] );
				Redirect( base64_decode( $_GET['urlToReturn'] ) );
			}


			if (isset( $_POST['set_status'] )) {
				if (CONF_BACKEND_SAFEMODE) {
					Redirect( 'admincp.php?tab=custord&sub=new_orders&orders_detailed&orderID=' . $_GET['orderID'] . '&urlToReturn=' . $_GET['urlToReturn'] . '&safemode' );
				}


				if ((int)$_POST['status'] != -1) {
					ostSetOrderStatusToOrder( $_GET['orderID'], $_POST['status'], (isset( $_POST['status_comment'] ) ? $_POST['status_comment'] : ''), (isset( $_POST['notify_customer'] ) ? $_POST['notify_customer'] : '') );
				}

				Redirect( 'admincp.php?tab=custord&sub=new_orders&orders_detailed&orderID=' . $_GET['orderID'] . '&urlToReturn=' . $_GET['urlToReturn'] );
			}


			if (isset( $_GET['urlToReturn'] )) {
				$smarty->assign( 'encodedUrlToReturn', $_GET['urlToReturn'] );
			}


			if (isset( $_GET['urlToReturn'] )) {
				$smarty->assign( 'urlToReturn', base64_decode( $_GET['urlToReturn'] ) );
			}

			$order = ordGetOrder( $_GET['orderID'] );
			getCardsInfo2( $_GET['orderID'] );
			$pinInfo = ;
			$orderContent = xHtmlSpecialChars( ordGetOrderContent( $_GET['orderID'] ), null, 'name' );
			$order_status_report = xNl2Br( html_spchars( stGetOrderStatusReport( $_GET['orderID'] ) ), 'status_comment' );
			$order_statuses = ostGetOrderStatues(  );
			$smarty->assign( 'cancledOrderStatus', ostGetCanceledStatusId(  ) );
			$smarty->assign( 'orderContent', $orderContent );
			$smarty->assign( 'order', $order );
			$smarty->assign( 'pininfo', $pinInfo );
			$smarty->assign( 'https_connection_flag', 1 );
			$smarty->assign( 'order_status_report', $order_status_report );
			$smarty->assign( 'order_statuses', $order_statuses );
			$smarty->assign( 'order_detailed', 1 );
		}


		if (isset( $callBackParam['from_date'] )) {
			$seldate = explode( '/', jdate( 'Y/m/d', strtotime( $callBackParam['from_date'] ) ) );
		} 
else {
			$seldate = explode( '/', jdate( 'Y/m/d' ) );
		}


		if (isset( $callBackParam['till_date'] )) {
			$sel2date = explode( '/', jdate( 'Y/m/d', strtotime( $callBackParam['till_date'] ) ) );
		} 
else {
			$sel2date = explode( '/', jdate( 'Y/m/d' ) );
		}

		$data = array( '', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند' );
		$smarty->assign( 'months', $data );
		$j = jdate( 'Y' ) - 10;

		while ($j < jdate( 'Y' ) + 10) {
			$ydata[] = $j;
			++$j;
		}

		$smarty->assign( 'years', $ydata );

		if (isset( $callBackParam['customer_ip'] )) {
			$smarty->assign( 'c_ip', $callBackParam['customer_ip'] );
			$smarty->assign( 'c_name', $callBackParam['customer_name'] );
			$smarty->assign( 'c_lname', $callBackParam['customer_lname'] );
			$smarty->assign( 'c_email', $callBackParam['customer_email'] );
		}

		$smarty->assign( 'seldate', $seldate );
		$smarty->assign( 'sel2date', $sel2date );
		$smarty->assign( 'admin_sub_tab', 'custord_new_orders.tpl.html' );
	}

?>