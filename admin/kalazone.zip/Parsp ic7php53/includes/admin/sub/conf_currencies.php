<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'currencies' )) {
		if (isset( $_GET['save_successful'] )) {
			$smarty->assign( 'configuration_saved', 1 );
		}


		if (isset( $_GET['delete'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=currencies&safemode' );
			}

			currDeleteCurrency( $_GET['delete'] );
			Redirect( 'admincp.php?tab=conf&sub=currencies' );
		}


		if (isset( $_POST['save_currencies'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=currencies&safemode' );
			}

			$data = scanArrayKeysForID( $_POST, array( 'curr_Name_\w{2}', 'curr_value', 'curr_where', 'curr_code_\w{2}', 'curr_sort', 'curr_currencyIso3' ) );
			foreach ($data as $key => $val) {
				$val['curr_value'] = (double)$val['curr_value'];
				$val['curr_sort'] = (int)$val['curr_sort'];
				$val['curr_where'] = (int)$val['curr_where'];

				if ($val['curr_value'] < 0) {
					continue;
				}

				currUpdateCurrency( $key, $val, $val['curr_currencyIso3'], $val['curr_value'], $val['curr_where'], $val['curr_sort'] );
			}


			if (( ( ( !LanguagesManager::ml_isEmpty( 'curr_new_name', $_POST ) && !LanguagesManager::ml_isEmpty( 'curr_new_code', $_POST ) ) && $_POST['curr_new_value'] != '' ) && $_POST['curr_new_currencyIso3'] )) {
				currAddCurrency( $_POST, $_POST['curr_new_currencyIso3'], $_POST['curr_new_value'], $_POST['curr_new_where'], $_POST['curr_new_sort'] );
			}

			Redirect( 'admincp.php?tab=conf&sub=currencies&save_successful' );
		}

		$currencies = currGetAllCurrencies(  );
		$smarty->assign( 'currencies', $currencies );
		$smarty->assign( 'admin_sub_tab', 'conf_currencies.tpl.html' );
	}

?>