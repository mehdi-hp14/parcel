<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (!strcmp( $sub, 'taxes' )) {
		function _getUrlToSubmit() {
			$url = 'admincp.php?tab=conf&sub=taxes';

			if (isset( $_GET['define_rate'] )) {
				$url .= '&define_rate=' . $_GET['define_rate'];
			}


			if (isset( $_GET['define_zone_rates'] )) {
				$url .= '&define_zone_rates=' . $_GET['define_zone_rates'];
			}


			if (isset( $_GET['countryID'] )) {
				$url .= '&countryID=' . $_GET['countryID'];
			}

			return $url;
		}

		function _verifyPerCent(&$value, $verifyResult) {
			$value = (double)$value;
			$verifyResult = 706;

			if ($value < 0) {
				$value = 706;
				$verifyResult = 707;
			}


			if (100 < $value) {
				$value = 806;
				$verifyResult = 707;
			}

			return $value;
		}

		function _saveZipRates() {
			$error_percent = '';
			$data = ScanPostVariableWithId( array( 'zip_template', 'zip_rate' ) );
			foreach ($data as $val) {
				taxUpdateZipRate( $key, $val['zip_template'], _verifyPerCent( $val['zip_rate'], $verifyResult ) );

				if ($verifyResult == 1) {
					$error_percent = '&error_percent';
					continue;
				}
			}


			if (trim( $_POST['new_zip_template'] ) != '') {
				taxAddZipRate( $_GET['define_zone_rates'], $_GET['countryID'], $_POST['new_zip_template'], _verifyPerCent( $_POST['new_zip_rate'], $verifyResult ) );

				if ($verifyResult == 1) {
					$error_percent = '&error_percent';
				}
			}

			taxSetIsByZoneAttribute( $_GET['define_zone_rates'], $_GET['countryID'], 1 );
			Redirect( 'admincp.php?tab=conf&sub=taxes&define_zone_rates=' . $_GET['define_zone_rates'] . '&countryID=' . $_GET['countryID'] . $error_percent );
		}

		function _saveZoneRates() {
			ScanPostVariableWithId( array( 'zone_rate' ) );
			$data = $error_percent = '';
			foreach ($data as $key => $val) {
				taxUpdateZoneRate( $_GET['define_zone_rates'], $key, _verifyPerCent( $val['zone_rate'], $verifyResult ) );

				if ($verifyResult == 1) {
					$error_percent = '&error_percent';
					continue;
				}
			}


			if (isset( $_POST['new_zone'] )) {
				if ((int)$_POST['new_zone'] != -1) {
					taxAddZoneRate( $_GET['define_zone_rates'], $_GET['countryID'], $_POST['new_zone'], _verifyPerCent( $_POST['new_rate'], $verifyResult ) );

					if ($verifyResult == 1) {
						$error_percent = '&error_percent';
					}
				}
			}

			taxSetIsByZoneAttribute( $_GET['define_zone_rates'], $_GET['countryID'], 1 );
			Redirect( 'admincp.php?tab=conf&sub=taxes&define_zone_rates=' . $_GET['define_zone_rates'] . '&countryID=' . $_GET['countryID'] . $error_percent );
		}

		function _saveTaxClasses() {
			$error_percent = '';
			$data = ScanPostVariableWithId( array( 'class_name', 'tax_based_on_address' ) );
			foreach ($data as $key => $val) {
				taxUpdateTaxClass( $key, $val['class_name'], $val['tax_based_on_address'] );
			}


			if (trim( $_POST['new_class_name'] ) != '') {
				taxAddTaxClass( trim( $_POST['new_class_name'] ), $_POST['new_tax_based_on_address'] );
			}

			header( 'Location: admincp.php?tab=conf&sub=taxes' );
		}

		function _saveRates() {
			$error_percent = '';
			$data = ScanPostVariableWithId( array( 'isByZone', 'rate' ) );
			foreach ($data as $key => $val) {

				if (!isset( $val['isByZone'] )) {
					$val['isByZone'] = 0;
				}

				taxUpdateRate( $_GET['define_rate'], $key, $val['isByZone'], _verifyPerCent( $val['rate'], $verifyResult ) );

				if ($verifyResult == 1) {
					$error_percent = '&error_percent';
					continue;
				}
			}


			if (isset( $_POST['new_country'] )) {
				if ((int)$_POST['new_country'] != -1) {
					taxAddRate( $_GET['define_rate'], $_POST['new_country'], 0, _verifyPerCent( $_POST['new_rate'], $verifyResult ) );

					if ($verifyResult == 1) {
						$error_percent = '&error_percent';
					}
				}
			}

			Redirect( 'admincp.php?tab=conf&sub=taxes&define_rate=' . $_GET['define_rate'] . $error_percent );
		}

		function _showRates($smarty) {
			$class = taxGetTaxClassById( $_GET['define_rate'] );
			$smarty->assign( 'class_name', $class['name'] );
			$rates = taxGetRates( $_GET['define_rate'] );
			foreach ($rates as $val) {

				if ($val['country_iso_2'] == 0) {
					$smarty->assign( 'group_exists', 1 );
					continue;
				}
			}

			$admin_is_depended_on_zone = array(  );
			$count_zones = array(  );
			foreach ($rates as $val) {

				if ($val['country_iso_2'] != 0) {
					$str = ADMIN_RATE_IS_DEPENDED_ON_ZONE;
					$str = str_replace( '{N}', taxGetCountSetZone( $_GET['define_rate'], $val['country_iso_2'] ), $str );
					$str = str_replace( '{M}', taxGetCountZones( $val['country_iso_2'] ), $str );
					$count_zones[] = taxGetCountZones( $val['country_iso_2'] );
					$admin_is_depended_on_zone[] = $str;
					continue;
				}
			}

			$smarty->assign( 'admin_is_depended_on_zone', $admin_is_depended_on_zone );
			$smarty->assign( 'count_zones', $count_zones );
			$smarty->assign( 'rates', $rates );
			$smarty->assign( 'rate_count', count( $rates ) );
			$countries = taxGetCountriesByClassID_ToSetRate( $_GET['define_rate'] );
			$smarty->assign( 'countries', $countries );
			$smarty->assign( 'country_count', count( $countries ) );
			$smarty->assign( 'define_rate', $_GET['define_rate'] );
		}

		function _showZoneRates($smarty) {
			$zone_rates = taxGetZoneRates( $_GET['define_zone_rates'], $_GET['country_iso_2'] );
			foreach ($zone_rates as $val) {

				if ($val['zoneID'] == 0) {
					$smarty->assign( 'group_exists', 1 );
					continue;
				}
			}

			$smarty->assign( 'zone_rates', $zone_rates );
			$smarty->assign( 'zone_rate_count', count( $zone_rates ) );
			$zip_rates = taxGetZipRates( $_GET['define_zone_rates'], $_GET['country_iso_2'] );
			$smarty->assign( 'zip_rates', $zip_rates );
			$smarty->assign( 'rowspan', count( $zone_rates ) + 2 + 1 + 1 + 1 + count( $zip_rates ) + 2 + 2 + 1 );
			$zones = taxGetZoneByClassIDcountry_iso_2_ToSetRate( $_GET['define_zone_rates'], $_GET['country_iso_2'] );
			$smarty->assign( 'zones', $zones );
			$smarty->assign( 'zone_count', count( $zones ) );
			$smarty->assign( 'define_zone_rates', $_GET['define_zone_rates'] );
			$tax_class = taxGetTaxClassById( $_GET['define_zone_rates'] );
			$smarty->assign( 'className', $tax_class['name'] );
			$country = cnGetCountryById( $_GET['country_iso_2'] );
			$smarty->assign( 'country_name', $country['country_name'] );
		}

		function _showTaxClasses($smarty) {
			$smarty->assign( 'classes', taxGetTaxClasses(  ) );
		}


		if (isset( $_GET['error_percent'] )) {
			$smarty->assign( 'error_percent', 1 );
		}


		if (isset( $_GET['kill_rate'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=taxes&define_rate=' . $_GET['define_rate'] . '&safemode' );
			}

			taxDeleteRate( $_GET['define_rate'], $_GET['kill_rate'] );
			Redirect( 'admincp.php?tab=conf&sub=taxes&define_rate=' . $_GET['define_rate'] );
		}


		if (isset( $_GET['kill_zone_rate'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=taxes&define_zone_rates=' . $_GET['define_zone_rates'] . '&country_iso_2=' . $_GET['country_iso_2'] . '&safemode' );
			}

			taxDeleteZoneRate( $_GET['define_zone_rates'], $_GET['kill_zone_rate'] );
			Redirect( 'admincp.php?tab=conf&sub=taxes&define_zone_rates=' . $_GET['define_zone_rates'] . '&country_iso_2=' . $_GET['country_iso_2'] );
		}


		if (isset( $_GET['kill_zip_rate'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=taxes&define_zone_rates=' . $_GET['define_zone_rates'] . '&country_iso_2=' . $_GET['country_iso_2'] . '&safemode' );
			}

			taxDeleteZipRate( $_GET['kill_zip_rate'] );
			Redirect( 'admincp.php?tab=conf&sub=taxes&define_zone_rates=' . $_GET['define_zone_rates'] . '&country_iso_2=' . $_GET['country_iso_2'] );
		}


		if (isset( $_POST['save_zone_rates'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=taxes&define_zone_rates=' . $_GET['define_zone_rates'] . '&country_iso_2=' . $_GET['country_iso_2'] . '&safemode' );
			}

			_saveZoneRates(  );
		}


		if (isset( $_POST['save_zip_rates'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=taxes&define_zone_rates=' . $_GET['define_zone_rates'] . '&country_iso_2=' . $_GET['country_iso_2'] . '&safemode' );
			}

			_saveZipRates(  );
		}


		if (isset( $_POST['save'] )) {
			if (isset( $_GET['define_rate'] )) {
				if (CONF_BACKEND_SAFEMODE) {
					Redirect( 'admincp.php?tab=conf&sub=taxes&define_rate=' . $_GET['define_rate'] . '&safemode' );
				}

				_saveRates(  );
			} 
else {
				if (CONF_BACKEND_SAFEMODE) {
					Redirect( 'admincp.php?tab=conf&sub=taxes&safemode' );
				}

				_saveTaxClasses(  );
			}
		}


		if (isset( $_GET['kill_class'] )) {
			if (CONF_BACKEND_SAFEMODE) {
				Redirect( 'admincp.php?tab=conf&sub=taxes&safemode' );
			}

			taxDeleteTaxClass( $_GET['kill_class'] );
			Redirect( 'admincp.php?tab=conf&sub=taxes' );
		}


		if (isset( $_GET['define_rate'] )) {
			_showRates( $smarty );
		} 
else {
			if (isset( $_GET['define_zone_rates'] )) {
				_showZoneRates( $smarty );
			} 
else {
				_showTaxClasses( $smarty );
			}
		}

		$smarty->assign( 'urlToSubmit', _getUrlToSubmit(  ) );
		$smarty->assign( 'admin_sub_tab', 'conf_taxes.tpl.html' );
	}

?>