<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$admin_tab = array( 'id' => 'catalog', 'sort_order' => 10, 'name' => ADMIN_CATALOG, 'sub_departments' => array( array( 'id' => 'products_categories', 'name' => ADMIN_CATEGORIES_PRODUCTS ), array( 'id' => 'lists', 'name' => ADMIN_LISTS ), array( 'id' => 'excel_import', 'name' => 'ورود اطلاعات از فایل csv' ), array( 'id' => 'excel_import_in', 'name' => ADMIN_IMPORT_FROM_EXCEL ), array( 'id' => 'excel_import_accounts', 'name' => ADMIN_IMPORT_FROM_EXCEL_ACCOUNTS ), array( 'id' => 'excel_export', 'name' => ADMIN_EXPORT_TO_EXCEL ), array( 'id' => 'dbsync', 'name' => ADMIN_SYNCHRONIZE_TOOLS ), array( 'id' => 'extra', 'name' => ADMIN_PRODUCT_OPTIONS ), array( 'id' => 'discuss', 'name' => ADMIN_DISCUSSIONS ) ) );
	add_department( $admin_tab );
?>