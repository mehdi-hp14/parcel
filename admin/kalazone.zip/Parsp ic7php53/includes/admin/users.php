<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$admin_tab = array( 'id' => 'users', 'sort_order' => 25, 'name' => ADMIN_USERS, 'sub_departments' => array( array( 'id' => 'custlist', 'name' => ADMIN_CUSTOMERS ), array( 'id' => 'custgroup', 'name' => ADMIN_CUSTGROUP ), array( 'id' => 'reg_fields', 'name' => ADMIN_CUSTOMER_REG_FIELDS ), array( 'id' => 'subscribers', 'name' => ADMIN_NEWS_SUBSCRIBERS ), array( 'id' => 'smsmail', 'name' => STRING_GROUPSMSMAIL ) ) );
	add_department( $admin_tab );
?>