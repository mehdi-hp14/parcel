<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$admin_tab = array( 'id' => 'content', 'sort_order' => 30, 'name' => ADMIN_CONTENT, 'sub_departments' => array( array( 'id' => 'aux_pages', 'name' => ADMIN_AUX_PAGES ), array( 'id' => 'home_text', 'name' => HOME_TEXT ), array( 'id' => 'contactus', 'name' => AUX_PAGE_TEXT . ' ' . STRING_FEEDBACK ), array( 'id' => 'survey', 'name' => ADMIN_VOTING ), array( 'id' => 'linkexchange', 'name' => STRING_MODULES_LINKEXCHANGE ), array( 'id' => 'news', 'name' => ADMIN_NEWS ) ) );
	add_department( $admin_tab );
?>