<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (empty( $$page_not_found )) {
		$smarty->assign( 'main_content_template', 'page_not_found.tpl.html' );
	}

?>