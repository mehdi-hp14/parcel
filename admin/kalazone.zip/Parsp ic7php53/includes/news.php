<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_POST['subscribe'] )) {
		$error = subscrVerifyEmailAddress( $_POST['email'] );

		if ($error == '') {
			$smarty->assign( 'subscribe', 1 );
			subscrAddUnRegisteredCustomerEmail( $_POST['email'] );
		} 
else {
			$smarty->assign( 'error_message', $error );
		}
	}


	if (isset( $_POST['email'] )) {
		$smarty->assign( 'email_to_subscribe', $_POST['email'] );
	} 
else {
		$smarty->assign( 'email_to_subscribe', 'Email' );
	}

	require_once( './includes/modules/news/class.newsmodule.php' );
	$NewsObj = new News(  );
	$NewsObj->generatePage( 'frontend news short list' );

	if (empty( $$news )) {
		$NewsObj->generatePage( 'frontend news list' );
	}

?>