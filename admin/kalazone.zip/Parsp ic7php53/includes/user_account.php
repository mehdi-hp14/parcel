<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (( isset( $_GET['user_details'] ) && isset( $_SESSION['log'] ) )) {
		$smarty->assign( 'selected_tab', 0 );
		$cust_password = null;
		$Email = null;
		$first_name = null;
		$last_name = null;
		$subscribed4news = null;
		$additional_field_values = null;
		regGetContactInfo( $_SESSION['log'], $cust_password, $Email, $first_name, $last_name, $subscribed4news, $additional_field_values, $phone, $mobile );

		if (CONF_SHOW_USERCREDIT == 1) {
			$userCredit = getUcreditByLogin( $_SESSION['log'] );
			$smarty->assign( 'userCredit', show_price( $userCredit ) );
		}

		$all_bankaccs = getBankAccounts(  );
		$smarty->assign( 'all_bankaccs', $all_bankaccs );

		if (isset( $_POST['submitbill'] )) {
			$smarty->assign( 'selected_tab', 2 );

			if (( ( !empty( $_POST['billdate'] ) && !empty( $_POST['billno'] ) ) && !empty( $_POST['billamount'] ) )) {
				if ($_POST['billfor'] == 'addtocredit') {
					$billfor = ADMIN_BANK_BILLS_ADDTO_USERACCOUNT;
				} 
else {
					$BilFororderID = $_POST['billfor'];
					$billfor = ADMIN_ORDER_NUMBER . ' ' . $BilFororderID;
					ostSetOrderStatusToOrder( $BilFororderID, CONF_BANKBILLED_ORDER_STATUS );
				}

				addNewBill( $_SESSION['log'], $billfor, $_POST['Account'], $_POST['billdate'], $_POST['billno'], $_POST['billamount'] );
				$smarty->assign( 'billmsgok', ADMIN_BANK_BILLS_BILL_SUBMITTED );
			} 
else {
				$smarty->assign( 'billmsgerr', ADMIN_BANK_BILLS_BILLNOT_SUBMITTED );
			}
		}

		$pendingOrders = getpendingOrdersForUserByLogin( $_SESSION['log'] );
		$smarty->assign( 'pending_orders', $pendingOrders );
		$smarty->assign( 'additional_field_values', $additional_field_values );
		$smarty->assign( 'first_name', $first_name );
		$smarty->assign( 'last_name', $last_name );
		$smarty->assign( 'Email', $Email );
		$smarty->assign( 'login', $_SESSION['log'] );
		$smarty->assign( 'phone', $phone );
		$smarty->assign( 'mobile', $mobile );
		$customerID = regGetIdByLogin( $_SESSION['log'] );
		$custgroup = GetCustomerGroupByCustomerId( $customerID );
		$smarty->assign( 'custgroup_name', $custgroup['custgroup_name'] );
		$smarty->assign( 'affiliate_customers', affp_getCustomersNum( $customerID ) );

		if (CONF_DISCOUNT_TYPE == '2') {
			if (0 < $custgroup['custgroup_discount']) {
				$smarty->assign( 'discount', $custgroup['custgroup_discount'] );
			}
		}


		if (( CONF_DISCOUNT_TYPE == '4' || CONF_DISCOUNT_TYPE == '5' )) {
			if (0 < $custgroup['custgroup_discount']) {
				$smarty->assign( 'min_discount', $custgroup['custgroup_discount'] );
			}
		}

		$defaultAddressID = regGetDefaultAddressIDByLogin( $_SESSION['log'] );
		$addressStr = regGetAddressStr( $defaultAddressID );
		$smarty->assign( 'addressStr', $addressStr );
		$smarty->assign( 'visits_count', stGetVisitsCount( $_SESSION['log'] ) );
		$smarty->assign( 'CONF_AFFILIATE_EMAIL_NEW_PAYMENT', CONF_AFFILIATE_EMAIL_NEW_PAYMENT );
		$smarty->assign( 'CONF_AFFILIATE_EMAIL_NEW_COMMISSION', CONF_AFFILIATE_EMAIL_NEW_COMMISSION );
		$smarty->assign( 'CONF_AFFILIATE_PROGRAM_ENABLED', CONF_AFFILIATE_PROGRAM_ENABLED );
		$smarty->assign( 'status_distribution', ordGetDistributionByStatuses( $_SESSION['log'] ) );
		$smarty->assign( 'main_content_template', 'user_account.tpl.html' );
	}

?>