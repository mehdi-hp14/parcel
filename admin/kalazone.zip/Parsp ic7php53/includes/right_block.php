<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$best_sellers = getBestsellers( CONF_BESTSELLERS_COUNT );
	$smarty->assign( 'CONF_SHOW_BESTSELLERS_RIGHT', CONF_SHOW_BESTSELLERS_RIGHT );
	$smarty->assign( 'best_sellers', $best_sellers );
	$best_viewed = getBestviewed( CONF_MOSTVIEWED_COUNT );
	$smarty->assign( 'CONF_MOSTVIEWED_RIGHT', CONF_MOSTVIEWED_RIGHT );
	$smarty->assign( 'best_viewed', $best_viewed );
	$latest_added = getLatestadded( CONF_LATESTADDED_COUNT );
	$smarty->assign( 'CONF_SHOW_LATEST_RIGHT', CONF_SHOW_LATEST_RIGHT );
	$smarty->assign( 'latest_added', $latest_added );
?>