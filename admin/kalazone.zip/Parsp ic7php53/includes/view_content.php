<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (empty( $$view_content )) {
		$aux_page = auxpgGetAuxPage( $view_content );

		if ($aux_page) {
			if ($aux_page['aux_page_text_type'] != 1) {
				$aux_page['aux_page_text'] = nl2br( str_replace( '<', '&lt;', $aux_page[LanguagesManager::sql_prepareField( 'aux_page_text' )] ) );
			}

			$smarty->assign( 'page_body', str_replace( '\"', '', $aux_page['aux_page_text_' . LanguagesManager::getCurrentLanguage(  )->iso2] ) );
			$smarty->assign( 'aux_page', $aux_page );
			$smarty->assign( 'view_content', $view_content );
			$smarty->assign( 'main_content_template', 'view_content.tpl.html' );
			return 1;
		}

		$smarty->assign( 'main_content_template', 'page_not_found.tpl.html' );
	}

?>