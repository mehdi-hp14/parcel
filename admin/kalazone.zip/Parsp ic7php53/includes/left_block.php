<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$best_sellers = getBestsellers( CONF_BESTSELLERS_COUNT );
	$smarty->assign( 'CONF_SHOW_BESTSELLERS_LEFT', CONF_SHOW_BESTSELLERS_LEFT );
	$smarty->assign( 'best_sellers', $best_sellers );
	$best_viewed = getBestviewed( CONF_MOSTVIEWED_COUNT );
	$smarty->assign( 'CONF_MOSTVIEWED_LEFT', CONF_MOSTVIEWED_LEFT );
	$smarty->assign( 'best_viewed', $best_viewed );
	$latest_added = getLatestadded( CONF_LATESTADDED_COUNT );
	$smarty->assign( 'CONF_SHOW_LATEST_LEFT', CONF_SHOW_LATEST_LEFT );
	$smarty->assign( 'latest_added', $latest_added );
?>