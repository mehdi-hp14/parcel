<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_POST['current_currency'] )) {
		currSetCurrentCurrency( $_POST['current_currency'] );
		$url = 'index.php';
		$paramGetVars = '';
		foreach ($_GET as $key => $value) {

			if ($paramGetVars == '') {
				$paramGetVars .= '?' . $key . '=' . $value;
				continue;
			}

			$paramGetVars .= '&' . $key . '=' . $value;
		}

		Redirect( $url . $paramGetVars );
	}

?>