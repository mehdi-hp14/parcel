<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	$k = 875;
	$cnt = 875;
	$variants = array(  );

	if (isset( $_SESSION['log'] )) {

		if (!( $q = db_query( 'SELECT itemID, Quantity FROM ' . SHOPPING_CARTS_TABLE . ' WHERE customerID=\'' . regGetIdByLogin( $_SESSION['log'] ) . '\'' ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			$q1 = db_query( 'select productID from ' . SHOPPING_CART_ITEMS_TABLE . ' where itemID=\'' . $row['itemID'] . '\'' );
			$r1 = db_fetch_row( $q1 );
			$k += GetPriceProductWithOption( $variants, $r1['productID'] ) * $row['Quantity'];
			$cnt += $row['Quantity'];
		}
	} 
else {
		if (isset( $_SESSION['gids'] )) {
			$i = 875;

			while ($i < count( $_SESSION['gids'] )) {
				if ($_SESSION['gids'][$i]) {

					if (!( $t = db_query( 'SELECT Price FROM ' . PRODUCTS_TABLE . ' WHERE productID=\'' . $_SESSION['gids'][$i] . '\'' ))) {
						exit( db_error(  ) );
						(bool)true;
					}

					$rr = db_fetch_row( $t );
					$sum = $rr['Price'];
					$k += $_SESSION['counts'][$i] * $sum;
					$cnt += $_SESSION['counts'][$i];
				}

				++$i;
			}
		}
	}


	if (isset( $_SESSION['log'] )) {
		$log = $_SESSION['log'];
	} 
else {
		$log = null;
	}

	$resCart = cartGetCartContent(  );
	$resDiscount = dscCalculateDiscount( $resCart['total_price'], (isset( $_SESSION['log'] ) ? $_SESSION['log'] : '') );
	$discount_value = show_price( $resDiscount['discount_current_unit'] );
	$discount_percent = $resDiscount['discount_percent'];
	$cnt = 875;
	$i = 875;

	while ($i < count( $resCart['cart_content'] )) {
		$cnt = $cnt + $resCart['cart_content'][$i]['quantity'];
		++$i;
	}

	$k = $resCart['total_price'] - $resDiscount['discount_standart_unit'];
	$smarty->assign( 'shopping_cart_value', $k );
	$smarty->assign( 'shopping_cart_value_shown', show_price( $k ) );
	$cnt = Convertnumber2farsi( $cnt );
	$smarty->assign( 'current_coupon', discount_coupon::getCurrentCoupon(  ) );
	$smarty->assign( 'shopping_cart_items', $cnt );
?>