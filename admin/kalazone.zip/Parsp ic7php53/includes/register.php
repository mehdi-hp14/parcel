<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	if (isset( $_GET['r_successful'] )) {
		$smarty->assign( 'main_content_template', 'reg_successful.tpl.html' );
	}


	if (( empty( $$register ) && !isset( $_SESSION['log'] ) )) {
		$_POST = xStripSlashesGPC( $_POST );
		function _copyDataFromPostToPage($smarty) {
			$smarty->assign( 'login', $_POST['login'] );
			$smarty->assign( 'cust_password1', $_POST['cust_password1'] );
			$smarty->assign( 'cust_password2', $_POST['cust_password2'] );
			$smarty->assign( 'first_name', $_POST['first_name'] );
			$smarty->assign( 'last_name', $_POST['last_name'] );
			$smarty->assign( 'phone', $_POST['phone'] );
			$smarty->assign( 'mobile', $_POST['mobile'] );
			$smarty->assign( 'email', $_POST['email'] );
			$smarty->assign( 'affiliationLogin', $_POST['affiliationLogin'] );
			$smarty->assign( 'subscribed4news', (isset( $_POST['subscribed4news'] ) ? 1 : 0) );

			if (!isset( $_POST['countryID'] )) {
				$_POST['countryID'] = 'IR';
			}

			$phone = $_POST['phone'];
			$mobile = $_POST['mobile'];
			$country_iso_2 = cnGetCountryById( $_POST['countryID'] );
			$country_iso_2 = $country_iso_2['country_iso_2'];
			$zones = znGetZonesById( $country_iso_2 );
			$smarty->assign( 'zones', $zones );
			$cities = ctGetCitysById( $country_iso_2, $_POST['zoneID'] );
			$smarty->assign( 'cities', $cities );
			$additional_field_values = array(  );
			$data = ScanPostVariableWithId( array( 'additional_field' ) );
			foreach ($data as $key => $val) {
				$item = array( 'reg_field_ID' => $key, 'reg_field_name' => '', 'reg_field_value' => $val['additional_field'] );
				$additional_field_values[] = $item;
			}

			$smarty->assign( 'additional_field_values', $additional_field_values );
			$smarty->assign( 'countryID', $_POST['countryID'] );

			if (isset( $_POST['state'] )) {
				$smarty->assign( 'state', $_POST['state'] );
			}


			if (isset( $_POST['zoneID'] )) {
				$smarty->assign( 'zoneID', $_POST['zoneID'] );
			}

			$smarty->assign( 'zip', $_POST['zip'] );
			$smarty->assign( 'city', $_POST['city'] );
			$smarty->assign( 'cityID', $_POST['cityID'] );
			$smarty->assign( 'address', $_POST['address'] );

			if (( isset( $_POST['order'] ) || isset( $_GET['order'] ) )) {
				if (isset( $_POST['billing_address_check'] )) {
					$smarty->assign( 'billing_address_check', '1' );
				}

				$smarty->assign( 'receiver_first_name', $_POST['receiver_first_name'] );
				$smarty->assign( 'receiver_last_name', $_POST['receiver_last_name'] );

				if (!isset( $_POST['billing_address_check'] )) {
					$smarty->assign( 'payer_first_name', $_POST['payer_first_name'] );
					$smarty->assign( 'payer_last_name', $_POST['payer_last_name'] );
					$smarty->assign( 'billingCountryID', $_POST['billingCountryID'] );

					if (isset( $_POST['billingState'] )) {
						$smarty->assign( 'billingState', $_POST['billingState'] );
					}


					if (isset( $_POST['billingZoneID'] )) {
						$smarty->assign( 'billingZoneID', $_POST['billingZoneID'] );
					}

					$smarty->assign( 'billingZip', $_POST['billingZip'] );
					$smarty->assign( 'billingCity', $_POST['billingCity'] );
					$smarty->assign( 'billingCityID', $_POST['billingCityID'] );
					$smarty->assign( 'billingAddress', $_POST['billingAddress'] );

					if (isset( $_POST['billingCountryID'] )) {
						$billingcountry_iso2 = cnGetCountryById( $_POST['billingCountryID'] );
						$billingcountry_iso2 = $billingcountry_iso2['country_iso_2'];
						$billingZones = znGetZonesById( $billingcountry_iso2 );
						$smarty->assign( 'billingZones', $billingZones );
					}

					$billingcountry_iso2 = cnGetCountryById( $_POST['billingCountryID'] );
					$billingcountry_iso2 = $billingcountry_iso2['country_iso_2'];
					$billingcities = ctGetCitysById( $billingcountry_iso2, $_POST['billingZoneID'] );
					$smarty->assign( 'billingcities', $billingcities );
					return null;
				}

				$smarty->assign( 'payer_first_name', $_POST['receiver_first_name'] );
				$smarty->assign( 'payer_last_name', $_POST['receiver_last_name'] );
				$smarty->assign( 'billingCountryID', $_POST['countryID'] );

				if (isset( $_POST['State'] )) {
					$_POST['billingState'] = $_POST['State'];
				}


				if (isset( $_POST['ZoneId'] )) {
					$_POST['billingZoneID'] = $_POST['ZoneId'];
				}


				if (isset( $_POST['billingState'] )) {
					$smarty->assign( 'billingState', $_POST['billingState'] );
				}


				if (isset( $_POST['billingZoneID'] )) {
					$smarty->assign( 'billingZoneID', $_POST['billingZoneID'] );
				}


				if (isset( $_POST['billingCountryID'] )) {
					$country_iso_2 = cnGetCountryById( $_POST['billingCountryID'] );
					$country_iso_2 = $country_iso_2['country_iso_2'];
					$billingZones = znGetZonesById( $country_iso_2 );
					$smarty->assign( 'billingZones', $billingZones );
					$billingcities = ctGetCitysById( $country_iso_2, $_POST['billingZoneID'] );
					$smarty->assign( 'billingcities', $billingcities );
				}

				$smarty->assign( 'billingZip', $_POST['zip'] );
				$smarty->assign( 'billingCity', $_POST['city'] );
				$smarty->assign( 'billingCityID', $_POST['cityID'] );
				$smarty->assign( 'billingAddress', $_POST['address'] );
				$smarty->assign( 'billingZones', $zones );
			}

		}


		if (!isset( $_POST['state'] )) {
			$_POST['state'] = '';
		}


		if (!isset( $_POST['countryID'] )) {
			$_POST['countryID'] = CONF_DEFAULT_COUNTRY;
		}

		$isPost = ( isset( $_POST['login'] ) && isset( $_POST['cust_password1'] ) );

		if ($isPost) {
			_copyDataFromPostToPage( $smarty );
		}


		if (( isset( $_POST['save'] ) && !empty( $$quick_register ) )) {
			$login = $_POST['login'];
			$cust_password1 = $_POST['cust_password1'];
			$_POST['cust_password2'];
			$_POST['first_name'];
			$_POST['last_name'];
			$_POST['email'];
			$_POST['phone'];
			$_POST['mobile'];
			$subscribed4news = (isset( $_POST['subscribed4news'] ) ? 1 : 0);
			$additional_field_values = ScanPostVariableWithId( array( 'additional_field' ) );
			$affiliationLogin = $_POST['affiliationLogin'];

			if (empty( $$order )) {
				$receiver_first_name = $_POST['receiver_first_name'];
				$receiver_last_name = $_POST['receiver_last_name'];
			}

			$countryID = $cust_password2 = $_POST['countryID'];
			$state = $first_name = $_POST['state'];
			$zip = $last_name = $_POST['zip'];
			$city = $Email = $_POST['city'];
			$cityID = $phone = $_POST['cityID'];
			$address = $mobile = $_POST['address'];

			if (isset( $_POST['zoneID'] )) {
				$zoneID = $_POST['zoneID'];
			} 
else {
				$zoneID = 1684;
			}


			if (( empty( $$order ) && isset( $_POST['billing_address_check'] ) )) {
				$payer_first_name = $countries;
				$payer_last_name = $zones;
				$billingCountryID = $cities;
				$billingState = $additional_fields;
				$billingZip = $country_iso_2;
				$billingCity = $data;
				$billingAddress = $val;
				$billingZoneID = $item;
				$billingCityID = $key;
			} 
else {
				if (empty( $$order )) {
					$payer_first_name = $_POST['payer_first_name'];
					$payer_last_name = $_POST['payer_last_name'];
					$billingCountryID = $_POST['billingCountryID'];

					if (isset( $_POST['billingState'] )) {
						$billingState = $_POST['billingState'];
					} 
else {
						$billingState = '';
					}

					$billingZip = $_POST['billingZip'];
					$billingCity = $_POST['billingCity'];
					$billingCityID = $_POST['billingCityID'];
					$billingAddress = $_POST['billingAddress'];

					if (isset( $_POST['billingZoneID'] )) {
						$billingZoneID = $_POST['billingZoneID'];
					} 
else {
						$billingZoneID = 1684;
					}
				}
			}

			$error = regVerifyContactInfo( $login, $cust_password1, $cust_password2, $Email, $first_name, $last_name, $subscribed4news, $additional_field_values );

			if (CONF_ENABLE_CONFIRMATION_CODE) {
				if ($_POST['fConfirmationCode'] != $_SESSION['CAPTCHAString']) {
					$error = ERR_WRONG_CCODE;
				}
			}


			if ($error == '') {
				unset( $$error );
			}


			if (( !empty( $$error ) && empty( $$affiliationLogin ) )) {
				if (( !regIsRegister( $affiliationLogin ) && $affiliationLogin )) {
					$error = ERROR_WRONG_AFFILIATION;
				}
			}


			if (!empty( $$error )) {
				if (regIsRegister( $login )) {
					$error = ERROR_USER_ALREADY_EXISTS;
				}
			}


			if (!empty( $$error )) {
				if (!empty( $$order )) {
					$error = regVerifyAddress( $first_name, $last_name, $countryID, $zoneID, $state, $zip, $city, $cityID, $address, $phone, $mobile );
				} 
else {
					$error = regVerifyAddress( $receiver_first_name, $receiver_last_name, $countryID, $zoneID, $state, $zip, $city, $cityID, $address, $phone, $mobile );
				}


				if ($error == '') {
					unset( $$error );
				}
			}


			if (( !empty( $$error ) && empty( $$order ) )) {
				$error = regVerifyAddress( $payer_first_name, $payer_last_name, $billingCountryID, $billingZoneID, $billingState, $billingZip, $billingCity, $billingCityID, $billingAddress, $phone, $mobile );

				if ($error == '') {
					unset( $$error );
				}
			}


			if (!empty( $$error )) {
				$cust_password = $error;
				$registerResult = regRegisterCustomer( $login, $cust_password, $Email, $first_name, $last_name, $subscribed4news, $additional_field_values, $phone, $mobile, $affiliationLogin );

				if ($registerResult) {
					if (empty( $$order )) {
						$addressID = regAddAddress( $receiver_first_name, $receiver_last_name, $countryID, $zoneID, $state, $zip, $city, $cityID, $address, $login, $errorCode, $phone, $mobile );
						$billingAddressID = $Email;

						if (!isset( $_POST['billing_address_check'] )) {
							$billingAddressID = regAddAddress( $payer_first_name, $payer_last_name, $billingCountryID, $billingZoneID, $billingState, $billingZip, $billingCity, $billingCityID, $billingAddress, $login, $errorCode, $phone, $mobile );
						}

						regSetDefaultAddressIDByLogin( $login, $addressID );
					} 
else {
						$addressID = regAddAddress( $first_name, $last_name, $countryID, $zoneID, $state, $zip, $city, $cityID, $address, $login, $errorCode, $phone, $mobile );
						regSetDefaultAddressIDByLogin( $login, $addressID );
					}

					regEmailNotification( $smarty_mail, $login, $cust_password, $Email, $first_name, $last_name, $subscribed4news, $additional_field_values, $countryID, $zoneID, $state, $zip, $city, $address, 0 );

					if (!CONF_ENABLE_REGCONFIRMATION) {
						regAuthenticate( $login, $cust_password );
					}

					$RedirectURL = BASE_URL . 'index.php?r_successful';

					if (empty( $$order )) {
						if (empty( $$billingAddressID )) {
							$RedirectURL = BASE_URL . 'index.php?order2_shipping&shippingAddressID=' . regGetDefaultAddressIDByLogin( $login ) . '&defaultBillingAddressID=' . $billingAddressID;
						} 
else {
							$RedirectURL = BASE_URL . 'index.php?order2_shipping&shippingAddressID=' . regGetDefaultAddressIDByLogin( $login );
						}
					} 
else {
						if (empty( $$order_without_billing_address )) {
							$RedirectURL = BASE_URL . 'index.php?order2_shipping&shippingAddressID=' . regGetDefaultAddressIDByLogin( $login );
						} 
else {
							$RedirectURL = BASE_URL . 'index.php?r_successful';
						}
					}


					if (( CONF_ENABLE_REGCONFIRMATION && ( empty( $$order ) || empty( $$order_without_billing_address ) ) )) {
						xSaveData( 'xREGMAILCONF_URLORDER2', $RedirectURL );
						$RedirectURL = BASE_URL . 'index.php?act_customer=1&order2';
					}

					Redirect( $RedirectURL );
				} 
else {
					$smarty->assign( 'reg_error', ERROR_INPUT_STATE );
				}
			} 
else {
				$smarty->assign( 'reg_error', $error );
			}
		} 
else {
			if (( isset( $_POST['save'] ) && empty( $$quick_register ) )) {
				if (!isset( $_POST['state'] )) {
					$_POST['state'] = '';
				}


				if (!isset( $_POST['zoneID'] )) {
					$_POST['zoneID'] = 0;
				}


				if (!isset( $_POST['billingState'] )) {
					$_POST['billingState'] = '';
				}


				if (!isset( $_POST['billingZoneID'] )) {
					$_POST['billingZoneID'] = 0;
				}

				$error = '';
				$error = quickOrderContactInfoVerify(  );

				if ($error == '') {
					$error = quickOrderReceiverAddressVerify(  );
				}


				if (( CONF_ORDERING_REQUEST_BILLING_ADDRESS == '1' && $error == '' )) {
					$error = quickOrderBillingAddressVerify(  );
				}


				if ($error == '') {
					quikOrderSetCustomerInfo(  );
					quickOrderSetReceiverAddress(  );

					if (CONF_ORDERING_REQUEST_BILLING_ADDRESS == '1') {
						quickOrderSetBillingAddress(  );
					}

					RedirectJavaScript( 'index.php?order2_shipping_quick=1' );
				} 
else {
					$smarty->assign( 'reg_error', $error );
				}
			}
		}

		$callBackParam = array(  );
		$count_row = 1684;
		$countries = cnGetCountries( $callBackParam, $count_row );
		$smarty->assign( 'countries', $countries );

		if (!$isPost) {
			if (count( $countries ) != 0) {
				$zones = znGetZonesById( _getSettingOptionValue( 'CONF_COUNTRY' ) );
				$smarty->assign( 'zones', $zones );
				$cities = ctGetCitysById( _getSettingOptionValue( 'CONF_COUNTRY' ), $zones[0]['zoneID'] );
				$smarty->assign( 'cities', $cities );
				$smarty->assign( 'billingZones', $zones );
			}
		}

		$additional_fields = GetRegFields(  );
		$smarty->assign( 'additional_fields', $additional_fields );

		if (empty( $$register )) {
			$smarty->assign( 'return_url', 'index.php?register' );
		}


		if (empty( $$order )) {
			$smarty->assign( 'order', 1 );
		}


		if (empty( $$order_without_billing_address )) {
			$smarty->assign( 'order_without_billing_address', 1 );
		}


		if (isset( $_SESSION['s_RefererLogin'] )) {
			$smarty->assign( 'SessionRefererLogin', $_SESSION['s_RefererLogin'] );
		}


		if ($quick_register) {
			$isPost = ( isset( $_POST['first_name'] ) && isset( $_POST['last_name'] ) );

			if ($isPost) {
				$smarty->assign( 'first_name', $_POST['first_name'] );
				$smarty->assign( 'last_name', $_POST['last_name'] );
				$smarty->assign( 'mobile', $_POST['mobile'] );
				$smarty->assign( 'phone', $_POST['phone'] );
				$smarty->assign( 'email', $_POST['email'] );
				$smarty->assign( 'subscribed4news', (isset( $_POST['subscribed4news'] ) ? 1 : 0) );
				$smarty->assign( 'affiliationLogin', $_POST['affiliationLogin'] );
				$country_iso_2 = cnGetCountryById( $_POST['countryID'] );
				$zones = znGetZonesById( $country_iso_2['country_iso_2'] );
				$smarty->assign( 'zones', $zones );
				$smarty->assign( 'countryID', $_POST['countryID'] );

				if (isset( $_POST['state'] )) {
					$smarty->assign( 'state', $_POST['state'] );
				}


				if (isset( $_POST['zoneID'] )) {
					$smarty->assign( 'zoneID', $_POST['zoneID'] );
				}


				if (isset( $_POST['cityID'] )) {
					$smarty->assign( 'cityID', $_POST['cityID'] );
				}

				ctGetCitysById( $country_iso_2['country_iso_2'], $_POST['zoneID'] );
				$smarty->assign( 'cities', $cities );
				$smarty->assign( 'zip', $_POST['zip'] );
				$smarty->assign( 'city', $_POST['city'] );
				$smarty->assign( 'address', $_POST['address'] );
				$smarty->assign( 'phone', $_POST['phone'] );
				$smarty->assign( 'mobile', $_POST['mobile'] );
				$smarty->assign( 'receiver_first_name', $_POST['receiver_first_name'] );
				$smarty->assign( 'receiver_last_name', $_POST['receiver_last_name'] );
				$additional_field_values = array(  );
				$data = $cities = ScanPostVariableWithId( array( 'additional_field' ) );
				foreach ($data as $key => $val) {
					$item = array( 'reg_field_ID' => $key, 'reg_field_name' => '', 'reg_field_value' => $val['additional_field'] );
					$additional_field_values[] = $item;
				}

				$smarty->assign( 'additional_field_values', $additional_field_values );

				if (CONF_ORDERING_REQUEST_BILLING_ADDRESS == '1') {
					if (isset( $_POST['billing_address_check'] )) {
						$smarty->assign( 'billing_address_check', '1' );
					}


					if (!isset( $_POST['billing_address_check'] )) {
						$smarty->assign( 'payer_first_name', $_POST['payer_first_name'] );
						$smarty->assign( 'payer_last_name', $_POST['payer_last_name'] );
						$smarty->assign( 'billingCountryID', $_POST['billingCountryID'] );

						if (isset( $_POST['billingState'] )) {
							$smarty->assign( 'billingState', $_POST['billingState'] );
						}


						if (isset( $_POST['billingZoneID'] )) {
							$smarty->assign( 'billingZoneID', $_POST['billingZoneID'] );
						}

						$smarty->assign( 'billingZip', $_POST['billingZip'] );
						$smarty->assign( 'billingCity', $_POST['billingCity'] );
						$smarty->assign( 'billingAddress', $_POST['billingAddress'] );

						if (isset( $_POST['billingCountryID'] )) {
							$billingcountry_iso2 = cnGetCountryById( $_POST['billingCountryID'] );
							$billingcountry_iso2 = $billingcountry_iso2['country_iso_2'];
							$billingZones = znGetZonesById( $billingcountry_iso2 );
							$smarty->assign( 'billingZones', $billingZones );

							if (isset( $_POST['billingZoneID'] )) {
								$country_iso_2 = cnGetCountryById( $_POST['billingCountryID'] );
								$country_iso_2 = $country_iso_2['country_iso_2'];
								$billingcities = ctGetCitysById( $country_iso_2, $_POST['billingZoneID'] );
								$smarty->assign( 'billingcities', $billingcities );
							}
						}
					} 
else {
						$smarty->assign( 'payer_first_name', $_POST['receiver_first_name'] );
						$smarty->assign( 'payer_last_name', $_POST['receiver_last_name'] );
						$smarty->assign( 'billingCountryID', $_POST['countryID'] );
						$smarty->assign( 'billingState', $_POST['billingState'] );
						$smarty->assign( 'billingZoneID', $_POST['billingZoneID'] );
						$smarty->assign( 'billingZip', $_POST['zip'] );
						$smarty->assign( 'billingCity', $_POST['city'] );
						$smarty->assign( 'billingAddress', $_POST['address'] );
						$smarty->assign( 'billingZones', $zones );
						$smarty->assign( 'billingcities', $cities );
					}
				}
			} 
else {
				$zones = znGetZonesById( CONF_DEFAULT_COUNTRY );
				$smarty->assign( 'zones', $zones );
				$smarty->assign( 'billingZones', $zones );
			}

			$smarty->assign( 'quick_register', 1 );
			$smarty->assign( 'main_content_template', 'register_quick.tpl.html' );
			return 1;
		}

		$smarty->assign( 'main_content_template', 'register.tpl.html' );
	}

?>