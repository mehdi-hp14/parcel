<?php
/**
*
* @ IonCube v7 Decoder By DoraemonPT
*
* @ Version  : 1,0,0,0
* @ Author   : DoraemonPT
* @ Release on : 19-08-2013
* @ Website  : http://EasyToYou.eu
*
**/

	define( 'DATABASE_STRUCTURE_XML_PATH', './cfg/db_structure.xml' );
	define( 'RESULT_XML_PATH', './cfg/result.xml' );
	define( 'TABLES_INC_PHP_PATH', './cfg/tables.inc.php' );
	define( 'CONNECT_INC_PHP_PATH', './cfg/connect.inc.php' );
	define( 'STRING_PRODUCT_NAME', 'Enterprise' );
	define( 'STRING_VERSION', '8.1.1' );
	define( 'STRING_COULDNT_REWRITE_FILE', 'Couldn\'t rewrite configuration files. Please refer to User Guide for information on how to configure file access permissions.' );
?>