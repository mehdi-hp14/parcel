INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate`) VALUES ('fa','DEFAULT_CHARSET', 'utf-8');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','LINK_TO_CONTROLPANEL', 'صفحه من','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','LINK_TO_ADMINPANEL', 'پنل مدیریت فروشگاه','general');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','LINK_TO_HOMEPAGE', 'صفحه اصلی','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','PRODUCTS_BEST_CHOISE', 'بهترین انتخاب','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MORE_INFO_ON_PRODUCT', 'اطلاعات بیشتر...','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ENLARGE_PICTURE', 'تصویر بزرگتر...','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','DISCUSS_ITEM_LINK', 'نظرات کاربران','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','POSTS_FOR_ITEM_STRING', 'پست','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MR', 'گرامی!','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADD_TO_CART_STRING', 'اضافه به سبد خرید','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','LIST_PRICE', 'قیمت قبلی','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CURRENT_PRICE', 'قیمت','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','YOU_SAVE', 'مقدار تغییر قیمت','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','IN_STOCK', 'موجود در انبار','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','VOTING_FOR_ITEM_TITLE', 'امتیاز به این محصول','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','VOTING_FOR_ITEM_BEFORE', 'قبلا به این محصول امتیاز داده اید!','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','VOTING_CONFIRM_DELETE', 'از حذف این نظر سنجی اطمینان دارید؟ نظر شماره ','general'); 
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MARK_EXCELLENT', 'عالی','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MARK_GOOD', 'خوب','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MARK_AVERAGE', 'متوسط','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MARK_POOR', 'ضعیف','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MARK_PUNY', 'خیلی بد','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','VOTE_BUTTON', 'امتیاز دادن','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','UNINSTALL_BUTTON', 'لغو نصب','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','VOTES_FOR_ITEM_STRING', 'تعداد رای','general');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MY_ACCOUNT_LINK', 'حساب من','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','REGISTER_LINK', 'ثبت نام','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CHANGE_CURRENCY_LINK', 'تغییر واحد پول','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TIMEOUT_LINK','زمان اعتبار','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','LOGOUT_LINK', 'خروج از سیستم','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_LOGOUT', 'خروج','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADVANCED_SEARCH_LINK', 'جستجوی پیشرفته','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','FORGOT_PASSWORD_LINK', 'فراموشی رمز','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMINISTRATE_LINK', ':: پنل مدیریت ::','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TERMINATE_ACCOUNT_LINK', 'حدف عضویت','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_REGISTER_NEW', 'عضویت','general');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ANSWER_YES', 'بله','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ANSWER_NO', 'خیر','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','POST_BUTTON', 'پست','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','OK_BUTTON', 'ثبت','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','RESET_BUTTON', 'از نو','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','SAVE_BUTTON', 'ذخیره','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','DELETE_BUTTON', 'حذف','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CLOSE_BUTTON', 'بستن','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CANCEL_BUTTON', 'انصراف','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','UPDATE_BUTTON', 'به روز','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADD_BUTTON', 'افزودن','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CONFIG_BUTTON', 'تنظیم','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EDIT_BUTTON', 'ویرایش','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','FIND_BUTTON', 'پیدا کردن','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','COMPLETE_ORDERS_BUTTON', 'تکمیل سفارش','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LOGO_RESIZE_IAR', 'تغییر اندازه تصویر بدون در نظر گرفتن نسبت طول به عرض','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PIXEL', 'پیکسل','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_WIDTH', 'عرض','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_HEIGHT', 'طول','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_BACK_TO_SHOPPING', 'بازگشت به خرید','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SIZE', 'اندازه','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_BEFORE', 'قبل','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PARAMETERS', 'پارامترها','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_AFTER', 'بعد','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHOW', 'نمایش','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NUMBER', 'رقم','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_AUTHORIZATION', 'ورود به سیستم','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_RELATED_ITEMS', 'محصولات مرتبط','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NUMBER_ONLY', 'فقط عدد','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_UNIVERSAL_CURRENCY', 'در واحد پیشفرض','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_EMPTY_CATEGORY', 'بدون محصول','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NO_ORDERS', 'هیچ سفارشی موجود نیست','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SURVEYS', 'نظرسنجی','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NO_SURVEYS', 'در حال حاضر نظرسنجی وجود ندارد','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_EMPTY_LIST', 'لیست خالی','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SEARCH', 'جستجو','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SEARCH_IN_RESULTS', 'جستجو در نتایج','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_LANGUAGE', 'زبان','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_THANK_YOU', 'با تشکر!','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SUCCESSFUL_ACCOUNT_TERMINATION', 'حساب شما با موفقیت به پایان رسید، با تشکر از خرید شما!','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PASSWORD_SENT', 'رمز عبور شما به آدرس پست الکترونیک شما فرستاده شد','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CHANGE_PASSWORD', 'تغییر رمز عبور','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CHANGE_PASSWORD_CHANGED', 'رمز عبور شما با موفقیت تغییر کرد ، می توانید با رمز جدید وارد  سیستم شوید.','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CANT_FIND_USER_IN_DB', 'متاسفانه چنین شناسه کاربری پیدا نشد','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRICELIST', 'اقلام موجود','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SELECT_CURRENCY_TYPE', 'انتخاب واحد پول','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_FORGOT_PASSWORD_FIX', '<u>رمز عبور خود را فراموش کرده اید؟</u> شناسه کاربری خود را وارد کنید','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ACOOUNT_UPDATE_SUCCESSFUL', 'به روز رسانی با موفقیت انجام شد!<br>پیغامی همراه با اطلاعات به روز رسانی برای شما ارسال گردید','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_REGISTRATION_SUCCESSFUL', 'ثبت نام با موفقیت انجام شد!<br>پیغامی همراه با مشخصات و اطلاعات لازم به پست الکترونیک شما فرستاده شد.','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_GREETINGS', '','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CC_SELECTED', 'شما کارت اعتباری را برای پرداخت  انتخاب نمودید. لطفا اطلاعات زیر راوارد نمایید','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CC_NUMBER', 'شماره کارت اعتباری:','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CC_EXP_DATE', 'تاریخ اتمام اعتبار','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_FOUND', 'یافت شد','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRODUCTS', 'محصول','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CATEGORIES', 'دسته بندی ها','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SEARCH_TIP', '<font color=gray>// جستجوی نام یا توضیحات برای اقلام یا دسته ها //</font>','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ADVANCED_SEACH_TITLE', 'فرم جستجوی پیشرفته','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NO_MATCHES_FOUND', 'موردی یافت نشد','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ADV_SEARCH_ANY', 'هر','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRICE_FROM', 'از','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRICE_TO', 'تا','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_IN', 'در','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_ID', 'شناسه سفارش','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER', 'سفارش','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CHECK_YOUR_ORDER', 'لطفا اطلاعات سفارش خود را بررسی نمایید','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CHOOSE_PAYMENT_SHIPPING_TYPES', 'لطفا نوع پرداخت و دریافت خود را انتخاب نمایید','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_CONFIRMATION', 'تایید سفارش','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_TAX', 'مالیات','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHIPPING_TYPE', 'حمل و نقل','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PAYMENT_TYPE', 'پرداخت','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CUSTOMER_COMMENTS', 'نظرات/پیشنهادات','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_PLACED', '<h1>با تشکر از سفارش شما</h1><br>لطفا برای پرداخت اقدام نمایید. توجه داشته باشید تا قبل از پرداخت موفق سفارش شما به صورت معلق باقی می ماند.','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_YOUR_ORDER', 'سفارش شما','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHIPPING_ADDRESS', 'نشانی دریافت کننده','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PLACE_ORDER', 'سفارش دادن','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CONTACT_INFORMATION', 'اطلاعات تماس','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_UPDATE_DETAILS', 'به روز رسانی جزئیات','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_REGISTRATION_FORM', 'فرم ثبت نام','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_CONTINUE_TIP', 'برای ادامه خرید باید ثبت نام کرده باشید<br>
	اگر هم اکنون عضو هستید وارد سیستم شوید در غیر این صورت ثبت نام کنید','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_REQUIRED', '<font color=red>*</font> اجباری','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_AUTHORIZATION_FIELDS', 'اطلاعات ورود به سیستم','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHOPPING_HISTORY', 'گزارش سفارشات','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CONTACTS', 'اطلاعات تماس','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ALL', 'همه','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_DEFAULT', 'پیش فرض','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NEXT', 'بعدی','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PREVIOUS', 'قبلی','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHOWALL', 'نمایش همه','general');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NAME', 'نام','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_DESCRIPTION', 'توضیحات','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHIPPING_LUMPSUM', 'حداقل هزینه','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHIPPING_PERCENT', 'درصد از کل مقدار سفارش','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PERCENT', 'درصد','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PAYMENT_CALCTAX', 'محاسبه مالیات برای این نوع پرداخت','general');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','DISCUSSION_TITLE', 'نظرات','discussion');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','DISCUSSION_NO_POSTS_ON_ITEM_STRING', 'برای این محصول پستی وجود ندارد','discussion');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','DISCUSSION_NICKNAME', 'نام','discussion');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','DISCUSSION_SUBJECT', 'موضوع','discussion');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','DISCUSSION_BODY', 'پست','discussion');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','DISCUSSION_DELETE_POST_LINK', 'حذف پست','discussion');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','DISCUSSION_ADD_MESSAGE', 'پست جدید','discussion');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CART_CONTENT_EMPTY', '(خالی)','shopping_cart');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CART_CONTENT_NOT_EMPTY', 'مورد: ','shopping_cart');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CART_TITLE', 'محتویات سبد','shopping_cart');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CART_CLEAR', 'خالی کردن سبد خرید','shopping_cart');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CART_UPDATE', 'به روز رسانی','shopping_cart');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CART_PROCEED_TO_CHECKOUT', 'پرداخت >>','shopping_cart');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CART_EMPTY', '<h3>سبد خرید شما خالی است</h3>','shopping_cart');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TABLE_PRODUCT_NAME', 'نام محصول','table');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TABLE_PRODUCT_QUANTITY', 'تعداد','table');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TABLE_PRODUCT_COST', 'قیمت','table');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TABLE_TOTAL', 'جمعا:','table');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TABLE_ORDER_TIME', 'زمان سفارش','table');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TABLE_ORDERED_PRODUCTS', 'محصولات سفارش شده','table');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TABLE_ORDER_TOTAL', 'جمع سفارش','table');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TABLE_CUSTOMER', 'مشتری','table');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TABLE_ORDER_COMMENTS', 'نظرات','table');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TITLE', 'ابزارهای مدیریت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_WELCOME', '<p><h1>به پنل مدیریت خوش آمدید</h1><br><p>برای مدیریت از منوها استفاده نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NEW_ORDERS', 'سفارشات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORIES_PRODUCTS', 'دسته ها و محصولات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATALOG', 'کاتالوگ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_OPTIONS', 'پارامتر های اضافی محصولات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SETTINGS', 'تنظیمات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SETTINGS_GENERAL', 'تنظیمات کلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SETTINGS_APPEARENCE', 'شکل ظاهری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANGUAGES', 'زبانها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANGUAGES_DIRECTION', 'جهت متن','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANGUAGES_RTL', 'راست به چپ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANGUAGES_DEL_CONFIRM','آیا از حذف این زبان اطمینان دارید؟','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANGUAGES_DEL_NOTALLOW','امکان حذف زبان پیش فرض وجود ندارد.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANGUAGES_DEL_SUCCESS','حذف با موفقیت انجام شد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANGUAGES_HIGHLIGHTING','مشخص کردن عبارتهای ترجمه نشده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANGUAGES_EXPSTR', 'عبارت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANGUAGES_DEFTRANSLATE','ترجمه پیشفرض','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANGUAGES_TRANSLATE','ترجمه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANGUAGES_ICON','نشانه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LOGO_DESCRIPTION','با استفاده از این قسمت می توانید برای سایت خود یک لوگو جدید قرار دهید . <br> برای لوگو می توانید از کلیه فایلهای تصویری که توسط مرورگرها پشتیبانی می شوند استفاده کنید .(jpg,Gif,Png)','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANGUAGES_LTR', 'چپ به راست','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_REPORTS', 'گزارشات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTOMERS', 'کاربران','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDERS', 'سفارشات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_VOTING', 'نظر سنجی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NEW_VOTING', 'افزودن نظر سنجی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EDIT_VOTING', 'ویرایش نظر سنجی شماره ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_POLL_RESULT', 'نتایج نظرسنجی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_POLL_SELECT', 'انتخاب نظرسنجی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BACKTO_VOTING', 'بازگشت به لیست نظرسنجی ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_BACKTO', 'بازگشت به','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHIPPING_PAYMENT', 'انواع پرداخت و دریافت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CC_PROCESSING', 'پروسه کارت اعتباری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_IMPORT_FROM_EXCEL', 'ورود از اکسل','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LANG_ISO2', 'کد زبان ISO2','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_IMPORT_FROM_EXCEL_ACCOUNTS', 'ورود پین ها از اکسل','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_IMPORT_FROM_EXCEL_ACCOUNTS_DESC', 'توسط این قسمت می توانید اطلاعات پین کد یا username و password مربوط به محصولات را از یک فایل اکسل مایکروسافت (XLS) وارد سیستم نمایید. 
<br/>لطفاً فایل نمونه سازگار با سیستم را دریافت نمایید.
<p><a href=example.xls>دریافت فایل Excel نمونه</a><br/>
','admin'); 
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NEWS', 'اخبار','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SYNCHRONIZE_TOOLS', 'نسخه پشتیبان','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DB_TOOLS', 'ابزارهای پایگاه داده ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_MODULES', 'ماژولها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LAYOUT', 'ظاهر و زبان','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_REMEMBER_ME', 'مرا به یاد داشته باش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BACK_TO_SHOP', 'بازگشت به فروشگاه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SORT_ORDER', 'ترتیب نمایش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ENTER_BUTTON','ورود','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRIMARY_COLUMN', 'ستون اصلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRIMARY_COLUMN_DESC', '(لطفا ستونی را انتخاب نمایید که منحصرا یک محصول را نشان دهد)<br><b>لطفا هنگام انتخاب دقت نمایید، انتخاب غلط امکان دارد نتایج غیر قابل قبولی به همراه داشته باشد!!!</b>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_UPDATE_SUCCESSFUL', '<font color=blue><b>به روز رسانی با موفقیت انجام شد!</b></font>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NO_PRODUCT_OPTIONS', 'گزینه های اضافی برای محصول موجود نمی باشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTOM_OPTION_TITLE', 'عنوان گزینه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADD_NEW_OPTION', '<b>اضافه کردن گزینه:</b>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NO_SPECIAL_OFFERS', 'پیشنهاد ویژه ای انتخاب نشده است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADD_SPECIAL_OFFERS', 'اضافه به لیست','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SPECIAL_OFFERS_DESC', 'پیشنهادات ویژه که در صفحه اول نمایش داده میشود.<br>
شما باید پیشنهادات ویژه را در<a href=admincp.php?dpt=catalog&sub=products_categories>دسته ها  و محصولات</a>,<br>
با کلیک بر روی <img src=images/admin_special_offer.gif border=0> در جدول محصولات انتخاب نمایید.<br>
شما فقط قادر به انتخاب محصولات دارای تصویر برای این قسمت می باشید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_UPDATE_GC_VALUE_BUTTON', 'به روز رسانی تعداد محصولات برای دسته بندی ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ROOT_WARNING', '<font color=red>تمامی محصولات این قسمت به مشتریان نشان داده نخواهد شد!</font>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ABOUT_PRICES', '<font class=small></font>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NEW_NEWSARTICLE', 'اضافه کردن خبر جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CURRENT_DATE', 'تاریخ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SEND_NEWS_TO_SUBSCRIBERS', 'ارسال این خبر به اعضای خبرنامه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NEWS_SUBSCRIBERS', 'اعضای خبرنامه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ALL_USERS', 'تمام مشتریان:','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_USERS_WITH_LOGIN_ON', 'کاربران با شناسه کاربری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXPORT_USER_TO_FILE', 'صدور لیست اعضا به فایل Excel','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXPORT_DB_TO_FILE', 'صدور پایگاه داده به فایل','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_USERS_EXPORTED_TO', 'کاربران با موفقیت به فایل Excel فرستاده شدند','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DB_EXPORTED_TO', 'پایگاه داده ها با موفقیت به فایل SQL فرستاده شد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_IMPORT_FROM_SQL', 'بازیابی از یک فایل SQL<br>(از فایلی که توسط سیستم ساخته شده استفاده نمایید)<br>
	<b>تمامی اقلام و موارد موجود شما  (محصولات و دسته ها) در سایت پاک خواهد شد!</b>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHOP_NAME', 'نام فروشگاه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHOP_URL', 'آدرس (URL) فروشگاه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHOP_EMAIL', 'پست الکترونیک کلی سایت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDERS_EMAIL', 'پست الکترونیک اعلام سفارشات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CHECK_STOCK', 'محاسبه مقدار و تغییر موجودی انبار','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHOW_CART_IN_NEW_WINDOW', 'باز شدن پنجره ای جدید هنگام اضافه کردن به سبد خرید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_UPDATE_GCV', 'محاسبه اتوماتیک تعداد اقلام در هر دسته بندی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CHECKSTOCK_DISABLED', 'کنترل مقدار موجود در انبار غیر فعال است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHOW_ADD2CART', 'نمایش دکمه اضافه به سبد خرید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHOW_BESTCHOICE', 'نمایش بهترین انتخاب ها در دسته بندی های خالی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_MAX_PRODUCTS_COUNT_PER_PAGE', 'حداکثر اقلام موجود در یک صفحه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_MAX_COLUMNS_PER_PAGE', 'حداکثر ردیف موجود در یک صفحه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_MAIN_COLORS', 'سه رنگ اصلی برای جداول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_COLOR', 'رنگ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CURRENCY_TYPES', 'واحد های پول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CURRENCY_NAME', 'نام واحد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CURRENCY_ID', 'شناسه واحد پول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DEFAULT_CURRENCY', 'واحد پول پیش فرض','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CURRENCY_EXCHANGERATE', 'نرخ تغییر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_POPULAR_PRODUCTS', '<b>پر طرفدارترین</b>محصولات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SALABLE_PRODUCTS', 'بیشترین فروش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_OUT_OF_STOCK', 'در انبار موجود نمیباشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SYNCR_DESC', 'در این قسمت شما می توانید پایگاه داده های خود را به یک فایل SQL صادر نمایید(ساخت نسخه پشتیبان).<br>
سپس بازگرداندن محصولات در صورت پاک شدن احتمالی بسیار ساده است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SPECIAL_OFFERS', 'پیشنهادات ویژه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_START_NEW_POLL', 'اضافه کردن نظر سنجی جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_POLL_WARNING', 'وضعیت سفارش زمانی را مشخص می کند که هم سفارش فعال است و همچنین در محدوده مشخص شده باشید.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_POLL_QUESTION', 'سوال نظر سنجی:','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_POLL_OPTIONS', 'گزینه های جواب:','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_POLL_ADDANSWER', 'افزودن جواب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_POLL_RESPONSE', 'توضیحات جواب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_POLL_CODE', 'کدپرسش','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_TITLE', 'دسته بندی ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_NEW', 'ساخت یک دسته بندی جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_PARENT', 'دسته بندی والد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_MOVE_TO', 'انتقال به','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_NAME', 'نام دسته','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_LOGO', 'نشان','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_ROOT', 'ریشه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_DESC', 'توضیحات','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_TITLE', 'محصولات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_NEW', 'اضافه کردن محصول جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_PARENT', 'اصلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_CODE', 'سریال محصول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_ID', 'کد محصول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_NAME', 'نام محصول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_RATING', 'امتیاز','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_PRICE', 'قیمت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_LISTPRICE', 'قیمت قبلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_INSTOCK', 'موجود در انبار','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_PICTURE', 'تصویر اصلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_THUMBNAIL', 'تصویر کوچک','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_BIGPICTURE', 'تصویر بزرگ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_ROOT', 'ریشه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_DESC', 'توضیحات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_BRIEF_DESC', 'توضیحات کوتاه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_SOLD', 'فروخته شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_VOTES', 'نظر سنجی','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_MAIN_MENU', 'منوی اصلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DB_UPDATE_SUCCESSFUL', 'محتویات پایگاه داده ها به روز گردید!','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXCEL_DESC1', 'لیست قیمت خود را به عنوان فایل CSV ذخیره کرده به توسط فرم پایین به سرور بفرستید<p>سیستم از شما میپرسد مایل به به روز رسانی پایگاه داده هستید؟ سپس به صورت خودکار این عمل را انجام می دهد.<p>همچنین دسته ها را تشخیص می دهد (ردیف ها با ستون های مشخص شده نام (اجباری) و توضیحات (اختیاری) - سایر ستون ها باید خالی باشد).<br>
شما میتوانید یک یا چند علامت `!` اضافه نمایید برای نمایش دسته ها یا دسته های زیرین. برای اطلاعات بیشتر فایل نمونه را دریافت نمایید:
<p><a href=example.csv>دریافت فایل Excel نمونه</a><br/><br/>
','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXCEL_PERSIAN_PROBLEM','<hr>
<b style=color:red;>توجه </b>: در صورتی که مشکل در شناسایی حروف فارسی داشتید باید<br/><ul style=padding-right:10px;>
<li>
- فایل notepad را در برنامه اکسل باز کنید و به صورت یک فایل متنی و به صورت Unicode Text ذخیره کنید.</li><li>
- حالا فایل جدید را در NotePad باز کنید و همه فضاهای خالی را از طریق ابزار Copy and Replace با علامت کاما , جابجا کنید</li><li>
- در این حالت میبینید که فضاهای خالی جایشان را به علامت کاما , داده اند</li><li> 
- در این مرحله فایل را Save As کرده و Encoding را UTF-8 و پسوند فایل را csv قرار دهید.</li></ul>
<hr>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXCEL_UPDATE_DB', '<b>به روز رسانی پایگاه داده ها</b>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXCEL_CLEAR_DB', '<b>حذف پایگاه داده ها:</b>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXCEL_CLEAR_DB_DESC', 'حذف کامل پایگاه داده ها  (در این گزینه شما نباید یک فایل CSV انتخاب کنید).','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_IGNORE', '- نادیده گرفتن این ستون','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADD_AS_NEW_PARAMETER', '- اضافه کردن گزینه های دلخواه به محصول','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_IMPORT_DESC1', 'فایل شما این ستون ها را در بر دارد<br>لطفا هر ستون را با یک ستون دیتابیس مشخص کنید<br>اگر شمااضافه کردن گزینه دلخواه را انتخاب کنید همچنین میتوانید<br>عنوان گزینه دلخواه را نیز مشخص نمایید.','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_IMPORT_DESC2', 'در صورتی که مقدار فیلد کلیدی از قبل موجود بود مشخصات محصول به روز شود<br>در غیر اینصورت محصول وارد پایگاه داده شود.','admin');


INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTOMER_TITLE', 'مشتریان','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_BRIEF','کلیات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_DESCRIPTION','توضیحات ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_KEYS','کلیدواژه ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_SEARCH','شرایط جستجو','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_BRIEF','کلیات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_DESCRIPTION','توضیحات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CHECKSTOCK_INSTOCK','عدم بررسی موجودی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_CATEGORIES','دسته های دیکر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_OTHER','دیگرجزئیات','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_LOGIN', 'شناسه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_PASSWORD', 'رمز عبور','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_EMAIL', 'پست الکترونیک','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_FIRST_NAME', 'نام','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_LAST_NAME', 'نام خانوادگی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_COUNTRY', 'کشور','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_ZIP', 'کد پستی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_STATE', 'استان','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_CITY', 'شهر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_ADDRESS', 'نشانی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_PHONE_NUMBER', 'تلفن','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_PHONE', 'تلفن','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_MOBILE','همراه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_SUBSCRIBE_FOR_NEWS', 'عضویت در خبر نامه','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_CONFIRM_PASSWORD', 'تکرار رمز عبور','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_RELATED_PRODUCTS_SELECT', 'لطفا یک محصول انتخاب نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SELECTED_PRODUCTS', 'محصولات انتخاب شده','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PICTURE_NOT_UPLOADED', '(بدون تصویر)','admin');


INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_FAILED_TO_UPLOAD_FILE', '<b><font color=red>فایل ارسال نشد</font></b>','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_CANT_FIND_REQUIRED_PAGE', 'صفحه مورد نظر شما یافت نشد','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_CANT_READ_FILE', 'سیستم قادر به خواندن فایل نمی باشد','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_PRODUCT_NAME', 'لطفا حداقل نام محصول را وارد نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_FORBIDDEN', '<center><br>شما اجازه دسترسی ندارید</center>','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_WRONG_PASSWORD', 'شناسه ورود/رمز عبور اشتباه است','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_LOGIN', 'لطفا شناسه ورود خود را وارد نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_EMAIL', 'لطفا آدرس ایمیل صحیح وارد نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_LOGIN_SHOULD_START_WITH_LATIN_SYMBOL', 'شناسه ورود باید با یک حرف لاتین شروع شود','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_WRONG_PASSWORD_CONFIRMATION', 'تایید رمز عبور صحیح نمی باشد','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_NAME', 'نام خود را وارد نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_COUNTRY', 'کشور خود را وارد نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_CITY', 'شهر خود را وارد نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_ZIP', 'کد پستی خود را وارد نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_STATE', 'استان خود را مشخص نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_ADDRESS', 'نشانی خود را وارد نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_PHONE', 'شماره تلفن خود را وارد نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_MOBILE', 'شماره همراه خود را وارد نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_NICKNAME', 'نام مستعار خود را وارد نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_MESSAGE_SUBJECT', 'موضوع را مشخص نمایید','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_PRICE', 'قیمت باید عددی مثبت باشد','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_USER_ALREADY_EXISTS', 'متاسفانه کاربری با همین شناسه قبلا ثبت گردیده','errors');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_UPDATE_COLUMN_IS_NOT_SET', 'ستون اصلی یافت نشد! به روز رسانی انجام نگردید','errors');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','QUESTION_DELETE_PICTURE', 'حذف تصویر؟','quesions');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','QUESTION_DELETE_CONFIRMATION', 'آیا مطمئن به حذف این مورد هستید؟','quesions');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','QUESTION_UNSUBSCRIBE', 'آیا مطمئن به حذف حساب خود هستید؟','quesions');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_REMIN_PASSWORD_DESC','در صورتی که شما صاحب این نام کاربری هستید و در سایت عضو می باشید ، برای تغییر رمز عبور خود بر روی لینک مربوطه کلیک کنید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_CHANGED_PASSWORD','بازیابی رمز عبور','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_YOUR_LOGIN','نام کاربری شما ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_DELETE_CUSTOMER_SUBJECT', 'حساب شما به حالت معلق در آمده است','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_FORGOT_PASSWORD_LINK', 'برای بازیابی و تغییر رمز عبور خود بر روی لینک کلیک کنید:','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_FORGOT_PASSWORD_LINK_DIRECT', 'می توانید این لینک را در مرورگر خود کپی کنید :','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_FORGOT_PASSWORD_SUBJECT', 'رمز عبور شما:','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_ADMIN_ORDER_NOTIFICATION_SUBJECT', 'سفارش جدید!','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_CUSTOMER_ORDER_NOTIFICATION_SUBJECT', 'سفارش شما','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_MESSAGE_PARAMETERS', 'Content-Type: text/html; charsutf8','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_HELLO', 'با سلام','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_SINCERELY', 'با تشکر','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_THANK_YOU_FOR_SHOPPING_AT', 'با تشکر از خرید شما در','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_ORDER_WILL_BE_SHIPPED_TO', 'سفارش شما فرستاده خواهد شد به:','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_OUR_MANAGER_WILL_CONTACT_YOU', 'مسئولان ما در اولین فرصت با شما تماس خواهند گرفت','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_YOUVE_BEEN_REGISTERED_AT', 'شما با موفقیت ثبت نام کردید در','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_REGISTRATION', 'ثبت نام','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_YOUR_REGTRATION_INFO', 'اطلاعات ثبت نام شما:','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_NEWS_OF', 'اخبار','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_YOUR_PASSWORD', 'رمز عبور شما','email');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EMAIL_ACCOUNT_CLOSED', 'با تشکر از خرید شما، حساب شما توسط مدیران ما بسته شده است.','email');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CHANGE_PASSWORD_DESC', 'رمز عبور خود را فراموش کرده اید <br> صاحب پست الکترونیک صاحب حساب کاربری در نظر گرفته می شود و با ورود رمز عبور جدید می توانید رمز خود را تغییر دهید !<br> پس از تغییر رمز وارد سیستم خواهید شد.<br>','general');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','WARNING_DELETE_INSTALL_PHP', '<span dir=rtl stylefloat: right>اخطار: فایل<b>install.php</b> در ریشه (root) سایت وجود دارد آنرا پاک کنید!<br></span>','warning');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','PROMPT_DELETE_INSTALL_PHP', '<span dir=rtl style=float: right>برای حذف این فایل کلیک کنید.</span>','warning');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','WARNING_MAGIC_QUOTES_GPC', '<b>magic_quotes_gpc</b> در تنظیمات PHP شما بر روی<b>Off</b> است. شما باید آنرا فعال نمایید','warning');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','WARNING_WRONG_CHMOD', 'اجازه های دسترسی اشتباه برای: products_files, products_pictures, temp, templates_c (و یا این فولدر ها موجود نیستند).<br> لطفا اجازه نوشتن برای این فولدرها را فعال نمایید (chmod 777 برای این فولدرها).<br>سعی می شود این تغییر اعمال شود. دوباره سایت را باز کنید.','warning');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DELETE_ALL_PRODUCTS','حذف تمام محصولات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PHOTOS','گالری تصویر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_VIDEOS','گالری فیلم','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_VIDEOS_VIDEO','فایل فیلم','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DEFAULT_PHOTO', 'پیش فرض' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PHOTO_PREVIEW','پیش نمایش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SAVE_PHOTOS', 'ذخیره تصاویر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_PICTURES', 'تصاویر' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DATE_ADDED','تاریخ ارسال' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DATE_MODIFIED','تاریخ ویرایش' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_VALUE_VARIANTS', 'گزینه های موجود','admin');



INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_VALUES', '<b>مقادیر</b>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_OPTION', 'گزینه ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NO_VALUES', 'هیچ گزینه ای موجود نیست','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ONE_VALUE', 'مقدار','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADD_VALUE', '<b>مقدار جدید:</b>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_GOBACK_TO_OPTION_LIST', 'بازگشت به لیست گزینه ها>>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CONFIGURATOR_TITLE','مقدار دلخواه برای','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_TYPE','نوع کوپن','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_TYPE_SU','یکبارمصرف','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_TYPE_MUL','چند بار مصرف ، محدود','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_TYPE_MUU','چند بار مصرف ، نا محدود.','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_DISCOUNT','تخفیف','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_EMPTY','هیچ کوپنی تعریف نشده است.','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_NOT_USED','کوپن استفاده نشده است','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_USED','بار استفاده شده ','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_VALID_TO','معتبر تا','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_EXPIRED','منقضی شده','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_CODE_EXISTS','منقضی شده','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_CODE_OPTIONAL','کد کوپن ﴿اختیاری﴾','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_CODE_OK','تایید','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_CODE_WRONG','کد کوپن وارد شده اشتباه است','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_CODE_PROCCESSING','در حال بررسی کوپن','general');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ON_OFF','فعال','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BY_DEF','پیش فرض','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_VALUE','مقدار','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRICE_SURPLUS','قیمت بعلاوه مقدار','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_OFFER_TO_SELECT','اجازه انتخاب این گزینه توسط مشتریان','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NO_VARIANTS','گزینه ای انتخاب نگردیده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_OFFER_TIMES','بار','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NOT_DEFINED','تعیین نشده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ANY_VALUE','مقدار دلخواه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SELECTING_FROM_VALUES','قابل انتخاب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SELECT_SETTING', 'تنظیمات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_VARIANTS', 'گزینه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CURRENT_PRICE_OPTION','قیمت نهایی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','COULD_NOT_DELETE_THIS_PRODUCT', 'این فایل قابل پاک شدن نمی باشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','COULD_NOT_DELETE_THESE_PRODUCT', 'این محصول قابل پاک شدن نمی باشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_VIEWED_TIMES', 'بیشترین محصولات بازدید شده' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_VIEWED_TIMES', 'بیشترین بازدیدها' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_VIEW_COUNT', 'تعداد بازدید' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_NEWCATEGORY_NOT_DEFIND', 'باید از لیست یک دسته بندی را انتخاب کنید' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADDITION','افزایش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INPUT_ADDITION_FIELD', 'لطفا فیلد های اجباری را پر کنید' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTOMER_REG_FIELDS', 'فرم ثبت نام مشتریان' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTOMER_REG_FIELDS_DESCRIPTION', 'در این قسمت شما میتوانید گزینه های دلخواه برای ثبت نام مشتریان تعریف کنید(برای مثال کد ملی، شماره فکس و ...) و می توانید مشخص نمایید این گزینه ها اجباری هستند یا خیر.' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_FIELD_NAME', 'عنوان فیلد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_REQUIRED_TO_SET', 'اجباری' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_GOTO_URL', 'Go to URL' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ALL_PRODUCTS', 'تمامی محصولات' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PROMPT_TO_SELECT_CATEGORY', 'لطفا دسته را انتخاب نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','NOT_DEFINED', 'نا مشخص' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_COUNTRIES', 'کشورها' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_COUNTRY_NAME', 'کشور' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_COUNTRY_ISO2', 'ISO2' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_COUNTRY_ISO3', 'ISO3' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ZONES', 'استانها' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CITIES', 'شهرها' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_GOOGLEANLYTIC', 'آنالیز گوگل' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_GOOGLEANLYTIC_TITLE', 'آنالیز گوگل ابزاری است که صاحبان وب سایت ها توسط آن می توانند آمارهای متنوعی از قبیل بازدید وب سایت خود، کلمه های جستجو شده و... مطلع شوند.<br>
برای استفاده از این امکان گوگل به نشانی <a href=http://www.google.com/analytics target=_blank>http://www.google.com/analytics</a> مراجعه نموده و پس از ورود به سیستم شناسه پروفایل خود را دریافت و در محل مربوطه در این قسمت وارد نمایید.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_GOOGLESITEMAP','نقشه سایت گوگل','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_GOOGLESITEMAP_DESCRIPTION','
<p>
توسط نقشه سایت می توانید ایندکس شدن سایت خود را در گوگل بالا ببرید. <br>
نقشه سایت که توسط گوگل قابل قبول است فرمت خاصی دارد که توسط سیستم به صورت خودکار ایجاد می گردد.
<br>
برای استفاده از این خدمات گوگل باید در بخش Webmasters  گوگل ثبت نام نموده و سایت خود را ثبت و اعتبارسنجی نمایید.
<br>
برای اعتبار سنجی گوگل یک تگ Meta برای قراردادن داخل سایت در اختیارتان قرار می دهد. لطفاً مقدار آن تگ را در قسمت پایین قرارداده و سپس سایت خود را اعتبار سنجی نمایید.
</p>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ZONE_NAME', 'نام استان' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CITY_NAME', 'نام شهر' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CITY_IRMC', 'کد ایران مارکت' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CITY_CODE', 'کد شهر' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ZONE_CODE', 'کد استان' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','DELIVERY_ADDRESS', 'نشانی دریافت' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_GENERAL_INFORMATION', 'اطلاعات کلی' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NO_COUNTRIES', 'کشوری برای انتخاب نیست' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SELECT_ZONES', 'لطفا منطقه را انتخاب نمایید' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_ZONE_DOES_NOT_CONTAIN_TO_COUNTRY', 'لطفا منطقه را از لیست انتخاب نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_CITY_DOES_NOT_CONTAIN_TO_COUNTRY', 'لطفا شهر را از لیست انتخاب نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NO_COUNTRIES_PROMPT', 'لطفا کشور را قبل از انتخاب منطقه انتخاب نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTOMER_LOG', 'فعالیت کاربران و مدیران','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTOMER_LOGIN', 'شناسه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTOMER_ENTER_TIME', 'زمان ورود','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_REPORT_CLEAR', 'حذف','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDER_STATUES', 'وضعیت سفارش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDER_NUMBER', 'شماره سفارش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDER_STATUS_NAME', 'وضعیت' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_COULDNT_DELETE_ORDER_STATUS', 'وضعیت سفارش به دلیل وجود سفارش فعال قابل پاک شدن نیست','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NEW_ORDER_STATUS', 'وضعیت سفارش جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_COMPLETED_ORDER_STATUS', 'وضعیت سفارش تکمیل شد ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_STATUSES_COUNT_PROMPT_ERROR', 'حداقل دو وضعیت سفارش وارد نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_STATUSES_EQUAL_PROMPT_ERROR', 'وضعیت سفارش تکمیل شده و جدید باید متفاوت باشند','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CHANGE', 'تغییر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHOW', 'نمایش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHOW_ORDER_IN_STATUS', 'نمایش سفارش در وضعیت های ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCUSSIONS', 'نظرات کاربران','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCUSSION_ADDITION_TIME', 'زمان پست','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ANSWER_TO_DISCUSSION', 'جواب دادن','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_RETURN_TO_MESSAGES', 'بازگشت به لیست نظرات کاربران','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CLEAR', 'حذف','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_VISIT_LOG', 'گزارش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_STATUS', 'وضعیت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_STATUS', 'وضعیت','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_AUX_PAGES', 'صفحات محتوا','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AUX_PAGE_NAME', 'عنوان صفحه' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AUX_PAGE_TEXT_TYPE', 'نوع متن صفحه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AUX_PAGE_REF', 'لینک برای قرار دادن در قالب طراحی سایت' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AUX_PAGE_EDIT', 'ویرایش' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AUX_PAGE_ADD_NEW', 'اضافه کردن صفحه جدید' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AUX_PAGE_TEXT', 'متن صفحه' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AUX_PAGES_DESCRIPTION', 'این جدول لیست صفحات اطلاع رسانی (محتوا) را نشان می دهد. شما می تواندید صفحات جدید اضافه کرده و یا صفحات فعلی را ویرایش کنید.<p>توجه داشته باشید برای دیدن این صفحات در سایت باید لینک صفحات خود را در قالب طراحی شده سایت خود جای دهید.' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_GOBACK_TO_AUX_PAGES', 'بازگشت به لیست صفحات محتوا>>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_APPENDED_PARENTS', 'اضافه کردن محصول به دسته های دیگر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CONFIGURATOR', 'پارامترها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ACCOUNT_LINK', 'حساب من','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_VISIT_HISTORY_SHOWING',  'مشاهده گزارش' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_RECORDS', 'مورد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUNT_ORDER_IN_STATUS', 'سفارش در وضعیت' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CONTACT_INFORMATION_DOWN_CASE', 'اطلاعات تماس','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ADDRESS_BOOK', 'دفتر نشانی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_HISTORY', 'لیست سفارشات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_VISIT_HISTORY', 'گزارش ورود و خروج','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_RECEIVER', 'دریافت کننده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_UPDATE_CONTACT_INFO', 'ویرایش اطلاعات تماس','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_UPDATE_ADDRESSES', 'ویرایش  نشانی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_DEFAULT_ADDRESS', 'نشانی پیشفرض','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_SHOW', 'نمایش آرشیو سفارشات قبلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ADD_NEW_ADDRESS', 'اضافه کردن نشانی جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_GO_TO_ADDRESS_LIST', 'بازگشت به لیست نشانی ها >>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CANCELED_ORDER_STATUS', 'انصراف داده شده' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_INSUFFICIENT_IN_STOCK', 'در انبار موجود نیست','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_INSUFFICIENT_IN_STOCK_PROMPT', 'عدد را به سبد خرید به علت تعداد کم در انبار وجود ندارد{COUNT} امکان اضافه کردن','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_STATUS_IS_NOT_DEFINED', 'وضعیت مشخص نشده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CONF_COUNTRY_IS_NOT_DEFINED','کشور مشخص نشده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ALLOW_PRODUCTS_COMPARISON', 'فعال کردن مقایسه محصول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRODUCT_PRICE', 'قیمت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRODUCT_BRIEF_DESC', 'توضیحات کوتاه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRODUCT_COMPARISON', 'مقایسه اقلام' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SELECT_TO_COMPARISON', 'انتخاب برای مقایسه' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COMPARE_SELECTED_PRODUCT', 'مقایسه اقلام انتخاب شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SELECT_IS_POSSIBLE', '[ قابل انتخاب ]','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_VALUE_IS_UNDEFINED', '[ مشخص نشده ]','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_ENABLED', 'فعال' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADD_PRODUCT_INTO', 'اضافه به لیستها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADD_NEW_CATEGORY_BUTTON', 'اضافه کردن دسته بندی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADD_NEW_PRODUCT_BUTTON', 'اضافه کردن محصول','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EPRODUCT_FILE', 'فایل محصول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_IS_PROGRAM', 'محصول قابل دانلود است' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','PRODUCT_IS_DOWNLOADABLE', '<p>این محصول به صورت فایل می باشد و پس از پرداخت موفق توسط شما بلافاصله قابلیت دانلود دارد.' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','PRODUCT_IS_DOWNLOADABLE_NOTE', ' لینک دانلود محصول هم به نشانی ایمیل شما ارسال میگردد و نیز در صفحه حساب شخصی شما ذخیره میگردد.' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EPRODUCT_FILENAME', 'نام فایل' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EPRODUCT_FILESIZE', 'حجم فایل' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EPRODUCT_AVAILABLE_DAYS', 'تعداد روزهای قابل دانلود: ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DAYS', 'روز','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EPRODUCT_DOWNLOAD_TIMES', 'حداکثر تعداد دانلود (در صورت نا محدود بودن خالی باشد)','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_FILE_NOT_UPLOADED', '(فایل فرستاده نشد)','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_WEIGHT', 'وزن','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_META_DESCRIPTION', 'توضیحات موتورهای جستجو','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_META_KEYWORDS', 'کلید واژه های موتورهای جستجو','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_FREE_SHIPPING', 'ارسال رایگان<br><small>(تاثیری بر قیمت حمل و نقل ندارد)</small>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_MIN_ORDER_AMOUNT', 'کمترین مقدار سفارش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SEARCH_PRODUCT_IN_CATEGORY', 'جستجوی محصولات در این دسته','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SEARCH_BUTTON', 'پیدا کردن' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_N_RECORD_IS_SEARCHED', '{N} مورد یافت شد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHOW_ALL_PRODUCT_IN_THIS_CATEGORY', 'نمایش تمامی اقلام موجود در این دسته بندی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ADVANCED_SEARCH_IN_CATEGORY', 'جستجوی پیشرفته','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SEARCH_IN_SUBCATEGORIES', 'جستجو در دسته بندی های زیرین','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ALLOW_SEARCH_IN_CATEGORY', 'فعال کردن جستجوی پیشرفته در این دسته','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ALLOW_SEARCH_IN_CATEGORY_PROMPT','این گرینه را در صورتی فعال کنید که میخواهید جستجوی پیشرفته در دسته فعال شود','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SEARCH_IN_CATEGORY_PARAMETR_VALUE_ARBITRARILY', 'مشخص شده توسط کاربر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SEARCH_IN_CATEGORY_PARAMETR_VALUE_SELECT_FROM_VALUES', 'قابل انتخاب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SEARCH_RESULT', 'نتایج جستجو','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_UNIMPORTANT', 'نیاز نیست','admin'); 
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SELECT_PARAMETRS', 'امکانات موجود','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TAXES', 'مالیات','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TAX_CLASSES', 'نوع مالیات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CLASS_NAME', 'نام دسته مالیات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TAX_BASED_ON_ADDRESS', 'مقدار مالیات بستگی دارد به :','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DEFINE_RATE', 'مقدار مالیات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDER_DELIVERY_ADDRESS', 'محل دریافت کننده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SCORE_DELIVERY_ADDRESS', 'محل پرداخت کننده','admin');       
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ALL_COUNTRIES', 'تمام کشور ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ALL_REST_COUNTRIES', 'کشورهای دیگر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SET_COUNTRY_RATE', 'لطفا مالیات را برای کشورها مشخص نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DEFINE_COUNTRY_RATE', 'مشخص کردن مالیات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_OVERALL_RATE', 'نرخ کلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_RATE_IS_DEPENDED_ON_ZONE', 'نرخ مالیات بر اساس منطقه ها (نرخ برای {N} منطقه از {M} مشخص شده است.)','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SET_RATE_BY_ZONE', 'تنظیم نرخ مالیات بر اساس استان ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BACK_TO_TAX_CLASS_LIST', 'بازگشت به لیست نرخ های مالیاتی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BACK_TO_TAX_COUNTRY_LIST', 'بازگشت به تعریف نرخ مالیات بر اساس کشورها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DEFINE_ZONE_RATE', 'تعریف نرخ مالیات در کشور','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SET_ZONE_RATE', 'لطفا نرخ مالیات را برای مناطق در لیست مشخص کنید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ALL_ZONES', 'تمامی مناطق','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ALL_REST_ZONES', 'مناطق دیگر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_RATE_PERCENT_RANGE', 'مقدار 
 - بین 0 تا 100','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_RATE', 'نرخ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CATEGORY', 'دسته بندی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ADDRESS', 'نشانی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ADDRESSES', 'نشانی ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_EQUAL_TO_SHIPPING_ADDRESS', 'همانند نشانی دریافت کننده' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_INPUT_IF_OTHER', 'لطفا در صورت تفاوت وارد نمایید' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDERING', 'پرداخت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_AM_NEW_CUSTOMER', 'کاربران جدید...','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_REGISTER', 'ثبت نام در سایت!!','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_I_AM_REGISTERED_CUSTOMER', 'کاربران ثبت نام کرده..','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_REGISTERED_CUSTOMER', 'کاربر ثبت نام کرده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_RECEIVER_FIRST_NAME', 'نام دریافت کننده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_RECEIVER_LAST_NAME', 'نام خانوادگی دریافت کننده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PAYER_FIRST_NAME', 'نام پرداخت کننده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PAYER_LAST_NAME', 'نام خانوادگی پرداخت کننده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_BILLING_ADDRESS', 'نشانی پرداخت کننده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULE_NAME', 'نام ماژول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULE_DESCRIPTION', 'توضیحات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULE_STATUS', 'وضعیت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULE_ACTIONS', 'عملیات','admin');                
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULE_INSTALLED', 'نصب شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULE_UNINSTALLED', 'نصب نشده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULE_SETTING', 'تنظیمات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULE_INSTALL', 'نصب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_TITLE_SHIPPING_MODULE_SETTING', 'تنظیم ماژول حمل و نقل','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHIPPING_MODULES', 'ماژولهای حمل و نقل','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_TITLE_PAYMENT_MODULE_SETTING', 'تنظیم ماژول پرداخت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PAYMENT_MODULES', 'ماژولهای پرداخت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_LOGO', 'لوگو','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ICON', 'نشانه سایت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ICON_DESCRIPTION', '
فایلی با فرمت JPG، GIF، PNG و یا ICO برای ایجاد نشان سایت وارد نمایید.<br>
استفاده از تصاویر با هر سایزی امکانپذیر است ولی برای بهترین بازده از فایل های کوچک استفاده نمایید.<br> 
فایل های با پس زمینه شفاف (Transparent) نیز پشتیبانی می گردد.<br> 
سیستم به صورت خودکار سایز و فرمت تصویر ارسالی را به صورت مناسب تنظیم خواهد کرد.<br>
ضمنا حجم فایل باید کمتر از 175 کیلو بایت باشد.<br> 
','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHIPPING_MODULE_EMAIL_COMMENTS_TEXT', 'اطلاعات تحویل که هنگام خرید توسط ایمیل برای مشتری فرستاده می شود','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PAYMENT_MODULE_EMAIL_COMMENTS_TEXT', 'متنی که هنگام پرداخت، توسط ایمیل به مشتری فرستاده می شود','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHIPPING_METHODS_ARE_ALLOWED', 'این نوع پرداخت قابل برای سیستم های زیر قابل استفاده است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCOUNTS' ,'تخفیفات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCOUNTS_COUPONS','کوپن های تخفیف','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CREATE_COUPON','ایجاد کوپن جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CREATE_COUPON','ایجاد کوپن جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_CODE','کد کوپن','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUPON_CODE','کد کوپن','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCOUNTS_PROMPT', 'سیستم تخفیف به مشتریان - لطفا چگونگی تخفیف را انتخاب نمایید:','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCOUNT_IS_SWITCHED_OFF', 'تخفیف غیر فعال است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCOUNT_CUSTOMER_GROUP', 'مقدار تخفیف = تخفیف مربوط به گروه مشتری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCOUNT_GENERAL_ORDER_PRICE', 'تخفیف بر مبنای مقدار سفارش محاسبه می شود (ضوابط در قسمت پایین تعیین میشود)','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCOUNT_CUSTOMER_GROUP_PLUS_GENERAL_ORDER_PRICE', 'تخفیف بر مبنای تخفیف گروه مشتری به علاوه تخفیف جمع مبلغ سفارش تعیین می شود','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCOUNT_MAX_CUSTOMER_GROUP_GENERAL_ORDER_PRICE', 'تخفیف بر مبنای حداکثر تخفیف از گروه مشتری یا تخفیف جمع مبلغ سفارش تعیین می گردد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCOUNT_GENERAL_ORDER_PRICE_TITLE', 'تخفیف بر مبنای جمع مبلغ سفارش محاسبه می شود (ضوابط ):','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCOUNT_GENERAL_ORDER_PRICE_PROMPT', 'در جدول زیر شما می توانید مقدار تخفیف مختلف برای مقدار سفارشات مختلف تعیین کنید.لطفا هر دو را مشخص نمایید مانند:  (<i>مبلغ سفارش</i>، <i>درصد تخفیف</i>). هر جفت نشان دهنده <i>درصد تخفیف</i>(%) است هنگامی که مبلغ سفارش خریدار  از <i>مبلغ سفارش</i> بیشتر باشد.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_GENERAL_ORDER_PRICE', 'مبلغ سفارش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_GENERAL_ORDER_PRICE_RANGE', 'درصد تخفیف(%), هنگامی عمل خواهد کرد که جمع سفارش بیشتر از مقدار تعیین شده باشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_UNREGISTERED_CUSTOMER_DISCOUNT_PROMPT', 'به مشتریان ثبت نام کرده تخفیف تعلق میگیرد.برای اطلاعات بیشتر با ما تماس بگیرید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_UNREGISTERED_CUSTOMER_COMBINED_DISCOUNT_PROMPT', 'امکان وجود دارد که به مشتریان ثبت نام کرده تخفیف تعلق بگیرد.برای اطلاعات بیشتر با ما تماس بگیرید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_IS_ACCESSIBLE', 'برای تمامی کاربران','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_IS_ACCESSIBLE_TO_REGISTERED_CUSTOMERS', 'برای کاربران ثبت نام کرده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_IS_NOT_ACCESSIBLE', 'غیر قابل دسترسی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_ACCESS_LEVEL', 'سطح دسترسی دسته بندی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CATEGORY_IS_NOT_ACCESSIBLE_SHORT', 'غیر فعال','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_EMPTY_SEARCH_RESULT', 'محصولی یافت نشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MIN_ORDER_AMOUNT', 'کمترین مقدار سفارش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ITEM', 'مورد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_KG', 'کیلو گرم','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHOW_AUX_PAGE', 'نمایش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TAX_CLASS', 'نوع مالیات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_SHIPPING', 'نوع دریافت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CHANGE_ADDRESS', 'تغییر نشانی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SELECT_ORDER_SHIPPING_METHOD_PROMPT', 'لطفا نوع سفارش خود را مشخص نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CONTINUE_BUTTON', 'ادامه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TABLE_PRODUCT_COST_WITHOUT_TAX', 'قیمت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRED_TOTAL', 'جمع کالا','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_TARGET_SHIPPING_ADDRESS', 'سفارش فرستاده خواهد شد به','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_COMMENT', 'توضیحات (اختیاری)','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_FORMALIZE_ORDER', 'سفارش قطعی!','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SET_ZIP_RATE', 'مشخص نمودن مالیات بر اساس کد پستی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ZIP', 'کد پستی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_PAYMENT', 'پرداخت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SELECT_ORDER_PAYMENT_METHOD_PROMPT', 'نوع پرداخت را مشخص نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_OTHER_ADDRESS', 'اضافه کردن نشانی جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','SELECT_BUTTON', 'انتخاب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PAYMENT_ERROR', 'خطا در هنگام انجام پرداخت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PROMPT_TO_SELECT', 'انتخاب نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NO_SHIPPING_METHODS_TO_SELECT', 'هیچ روش ارسالی موجود نیست','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NO_PAYMENT_METHODS_TO_SELECT', 'هیچ روش پرداختی موجود نیست','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ZIP_RATE_PROMPT', 'If you\'d like to define tax rates by counties, please use following ZIP codes taxing system.<br>
In the following form input ZIP masks - numbers/letters and asterixes (*). Asterix is assumed as any symbol. For example, mask 12*** is applicable for ZIP codes of length of 5 symbols and \'12\' as first two symbols - e.g. 12365, 12963, 12AB7 (you may use both letters and nummbers).<br><br>
Among all masks applicable for particular ZIP code, the closest one will be used. For example if you have to masks defined: 92*** and 923**, and customer inputs ZIP code 92301 - in this case mask 923** will be used for tax rate calculation, and 92*** will be ignored.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ZIP_RATE_PROMPT2', 'ZIP code tax rates are higher priority than state codes. Tax rate defined by state will be used only if there is no mask for ZIP code customer provided.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CURRENCY_ISO3', 'واحد پول به صورت اختصار','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDER_SEARCH_BY_NUMBER', 'جستجوی سفارش بر اساس شناسه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDER_SEARCH_BY_CONDITION', 'جستجوی سفارش با محدودیت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDER_SEARCH_FDATE', 'از تاریخ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDER_SEARCH_TDATE', 'تا تاریخ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDERS_ARE_NOT_SEARCHED', 'سفارشی یافت نشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ABOUT_CUSTOMER', 'اطلاعات مشتری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_QUICK_ORDERING', 'پرداخت بدون ثبت نام','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDER_LIST_GO_BACK', 'بازگشت به لیست سفارش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CHANGE_STATUS', 'تغییر وضعیت سفارش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CC_INFO', 'اطلاعات کارت اعتباری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_INFO_CAN_BE_SHOWN_WHEN_HTTPS_IS_USED', 'نمایش اطلاعات فقط در SSL (HTTPS) موجود است','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_IP_ADDRESS', 'IP مشتری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PAYER', 'پرداخت کننده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CC_NUMBER', 'CC number','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CC_HOLDER_NAME', 'CC holder','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CC_EXPIRES', 'CC expires','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CC_CVV', 'CVV','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDERED_PRODUCTS', 'اقلام سفارش شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHIPPING_COST', 'جمع هزینه ارسال','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SELECT_PRODUCT_BY_PARAMS', 'جستجوی اقلام بر اساس پارامتر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BACK_TO_SEARCH_FORM', 'بازگشت به فرم جستجوی مشتریان','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SEARCH_OF_CUSTOMER', 'جستجوی مشتریان ثبت نام شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SEARCH_OF_CUSTOMER_PROMPT', 'موارد جستجو را وارد نمایید. موارد خالی نادیده گرفته میشوند.<br>برای دیدن تمامی اعضا ، تمامی موارد را خالی رها کنید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTOMER_GROUP_NAME', 'نام گروه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_REGISTRATION_TIME', 'زمان ثبت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SELECT_PARAMETRS_PROMPT', 'انتخاب پارامترهای موجود ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NOTANY_PARAMETRS_PROMPT', 'هیچ  پارامتری برای فعالسازی این گزینه وجود ندارد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHOW_PRODUCT_IN_SUBCATEGORY', 'نمایش محصولات دسته های زیرین میان محصولات این دسته','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDER_EXECUTING', 'پروسه سفارش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TIME', 'زمان','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTOMERS_HAS_BEEN_EXPORTED_SUCCESSFULLY', 'لیست مشتریان با موفقیت به فایل CSV فرستاده شد.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DOWN_LOAD', 'دانلود','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTOMER_GROUP', 'گروه مشتری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NO_RECORD_FOUND', 'موردی یافت نشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_COUNT_DOWNLOAD_IS_EXCEEDED_EPRODUCT_DOWNLOAD_TIMES', 'تعداد دفعات دانلود به پایان رسیده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_AVAILABLE_DAYS_ARE_EXHAUSTED_TO_DOWNLOAD_PRODUCT', 'فایل قابل دسترسی نمی باشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_FILE_NOT_AVAILABLE', 'فایل وجود ندارد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRODUCT_SORT', 'چیدمان بر اساس: نام ({ASC_NAME} | {DESC_NAME}), قیمت ({ASC_PRICE} | {DESC_PRICE}), امتیاز مشتریان ({ASC_RATING} | {DESC_RATING})','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ASC', 'صعودی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_DESC', 'نزولی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_REMANDER_EPRODUCT_DOWNLOAD_TIMES', 'بیشترین تعداد دانلود:','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DOWNLOAD_TIMES', 'دانلود' ,'admin'); 
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SHIPPING_FREIGHT', 'هزینه حمل و نقل','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_DISCOUNT', 'تخفیف','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ANY', 'هر کدام','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MIN_DISCOUNT', 'حداقل تخفیف','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PAYMENT_METHODS_USING_THIS_MODULE', 'انواع پرداخت<br>قابل استفاده با این ماژول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PAYMENT_SHIPPING_USING_THIS_MODULE', 'انواع ارسال<br>قابل استفاده با این ماژول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SETTING_NAME', 'تنظیمات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NO_SETTINGS', 'هییچ گزینه ای موجود نیست','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MAKE_MORE_EXACT_CART_CONTENT', 'تعدادی از محصولات سفارش شده شما از بازدید گذشته شما باقی مانده است.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_INVALID_SYMBOL_LOGIN_INFO', 'علامات \', \\, \, <, > کارکترهای مجاز برای شناسه و رمز نمی باشند','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCT_REPORT', 'گزارش محصولات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ACTIONS', 'عملیات','admin'); 

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTGROUP', 'گروه های کاربران' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTGROUP_DESCRIPTION', 'در این قسمت شما می توانید گروه های مشتریان و تخفیفات هر گروه را مشخص نمایید.<br>بیاد داشته باشید که تخفیف محاسبه نمی شود تا زمانی  که مشخص نشده  است در [مشتریان /سفارشات] -> [تخفیفات]' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_GROUP', 'گروه' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DISCOUNT', 'درصد تخفیف' ,'admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NEWS_TITLE', 'عنوان','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PICTURE', 'عکس','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_FLASH', 'flash','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_HTML', 'html','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CODE', 'code','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_POSITION','محل نمایش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_BLOCK','بلوک','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEXT_TO_PUBLICATION', 'متن خبر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEXT_TO_MAIL', 'متن برای ارسال ایمیل','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ALL_NEWS', 'تمامی پستهای خبر' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NOT_HTML', 'غیر HTML','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_HTML', 'HTML','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_FILE_IS_DOWNLOADED', 'فایل فرستاده شد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CURRENCY_PROMPT', 'حد اقل یک واحد پول وارد نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_COUNTRY_PROMPT', 'حداقل یک کشور وارد نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_CONTENT', 'اقلام سفارش شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRODUCT_DOWNLOAD_LINK', 'لینک دانلود محصول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHIPPING_INFORMATION', 'اطلاعات ارسال','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PAYMENT_INFORMATION', 'اطلاعات پرداخت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHIPPING_COMMENTS', 'اطلاعات خرید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PAYMENT_COMMENTS', 'اطلاعات پرداخت' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_TOTAL_TAX', 'جمع مالیات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_TOTAL_REVENUE', 'جمع مبلغ سفارشات تکمیل شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ADDRESSES_HAS_BEEN_ADDED', 'نشانی ذیل با موفقیت اضافه شد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ORDER_TIME', 'زمان سفارش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRICELIST_ITEM_SORT', 'چیدمان بر اساس عنوان محصول ({ASC_NAME} | {DESC_NAME})، قیمت ({ASC_PRICE} | {DESC_PRICE})','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_FREE_SHIPPING2', 'ارسال رایگان','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EPRODUCT_AVAILABLE_DAYS2', 'قابل دانلود تا (روز)','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_FORBIDDEN_TO_ACCESS_FILE_ORDER_IS_NOT_PAYED', 'دسترسی به فایل غیر مجاز میباشد(پرداخت انجام نگردیده است)','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PLEASE_SPECIFY_ADDRESS', 'لطفا برای انجام ادامه سفارش نشانی خود را وارد نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ADDRESS_NOT_SPECIFIED', '< نشانی مشخص نگردیده است >','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULES_FROOGLE', 'ارسال به Froogle','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_FROOGLE_EXPORT_SUCCESSFUL', 'محصولات شما با موفقیت به  Froogle! ارسال گردید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULES_FROOGLE_PRICING_DESCRIPTION', 'واحد پول برای قیمت های محصولات ارسالی به Froogle حتما میباست از نوع دلار امریکا باشند، لطفا واحد پول دلار امریکا را مشخص نمایید.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULES_FROOGLE_USD_CURRENCY_TYPE', 'واحد پول دلار امریکا','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULES_FROOGLE_DESCRIPTION_HINT1', 'لطفا نوع توضیحات ارسالی به Froogle را مشخص نمایید:','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULES_FROOGLE_DESCRIPTION_HINT2', 'توجه: توضیحات ارسالی به Froogle نباید دارای کد های HTML باشند.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULES_FROOGLE_CREATE_FEED', 'ایجاد یک feed برای Froogle','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_FEEDBACK', 'تماس با ما','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_FEEDBACK_DESCRIPTION', 'توسط این فرم قادر به ارسال پیام خواهید بود.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_FEEDBACK_PRODUCT_HEADER', 'آیا در رابطه با [product_name] سوالی دارید؟','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_FEEDBACK_PRODUCT_DESCRIPTION', 'برای کسب اطلاعات بیشتر از فرم زیر استفاده نمایید.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_FEEDBACK_PRODUCT_INQUIRY_EXPLANATION', 'لطفا دقیقا مشخص نمایید در مورد محصول چه اطلاعاتی می خواهید ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','FEEDBACK_ERROR_FILL_IN_FORM', ' لطفا تمامی فیلد هارا پر نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','FEEDBACK_CUSTOMER_NAME', 'نام شما','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','FEEDBACK_CUSTOMER_MESSAGE_SUBJ', 'موضوع پیام','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','FEEDBACK_CUSTOMER_MESSAGE_TEXT', 'متن پیام','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','FEEDBACK_SENT_SUCCESSFULLY', '<B>پیام شما ارسال گردید.</B><br>در اولین فرصت ممکن جواب خود را دریافت خواهید کرد. با تشکر','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_INVOICE', 'فاکتور','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_INVOICE_OPEN', 'چاپ فاکتور','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CSV_SPECIFY_FILE', 'لطفا یک فایل CSV اکسل مشخص نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXCEL_SPECIFY_FILE', 'لطفا یک فایل XLS اکسل مشخص نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXCEL_DELIMETER', 'نوع جدا کننده داده در فایل CSV:','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXCEL_DELIMETER_SEMICOLON', 'سمی کالن','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXCEL_DELIMETER_COMMA', 'کاما','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXCEL_DELIMETER_TAB', 'Tab','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CUSTOMER_ADDITIONAL_REG_FIELDS', 'فیلد های اختیاری فرم ثبت نام ' ,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADDRESS_FORM_CONFIGURATOR', 'تنظیمات فرم نشانی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADDRESS_FORM_CONFIGURATOR_COUNTRY_DESC', 'اگر در تنظیمات فروشگاه شما لیست کشورها خالی نیست به قسمت (تنظیمات -> کشورها) رفته کشور مورد نظر را اضافه نمایید که در هنگام ثبت نام اجباری است <br>در صورتی که لیست کشورها خالی باشد از مشتری، مورد کشور سوال نخواهد گردید.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NOTREQUIRED_TO_SET', 'اختیاری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NOT_REQUESTED', 'خواسته نشده','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXPORT_TO_EXCEL', 'صدور محصولات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_EXCEL_EXPORT_DESCRIPTION', '<B>شما در این قسمت قادر به ارسال محصولات خود به یک فایلCSV هستید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_EXCEL_EXPORT_BUTTON', 'صدور کاتالوگ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_EXCEL_EXPORT_SUCCESSFUL', 'با موفقیت ارسال شد:','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SAFEMODE_WARNING', 'عملیات درخواستی شما در نسخه نمایشی غیر فعال گردیده است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SAFEMODE_BLOCKED', 'عملیات درخواستی شما در نسخه نمایشی غیر فعال گردیده است','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_LBS', 'Lbs (پوند)','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_GRAM', 'گرم','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PCS', 'عدد','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRINTABLE_VERSION', 'نسخه قابل چاپ','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MODULES_LINKEXCHANGE', 'تبادل لینک','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LE_CATEGORIES_TITLE', 'دسته بندی ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LE_LINKS_TITLE', 'لینک ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LE_ALL_CATEGORIES', 'تمامی دسته بندی ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LE_NEW_CATEGORY_NAME', 'نام دسته بندی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LE_LINK_URL','URL','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LE_LINK_TEXT','متن لینک','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_LE_ADD_LINK','اضافه کردن لینک','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ERROR_LE_LINK_EXISTS', 'این لینک هم اکنون ثبت شده است.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ERROR_LE_LINK_CATEGORY_EXISTS', 'دسته بندی با همین نام موجود است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ERROR_LE_LINK_ADDED', 'لینک شما ثبت گردید و پس از تایید نمایش داده خواهد شد.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ERROR_LE_CHOOSE_CATEGORY', 'انتخاب یک دسته بندی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ERROR_LE_ENTER_TEXT', 'لطفا متن لینک را وارد نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ERROR_LE_ENTER_LINK', 'لطفا URL را وارد نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_LE_CATEGORIES', 'دسته بندی ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_LE_LINKS', 'لینک ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LE_LINK_CATEGORY', 'دسته بندی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_LE_CONFIRM_DELETE_CATEGORY', 'آیا مایل به حذف این دسته بندی هستید؟','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_LE_CONFIRM', 'آیا مایل به حذف لینک های انتخاب شده هستید؟','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LE_LINK_VERIFIED', 'تایید شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LE_LINK_NOT_VERIFIED', 'تایید نشده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','VERIFIED_BUTTON','مشخص نمودن به عنوان &quot;شناسایی شده&quot;','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','UNVERIFIED_BUTTON','مشخص نمودن به عنوان &quot;شناسایی نشده&quot;','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','SAVE_CHANGES_BUTTON','ذخیره تغییرات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_LE_TODO', 'انتخاب شده:','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','LE_ADD_NEW_CATEGORY_BUTTON','اضافه کردن دسته بندی','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CUSTOMER_AFFILIATION', 'نام کاربری معرف (login):<br>(در صورت عدم وجود خالی بگذارید)','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_WRONG_AFFILIATION', 'نام کاربری معرف نادرست (login). در صورت عدم وجود خالی بگذارید.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_AFFILIATE','همکاری در فروش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_AFFILIATE_PROGRAM', 'همکاری در فروش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_AFFILIATE_CUSTOMERS', 'مشتریان معرفی شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_AFFILIATE_NO_CUSTOMERS', 'شما هیچ مشتریان معرفی شده ندارید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_PAYMENTS_HISTORY', 'تاریخ پرداخت ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_ATTRACT_GUIDE', 'طریقه دریافت پورسانت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_EMAILPAYMENTS', 'دریافت ایمیل هنگام واریز اعتبار به حساب شما','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_EMAILORDERS', 'دریافت ایمیل هنگام دریافت کمیسیون به حساب شما','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_NEW_PAYMENT', 'پرداخت جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_MAIL_NEW_PAYMENT', 'شما به مقدار {MONEY} اعتبار کسب نمودید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_NEW_COMMISSION', 'کمیسیون جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_MAIL_NEW_COMMISSION', 'مقدار {MONEY} کمیسیون به اعتبار شما اضافه شد.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_STRING_TOTAL_EARNINGS', 'جمع بدست آورده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_STRING_TOTAL_PAYMENTS', 'جمع پرداخت ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_PAYMENT_NUMBER', 'شناسه پرداخت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SUM', 'جمعا','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_MSG_NO_BALANCE', 'مبلغی به اعتبار شما اضافه نگردیده است.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_MSG_NO_PAYMENTS', 'مبلغی به اعتبار شما اضافه نگردیده است.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_AFFP_ENABLE_PROGRAM', 'فعال سازی همکاری در فروش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_COMMISSIONS_CALCULATE', 'تنظیمات همکاری در فروش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_AMOUNT_PERCENT', 'کمیسون بر اساس درصدی از مشتریان معرفی شده حساب شود.<br>مقدار درصد را مشخص نمایید:','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_USER_SETTINGS_CONTROL', 'تنظیمات ارسال ایمیل','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFR_EMAIL_NEW_COMMISSION_CTRL', 'ارسال ایمیل هنگام دریافت کمیسیون به حساب کاربر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFR_EMAIL_NEW_PAYMENT_CTRL', 'ارسال ایمیل هنگام دریافت اعتبار به حساب کاربر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_COMMISSION_PAYMENTS', 'کمیسونها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CALENDAR', 'یک دوره زمانی مشخص نمایید:','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_FROM', 'از','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_TILL', 'به','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','VIEW_BUTTON', 'مشاهده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_SUBMIT_NEW_PAYMENT', 'ثبت پرداخت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_SUBMIT_NEW_COMMISSION', 'اضافه کردن کمیسیون','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_STRING_CUSTOMER_COMMISSIONS', 'کمیسیونها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_STRING_PAYMENTS_TO_CUSTOMERS', 'پرداخت ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_EDIT_COMMISSION', 'ویرایش جزئیات کمیسیون','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_EDIT_PAYMENT', 'ویرایش جزئیان پرداخت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_MSG_ERROR_DATE_FORMAT', 'فرمت تاریخ نا درست است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_STRING_ATTRACT_GUIDE', '<p><B>بدست آوردن پورسانت از طریق سایت ما بسیار ساده است!</B><br>به ازای هر خرید تکمیل شده توسط مشتریانی که شما معرف می نمایید به میزان {aff_percent} درصد از کل مبلغ سفارش پورسانت دریافت خواهید نمود 
<p>معرفی مشتریان به سایت جهت خرید به دو صورت امکان پذیر است

<ol><li>به افرادی که قصد دارید معرفی نمایید شناسه خود ({login}) را بدهید تا در هنگام ثبت نام در فیلد معرف شناسه شما را وارد نمایند<br>
در این صورت  شما از پورسانت تمامی خریدهای انجام شده توسط این شخص در هر زمان برخوردار خواهید بود
<br></li><li>یکی از کدهای زیر را به وب سایت یا وبلاگ خود اضافه نمایید<br><br>
<table cellpadding=4 cellspacing=1 bgcolor=#999999>
<tr bgcolor=#EEEEEE>
<td>پیش نمایش</td><td>کد</td>
</tr>
	<tr bgcolor=#ffffff>
		<td valign=top>
		<a href={URL} target=_blank> {shopName} </a> 
		</td>
		<td valign=top>
		<textarea cols=35 dir=ltr><a href={URL} target=_blank>{shopName}</a></textarea>
		</td>
	</tr>

	<tr bgcolor=#ffffff>
		<td valign=top>
		<a href={URL} target=_blank><img border=0 alt={shopName} src={shopURL}images/logo1.gif></a>
		</td>
		<td valign=top>
		<textarea cols=35 dir=ltr><a href={URL} target=_blank><img border=0 alt={shopName} src={shopURL}images/logo1.gif></a></textarea>
		</td>
	</tr>

	<tr bgcolor=#ffffff>
		<td valign=top>
		<a href={URL} target=_blank><img border=0 alt={shopName} src={shopURL}images/logo2.gif></a>
		</td>
		<td valign=top>
		<textarea cols=35 dir=ltr><a href={URL} target=_blank><img border=0 alt={shopName} src={shopURL}images/logo2.gif></a></textarea>
		</td>
	</tr>
	<tr bgcolor=#ffffff>
		<td valign=top>
		<a href={URL} target=_blank><img border=0 alt={shopName} src={shopURL}images/logo3.gif></a>
		</td>
		<td valign=top>
		<textarea cols=35 dir=ltr><a href={URL} target=_blank><img border=0 alt={shopName} src={shopURL}images/logo3.gif></a></textarea>
		</td>
	</tr>
</table>

<br>
<br>
پورسانت خرید تمامی کاربرانی که با کلیک بر روی این لینک وارد سایت شوند و خرید انجام دهند به حساب شما منظور خواهد شد.
<br>
با استفاده از این روش کاربر نیازی به وارد کردن شناسه شما نخواهد داشت.
</li></ol>
','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_COMMISSION_DESCRIPTION', 'کمسیون برای سفارش شماره #{ORDERID} توسط {USERLOGIN}','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_STRING_NOTIFY_CUSTOMER', 'اطلاع توسط ایمیل به کاربر به هنگام تغییر وضعیت سفارش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ADMIN_COMMENT', 'یادداشت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CHANGE_ORDER_STATUS', 'وضعیت سفارش شما تغییر یافته است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MSG_CHANGE_ORDER_STATUS', 'وضعیت سفارش شماره #{ORDERID} به {STATUS} تغییر یافت','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CHOOSE_PRODUCTS', 'انتخاب دسته بندی ها و محصولات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MSG_COST_DOESNT_EXIST', 'قیمت مشخص نگردیده است','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_MSG_PROGRAM_DISABLED', 'همکاری در فروش غیر فعال است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MSG_INFORMATION_SAVED', 'اطلاعات با موفقیت ذخیره شد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_MSG_NEW_COMMISSION_OK', 'کمیسیون جدید ثبت شد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_MSG_NEW_PAY_OK', 'پرداخت جدید ثبت شد','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_REMOVE_USER', 'حذف این کاربر از لیست اعتارهای کاربران؟','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MSG_PERIOD_ISNT_SPECIFIED', '[ دوره زمانی مشخص نگردیده است ]','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_MSG_NOCOMMISISONS_FOUND','هیچ کمیسونی در تاریخ مشخص شده یافت نشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_MSG_NOPAYMENTS_FOUND','هیچ پرداختی در تاریخ مشخص شده یافت نشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_MSG_PAYMENT_DELETED', 'پرداخت حذف گردیده است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_MSG_COMMISSION_DELETED', 'کمیسون حذف شده است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','AFFP_USER_BALANCE', 'موجودی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MSG_ERROR_PERCENT_VALUE', 'لطفا مقداری از 0 تا 100 مشخص نمایید','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','SHMODULES_INSTALLED_CONFIGS', 'ماژولهای نصب شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NO_INSTALLED_MODULE_CONFS', 'هیچ ماژولی نصب نشده است','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CART_TOO_SMALL_ORDER_AMOUNT', 'جمع سفارش حداقل باید برابر باشد با ','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMSMAIL','پیام کوتاه (SMS)','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMSMAIL_SENDSUCCESS','پیام کوتاه ارسال شد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMSMAIL_SENDFAILED','ارسال پیام کوتاه با شکست روبرو شد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_GROUPSMSMAIL','پیام کوتاه گروهی (SMS)','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_GROUPSMSMAIL_DSCR','در این قسمت می توانید بدون ورود به کنترل پنل اس ام اس سنتر خود از طریق ماژولهای پیام کوتاه نصب شده در سیستم جاری برای یک یا چند نفر و یا اعضا فروشگاه به صورت گروهی پیام کوتاه ارسال کنید. توجه داشته باشید که این امکان در صورتی فعال خواهد بود که ماژول پیام کوتاه از قسمت ماژولها نصب و همچنین اعتبار کافی از سرویس دهنده مربوطه خریداری شده باشد.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_GROUPSMSMAIL_MOBILES','لیست شماره هایی که می خواهید برای آنها پیام کوتاه ارسال شود ، شماره ها را با علامت ; از یکدیگر جدا کنید ، ضمنا شماره ها برای رجوع های بعدی ذخیره خواهند شد . ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_GROUPSMSMAIL_SENDTOALL','ارسال پیام کوتاه برای همه اعضا سایت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_GROUPSMSMAIL_SENDTOCUSTOM','ارسال پیام کوتاه برای شماره های خاص','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMSMAIL_MODULES','ماژول پیام کوتاه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_TITLE_SMSMAIL_MODULE_SETTING','تنظیمات ماژول پیام کوتاه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ENABLE_SMS_NOTIFY', 'فعال کردن اطلاع توسط پیام کوتاه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMS_NOTIFY_NEW_PHONE', 'شماره جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMS_MAIL_CHOOSE_SMSSENDER', '<b>لطفا ماژولی برای ارسال SMS انتخاب نمایید </b>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMSMAIL_SEND','ارسال پیام کوتاه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMS_MAIL_SEND_PERIOD', '<b>زمان مجاز برای ارسال پیام کوتاه (زمان سرور)</b><div class=small> لطفا بازه زمانی که میخواهید هنگام سفارش پیام کوتاه دریافت کنید را مشخص نمایید. بجز ساعات مشخص شده در ساعات دیگر شما پیام کوتاه دریافت نخواهید کرد.</div>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMS_MAIL_PHONELIST', '<b>لیست شماره تلفن های همراهی که هنگام سفارش برای آنها SMS فرستاده خواهد شد.</b>
	<div class=small>مثال:09122222222<br><br>
	برای<b>اضافه  کردن</b> یک شماره به لیست داخل فیلد شماره جدید شماره مورد نظر را نوشته دکمه ذخیره را بفشارید.<br />برای <b>حذف</b> یک شماره فیلد آنرا خالی کرده و دکمه ذخیره را بفشارید.</div>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMSMAIL_DISABLE_MODULE', 'غیر فعال کردن پیام کوتاه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMSNOTIFY_SMS_NEW_ORDER','New order!','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMSNOTIFY_SMS_NUMBER','Order ID','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMSNOTIFY_SMS_AMOUNT','Order total','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMS_NOTIFY_ERROR_PERIOD', 'Wrong period format!','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERR_CURLINIT', 1000,'admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERR_CURLEXEC', 1001,'admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PAYMENT_MODULES_DSCR', 'این نرم افزار به همراه ماژولهای پرداخت زیادی ارائه شده و قابلیت اضافه کردن ماژولهای جدید را نیز دارد.<br>بعد از نصب هر ماژول به قسمت تنظیمات ماژول رفته و اطلاعات مربوطه را پر کنید<br>سپس به قسمت تنظیمات -> پرداخت رفته یک روش پرداخت ایجاد کرده و ماژول نصب شده مورد نظر را به آن روش اختصاص دهید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SHIPPING_MODULES_DSCR', 'برای محاسبه قیمت ارسال ماژولهایی ایجاد گردیده اند. برای استفاده از آنها، گزینه مورد نظر را نصب و در تنظیمات آن اطلاعات خواسته شده را انجام دهید<br>سپس به قسمت تنظیمات -> حمل و نقل رفته و روشی ایجاد نموده و ماژول مورد نظر را به آن روش حمل و نقل اختصاص دهید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_SMS_GATEWAYS_DSCR', 'در صورت نیاز به استفاده از پیام کوتاه ابتدا شما می بایست مقداری اعتبار از شرکتهای ارائه کننده خدمات پیام کوتاه خریداری نمایید','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_FROOGLE_FILE_CREATION', 'خطا','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_FROOGLE_CURRENCY_TYPE', 'واحد پول را انتخاب نمایید','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SUBSCRIPTIONS_ERROR_FILE_CREATION', 'قادر به ارسال اعضای سایت به فایل نیست. خطا در هنگام ساخت فایل temp/subscribers.txt','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SUBSCRIPTIONS_OK_EXPORT_SUBSCRLIST','لیست اعضا با موفقیت به فایل ارسال شد<br /><a href={*URL*}>دانلود فایل حاوی اطلاعات اعضا</a>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SUBSCRIPTIONS_OK_EMAIL_DELETED','پست الکترونیک ({*EMAIL*}) حذف گردید!','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SUBSCRIPTIONS_ERROR_UPLOAD_SUBSCRLIST','خطا در هنگام ارسال فایل به سرور','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SUBSCRIPTIONS_OK_UPLOAD_SUBSCRLIST',' اعضا با موفقیت وارد سیستم شد. تعداد {*EMAILS_NUMBER*} مورد جدید وارد سیستم گردید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SUBSCRIPTIONS_ERROR_UPLOAD_NO_EMAILS','هیچ موردی در فایل ارسالی شما یافت نشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SUBSCRIPTIONS_OK_ERASE_SUBSCRLIST','{*EMAILS_NUMBER*} مورد حذف شد.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SUBSCRIPTIONS_STRING_UPLOAD','ورود اعضا از فایل','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SUBSCRIPTIONS_STRING_EXPORT','صدور اعضا به فایل متنی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SUBSCRIPTIONS_STRING_ERASE','حذف تمامی موارد','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SUBSCRIPTIONS_STRING_DESC','این بخش به شما اجازه مدیریت اعضای خبرنامه را می دهد<br>و همچنین شما میتوانید لیست اعضا را به فایل متنی ساده ارسال و یا از فایل وارد سیستم نمایید<br><a href=newsletter_sample.csv>دریافت فایل نمونه اعضای خبرنامه</a>','admin');


INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_TRANSACTION_RESULT_SUCCESS','با تشکر پرداخت شما با موفقیت انجام گردید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_TRANSACTION_RESULT_FAILURE','هنگام انجام پرداخت خطایی رخ داد<p>لطفا دوباره تلاش نمایید یا با ذکر شماره سفارش با ما تماس بگیرید','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PRIORITY', 'اولویت','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_CONFIRMATION_CODE' , 'کد امنیتی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_ENTER_CCODE' , 'لطفا کد امنیتی را وارد نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERR_WRONG_CCODE', 'کد امنیتی وارد شده صحیح نمی باشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','REGCONFIRM_SUBJECT', 'اطلاعات حساب کاربری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','REGCONFIRM_SUCCESS', '<p>با تشکر حساب کاربری شما با موفقیت فعال گردید<p><a href=index.php?user_details>مدیریت حساب کاربری</a>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','REGCONFIRM_WRONG_ACTCODE', 'کد وارد شده صحیح نمی باشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','REGCONFIRM_NOTACTIVATED','برای فعال نمودن حساب کاربری خود کد ارسال شده به ایمیلتان را وارد نمایید<br>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','REGCONFIRM_TYPE_CODE','کد تایید را وارد نمایید:','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ACTIVATE_BUTTON','فعال کردن حساب کاربری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','REGACTIVATION', 'فعال کردن حساب کاربری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CONF_EMAIL_REGCONFIRMATION','برای فعال نمودن حساب کاربری خود کد را وارد نموده و یا بر روی لینک زیر کلیک نمایید : [code]<br>لینک:[codeurl]','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_DO','نمودن','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_ACTIVATED','فعال','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_NOTACTIVATED','غیر فعال','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_ACTSTATE','وضعیت اکانت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_ACTCODE','کد فعال سازی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_QACTIVATE_ACCOUNT','فعال سازی حساب برای [email]?','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_TYPE_ACTCODE_ORDER2', 'لطفا کد فعال سازی را که به آدرس ایمیل شما ارسال گردیده وارد نمایید. این کد برای فعال سازی حساب شما لازم است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_ACTIVATION',' فعال سازی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_PROFILE_NUMBER',' پروفایل','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_ANY_COUNTRY', 'هر کشور','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_ANY_ZONE', 'هر استان','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_ZONES_NOTDEFINED', 'برای کشور انتخاب شده هیچ استانی تعیین نگردیده است','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MOD_NEWS_TXT_DELETE_OK', 'اخبار با موفقیت حذف گردید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MOD_NEWS_TXT_PCTDELETE_OK', 'تصویر با موفقیت حذف گردید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MOD_NEWS_TXT_EDIT_OK', 'تغییرات ذخیره گردید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MOD_NEWS_TXT_ADD_OK', 'اخبار ذخیره گردید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MOD_NEWS_TXT_NEWS_LIST', 'آرشیو آخبار','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MOD_NEWS_TXT_NEWS_EDIT', 'ویرایش','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MOD_NEWS_TXT_EMAILED','خبر نامه به اعضا ارسال گردید.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MOD_NEWS_EMPTY_TITLETEXT','لطفا عنوان را وارد نمایی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MOD_NEWS_EMPTY_TEXTTOEMAIL','لطفا متن خبرنامه را وارد نمایید','admin');



INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_PAYMENTFAILD', 'پرداخت انجام نگردید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_1', 'خطا: خطای داخلی شبکه مالی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_2', 'خطا: سپرده ها برابر نیستند','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_3', 'خطا: ورودی ها حاوی کارکترهای غیر مجاز میباشند','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_4', 'خطا: کلمه عبور یا کد فروشنده اشتباه می باشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_5', 'خطا: خطای دیتابیس','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_6', 'خطا: سند قابلا برگشت کامل یافته است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_7', 'خطا: رسید دیجیتالی تهی است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_8', 'خطا: طول ورودی های بیش از حد مجاز می باشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_9', 'خطا: وجود کارکترهای غیر مجاز در مبلغ برگشتی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_10', 'خطا: رسید دیجیتالی حاوی کارکترهای غیر مجاز میباشند','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_11', 'خطا: طول ورودی ها کمتر از حد مجاز است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_12', 'خطا: مبلغ برگشتی منفی است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_13', 'خطا: مبلغ برگشتی برای برگشت جزیی بیش از مبلغ برگشت نخورده رسید دیجیتالی است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_14', 'خطا: چنین تراکنشی تعریف نشده است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_15', 'خطا: مبلغ برگشتی به صورت اعشاری داده شده است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_16', 'خطا: خطای داخلی سیستم بانکی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_17', 'خطا: برگشت زدن جزیی تراکنشی که با کارت بانکی غیر از بانک صادر کننده انجام پذیرفته است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_18', 'خطا: آدرس IP شما در سرور بانک به درستی تنظیم نگردیده است. برای تصحیح این مشکل با بانک تماس حاصل نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_19', 'خطای نامشخص','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_ERROR_NO', 'شماره خطا: ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_NOREFNUM', 'خطا: رسید دیجیتالی تهی می باشد!','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_NOTEQ', 'مبلغ سفارش با مبلغ پرداخت شده برابر نیست','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_ISCOMPLETED', 'سفارش قبلا تکمیل گردید است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_SHETAB_THANKS', 'با تشکر پرداخت شما با موفقیت انجام و قبول گردید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_SHETAB_REFNUM', 'رسید دیجیتالی: ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_SHETAB_ERROR_RESON', 'علت خطا: ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_SHETAB_RESON', 'علت : ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_SHETAB_SAMAN', 'تایید پرداخت توسط بانک سامان','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_SHETAB_EGHTESADNOVIN', 'تایید پرداخت توسط بانک اقتصاد نوین','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_SHETAB_PARSIAN', 'تایید پرداخت توسط بانک پارسیان','admin');


INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_INVALIDAMOUNT', 'مبلغ سند برگشتی از مبلغ تراکنش اصلی بیشتر است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_INVALIDTRANSACRION', 'درخواست برگشت یک تراکنش رسیده است درحالیکه تراکنش اصلی پیـدا نمـیشود','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_INVALIDCARDNO', 'شماره کارت اشتباه است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_NOSUCHISSUER', 'چنین صادرکننده کارتی وجود ندارد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_EXPIREDCARD', 'از تاریخ انقضای کارت گذشته است، کارت دیگر معتبر نیست','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_PIN3TRY', 'اشتباه وارد شده است درنتیجه کارت غیرفعال خواهد شد 3 کارت PIN شماره','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_EXPIREDACCOUNT', 'حساب پشت کارت منقضی شده است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_INCORRETPIN', 'خریدار رمز کارت را اشتباه وارد کرده است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_TRCANNOTBECOMP', 'امکـان سندخوردن وجود ندارد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_RESPONSETOOLATE', '. خورده است Timeout تراکنش در شبکه بانکی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_SUSPECTFRAUD', ' . را اشتباه زده یا اصلاً وارد نکرده است ExpDate و یا فیلد CVV٢ خریدار یا فیلد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_NOSUFFICIENT', 'موجودی به اندازه کافی در حساب وجود ندارد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_ISSUERDOWN', ' . سازمان صادرکننده بانک ( دراینجا بانکها ) در دسترس نیست','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ERROR_SHETAB_CANCELED', 'پرداخت توسط کاربر لغو گردید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TABLE_PRODUCT_CREDIT', 'اعتبار کالا','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TABLE_PRODUCT_CREDIT_TOTAL', 'جمع اعتبار کالاها','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MAIN_AMOUNT', 'جمع اصلی کالاها بدون کسر اعتبار','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_YOUR_CREDIT', 'اعتبار شما','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_USER_CREDIT', 'اعتبار کاربر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PAYABLE_AMOUNT', 'مبلغ قابل پرداخت','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PENDING_ORDERS', 'پاکسازی سفارشات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CHANEGE_STATUS', 'تغییر وضعیت سفارشات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DEL_CANCELD_ORDRES', 'حذف سفارشات انصراف داده شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DELETE_CANCELD', 'حذف سفارشات با وضعیت ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_MORE_THAN', 'با بیش از','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DAYS_OLD', 'روز قدمت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_AFFECTED_ORDERS', 'سفارش تغییر وضعیت داد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DELETED_ORDERS', 'سفارش حذف شد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NO_AFF', '<font color=blue>هیچ سفارشی تغییر وضعیت داده نشد!</font>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_NO_DEL', '<font color=blue>هیچ سفارشی حذف نشد!</font>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PENDING_ORDERS_WARNING', 'اخطار: دقت داشته باشید که بعد از انجام عملیات برای بازگشت به حالت اولیه فقط امکان تغییر وضعیت سفارشات به صورت تک تک وجود دارد.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DELETE_CANCELED_ORDERS_WARNING', 'اخطار: دقت داشته باشید که بعد از انجام عملیات امکان بازگشت به حالت اولیه وجود ندارد!','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','QUESTION_CONFIRMATION', 'آیا مطمئن هستید؟','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_IS_ACCOUNT', 'محصول به شکل پین کد می باشد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ACCOUNTS_INFO', 'اطلاعات مربوطه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ACCOUNTS_INFO_FOR_ORDERID', 'اطلاعات مربوط به سفارش شماره:','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','PROD_IS_ACCOUNT_NOTE', 'این محصول به صورت پین کد یا username, password میباشد. توجه داشته باشید که بعد از تکمیل سفارش و پرداخت موفق اطلاعات این محصول بلافاصله قابل مشاهده بوده، همچنین به ایمیل شما ارسال خواهد شد.','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','USERACCOUNT_ISNT_ENOUGH', 'اعتبار شما برای انجام خرید کافی نمی باشد!','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','USERACCOUNT_USER_CREDIT', 'اعتبار حساب کاربری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','USERACCOUNT_NOT_LOGGEDIN', 'برای استفاده از پرداخت با اعتبار موجود در حساب کاربری شما باید وارد سیستم (لاگین) شده باشید!','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','USERACCOUNT_REMAINING_CREDIT', 'اعتبار باقی مانده شما','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','USERACCOUNT_YOUR_CREDIT', 'اعتبار موجود در حساب شما','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','USERACCOUNT_ORDER_IS_COMP', 'سفارش شما قبلا یک بار پرداخت و تکمیل گردیده است!','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','USERACCOUNT_ORDERID_IS', 'شماره سفارش شما','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS', 'حسابهای بانکی و فیش ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_BANKACCOUNTS', 'حسابهای بانکی برای ثبت فیش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_ACCOUNTNO', 'شماره حساب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_BANKNAME', 'نام بانک','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_ACCOUNTHOLDER', 'نام دارنده حساب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_SUBMITNEW_ACCOUNT', 'ثبت حساب بانکی جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_SUBMITED_ACCOUNTS', 'حسابهای بانکی ثبت شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_SUCC_SUBMITED', 'حساب بانکی با موفقیت ثبت گردید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_NOT_SUCC_SUBMITED', 'حساب بانکی ثبت نگردید، لطفا ورودی ها را چک نموده دوباره تلاش نمایید.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_SUBMITTED_BILLS', 'فیش های ثبت شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_FOR', 'جهت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_ADDTO_USERACCOUNT', 'اضافه به اعتبار حساب کاربری','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_SUBMIT', 'ثبت فیش بانکی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_DATE', 'تاریخ واریز','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_BILLNO', 'شماره فیش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_BILLEDTO', 'واریز شده به حساب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_AMOUNT', 'مبلغ واریزی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_BILL_SUBMITTED', 'فیش بانکی با موفقیت ثبت شد و می بایست برای تایید بررسی گردد. بررسی حداکثر تا 24 ساعت انجام خواهد گرفت','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_BILLNOT_SUBMITTED', 'فیش ثبت نگردید. لطفا تمامی موارد خواسته شده را وارد نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_BILLS_CONFIRM', 'تایید فیش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_NEXT', 'بعدی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_LAST', 'آخر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_PREV', 'قبلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_FIRST', 'اول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_BANK_SHOWING_PAGE', 'نمایش صفحه','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PINS_FILLINFO', 'لطفا اطلاعات مربوطه (پین کد یا رمزهای عبور) را وارد نمایید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PINS_SUCC', 'اطلاعات با موفقیت به این محصول اضافه شد.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PINS_INFO', 'اطلاعات مربوط به محصول:  <font class=small><br>(پین کد یا رمز عبور و ...)</font>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PINS_INFO_SHORT', 'اطلاعات مربوط به محصول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PINS_INFO_NEEDSAVE', 'ابتدا ذخیره را بزنید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PINS_NOTSELLED', 'فروخته نشده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PINS_CODE', 'PIN','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_CONTENT'
, 
'مدیریت محتوا','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','HOME_TEXT', 'متن صفحه اصلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','HOME_TEXT_PREVIEW', 'پیش نمایش متن صفحه اصلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','NEW_HOME_TEXT', 'متن جدید صفحه اصلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NEW_TEXT', 'متن جدید','admin');


INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TEMPLATE', 'قالب (شکل ظاهری)','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TEMPLATE_NO', 'قالب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','TEMPLATE_PREVIEW', 'پیش نمایش قالب فعلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','SELECT_TEMPLATE', 'انتخاب از قالب های موجود','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EDITING_TMPL_FILE', 'در حال ویرایش فایل','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','FROM_TEMPLATE', 'از قالب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EDIT_TMPL_FILE', 'فایل های قالب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','EDIT_CURRTMPL_FILE', ' فایل های قالب فعلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','BACK_TO_TEMPLATES', 'بازگشت به صفحه اصلی قالب ها','admin');


INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_WELLCOME', 'خوش آمدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_BEST_SELLERS', 'پرفروش ترین محصولات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_MOST_VIEWED', 'پر بازدیدترین محصولات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PAYMENT_WITH', 'طرف قراداد با','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_LATEST_ADDED', 'آخرین محصولات اضافه شده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','DIRECT_COD_LINK', 'لینک مستقیم خرید پستی','admin'); 
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STR_POWERED_BY_PARSP', 'ایجادشده توسط <a href=http://www.parsp.com class=copyright target=_blank> فروشگاه ساز طراحی وب ایرانیان </a>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CONF_SHOW_LATEST_RIGHT','','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_TODAY', 'امروز','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_WITHOUT_FINISH', 'نامحدود','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_LINK', 'لینک','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_LOCALS', 'عبارت ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_PICTURE', 'تصویر','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_TEXT', 'متن','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_UNLIMITED','نامحدود','general');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_INBLOCK_DESC', 'توسط این بخش شما امکان اضافه نمودن تبلیغات در بلوک های مختلف سایت را خواهید داشت.<br> با انتخاب افزودن تبلیغ جدید می توانید در بلوکهای سایت از تبلیغات متفاوت چه عکس ، چه فایل flash و حتی کد PHP و یا HTML نیز وارد کنید.<br> حتما در ورود کدهای HTML و PHP دقت کنید تا ساختار نمایش سایت را به هم نزنید.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_INCATEGORY_DESC', 'در این قسمت می توانید برای نمایش تبلیغ در بلوک های ویژه هر قالب با توجه به شرایط خاص همچون نمایش یک دسته بندی خاص محدودیت ایجاد کنید. <br> این بلوک ها توسط طراح قالب مشخص می شوند و از هر قالب به قالب دیگر متفاوت هستند . ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT', 'تبلیغات','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_INBLOCK', 'در بلوک ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_INCATEGORY', 'دسته بندی ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_NAME', 'عنوان تبلیغ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_TYPE', 'نوع تبلیغ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_UPLOAD_IMAGE', 'آپلود تصویر تبلیغ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_UPLOAD_FLASH', 'آپلود FLASH تبلیغ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_UPLOAD_OR_URL', 'یا لینک URL','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_CODE','کد تبلیغ ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_CLICK_COUNT','تعداد کلیک','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_ADDNEW','افزودن تبلیغ جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_NAME_EXIST','نام تبلیغ تکراری است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_EMPTY_PICTURE','محتوای تصویری یا نمایشی و کد مربوطه وارد نشده است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_POSITION_DESC','محل نمایش را بر اساس قالب سایت انتخاب کنید ، <br>در صورتی که بلوک مورد نظر در قالب وجود نداشته باشد تبلیغ نمایش داده نخواهد شد!','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_COND','نمایش فقط در','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ADVERTIESMENT_CANTADD','امکان افزودن تبلیغ جدید قبل از ایجاد دسته بندی وجود ندارد.','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_USERS','کاربران','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_ACCESS','دسترسی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CHECKALL','انتخاب همه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_GROUP','گروه','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SUPPORT','پشتیبانی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ABOUT','درباره سیستم','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_MEMORY_LIMIT','مدیریت حافظه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ABOUT_DESC','این صفحه به شما اطلاعاتی در مورد نرم افزار و سروری که نرم افزار بر روی آن نصب شده است در اختیار شما قرار می دهد. ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_DELETED','حذف شد','general');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SALE_REPORT','گزارش فروش','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SALE_REPORT_DESC','در این قسمت می توانید گزارش فروش خود را در بازه مشخص شده مشاهده نمایید. <br> جهت بررسی بهتر وضعیت سفارش را نیز مشخص کنید . ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SALE_AMOUNT','میزان (مبلغ) فروش','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LISTS','لیست ها','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_ORDER_BUTTON','کلید خرید محصول','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LISTS_DESC','<p>شما می توانید لیست هایی را بر اساس تشابه محصولات در یک ویژگی خاص ایجاد کنید .<br> هر لیست می تواند چندین محصول را شامل شود برای مثال از پر کاربرد ترین لیست ها می توان به لیست پربازدید ترین ها ، پر فروش ترین ها ، جدیدترین محصولات یا از این قبیل اشاره کرد.</p>','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_CODE','کد','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_IN_LIST','داخل لیست','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LISTS_ADD','افزودن لیست جدید','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_STRING_INVALID','عبارت نا معتبر است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_PRODUCTLIST_CODE_EXIST','کد لیست تکراری است','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_DEL_CONFIRM','آیا از حذف اطمینان دارید؟','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LISTS_EMPTY','هیج محصولی در این لیست وجود ندارد','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_LISTS_ADD_PRODUCT','افزودن محصول به لیست','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_IWD','طراحی وب ایرانیان','admin');


INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_VERSION','نسخه نرم افزار','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SYSTEMMESSAGE','پیام سیستم','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SYSTEMMESSAGE_DESC','در این قسمت می توانید در صورتی که پیغام جدیدی از سوی پشتیبانی نرم افزار منتشر شده باشد ، مشاهده کنید .','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_SESSION_EXPIRED','جلسه کاری ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_EACH','هر','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_MINUTE','دقیقه','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_EXPIRE','منقضی شود','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NOT_EXPIRE','منقضی نشود','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','STRING_NOTHING','هرگز','general');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_NAME','نام قالب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_AUTHOR','پدیدآورنده','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_VERSION','نسخه','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_DATE','تاریخ','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_FILES','مدیریت فایلها','admin');

INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_DOWNLOAD','دانلود کامل قالب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_UPLOADEXTRACT','آپلود و جایگزینی قالب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_UPLOADFILE','آپلود فایل','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_UPLOADED','قالب آپلود و بارگذاری شد.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_REPLACE','جایگزین قالب فعلی','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_ADDNEW','افزودن قالب جدید','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_FOLDERNAME','نام پوشه قالب','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_FOLDERDESCRIPTION','برای قالبهای جدید باید یک نام انتخاب کنید تا در فولدر مشخص شده ، اطلاعات بازیابی و قرار بگیرند .<br> فرمت فایل باید با قالب zip باشد و فایل پیشنمایش و تنظیمات آن وجود داشته باشند.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','ADMIN_TEMPLATE_NOTSET','هیچ قالبی برای فروشگاه تعیین نشده است ! فروشگاه موقتا تعطیل است.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MSG_SELECT_ZONE_TO_SEE_CITIES', 'جهت مشاهده شهرها می بایست ابتدا استان را مشخص ، یا تعریف کنید.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','MSG_SELECT_COUNTRY_TO_SEE_ZONES', 'می بایست کشوری را انتخاب یا تعریف کنید تا استان ها را مشاهده کنید.','admin');
INSERT INTO LOCALS_TABLE (`iso2`,`expstr`, `translate` , `grname`) VALUES ('fa','CSAMAN_TTL', 'درگاه بانک سامان','general');