<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function auxpgGetAllPageAttributes() {
		$q = db_query( 'select * from ' . AUX_PAGES_TABLE );
		$data = array(  );

		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( AUX_PAGES_TABLE, $row );
			$row['aux_page_name'] = TransformDataBaseStringToText( $row['aux_page_name'] );
			$row['meta_keywords'] = TransformDataBaseStringToText( $row['meta_keywords'] );
			$row['meta_description'] = TransformDataBaseStringToText( $row['meta_description'] );
			$data[] = $row;
		}

		return $data;
	}

	function auxpgGetAuxPage($aux_page_ID) {
		$aux_page_ID = (int)$aux_page_ID;
		$q = db_query( 'select * from ' . AUX_PAGES_TABLE . ( ' where aux_page_ID=' . $aux_page_ID ) );

		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( AUX_PAGES_TABLE, $row );
		}

		return $row;
	}

	function auxpgUpdateAuxPage($aux_page_ID, $aux) {
		$aux_page_ID = (int)$aux_page_ID;
		db_query( 'update ' . AUX_PAGES_TABLE . ' set 	' . LanguagesManager::sql_prepareFieldUpdate( 'aux_page_name', $aux ) . ' ,' . LanguagesManager::sql_prepareFieldUpdate( 'aux_page_text', $aux ) . ' ,' . LanguagesManager::sql_prepareFieldUpdate( 'meta_keywords', $aux ) . ' ,' . LanguagesManager::sql_prepareFieldUpdate( 'meta_description', $aux ) . ' ,' . ' 	aux_page_text_type=\'1\' ' . ( ' where aux_page_ID = ' . $aux_page_ID ) );
	}

	function auxpgAddAuxPage($aux) {
		$auxf = array( 'aux_page_name', 'aux_page_text', 'meta_keywords', 'meta_description' );
		$aux_page = LanguagesManager::sql_prepareFieldsInsert( $auxf, $aux );
		db_query( 'insert into ' . AUX_PAGES_TABLE . ' ( ' . $aux_page['fields'] . ' )  ' . ' values( ' . $aux_page['values'] . ' ) ' );
	}

	function auxpgDeleteAuxPage($aux_page_ID) {
		$aux_page_ID = (int)$aux_page_ID;
		db_query( 'delete from ' . AUX_PAGES_TABLE . ( ' where aux_page_ID=' . $aux_page_ID ) );
	}

	function aux_en_di_page($key, $enabled) {
		db_query( 'update ' . AUX_PAGES_TABLE . ( ' set Enabled=' . $enabled . ' where aux_page_ID = ' . $key ) );
	}

?>