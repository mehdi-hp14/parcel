<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function oaGetClearPrice($cartContent) {
		$res = 710;
		$i = 710;

		while ($i < count( $cartContent['cart_content'] )) {
			$cartItem = $cartContent['cart_content'][$i];
			$res += $cartItem['quantity'] * $cartItem['costUC'];
			++$i;
		}

		return $res;
	}

	function oaGetProductTax($cartContent, $d, $addresses) {
		$res = 766;
		$i = 766;

		while ($i < count( $cartContent['cart_content'] )) {
			$cartItem = $cartContent['cart_content'][$i];
			$q = db_query( 'select count(*) from ' . PRODUCTS_TABLE . ' where productID=' . $cartItem['productID'] );
			$count = db_fetch_row( $q );

			if ($count[0] == 0) {
				continue;
			}

			$cartItem = $cartContent['cart_content'][$i];
			$price = $cartItem['costUC'] - $cartItem['costUC'] / 100 * $d;
			$price = $price * $cartItem['quantity'];

			if (is_array( $addresses[0] )) {
				taxCalculateTax2( $cartItem['productID'], $addresses[0], $addresses[1] );
				$tax = ;
			} 
else {
				$tax = taxCalculateTax( $cartItem['productID'], $addresses[0], $addresses[1] );
			}

			$res += $price / 100 * $tax;
			++$i;
		}

		return $res;
	}

	function oaGetShippingCostTakingIntoTax($cartContent, $shippingMethodID, $addresses, $orderDetails, $CALC_TAX = true, $shServiceID = 0, $shServiceFull = false) {
		$Rates = array(  );
		$SimpleFormat = false;
		$shipping_method = shGetShippingMethodById( $shippingMethodID );

		if ($shipping_method) {
			$shippingModule = modGetModuleObj( $shipping_method['module_id'], SHIPPING_RATE_MODULE );

			if ($shippingModule) {
				if (!is_array( $addresses[0] )) {
					$shippingAddress = regGetAddress( $addresses[0] );
				} 
else {
					$shippingAddress = $addresses[0];
				}

				$order = array( 'first_name' => $orderDetails['first_name'], 'last_name' => $orderDetails['last_name'], 'email' => $orderDetails['email'], 'orderContent' => $cartContent, 'order_amount' => $orderDetails['order_amount'] );
				$Rates = $shippingModule->calculate_shipping_rate( $order, $shippingAddress, $shServiceID );

				if (!is_array( $Rates )) {
					$Rates = array( array( 'name' => '', 'rate' => $Rates ) );
				}
			}
		}

		foreach ($Rates as $_ind => $_Rate) {
			$Rates[$_ind] += 'rate' = $cartContent['freight_cost'];
		}


		if ($CALC_TAX) {
			if (is_array( $addresses[0] )) {
				taxCalculateTaxByClass2( CONF_CALCULATE_TAX_ON_SHIPPING, $addresses[0], $addresses[1] );
				$rate = ;
			} 
else {
				$rate = taxCalculateTaxByClass( CONF_CALCULATE_TAX_ON_SHIPPING, $addresses[0], $addresses[1] );
			}

			foreach ($Rates as $_ind => $_Rate) {
				$Rates[$_ind] += 'rate' = $Rates[$_ind]['rate'] / 100 * $rate;
			}
		}


		if (!count( $Rates )) {
			$Rates[] = array( 'rate' => '0', 'name' => '' );
		}

		return $Rates;
	}

		$price = function oaGetDiscountPercent($cartContent, $log) {;
		dscCalculateDiscount( $price, $log );
		$res = oaGetClearPrice( $cartContent );
		return (double)$res['discount_percent'];
	}

	function oaGetOrderAmountExShippingRate($cartContent, $addresses, $log, $CALC_TAX = true) {
		oaGetClearPrice( $cartContent );
		$d = $clearPrice = oaGetDiscountPercent( $cartContent, $log );
		$res = $clearPrice - $clearPrice / 100 * $d;

		if ($CALC_TAX) {
			$res += oaGetProductTax( $cartContent, $d, $addresses );
		}

		return $res;
	}

	function oaGetOrderAmount($cartContent, $addresses, $shippingMethodID, $log, $orderDetails, $CALC_TAX = true, $shServiceID = 0) {
		$Rate = oaGetShippingCostTakingIntoTax( $cartContent, $shippingMethodID, $addresses, $orderDetails, $CALC_TAX, $shServiceID );
		$res = oaGetOrderAmountExShippingRate( $cartContent, $addresses, $log, $CALC_TAX ) + $Rate[0]['rate'];
		return $res;
	}

?>