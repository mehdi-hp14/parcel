<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function GetRegFields() {
		$q = db_query( 'select *,' . LanguagesManager::sql_constractSortField( CUSTOMER_REG_FIELDS_TABLE, 'reg_field_name' ) . ', reg_field_required, sort_order from ' . CUSTOMER_REG_FIELDS_TABLE . ' order by sort_order, ' . LanguagesManager::sql_getSortField( CUSTOMER_REG_FIELDS_TABLE, 'reg_field_name' ) );
		$data = array(  );

		if ($r = db_fetch_assoc( $q )) {
			LanguagesManager::ml_fillFields( CUSTOMER_REG_FIELDS_TABLE, $r );
			$data[] = $r;
		}

		return $data;
	}

	function AddRegField($reg_field, $reg_field_required) {
		foreach ($reg_field as $key => $value) {
			$key = str_replace( 'new_', '', $key );
			$reg_field[$key] = $value;
		}

		$ml_reqdbqs = LanguagesManager::sql_prepareFieldInsert( 'reg_field_name', $reg_field );
		$sort_order = (int)$reg_field['sort_order'];
		db_query( 'insert into ' . CUSTOMER_REG_FIELDS_TABLE . '(' . $ml_reqdbqs['fields'] . ', reg_field_required, sort_order) ' . 'values( ' . $ml_reqdbqs['values'] . ', ' . $reg_field_required . ', ' . '\'' . $sort_order . '\' ) ' );
	}

	function DeleteRegField($reg_field_ID) {
		db_query( 'delete from ' . CUSTOMER_REG_FIELDS_VALUES_TABLE . ' where reg_field_ID=\'' . $reg_field_ID . '\'' );
		db_query( 'delete from ' . CUSTOMER_REG_FIELDS_TABLE . ' where reg_field_ID=\'' . $reg_field_ID . '\'' );
	}

	function UpdateRegField($reg_field_ID, $reg_field, $reg_field_name, $reg_field_required, $sort_order) {
		$reg_field_name = TransformStringToDataBase( $reg_field_name );
		$sort_order = (int)$sort_order;
		db_query( 'update ' . CUSTOMER_REG_FIELDS_TABLE . ' set ' . LanguagesManager::sql_prepareFieldUpdate( 'reg_field_name', $reg_field ) . ',' . 'reg_field_required=' . $reg_field_required . ', ' . 'sort_order=\'' . $sort_order . '\' ' . 'where reg_field_ID=\'' . $reg_field_ID . '\'' );
	}

	function SetRegField($reg_field_ID, $customer_login, $reg_field_value) {
		$reg_field_value = TransformStringToDataBase( $reg_field_value );
		$customerID = regGetIdByLogin( $customer_login );
		$q = db_query( 'select count(*) from ' . CUSTOMER_REG_FIELDS_VALUES_TABLE . ' where reg_field_ID=\'' . $reg_field_ID . '\' AND customerID=\'' . $customerID . '\'' );
		$r = db_fetch_row( $q );

		if ($r[0] == 0) {
			if (trim( $reg_field_value ) == '') {
				return null;
			}

			db_query( 'insert into ' . CUSTOMER_REG_FIELDS_VALUES_TABLE . '(reg_field_ID, customerID, reg_field_value) ' . 'values( \'' . $reg_field_ID . '\', \'' . $customerID . '\', \'' . $reg_field_value . '\' )' );
			return null;
		}


		if (trim( $reg_field_value ) == '') {
			db_query( 'delete from ' . CUSTOMER_REG_FIELDS_VALUES_TABLE . ' where reg_field_ID=\'' . $reg_field_ID . '\' AND  ' . ' 	customerID=\'' . $customerID . '\'' );
			return null;
		}

		db_query( 'update ' . CUSTOMER_REG_FIELDS_VALUES_TABLE . ' set ' . ' reg_field_value=\'' . $reg_field_value . '\' ' . ' where reg_field_ID=\'' . $reg_field_ID . '\' AND customerID=\'' . $customerID . '\'' );
	}

	function GetIsRequiredRegField($reg_field_ID) {
		$q = db_query( 'select reg_field_required from ' . CUSTOMER_REG_FIELDS_TABLE . ' where reg_field_ID=\'' . $reg_field_ID . '\'' );
		$r = db_fetch_row( $q );
		return $r['reg_field_required'];
	}

	function GetRegFieldsValuesByCustomerID($customerID) {
		$customerID = (int)$customerID;

		if (!$customerID) {
			return array(  );
		}

		$q = db_query( 'select reg_field_ID, ' . LanguagesManager::sql_constractSortField( CUSTOMER_REG_FIELDS_TABLE, 'reg_field_name' ) . ',reg_field_name_' . LanguagesManager::getDefaultLanguage(  )->iso2 . ' as reg_field_name from ' . CUSTOMER_REG_FIELDS_TABLE . ' order by sort_order, ' . LanguagesManager::sql_getSortField( CUSTOMER_REG_FIELDS_TABLE, 'reg_field_name' ) );
		$data = array(  );

		if ($r = db_fetch_row( $q )) {
			$q1 = db_query( 'select reg_field_value from ' . CUSTOMER_REG_FIELDS_VALUES_TABLE . ' where reg_field_ID=\'' . $r['reg_field_ID'] . '\' AND customerID=\'' . $customerID . '\'' );
			$reg_field_value = '';

			if ($r1 = db_fetch_row( $q1 )) {
				$reg_field_value = $r1['reg_field_value'];
			}


			if (0 < strlen( trim( $reg_field_value ) )) {
				$row = array(  );
				$row['reg_field_ID'] = $r['reg_field_ID'];
				$row['reg_field_name'] = $r['reg_field_name'];
				$row['reg_field_value'] = $reg_field_value;
				$data[] = $row;
			}
		}

		return $data;
	}

	function GetRegFieldsValues($customer_login) {
		$customerID = regGetIdByLogin( $customer_login );

		if (!$customerID) {
			return array(  );
		}

		return GetRegFieldsValuesByCustomerID( $customerID );
	}

	function GetRegFieldsValuesByOrderID($orderID) {
		$orderID = (int)$orderID;

		if (!$orderID) {
			return array(  );
		}

		$q = db_query( 'select customerID from ' . ORDERS_TABLE . ( ' where orderID = ' . $orderID . ';' ) );
		$row = db_fetch_row( $q );

		if (0 < $row[0]) {
			return GetRegFieldsValuesByCustomerID( $row[0] );
		}

		$q = db_query( 'select reg_field_ID, ' . LanguagesManager::sql_prepareField( 'reg_field_name' ) . ' as reg_field_name from ' . CUSTOMER_REG_FIELDS_TABLE . ' order by sort_order, reg_field_name ' );
		$data = array(  );

		if ($r = db_fetch_row( $q )) {
			$q1 = db_query( 'select reg_field_value from ' . CUSTOMER_REG_FIELDS_VALUES_TABLE_QUICKREG . ' where reg_field_ID=\'' . $r['reg_field_ID'] . '\' AND orderID=\'' . $orderID . '\'' );
			$reg_field_value = '';

			if ($r1 = db_fetch_row( $q1 )) {
				$reg_field_value = $r1['reg_field_value'];
			}


			if (0 < strlen( trim( $reg_field_value ) )) {
				$row = array(  );
				$row['reg_field_ID'] = $r['reg_field_ID'];
				$row['reg_field_name'] = $r['reg_field_name'];
				$row['reg_field_value'] = $reg_field_value;
				$data[] = $row;
			}
		}

		return $data;
	}

?>