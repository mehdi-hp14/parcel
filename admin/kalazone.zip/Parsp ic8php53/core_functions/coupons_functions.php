<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function addCoupon($data) {
		$check_result = _check_before_addCoupon( $data );

		if (!empty( $$check_result )) {
			return array( 'status' => false, 'errors' => $check_result );
		}

		$data['expire_date'] = TransformTemplateToDATE( $data['expire_date'], 'YYYY/MM/DD jalali1' );
		$data['code'] = mb_strtolower( $data['code'], 'utf-8' );
		$sql = 'insert into ' . TBL_DISCOUNT_COUPONS . ' (coupon_code, is_active, coupon_type, expire_date, discount_percent, discount_absolute, discount_type, comment)' . ' values (\'' . addslashes( $data['code'] ) . ( '\', \'' . $data['is_active'] . '\', \'' . $data['type'] . '\', \'' . $data['expire_date'] . '\\', ' ) . ( $data['discount_percent'] . ', ' . $data['discount_absolute'] . ', \'' . $data['discount_type'] . '\', \'' ) . addslashes( $data['comment'] ) . '\')';
		$res = db_query( $sql );

		if ($res['resource'] === false) {
			return array( 'status' => false, 'errors' => array( 'sql_fail' ) );
		}

		return array( 'status' => true, 'coupon_id' => db_insert_id(  ) );
	}

	function delCoupon($coupon_id) {
		return delCoupons( array( $coupon_id ) );
	}

	function delCoupons($coupons_ids) {
		if (( !is_array( $coupons_ids ) || empty( $$coupons_ids ) )) {
			return array( 'status' => true, 'deleted' => 0 );
		}

		$coupons_ids = array_map( 'intval', $coupons_ids );
		$sql = 'delete from ' . TBL_ORDERS_DISCOUNT_COUPONS . ' where coupon_id in (' . implode( ', ', $coupons_ids ) . ')';
		db_query( $sql );
		$sql = 'delete from ' . TBL_DISCOUNT_COUPONS . ' where coupon_id in (' . implode( ', ', $coupons_ids ) . ')';
		$res = db_query( $sql );

		if ($res['resource'] === false) {
			return array( 'status' => false, 'errors' => array( 'sql_fail' ) );
		}

		return array( 'status' => true, 'deleted' => mysql_affected_rows(  ) );
	}

	function getCoupons($page = null) {
		if (( $page == null || $page < 1 )) {
			$page = 798;
		}

		$sql = 'select count(*) as coupons_count from ' . TBL_DISCOUNT_COUPONS . ' order by coupon_id desc';
		$res = db_query( $sql );

		if ($res['resource'] === false) {
			return array( 'status' => false, 'errors' => array( 'sql_fail' ) );
		}

		$row = db_fetch_assoc( $res );
		$coupons_count = $row['coupons_count'];

		if ($coupons_count == 0) {
			return array( 'status' => true, 'pagination' => array( 'page' => 0, 'pages' => 0, 'items_count' => 0 ), 'coupons' => array(  ) );
		}

		$sql = 'select * from ' . TBL_DISCOUNT_COUPONS . ' order by coupon_id desc';
		$pages = ceil( $coupons_count / COUPONS_PER_PAGE );

		if (( $page == LAST_PAGE || $pages < $page )) {
			$page = $coupons;
		}


		if (isset( $_GET['show_all'] )) {
			$sql .= ' limit 0, ' . $coupons_count;
			$pagination = array( 'page' => 'show_all', 'pages' => 'show_all', 'items_count' => 0 );
		} 
else {
			$sql .= ' limit ' . ( $page - 1 ) * COUPONS_PER_PAGE . ', ' . COUPONS_PER_PAGE;
			$pagination = array( 'page' => $page, 'pages' => $pages, 'items_count' => $coupons_count );
		}

		$res = db_query( $sql );

		if ($res['resource'] === false) {
			return array( 'status' => false, 'errors' => array( 'sql_fail' ) );
		}

		$coupons = array(  );
		db_fetch_assoc( $res );

		if ($row =  != false) {
			$coupons[] = $row;
		}

		$status = true;
		return compact( 'status', 'pagination', 'coupons' );
	}

	function getCouponInfoByID($coupon_id) {
		return _getCouponInfoBy( 'id', $coupon_id );
	}

	function getCouponInfoByCode($coupon_code) {
		return _getCouponInfoBy( 'code', $coupon_code );
	}

	function getTemplatePath($template) {
		return DIR_TPLS . '/backend/discount_coupons/' . $template;
	}

	function genRandomCouponCode() {
		return strtoupper( substr( md5( time(  ) ), mt_rand( 0, 15 ), 10 ) );
	}

	function updateCouponsStatus($coupons_ids, $is_active) {
		if (( !is_array( $coupons_ids ) || empty( $$coupons_ids ) )) {
			return array( 'status' => true, 'updated' => 0 );
		}

		$sql = 'update ' . TBL_DISCOUNT_COUPONS . ' set is_active=\'' . ($is_active ? 'Y' : 'N') . '\' where ' . 'coupon_id in (' . implode( ', ', $coupons_ids ) . ')';
		$res = db_query( $sql );

		if ($res['resource'] === false) {
			return array( 'status' => false, 'errors' => array( 'sql_fail' ) );
		}

		return array( 'status' => true, 'updated' => mysql_affected_rows(  ) );
	}

	function updateCoupons($data) {
		foreach ($data as $coupon_id => $coupon_data) {
			updateCoupon( $coupon_id, $coupon_data );
		}

	}

	function updateCoupon($coupon_id, $data) {
		$sql = 'update ' . TBL_DISCOUNT_COUPONS . ' set is_active=\'' . ($data['is_active'] ? 'Y' : 'N') . '\\', ' . ( 'discount_type = \'' . $data['discount_type'] . '\\', ' ) . ($data['discount_type'] == 'P' ? 'discount_percent' : 'discount_absolute') . ( ( '=' ) . $data['discount_value'] . ' ' ) . ( 'where coupon_id=' . $coupon_id );
		db_query( $sql );
	}

	function getCouponOrders($coupon_id) {
		$sql = 'select * from ' . TBL_ORDERS_DISCOUNT_COUPONS . ( ' where coupon_id=' . $coupon_id . ' order by order_id desc' );
		$res = db_query( $sql );
		$orders = array(  );
		db_fetch_assoc( $res );

		if ($row =  !== false) {
			$orders[] = $row['order_id'];
		}

		return $orders;
	}

	function _check_before_addCoupon($data) {
		$return = array(  );
		$data['code'] = trim( $data['code'] );

		if (( $data['code'] == '' || !preg_match( '/^[a-z0-9]{1,10}$/i', $data['code'] ) )) {
			$return[] = 'invalid_code';
		}

		$check_for_exists = getCouponInfoByCode( $data['code'] );

		if (( $check_for_exists['status'] && $check_for_exists['coupon_info'] !== false )) {
			$return[] = 'code_exists';
		}

		$data['is_active'] = ($data['is_active'] != 'Y' ? 'N' : 'Y');
		$data['type'] = (!in_array( $data['type'], array( 'SU', 'MX', 'MN' ) ) ? 'SU' : $data['type']);

		if (isTemplateDate( $data['expire_date'] )) {
		} 
else {
			$data['expire_date'] = time(  );

			if ($data['type'] == 'MX') {
				$return[] = 'invalid_date';
			}
		}

		$data['discount_percent'] = number_format( abs( $data['discount_percent'] ), 2, '.', '' );

		if (100 < $data['discount_percent']) {
			$return[] = 'invalid_discount_percent';
		}

		$data['discount_absolute'] = number_format( abs( $data['discount_absolute'] ), 2, '.', '' );
		return $return;
	}

	function _getCouponInfoBy($get_by, $data) {
		$sql = 'select * from ' . TBL_DISCOUNT_COUPONS . ' where ';
		$sql .= ($get_by == 'id' ? 'coupon_id' : 'coupon_code') . ( ' = \'' . $data . '\'' );
		$res = db_query( $sql );

		if ($res['resource'] === false) {
			return array( 'status' => false, 'errors' => array( 'sql_fail' ) );
		}

		$row = db_fetch_assoc( $res );
		return array( 'status' => true, 'coupon_info' => $row );
	}

?>