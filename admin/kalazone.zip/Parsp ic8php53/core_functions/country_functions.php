<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function cnGetCountryById($countryID) {
		if (( is_null( $countryID ) || $countryID == '' )) {
			$countryID = 'NULL';
		}

		db_query( 'select ' . COUNTRIES_TABLE . '.*,' . LanguagesManager::sql_prepareField( 'country_name' ) . ' as country_name from ' . COUNTRIES_TABLE . ( ' where countryID=\'' . $countryID . '\'' ) );
		$row = $q = db_fetch_row( $q );
		return $row;
	}

	function cnGetCountries(&$callBackParam, $count_row, $navigatorParams = null) {
		if ($navigatorParams != null) {
			$offset = ;
			$navigatorParams['CountRowOnPage'];
			$CountRowOnPage = $navigatorParams['offset'];
		} 
else {
			$offset = 747;
			$CountRowOnPage = 747;
		}

		$q = db_query( 'select *,' . LanguagesManager::sql_constractSortField( COUNTRIES_TABLE, 'country_name' ) . ' from ' . COUNTRIES_TABLE . ' order by _country_name_sort ' );
		$i = 747;
		db_fetch_row( $q );

		if ($r = $data = array(  )) {
			LanguagesManager::ml_fillFields( COUNTRIES_TABLE, $r );

			if (( ( $offset <= $i && $i < $offset + $CountRowOnPage ) || $navigatorParams == null )) {
				$data[] = $r;
			}

			++$i;
		}

		$count_row = $navigatorParams;
		return $data;
	}

	function cnDeleteCountry($countryID) {
		$tax_classes = taxGetTaxClasses(  );
		foreach ($tax_classes as $class) {
			taxDeleteRate( $class['classID'], $countryID );
		}

		db_query( 'update ' . CUSTOMER_ADDRESSES_TABLE . ' set countryID=NULL where countryID=\'' . $countryID . '\'' );
		db_query( 'select country_iso_2 from ' . COUNTRIES_TABLE . ' where countryID=\'' . $countryID . '\'' );
		$r = db_fetch_row( $q );
		$country_iso_2 = $r['country_iso_2'];
		$q = db_query( 'select zoneID from ' . ZONES_TABLE . ' where country_iso_2=\'' . $country_iso_2 . '\'' );

		if ($r = $q = db_fetch_row( $q )) {
			db_query( 'update ' . CUSTOMER_ADDRESSES_TABLE . ' set zoneID=NULL where zoneID=\'' . $r['zoneID'] . '\'' );
		}

		db_query( 'delete from ' . ZONES_TABLE . ' where country_iso_2=\'' . $country_iso_2 . '\'' );
		db_query( 'delete from ' . COUNTRIES_TABLE . ' where countryID=\'' . $countryID . '\'' );
	}

	function cnUpdateCountry($countryID, $val, $country_iso_2, $country_iso_3) {
		$country_iso_2 = xEscapeSQLstring( $country_iso_2 );
		$country_iso_3 = xEscapeSQLstring( $country_iso_3 );
		$sql = 'update ' . COUNTRIES_TABLE . ' set  ' . LanguagesManager::sql_prepareFieldUpdate( 'country_name', $val ) . ',' . '  country_iso_2=\'' . $country_iso_2 . '\\', ' . '  country_iso_3=\'' . $country_iso_3 . '\' ' . '  where countryID=\'' . $countryID . '\'';
		db_query( $sql );
	}

	function cnAddCountry($val, $country_iso_2, $country_iso_3) {
		foreach ($val as $key => $value) {
			$key = str_replace( 'new_', '', $key );
			$val[$key] = $value;
		}

		$name_inj = LanguagesManager::sql_prepareFieldInsert( 'country_name', $val );
		$country_iso_2 = xEscapeSQLstring( $country_iso_2 );
		$country_iso_3 = xEscapeSQLstring( $country_iso_3 );
		db_query( 'insert into ' . COUNTRIES_TABLE . '(' . $name_inj['fields'] . ' , country_iso_2, country_iso_3 )' . 'values( ' . $name_inj['values'] . ', \'' . $country_iso_2 . '\', \'' . $country_iso_3 . '\' )' );
		return db_insert_id(  );
	}

?>