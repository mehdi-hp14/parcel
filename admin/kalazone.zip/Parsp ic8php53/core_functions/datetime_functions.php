<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function get_current_time() {
		$timediff = _getSettingOptionValue( 'CONF_TIME_DIFF' );
		return strftime( '%Y-%m-%d %H:%M:%S', time(  ) + $timediff );
	}

	function dtConvertToStandartForm($datetime, $showtime = 0) {
		$array = explode( ' ', $datetime );
		$date = $array[0];
		$time = $array[1];
		$dateArray = explode( '-', $date );
		$day = $dateArray[2];
		$month = $dateArray[1];
		$year = $dateArray[0];

		if (!strcmp( _getSettingOptionValue( 'CONF_DATE_FORMAT' ), 'MM/DD/YYYY' )) {
			$date = $month . '/' . $day . '/' . $year;
		} 
else {
			$date = $day . '.' . $month . '.' . $year;
		}


		if ($showtime == 1) {
			return $date . ' ' . $time;
		}

		return $date;
	}

	function dtGetParsedDateTime($datetime) {
		$array = explode( ' ', $datetime );
		$date = $array[0];
		$time = $array[1];
		$dateArray = explode( '-', $date );
		return array( 'day' => (int)$dateArray[2], 'month' => (int)$dateArray[1], 'year' => (int)$dateArray[0] );
	}

	function format_datetime($dt) {
		$datetype = _getSettingOptionValue( 'CONF_DATE_FORMAT' );
		$timediff = _getSettingOptionValue( 'CONF_TIME_DIFF' );

		if ($datetype == 'jalali1') {
			$a = @date( 'm/d/Y', @strtotime( $dt ) );
			$b = @date( 'H:i:s', @strtotime( $dt ) );
			$date2 = explode( ':', $b );
			$date1 = explode( '/', $a );
			$ndate = jdate( 'j F Y h:i:s a', mktime( $date2[0], $date2[1], $date2[2], $date1[0], $date1[1], $date1[2] ) );
			return fa_get_persian_number( $ndate );
		}


		if ($datetype == 'jalali2') {
			$dformat = 'm/d/Y h:i:s a';
			$a = @date( $dformat, @strtotime( $dt ) );
			$b = @date( 'H:i:s', @strtotime( $dt ) );
			$date1 = explode( '/', $a );
			$date2 = explode( ':', $b );
			$newdate = jdate( 'Y/m/d h:i a', mktime( $date2[0], $date2[1], $date2[2], $date1[0], $date1[1], $date1[2] ) );
			return fa_get_persian_number( $newdate );
		}


		if ($datetype == 'jalali3') {
			$dformat = 'm/d/Y h:i:s A';
			$a = @date( $dformat, @strtotime( $dt ) );
			$b = @date( 'H:i:s', @strtotime( $dt ) );
			$date2 = explode( ':', $b );
			$date1 = explode( '/', $a );
			$newdate = jdate( 'l j F Y h:i:s a', mktime( $date2[0], $date2[1], $date2[2], $date1[0], $date1[1], $date1[2] ) );
			return fa_get_persian_number( $newdate );
		}


		if ($datetype == 'gregorian1') {
			$dformat = 'm/d/Y h:i:s A';
			$a = @date( $dformat, @strtotime( $dt ) );
			return $a;
		}

		$dformat = 'd.m.Y H:i:s';
		$a = @date( $dformat, @strtotime( $dt ) );
		return $a;
	}

	function get_today_jalali($format) {
		$a = $timediff = _getSettingOptionValue( 'CONF_TIME_DIFF' );
		explode( '/', $a );
		$date1 = jdate( $format, time(  ) + $timediff );
		return fa_get_persian_number( $a );
	}

?>