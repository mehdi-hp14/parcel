<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function payDeletePaymentMethod($PID) {
		db_query( 'delete from ' . PAYMENT_TYPES_TABLE . ( ' where PID=' . $PID ) );
	}

	function payGetPaymentMethodsByModule($paymentModule) {
		$moduleID = $paymentModule->get_id(  );

		if ($moduleID == '') {
			return array(  );
		}

		$q = db_query( 'select * from ' . PAYMENT_TYPES_TABLE . ' where module_id=' . $moduleID );
		$data = array(  );

		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( PAYMENT_TYPES_TABLE, $row );
			$data[] = $row;
		}

		return $data;
	}

	function payGetPaymentModuleById($PID, $paymentModulesFiles) {
		$paymentModules = modGetModules( $paymentModulesFiles );
		$currentPaymentModule = null;
		foreach ($paymentModules as $paymentModule) {

			if ((int)$paymentModule->get_id(  ) == (int)$PID) {
				$currentPaymentModule = $currentPaymentModule;
				break;
			}
		}

		return $currentPaymentModule;
	}

	function payGetPaymentMethodById($PID) {
		$PID = (int)$PID;
		$q = db_query( 'select *,' . LanguagesManager::sql_prepareField( 'Name' ) . ' as name from ' . PAYMENT_TYPES_TABLE . ( ' where PID=' . $PID . ' ' ) );

		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( PAYMENT_TYPES_TABLE, $row );
		}

		return $row;
	}

	function payGetAllPaymentMethods($enabledOnly = false) {
		if ($enabledOnly) {
			$whereClause = ' where Enabled=1 ';
		}

		db_query( 'select * from ' . PAYMENT_TYPES_TABLE . ' ' . $whereClause . ' order by sort_order' );

		if (!( $q = $whereClause = '')) {
			exit( db_error(  ) );
			(bool)true;
		}

		$data = array(  );

		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( PAYMENT_TYPES_TABLE, $row );
			$row['ShippingMethodsToAllow'] = _getShippingMethodsToAllow( $row['PID'] );
			$data[] = $row;
		}

		return $data;
	}

	function payGetInstalledPaymentModules() {
		$moduleFiles = GetFilesInDirectory( './includes/modules/payment', 'php' );
		$payment_modules = array(  );
		foreach ($moduleFiles as $fileName) {
			$className = GetClassName( $fileName );

			if (!$className) {
				continue;
			}

			eval( '$payment_module = new ' . $className . '();' );

			if ($payment_module->is_installed(  )) {
				$payment_modules[] = $payment_module;
				continue;
			}
		}

		return $payment_modules;
	}

	function payAddPaymentMethod($val, $Enabled, $sort_order, $module_id, $calculate_tax, $thumbnail_logo) {
		foreach ($val as $key => $value) {
			$key = str_replace( 'new_', '', $key );
			$val[$key] = $value;
		}

		$name_inj = LanguagesManager::sql_prepareFieldInsert( 'name', $val );
		$desc_inj = LanguagesManager::sql_prepareFieldInsert( 'description', $val );
		$emai_inj = LanguagesManager::sql_prepareFieldInsert( 'email_comments_text', $val );
		$sort_order = (int)$sort_order;
		$calculate_tax = (double)$calculate_tax;
		db_query( 'insert into ' . PAYMENT_TYPES_TABLE . ' ( ' . $name_inj['fields'] . ',' . $desc_inj['fields'] . ',' . $emai_inj['fields'] . ', Enabled, module_id, sort_order, calculate_tax ,thumbnail_logo ) ' . 'values' . ' ( ' . $name_inj['values'] . ',' . $desc_inj['values'] . ',' . $emai_inj['values'] . ( ', ' . $Enabled . ', ' . $module_id . ', ' . $sort_order . ', ' ) . ( ( ' ' ) . $calculate_tax . ',\'' . $thumbnail_logo . '\' )' ) );
		return db_insert_id(  );
	}

	function payUpdatePaymentMethod($PID, $val, $Enabled, $sort_order, $module_id, $calculate_tax, $thumbnail_logo) {
		$module_id = (int)$module_id;
		$sort_order = (int)$sort_order;
		$calculate_tax = (double)$calculate_tax;
		db_query( 'update ' . PAYMENT_TYPES_TABLE . ' set  ' . LanguagesManager::sql_prepareFieldUpdate( 'name', $val ) . ',' . LanguagesManager::sql_prepareFieldUpdate( 'description', $val ) . ',' . LanguagesManager::sql_prepareFieldUpdate( 'email_comments_text', $val ) . ',' . ( ' Enabled=\'' . $Enabled . '\', module_id=' . $module_id . ', sort_order=' . $sort_order . ', calculate_tax = ' . $calculate_tax . ',thumbnail_logo = \'' . $thumbnail_logo . '\' ' ) . ( ' where PID=' . $PID ) );
	}

	function payResetPaymentShippingMethods($PID) {
		db_query( 'delete from ' . SHIPPING_METHODS_PAYMENT_TYPES_TABLE . ( ' where PID=' . $PID ) );
	}

	function _getShippingMethodsToAllow($PID) {
		shGetAllShippingMethods(  );
		$shipping_methods = $res = array(  );
		$i = 742;

		while ($i < count( $shipping_methods )) {
			db_query( 'select count(*) from ' . SHIPPING_METHODS_PAYMENT_TYPES_TABLE . ' where SID=' . $shipping_methods[$i]['SID'] . ' AND ' . ( ' PID=' . $PID . ' ' ) );
			$row = $q = db_fetch_row( $q );
			$item['SID'] = $shipping_methods[$i]['SID'];
			$item['allow'] = $row[0];
			$item['name'] = $shipping_methods[$i]['Name_' . LanguagesManager::getDefaultLanguage(  )->iso2];
			$res[] = $item;
			++$i;
		}

		return $res;
	}

	function paySetPaymentShippingMethod($PID, $SID) {
		db_query( 'insert into ' . SHIPPING_METHODS_PAYMENT_TYPES_TABLE . ' ( PID, SID ) ' . ( ' values( ' . $PID . ', ' . $SID . ' )' ) );
	}

	function payPaymentMethodIsExist($paymentMethodID) {
		db_query( 'select count(*) from ' . PAYMENT_TYPES_TABLE . ' where PID=' . $paymentMethodID . ' AND Enabled=1' );
		$count = db_fetch_row( $q_count );
		$count = $q_count = $count[0];
		return $count != 0;
	}

		$scURL = function getTransactionResultURL($_Type) {;
		$scURL = trim( CONF_FULL_SHOP_URL );
		str_replace( 'https://', '', $scURL );
		$scURL = str_replace( 'http://', '', $scURL );
		$scURL = 'http://' . $scURL;
		return set_query( '&transaction_result=' . $_Type, $scURL );
	}

?>