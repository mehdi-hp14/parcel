<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function regRegisterAdmin($admin_login, $admin_pass, $Update = false, $OldAdminLogin = '') {
		if (( $Update && $OldAdminLogin )) {
			regGetCustomerInfo2( $OldAdminLogin );
			$CustomerInfo = ;

			if (is_array( $CustomerInfo )) {
				$sql = '
				UPDATE `' . CUSTOMERS_TABLE . '`
				SET Login="' . xEscapeSQLstring( $admin_login ) . '",cust_password="' . cryptPasswordCrypt( $admin_pass ) . '"
				WHERE customerID="' . xEscapeSQLstring( $CustomerInfo['customerID'] ) . '"
			';
				db_query( $sql );
				return true;
			}
		}

		$admin_login = ;
		TransformStringToDataBase( $admin_pass );
		$OldID = db_query( 'delete from ' . CUSTOMERS_TABLE . ' where Login=\'' . $admin_login . '\'' );
		$custgroupID = 820;
		$admin_pass = cryptPasswordCrypt( $admin_pass );
		db_query( 'select CID from ' . CURRENCY_TYPES_TABLE );
		$q = TransformStringToDataBase( $admin_login );
		$currencyID = 'NULL';

		if ($currency = $admin_pass = db_fetch_row( $q )) {
			$currencyID = $currency['CID'];
		}

		db_query( 'insert into ' . CUSTOMERS_TABLE . ' (Login, cust_password, Email, first_name, last_name, subscribed4news, ' . ' 	custgroupID, addressID, reg_datetime, CID ) values ' . '(\'' . $admin_login . '\',\'' . $admin_pass . '\\', ' . ( ' \'-\', \'-\', \'-\', 0, ' . $custgroupID . ', NULL, ' ) . ' \'' . get_current_time(  ) . '\\', ' . $currencyID . ' )' );
		$errorCode = 819;
		$zoneID = '347';
		$state = '';
		$countryID = '101';
		$city = '687';
		$country_iso_2 = 'IR';
		$defaultAddressID = regAddAddress( '-', '-', $countryID, $zoneID, $state, '-', '-', '-', '-', $admin_login, $errorCode, $country_iso_2, $city );
		regSetDefaultAddressIDByLogin( $admin_login, $defaultAddressID );
		return true;
	}

		$login = function regIsRegister($login) {;
		db_query( 'select count(Login) from ' . CUSTOMERS_TABLE . ' where Login=\'' . $login . '\'' );
		$q = TransformStringToDataBase( $login );
		$r = db_fetch_row( $q );
		return $r[0] != 0;
	}

	function regGetLoginById($customerID) {
		$customerID = (int)$customerID;

		if ($customerID == 0) {
			return false;
		}

		$q = db_query( 'select Login from ' . CUSTOMERS_TABLE . ' where customerID=' . $customerID );

		if ($r = db_fetch_row( $q )) {
			return $r['Login'];
		}

		return false;
	}

	function regGetIdByLogin($login) {
		$q = db_query( 'select customerID from ' . CUSTOMERS_TABLE . ' where Login=\'' . xEscapeSQLstring( $login ) . '\'' );

		if ($r = db_fetch_row( $q )) {
			return $r['customerID'];
		}

	}

	function regAuthenticate($login, $password, $Redirect = true) {
		$login = TransformStringToDataBase( $login );
		$password = TransformStringToDataBase( $password );

		if (!( $q = db_query( 'SELECT cust_password, CID, ActivationCode FROM ' . CUSTOMERS_TABLE . ' WHERE Login=\'' . $login . '\'' ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$row = db_fetch_row( $q );

		if (( CONF_ENABLE_REGCONFIRMATION && $row['ActivationCode'] )) {
			if ($Redirect) {
				RedirectProtected( set_query( '&act_customer=1&notact=1' ) );
			} 
else {
				return false;
			}
		}


		if (( $row && 0 < strlen( trim( $login ) ) )) {
			if (crypt_check( $row['cust_password'], $password )) {
				$_SESSION['log'] = $login;
				$_SESSION['pass'] = $row['cust_password'];
				$_SESSION['timeout'] = time(  );
				$_SESSION['current_currency'] = $row['CID'];
				stAddCustomerLog( $login );
				moveCartFromSession2DB(  );
				return true;
			}

			return false;
		}

		return false;
	}

	function checkforremind($Email, $password) {
		$sql = '
		SELECT Login, cust_password, Email FROM ' . CUSTOMERS_TABLE . '
		WHERE (Email="' . xEscapeSQLstring( $Email ) . '" AND cust_password="' . xEscapeSQLstring( $password ) . '")
		AND (ActivationCode="" OR ActivationCode IS NULL)';

		if (!( $q = db_query( $sql ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			return $row['Login'];
		}

		return false;
	}

	function regSendPasswordToUser(&$login, $smarty_mail) {
		$sql = '
		SELECT Login, cust_password, Email FROM ' . CUSTOMERS_TABLE . '
		WHERE (Login="' . xEscapeSQLstring( $login ) . '" OR Email="' . xEscapeSQLstring( $login ) . '")
		AND (ActivationCode="" OR ActivationCode IS NULL)
	';

		if (!( $q = db_query( $sql ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			$password = base64_encode( $row['cust_password'] );
			$login = base64_encode( $row['Email'] );
			$host = $_SERVER['HTTP_HOST'];
			$link = $host . '/index.php?remindpass&uid=' . $login . '__' . ( $password );

			if (strpos( $link, 'http://' ) == false) {
				$link = 'http://' . $link;
			}

			$smarty_mail->assign( 'user_pass', $link );
			$smarty_mail->assign( 'user_login', $row['Login'] );
			$html = $smarty_mail->fetch( 'remind_password.tpl.html' );
			sendEmail( $row['Email'], mail2utf8( EMAIL_FORGOT_PASSWORD_SUBJECT ), $html, 'From: "' . mail( CONF_SHOP_NAME_LATIN ) . '"<' . CONF_GENERAL_EMAIL . '>
' . stripslashes( EMAIL_MESSAGE_PARAMETERS ) . '
Return-path: <' . CONF_GENERAL_EMAIL . '>' );
			return true;
		}

		return false;
	}

	function regIsAdminiatrator($login) {
		return !strcmp( $login, ADMIN_LOGIN );
	}

	function regRegisterCustomer($login, $cust_password, $Email, $first_name, $last_name, $subscribed4news, $additional_field_values, $phone, $mobile, $affiliateLogin = '') {
		xEscapeSQLstring( $login );
		xEscapeSQLstring( $cust_password );
		$Email = xEscapeSQLstring( $Email );
		xEscapeSQLstring( $first_name );
		$last_name = xEscapeSQLstring( $last_name );
		$phone = xEscapeSQLstring( $phone );
		$mobile = xEscapeSQLstring( $mobile );
		$affiliateLogin = xEscapeSQLstring( $affiliateLogin );
		$affiliateID = 885;

		if ($affiliateLogin) {
			$sql = '
			SELECT customerID  FROM ' . CUSTOMERS_TABLE . ( '
			WHERE Login=\'' . $affiliateLogin . '\'
		' );
			$affiliateID = db_fetch_row( db_query( $sql ) )[0];
		}

		foreach ($additional_field_values as $key => $val) {
			$additional_field_values[$key] = xEscapeSQLstring( $val );
		}

		$q = db_query( 'select CID from ' . CURRENCY_TYPES_TABLE );
		$currencyID = $login = db_fetch_row( $q );
		$currencyID = $cust_password = $currencyID[0];

		if ($currencyID == null) {
			$currencyID = 'NULL';
		}

		$cust_password = $first_name = cryptPasswordCrypt( $cust_password );
		$custgroupID = CONF_DEFAULT_CUSTOMER_GROUP;

		if ($custgroupID == 0) {
			$custgroupID = 'NULL';
		}

		$ActivationCode = '';

		if (CONF_ENABLE_REGCONFIRMATION) {
			$CodeExists = true;

			while ($CodeExists) {
				$ActivationCode = generateRndCode( 16 );
				$sql = '
				SELECT 1 FROM ' . CUSTOMERS_TABLE . '
				WHERE ActivationCode="' . xEscapeSQLstring( $ActivationCode ) . '"
			';
				$CodeExists = @db_fetch_row( @db_query( $sql ) )[0];
			}
		}

		$sql = 'insert into ' . CUSTOMERS_TABLE . '( Login, cust_password, Email, first_name, last_name, subscribed4news, reg_datetime, CID, custgroupID' . ', affiliateID' . ', ActivationCode,phone,mobile)' . 'values( \'' . $login . '\', \'' . $cust_password . '\', \'' . $Email . '\\', ' . ' \'' . $first_name . '\', \'' . $last_name . '\', \'' . $subscribed4news . '\', \'' . get_current_time(  ) . '\', \'' . $currencyID . '\', \'' . $custgroupID . '\', \'' . $affiliateID . '\', \'' . $ActivationCode . '\', \'' . $phone . '\', \'' . $mobile . '\' )';
		db_query( $sql );
		foreach ($additional_field_values as $key => $val) {
			SetRegField( $key, $login, $val['additional_field'] );
		}

		$customerID = regGetIdByLogin( $login );

		if ($subscribed4news) {
			subscrAddRegisteredCustomerEmail( $customerID );
		}

		return true;
	}

	function regEmailNotification($smarty_mail, $login, $cust_password, $Email, $first_name, $last_name, $subscribed4news, $additional_field_values, $countryID, $zoneID, $state, $zip, $city, $address, $updateOperation) {
		$user = array(  );
		$smarty_mail->assign( 'cust_password', $cust_password );
		$smarty_mail->assign( 'first_name', $first_name );
		$smarty_mail->assign( 'last_name', $last_name );
		$smarty_mail->assign( 'Email', $Email );
		$additional_field_values = GetRegFieldsValues( $login );
		$smarty_mail->assign( 'additional_field_values', $additional_field_values );
		regGetAllAddressesByLogin( $login );
		$addresses = $smarty_mail->assign( 'login', $login );
		$i = 851;

		while ($i < count( $addresses )) {
			$addresses[$i]['addressStr'] = regGetAddressStr( $addresses[$i]['addressID'], true );
			++$i;
		}

		$smarty_mail->assign( 'addresses', $addresses );
		$sql = '	
			SELECT ActivationCode FROM ' . CUSTOMERS_TABLE . '
			WHERE Login="' . xEscapeSQLstring( $login ) . '"';
		$ActivationCode = @db_fetch_row( @db_query( $sql ) )[0];
		$smarty_mail->assign( 'ActURL', CONF_FULL_SHOP_URL . (substr( CONF_FULL_SHOP_URL, strlen( CONF_FULL_SHOP_URL ) - 1, 1 ) == '/' ? '' : '/') . 'index.php?act_customer=1&act_code=' . $ActivationCode );
		$smarty_mail->assign( 'ActCode', $ActivationCode );
		$html = $smarty_mail->fetch( 'register_successful.tpl.html' );
		sendEmail( $Email, EMAIL_REGISTRATION, $html, 'From: "' . CONF_SHOP_NAME_LATIN . '"<' . CONF_GENERAL_EMAIL . '>
		$r = ' . stripslashes( EMAIL_MESSAGE_PARAMETERS ) . '
Return-path: <' . CONF_GENERAL_EMAIL . '>' );

		return true;
	}

	function regGetCustomerInfo(&$login, &$cust_password, &$Email, &$first_name, &$last_name, &$subscribed4news, &$additional_field_values, &$countryID, &$zoneID, &$state, &$zip, &$city, &$address, &$phone, $mobile) {
		$q = db_query( 'select customerID, cust_password, Email, first_name, last_name, ' . ' subscribed4news, custgroupID, addressID, credit,phone,mobile  from ' . CUSTOMERS_TABLE . ' where Login=\'' . $login . '\'' );
		$cust_password = db_fetch_row( $q );

		if (CONF_BACKEND_SAFEMODE) {
			$row['Email'] = ADMIN_SAFEMODE_BLOCKED;
		} 
else {
			$Email = $r['Email'];
		}

		$first_name = $r = ;
		$last_name = cryptPasswordDeCrypt( $r['cust_password'], null );
		$subscribed4news = $r['subscribed4news'];
		$addressID = $r['addressID'];
		$r['customerID'];
		$r['phone'];
		$q = $customerID = $r['mobile'];
		$r = $phone = $r['first_name'];
		$zoneID = $countryID = $mobile = $r['last_name'];
		$zip = $r['zip'];
		$r['state'];
		$state = db_query( 'select countryID, zoneID, zip, state, city, address from ' . CUSTOMER_ADDRESSES_TABLE . ' where customerID=\'' . $customerID . '\'' );
		$r['city'];
		$city = db_fetch_row( $q );
		$r['address'];
		$address = $r['countryID'];
		GetRegFieldsValues( $login );
		$additional_field_values = $r['zoneID'];
	}

	function regGetCustomerInfo2($login) {
		$q = db_query( 'select customerID, cust_password, Email, first_name, last_name, ' . ' subscribed4news, custgroupID, addressID, Login, credit, ActivationCode , mobile, phone from ' . CUSTOMERS_TABLE . ' where Login=\'' . xEscapeSQLstring( $login ) . '\'' );

		if ($row = db_fetch_row( $q )) {
			if ($row['custgroupID'] != null) {
				$q = db_query( 'select custgroupID, custgroup_name, custgroup_discount, sort_order from ' . CUSTGROUPS_TABLE . ' where custgroupID=' . $row['custgroupID'] );
				$custGroup = db_fetch_row( $q );
				$row['custgroup_name'] = $custGroup['custgroup_name'];
			} 
else {
				$row['custgroup_name'] = '';
			}

			$row['cust_password'] = cryptPasswordDeCrypt( $row['cust_password'], null );

			if (CONF_BACKEND_SAFEMODE) {
				$row['Email'] = ADMIN_SAFEMODE_BLOCKED;
			}

			$row['allowToDelete'] = regVerifyToDelete( $row['customerID'] );
		}

		return $row;
	}

	function regAddAddress($first_name, $last_name, $countryID, $zoneID, $state, $zip, $city, $cityID, $address, &$log, $errorCode, $country_iso_2, $phone = '', $mobile = '') {
		xEscapeSQLstring( $first_name );
		$last_name = xEscapeSQLstring( $last_name );
		$state = xEscapeSQLstring( $state );
		xEscapeSQLstring( $zip );
		$city = xEscapeSQLstring( $city );
		$address = xEscapeSQLstring( $address );
		$phone = xEscapeSQLstring( $phone );
		$mobile = xEscapeSQLstring( $mobile );
		$q = db_query( 'select count(zoneID) from ' . ZONES_TABLE . ' where country_iso_2=\'' . $country_iso_2 . '\'' );
		$r = $first_name = db_fetch_row( $q );

		if (( $r[0] != 0 && $zoneID == 0 )) {
			$errorCode = 'zoneIncompatibleWithCountry';
			return false;
		}

		$customerID = $zip = regGetIdByLogin( $log );

		if ($cityID == 0) {
			$cityID = 'NULL';
		}


		if ($zoneID == 0) {
			$zoneID = 'NULL';
		}

		$sql = 'insert into ' . CUSTOMER_ADDRESSES_TABLE . ' ( first_name, last_name, countryID, zoneID, zip, state, city, address, customerID,cityID) ' . ( ' values( \'' . $first_name . '\', \'' . $last_name . '\\', ' . $countryID . ', ' . $zoneID . ', \'' . $zip . '\', \'' . $state . '\',\'' . $city . '\', \'' . $address . '\\', ' . $customerID . ', ' . $cityID . ' )' );
		db_query( $sql );
		return db_insert_id(  );
	}

	function regUpdateAddress($addressID, $first_name, $last_name, $countryID, $zoneID, $state, $zip, $city, $cityID, &$address, $errorCode) {
		$first_name = xEscapeSQLstring( $first_name );
		$last_name = xEscapeSQLstring( $last_name );
		$state = xEscapeSQLstring( $state );
		$zip = xEscapeSQLstring( $zip );
		$city = xEscapeSQLstring( $city );
		$address = xEscapeSQLstring( $address );

		if ($zoneID == 0) {
			$zoneID = 'NULL';
		}

		db_query( 'update ' . CUSTOMER_ADDRESSES_TABLE . ' set ' . ( ' first_name=\'' . $first_name . '\', last_name=\'' . $last_name . '\', countryID=' . $countryID . ', ' ) . ( ' zoneID=' . $zoneID . ', zip=\'' . $zip . '\', state=\'' . $state . '\\', ' ) . ( ' city=\'' . $city . '\',cityID=\'' . $cityID . '\', address=\'' . $address . '\' where addressID=' . $addressID ) );
		return true;
	}

	function redDeleteAddress($addressID) {
		db_query( 'update ' . CUSTOMERS_TABLE . ( ' set addressID=NULL where addressID=' . $addressID . ' ' ) );
		db_query( 'delete from ' . CUSTOMER_ADDRESSES_TABLE . ( ' where addressID=' . $addressID ) );
	}

	function regGetAddress($addressID) {
		if ($addressID != null) {
			$q = db_query( $sql );
			db_fetch_row( $q );
			$row = $sql = 'select first_name, last_name, countryID, zoneID, zip, ' . ' state, city, address, customerID,cityID from ' . CUSTOMER_ADDRESSES_TABLE . ' where addressID=' . xEscapeSQLstring( $addressID );

			if (isset( $row['cityID'] )) {
				$city = ctGetSingleCityById( $row['cityID'] );
				$row['city'] = $city['city_name'];
			}

			return $row;
		}

		return false;
	}

		$customerID = function regGetAddressByLogin($addressID, $login) {;
		regGetAddress( $addressID );
		$address = regGetIdByLogin( $login );

		if ((int)$address['customerID'] == (int)$customerID) {
			return $address;
		}

		return false;
	}

	function regGetAllAddressesByLogin($log) {
		$customerID = regGetIdByLogin( $log );
		$customerID = (int)$customerID;

		if ($customerID == 0) {
			return null;
		}

		$q = db_query( 'select * ' . ' from ' . CUSTOMER_ADDRESSES_TABLE . ( ' where customerID=' . $customerID . ' ' ) );
		$data = array(  );

		if ($row = db_fetch_row( $q )) {
			if ($row['country_iso_2'] != null) {
				$q1 = db_query( 'select country_name_' . LanguagesManager::getDefaultLanguage(  )->iso2 . ' as country_name from ' . COUNTRIES_TABLE . ' where countryID=\'' . $row['country_iso_2'] . '\'' );
				$country = db_fetch_row( $q1 );
				$row['country'] = $country[0];
			} 
else {
				$row['country'] = '-';
			}


			if ($row['zoneID'] != null) {
				$q1 = db_query( 'select ' . LanguagesManager::sql_prepareField( 'zone_name' ) . ' as zone_name from ' . ZONES_TABLE . ' where zoneID=' . $row['zoneID'] );
				$zone = db_fetch_row( $q1 );
				$row['state'] = $zone[0];
			}


			if ($row['cityID'] != null) {
				$q1 = db_query( 'select ' . LanguagesManager::sql_prepareField( 'city_name' ) . ' as city_name from ' . CITY_TABLE . ' where cityID=' . $row['cityID'] );
				$city = db_fetch_row( $q1 );
				$row['city'] = $city[0];
			}

			$data[] = $row;
		}

		return $data;
	}

	function regGetDefaultAddressIDByLogin($log) {
		$log = TransformStringToDataBase( $log );
		$q = db_query( 'select addressID from ' . CUSTOMERS_TABLE . ' where Login=\'' . $log . '\'' );

		if ($row = db_fetch_row( $q )) {
			return $row[0];
		}

	}

	function regSetDefaultAddressIDByLogin($log, $defaultAddressID) {
		$log = TransformStringToDataBase( $log );
		db_query( 'update ' . CUSTOMERS_TABLE . ( ' set addressID=' . $defaultAddressID . ' ' ) . ' where Login=\'' . $log . '\'' );
	}

	function _testStrInvalidSymbol($str) {
		strstr( $str, '\'' );

		if (is_string( $res )) {
			return false;
		}

		$res = strstr( $str, '\' );

		if (is_string( $res )) {
			return false;
		}

		$res = strstr( $str, '"' );

		if (is_string( $res )) {
			return false;
		}

		$res = strstr( $str, '<' );

		if (is_string( $res )) {
			return false;
		}

		$res = $res = strstr( $str, '>' );

		if (is_string( $res )) {
			return false;
		}

		return true;
	}

	function _testStrArrayInvalidSymbol($array) {
		foreach ($array as $str) {
			$res = _testStrInvalidSymbol( $str );

			if (!$res) {
				return false;
			}
		}

		return true;
	}

	function regVerifyAddress($first_name, $last_name, $countryID, $zoneID, $state, $zip, $city, $cityID, $address, $phone, $mobile) {
		$error = '';

		if (trim( $first_name ) == '') {
			$error = ERROR_INPUT_NAME;
		} 
else {
			if (trim( $last_name ) == '') {
				$error = ERROR_INPUT_NAME;
			} 
else {
				if (( CONF_ADDRESSFORM_ZIP == 0 && trim( $zip ) == '' )) {
					$error = ERROR_INPUT_ZIP;
				} 
else {
					if (( ( CONF_ADDRESSFORM_STATE == 0 && trim( $state ) == '' ) && $zoneID == 0 )) {
						$error = ERROR_INPUT_STATE;
					} 
else {
						if (( ( CONF_ADDRESSFORM_CITY == 0 && trim( $city ) == '' ) && $cityID == 0 )) {
							$error = ERROR_INPUT_CITY;
						} 
else {
							if (( CONF_ADDRESSFORM_ADDRESS == 0 && trim( $address ) == '' )) {
								$error = ERROR_INPUT_ADDRESS;
							} 
else {
								if (( $_POST['login'] && ( CONF_ADDRESSFORM_PHONE_NUMBER == 0 && trim( $phone ) == '' ) )) {
									$error = ERROR_INPUT_PHONE;
								} 
else {
									if (( $_POST['login'] && ( CONF_ADDRESSFORM_MOBILE == 0 && trim( $mobile ) == '' ) )) {
										$error = ERROR_INPUT_MOBILE;
									} 
else {
										if (CONF_ADDRESSFORM_STATE == 0) {
											$country_detail = cnGetCountryById( $countryID );
											$country_iso_2 = $country_detail['country_iso_2'];
											$q = db_query( 'select count(*) from ' . ZONES_TABLE . ( ' where country_iso_2=\'' . $country_iso_2 . '\'' ) );
											$r = db_fetch_row( $q );
											$countZone = $r[0];

											if ($countZone != 0) {
												$q = db_query( 'select count(*) from ' . ZONES_TABLE . ' where zoneID=' . $zoneID . ( '  AND  country_iso_2=\'' . $country_iso_2 . '\'' ) );
												$r = db_fetch_row( $q );

												if ($r[0] == 0) {
													$error = ERROR_ZONE_DOES_NOT_CONTAIN_TO_COUNTRY;
												}
											} 
else {
												if ($zoneID != 0) {
													$error = ERROR_INPUT_STATE;
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		return $error;
	}

		$row = $q = $login = function regGetContactInfo(&$login, &$cust_password, &$Email, &$first_name, &$last_name, &$subscribed4news, &$additional_field_values, &$phone, $mobile) {;
		$cust_password = cryptPasswordDeCrypt( $row['cust_password'], null );
		$Email = $row['Email'];
		$row['first_name'];
		$first_name = TransformStringToDataBase( $login );
		$last_name = $row['last_name'];
		$subscribed4news = $row['subscribed4news'];
		$phone = $row['phone'];
		$row['mobile'];
		$mobile = db_query( 'select customerID, cust_password, Email, first_name, last_name, ' . ' subscribed4news, custgroupID, addressID,phone,mobile  from ' . CUSTOMERS_TABLE . ' where Login=\'' . $login . '\'' );
		GetRegFieldsValues( $login );
		$additional_field_values = db_fetch_row( $q );
	}

	function regVerifyContactInfo($login, $cust_password1, $cust_password2, $Email, $first_name, $last_name, $subscribed4news, $additional_field_values) {
		$error = '';

		if (!_testStrArrayInvalidSymbol( array( $login, $cust_password1, $cust_password2 ) )) {
			$error = ERROR_INVALID_SYMBOL_LOGIN_INFO;
		} 
else {
			if (trim( $login ) == '') {
				$error = ERROR_INPUT_LOGIN;
			} 
else {
				if (!( ( ord( 'a' ) <= ord( $login ) && ord( $login ) <= ord( 'z' ) ) || ( ord( 'A' ) <= ord( $login ) && ord( $login ) <= ord( 'Z' ) ) )) {
					$error = ERROR_LOGIN_SHOULD_START_WITH_LATIN_SYMBOL;
				} 
else {
					if (( ( $cust_password1 == '' || $cust_password2 == '' ) || $cust_password1 != $cust_password2 )) {
						$error = ERROR_WRONG_PASSWORD_CONFIRMATION;
					} 
else {
						if (trim( $first_name ) == '') {
							$error = ERROR_INPUT_NAME;
						} 
else {
							if (trim( $last_name ) == '') {
								$error = ERROR_INPUT_NAME;
							} 
else {
								if (( trim( $Email ) == '' || checkreemail( $Email ) )) {
									$error = ERROR_INPUT_EMAIL . ' Failed';
								} 
else {
									if (!preg_match( '/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i', $Email )) {
										$error = ERROR_INPUT_EMAIL;
									}
								}
							}
						}
					}
				}
			}
		}

		return $error;
	}

	function regVerifyreContactInfo($login, $cust_password1, $cust_password2, $Email, $first_name, $last_name, $subscribed4news, $additional_field_values, $phone, $mobile, $newemail) {
		$error = '';

		if (!_testStrArrayInvalidSymbol( array( $login, $cust_password1, $cust_password2 ) )) {
			$error = ERROR_INVALID_SYMBOL_LOGIN_INFO;
		} 
else {
			if (trim( $login ) == '') {
				$error = ERROR_INPUT_LOGIN;
			} 
else {
				if (!( ( ord( 'a' ) <= ord( $login ) && ord( $login ) <= ord( 'z' ) ) || ( ord( 'A' ) <= ord( $login ) && ord( $login ) <= ord( 'Z' ) ) )) {
					$error = ERROR_LOGIN_SHOULD_START_WITH_LATIN_SYMBOL;
				} 
else {
					if (( ( $cust_password1 == '' || $cust_password2 == '' ) || $cust_password1 != $cust_password2 )) {
						$error = ERROR_WRONG_PASSWORD_CONFIRMATION;
					} 
else {
						if (trim( $first_name ) == '') {
							$error = ERROR_INPUT_NAME;
						} 
else {
							if (trim( $last_name ) == '') {
								$error = ERROR_INPUT_NAME;
							} 
else {
								if (( CONF_ADDRESSFORM_PHONE_NUMBER == 0 && trim( $phone ) == '' )) {
									$error = ERROR_INPUT_PHONE;
								} 
else {
									if (( CONF_ADDRESSFORM_MOBILE == 0 && trim( $mobile ) == '' )) {
										$error = ERROR_INPUT_MOBILE;
									} 
else {
										if ($Email != $newemail) {
											if (( $Email != '-' && checkreemail( $newemail ) )) {
												$error = ERROR_INPUT_EMAIL . ' Failed';
											} 
else {
												if (!preg_match( '/^[_\.0-9a-zA-Z-]+@([0-9a-zA-Z][0-9a-zA-Z-]+\.)+[a-zA-Z]{2,6}$/i', $newemail )) {
													$error = ERROR_INPUT_EMAIL;
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		return $error;
	}

	function checkreemail($email) {
		$q = db_query( 'select *  from ' . CUSTOMERS_TABLE . ' where Email=\'' . $email . '\'' );
		$r = db_fetch_row( $q );

		if ($r) {
			return true;
		}

		return false;
	}

	function regUpdateContactInfo($old_login, $login, $cust_password, $Email, $first_name, $last_name, $subscribed4news, $phone, $mobile, $additional_field_values) {
		$old_login = TransformStringToDataBase( $old_login );
		$login = TransformStringToDataBase( $login );
		$cust_password = TransformStringToDataBase( $cust_password );
		$Email = TransformStringToDataBase( $Email );
		$last_name = $first_name = TransformStringToDataBase( $first_name );
		$phone = TransformStringToDataBase( $phone );
		$mobile = TransformStringToDataBase( $mobile );
		db_query( 'update ' . CUSTOMERS_TABLE . '  set ' . ' Login = \'' . $login . '\\', ' . ' cust_password = \'' . cryptPasswordCrypt( $cust_password, null ) . '\\', ' . ' Email = \'' . $Email . '\\', ' . ' first_name = \'' . $first_name . '\\', ' . ' last_name = \'' . $last_name . '\\', ' . ' subscribed4news = ' . $subscribed4news . ' , ' . ' phone = \'' . $phone . '\' ,' . ' mobile = \'' . $mobile . '\' ' . ' where Login=\'' . $old_login . '\'' );
		foreach ($additional_field_values as $key => $val) {
			SetRegField( $key, $login, $val['additional_field'] );
		}

		regGetIdByLogin( $login );
		$customerID = TransformStringToDataBase( $last_name );

		if ($subscribed4news) {
			subscrAddRegisteredCustomerEmail( $customerID );
			return null;
		}

		subscrUnsubscribeSubscriberByEmail( base64_encode( $Email ) );
	}

	function regGetAddressStr($addressID, $NoTransform = false) {
		$address = regGetAddress( $addressID, $NoTransform );

		if (!is_array( $address )) {
			return '';
		}

		$country = cnGetCountryById( $address['countryID'] );
		$country = $country['country_name'];

		if (trim( $address['state'] ) == '') {
			$zone = znGetSingleZoneById( $address['zoneID'] );
			$zone = $zone['zone_name'];
		} 
else {
			$zone = trim( $address['state'] );
		}


		if (trim( $address['city'] ) == '') {
			$city = ctGetSingleCityById( $address['cityID'] );
			$city = $city['city_name'];
		} 
else {
			$city = trim( $address['city'] );
		}


		if (!$NoTransform) {
			$address = xHtmlSpecialChars( $address );
			$zone = xHtmlSpecialChars( $zone );
			$country = xHtmlSpecialChars( $country );
		}


		if ($country != '') {
			$strAddress = $address['first_name'] . '  ' . $address['last_name'];

			if (0 < strlen( $country )) {
				$strAddress .= '<br>' . $country;
			}


			if (0 < strlen( $zone )) {
				$strAddress .= ' - ' . $zone;
			}


			if (0 < strlen( $city )) {
				$strAddress .= '<br>' . $city;
			}


			if (0 < strlen( $address['address'] )) {
				$strAddress .= ', ' . $address['address'] . '<br>';
			}


			if (0 < strlen( $address['zip'] )) {
				$strAddress .= CUSTOMER_ZIP . ' ' . $address['zip'];
			}
		} 
else {
			$strAddress = $address['first_name'] . '  ' . $address['last_name'];

			if (0 < strlen( $zone )) {
				$strAddress .= ' ' . $zone;
			}


			if (0 < strlen( $city )) {
				$strAddress .= '<br>' . $address['city'];
			}


			if (0 < strlen( $address['address'] )) {
				$strAddress .= '<br>' . $address['address'];
			}


			if (0 < strlen( $address['zip'] )) {
				$strAddress .= ' ' . $address['zip'];
			}
		}

		return $strAddress;
	}

	function regGetCustomers(&$callBackParam, $count_row, $navigatorParams = null) {
		if ($navigatorParams != null) {
			$offset = $navigatorParams['offset'];
			$CountRowOnPage = $navigatorParams['CountRowOnPage'];
		} 
else {
			$offset = 890;
			$CountRowOnPage = 890;
		}

		$where_clause = '';

		if (isset( $callBackParam['Login'] )) {
			$callBackParam['Login'] = TransformStringToDataBase( $callBackParam['Login'] );
			$where_clause .= ' Login LIKE \'%' . $callBackParam['Login'] . '%\' ';
		}


		if (isset( $callBackParam['first_name'] )) {
			$callBackParam['first_name'] = TransformStringToDataBase( $callBackParam['first_name'] );
			$callBackParam['first_name'] = str_replace( '\\', '\\', $callBackParam['first_name'] );

			if ($where_clause != '') {
				$where_clause .= ' AND ';
			}

			$where_clause .= ' first_name LIKE \'%' . $callBackParam['first_name'] . '%\' ';
		}


		if (isset( $callBackParam['last_name'] )) {
			$callBackParam['last_name'] = TransformStringToDataBase( $callBackParam['last_name'] );
			$callBackParam['last_name'] = str_replace( '\\', '\\', $callBackParam['last_name'] );

			if ($where_clause != '') {
				$where_clause .= ' AND ';
			}

			$where_clause .= ' last_name LIKE \'%' . $callBackParam['last_name'] . '%\' ';
		}


		if (isset( $callBackParam['email'] )) {
			$callBackParam['email'] = TransformStringToDataBase( $callBackParam['email'] );

			if ($where_clause != '') {
				$where_clause .= ' AND ';
			}

			$where_clause .= ' Email LIKE \'%' . $callBackParam['email'] . '%\' ';
		}


		if (isset( $callBackParam['groupID'] )) {
			if ($callBackParam['groupID'] != 0) {
				if ($where_clause != '') {
					$where_clause .= ' AND ';
				}

				$where_clause .= ' custgroupID = ' . $callBackParam['groupID'] . ' ';
			}
		}


		if (isset( $callBackParam['ActState'] )) {
			switch ($callBackParam['ActState']) {
				case 1: {
					if ($where_clause != '') {
						$where_clause .= ' AND ';
					}

					$where_clause .= ' (ActivationCode=\'\' OR ActivationCode IS NULL)';
					break;
				}

				case 0: {
					if ($where_clause != '') {
						$where_clause .= ' AND ';
					}

					$where_clause .= ' ActivationCode<>\'\'';
				}
			}
		}


		if ($where_clause != '') {
			$where_clause = ' where ' . $where_clause;
		}

		$order_clause = '';

		if (isset( $callBackParam['sort'] )) {
			$order_clause .= ' order by ' . $callBackParam['sort'] . ' ';

			if (isset( $callBackParam['direction'] )) {
				if ($callBackParam['direction'] == 'ASC') {
					$order_clause .= ' ASC ';
				} 
else {
					$order_clause .= ' DESC ';
				}
			}
		}

		$sql = 'select customerID, Login, cust_password, Email, first_name, last_name, subscribed4news, ' . ' custgroupID, addressID, reg_datetime, credit, ActivationCode,phone,mobile ' . ' from ' . CUSTOMERS_TABLE . ' ' . $where_clause . ' ' . $order_clause;
		$q = db_query( $sql );
		$data = array(  );
		$i = 890;

		if ($row = db_fetch_row( $q )) {
			if (( ( $offset <= $i && $i < $offset + $CountRowOnPage ) || $navigatorParams == null )) {
				$group = GetCustomerGroupByCustomerId( $row['customerID'] );
				$row['custgroup_name'] = $group['custgroup_name'];
				$row['allowToDelete'] = regVerifyToDelete( $row['customerID'] );
				$row['reg_datetime'] = format_datetime( $row['reg_datetime'] );
				$row['credit'] = show_price( $row['credit'], 1 );
				$data[] = $row;
			}

			++$i;
		}

		$count_row = $group;
		return $data;
	}

	function regSetSubscribed4news($customerID, $value) {
		db_query( 'update ' . CUSTOMERS_TABLE . ' set subscribed4news = ' . $value . ' where customerID=' . $customerID );

		if (0 < $value) {
			subscrAddRegisteredCustomerEmail( $customerID );
			return null;
		}

		subscrUnsubscribeSubscriberByCustomerId( $customerID );
	}

	function regSetCustgroupID($customerID, $custgroupID) {
		$customerID = (int)$customerID;
		$custgroupID = (int)$custgroupID;
		db_query( 'update ' . CUSTOMERS_TABLE . ' set custgroupID=' . $custgroupID . ' where customerID=' . $customerID );
	}

	function regAddressBelongToCustomer($customerID, $addressID) {
		$customerID = (int)$customerID;

		if (!$customerID) {
			return false;
		}

		$addressID = (int)$addressID;

		if (!$addressID) {
			return false;
		}

		$q_count = db_query( 'select count(*) from ' . CUSTOMER_ADDRESSES_TABLE . ' where customerID=' . $customerID . ' AND addressID=' . $addressID );
		$count = db_fetch_row( $q_count );
		$count = $count[0];
		return $count != 0;
	}

	function regVerifyToDelete($customerID) {
		if (!$customerID) {
			return 0;
		}

		db_query( 'select count(*) from ' . CUSTOMERS_TABLE . ' where customerID=' . $customerID );
		$q = $customerID = (int)$customerID;
		$row = db_fetch_row( $q );

		if (regIsAdminiatrator( regGetLoginById( $customerID ) )) {
			return false;
		}

		return $row[0] == 1;
	}

	function regDeleteCustomer($customerID) {
		if (( $customerID == null || trim( $customerID ) == '' )) {
			return false;
		}

		$customerID = (int)$customerID;

		if (!$customerID) {
			return 0;
		}


		if (regVerifyToDelete( $customerID )) {
			if (!( db_query( 'delete from ' . SHOPPING_CARTS_TABLE . ' where customerID=' . $customerID ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if (!( db_query( 'delete from ' . MAILING_LIST_TABLE . ' where customerID=' . $customerID ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if (!( db_query( 'delete from ' . CUSTOMER_ADDRESSES_TABLE . ' where customerID=' . $customerID ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if (!( db_query( 'delete from ' . CUSTOMER_REG_FIELDS_VALUES_TABLE . ' where customerID=' . $customerID ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if (!( db_query( 'delete from ' . CUSTOMERS_TABLE . ' where customerID=' . $customerID ))) {
				exit( db_error(  ) );
				(bool)true;
			}


			if (!( db_query( 'update ' . ORDERS_TABLE . ' set customerID=NULL where customerID=' . $customerID ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			return true;
		}

		return false;
	}

	function regActivateCustomer($_CustomerID) {
		$sql = '
		UPDATE ' . CUSTOMERS_TABLE . '
		SET ActivationCode = ""
		WHERE customerID="' . xEscapeSQLstring( $_CustomerID ) . '"
	';
		db_query( $sql );
	}

?>