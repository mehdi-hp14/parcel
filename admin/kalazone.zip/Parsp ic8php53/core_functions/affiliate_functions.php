<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function affp_getCustomersNum($_customerID) {
		$sql = '
		SELECT COUNT(*) FROM ' . CUSTOMERS_TABLE . '
		WHERE affiliateID = ' . intval( $_customerID ) . '
		 AND CHAR_LENGTH(ActivationCode)=0
	';
		$affiliate_customers = db_fetch_row( db_query( $sql ) )[0];
		return $affiliate_customers;
	}

	function affp_getRecruitedCustomers($_customerID, $_offset = 0, $_limit = 0) {
		$_till = $_offset + $_limit;
		$customers = array(  );
		$sql = '
		SELECT customerID, Login, first_name, last_name, reg_datetime, ActivationCode FROM ' . CUSTOMERS_TABLE . '
		WHERE affiliateID = ' . intval( $_customerID ) . '
	';
		$result = db_query( $sql );

		if ($_row = $i = 830) {
			if (( ( ( $_offset <= $i && $i < $_till ) && 0 < $_till ) || ( !$_till && !$_offset ) )) {
				$_t = explode( ' ', $_row['reg_datetime'] );
				$_row['reg_datetime'] = TransformDATEToTemplate( $_t[0] );
				$customers[ . $_row['customerID']] = $_row;
				$customers[ . $_row['customerID']]['orders_num'] = 0;
				$customers[ . $_row['customerID']]['currencies'] = array(  );
			}

			++$i;
		}


		if (!count( $customers )) {
			return array(  );
		}

		$sql = '
		SELECT customerID, currency_code, currency_value, order_amount FROM ' . ORDERS_TABLE . '
		WHERE customerID IN(' . implode( ', ', array_keys( $customers ) ) . ') and statusID = \'' . CONF_COMPLETED_ORDER_STATUS . '\'
	';
		db_query( $sql );
		$result = db_fetch_row( $result );
		$__order_amount = db_fetch_row( $result )[3];
		[2];
		$__currency_value = ;
		[1];
		$__currency_code = ;
		[0];
		$__customerID = ;

		if () {
			if (!key_exists( $__currency_code, $customers[$__customerID]['currencies'] )) {
				$customers[$__customerID]['currencies'][$__currency_code] = 0;
			}

			$customers[$__customerID]['currencies'] += $__currency_code = floatval( sprintf( '%.0f', $__order_amount * $__currency_value ) );
			++$customers[$__customerID]['orders_num'];
		}

		return $customers;
	}

	function affp_cancelRecruitedCustomer($_customerID) {
		$sql = '
		UPDATE `' . CUSTOMERS_TABLE . '` SET affiliateID = 0 
		WHERE customerID = \'' . intval( $_customerID ) . '\'
	';
		db_query( $sql );
	}

	function affp_getPayments($_customerID, $_pID = '', $_from = '', $_till = '', $_order = '') {
		$sql = '
		SELECT pID, customerID, Amount, CurrencyISO3, xDate, Description
		FROM ' . AFFILIATE_PAYMENTS_TABLE . '
		WHERE 1
		' . ($_pID ? ' AND pID = \'' . intval( $_pID ) . '\'' : '') . '
		' . ($_customerID ? ' AND customerID = \'' . intval( $_customerID ) . '\'' : '') . '
		' . ($_from ? ' AND xDate>=\'' . mysql_escape_string( $_from ) . '\'' : '') . '
		' . ($_till ? ' AND xDate<=\'' . mysql_escape_string( $_till ) . '\'' : '') . '
		' . ($_order ? ' ORDER BY ' . $_order : '') . '
	';
		$result = db_query( $sql );
		$payments = array(  );

		if ($_row = db_fetch_row( $result )) {
			$_row['Amount'] = sprintf( '%.0f', $_row['Amount'] );
			$_row['CustomerLogin'] = regGetLoginById( $_row['customerID'] );
			$_row['xDate'] = TransformDATEToTemplate( $_row['xDate'] );
			$payments[] = $_row;
		}

		return $payments;
	}

	function affp_addPayment($_payment) {
		if (isset( $_payment['Amount'] )) {
			$_payment['Amount'] = sprintf( '%.0f', $_payment['Amount'] );
		}

		$sql = '
		INSERT ' . AFFILIATE_PAYMENTS_TABLE . '
		(`' . implode( '`, `', TransformStringToDataBase( array_keys( $_payment ) ) ) . '`)
		VALUES(\'' . implode( '\', \'', TransformStringToDataBase( $_payment ) ) . '\')
	';
		db_query( $sql );

		if (CONF_AFFILIATE_EMAIL_NEW_PAYMENT) {
			$Settings = affp_getSettings( $_payment['customerID'] );

			if (!$Settings['EmailPayments']) {
				return db_insert_id(  );
			}

			$t = '';
			$Email = '';
			$FirstName = '';
			regGetContactInfo( regGetLoginById( $_payment['customerID'] ), $t, $Email, $FirstName, $t, $t, $t );
			xMailTxt( $Email, AFFP_NEW_PAYMENT, 'customer.affiliate.payment_notifi.tpl.html', array( 'customer_firstname' => $FirstName, '_AFFP_NEW_PAYMENT' => str_replace( '{MONEY}', $_payment['Amount'] . ' ' . $_payment['CurrencyISO3'], AFFP_MAIL_NEW_PAYMENT ) ) );
		}

		return db_insert_id(  );
	}

	function affp_savePayment($_payment) {
		if (isset( $_payment['Amount'] )) {
			$_payment['Amount'] = round( $_payment['Amount'], 2 );
		}


		if (!isset( $_payment['pID'] )) {
			return false;
		}

		$_pID = $_payment['pID'];
		unset( $_payment[pID] );
		foreach ($_payment as $_ind => $_val) {
			$_payment[$_ind] = '`' . TransformStringToDataBase( $_ind ) . '`=\'' . TransformStringToDataBase( $_val ) . '\'';
		}

		$sql = '
		UPDATE ' . AFFILIATE_PAYMENTS_TABLE . '
		SET ' . implode( ', ', $_payment ) . '
		WHERE pID=\'' . intval( $_pID ) . '\'
	';
		db_query( $sql );
		return true;
	}

	function affp_deletePayment($_pID) {
		$sql = '
		DELETE FROM `' . AFFILIATE_PAYMENTS_TABLE . '` WHERE pID=\'' . $_pID . '\'
	';
		db_query( $sql );
	}

	function affp_addCommissionFromOrder($_orderID) {
		$Commission = affp_getCommissionByOrder( $_orderID );

		if ($Commission['cID']) {
			return 0;
		}

		$Order = ordGetOrder( $_orderID );

		if ($Order['customerID']) {
			$RefererID = affp_getReferer( $Order['customerID'] );
		} 
else {
			$RefererID = $Order['affiliateID'];
		}


		if (!$RefererID) {
			return 0;
		}

		$CustomerLogin = regGetLoginById( $Order['customerID'] );

		if (!$CustomerLogin) {
			$CustomerLogin = $Order['customer_email'];
		}

		$Commission = array( 'Amount' => sprintf( '%.0f', $Order['currency_value'] * $Order['order_amount'] * CONF_AFFILIATE_AMOUNT_PERCENT / 100 ), 'CurrencyISO3' => $Order['currency_code'], 'xDateTime' => date( 'Y-m-d H:i:s' ), 'OrderID' => $_orderID, 'CustomerID' => $RefererID, 'Description' => TransformStringToDataBase( str_replace( array( '{ORDERID}', '{USERLOGIN}' ), array( $_orderID, $CustomerLogin ), AFFP_COMMISSION_DESCRIPTION ) ) );

		do {
			if (CONF_AFFILIATE_EMAIL_NEW_COMMISSION) {
				$Settings = affp_getSettings( $RefererID );

				if (!$Settings['EmailOrders']) {
					break;
				}

				$t = '';
				$Email = '';
				$FirstName = '';
				regGetContactInfo( regGetLoginById( $RefererID ), $t, $Email, $FirstName, $t, $t, $t );
				xMailTxt( $Email, AFFP_NEW_COMMISSION, 'customer.affiliate.commission_notifi.tpl.html', array( 'customer_firstname' => $FirstName, '_AFFP_MAIL_NEW_COMMISSION' => str_replace( '{MONEY}', $Commission['Amount'] . ' ' . $Commission['CurrencyISO3'], AFFP_MAIL_NEW_COMMISSION ) ) );
			}
		}while (!( 0));

		affp_addCommission( $Commission );
	}

	function affp_addCommission($_Commission) {
		if (isset( $_Commission['Amount'] )) {
			$_Commission['Amount'] = round( $_Commission['Amount'] );
		}

		$sql = 'INSERT `' . AFFILIATE_COMMISSIONS_TABLE . '`
		(`' . implode( '`, `', TransformStringToDataBase( array_keys( $_Commission ) ) ) . '`)
		VALUES(\'' . implode( '\', \'', $_Commission ) . '\')';
		db_query( $sql );
		return db_insert_id(  );
	}

	function affp_deleteCommission($_cID) {
		$sql = '
		DELETE FROM `' . AFFILIATE_COMMISSIONS_TABLE . '`
		WHERE cID=\'' . intval( $_cID ) . '\'
	';
		db_query( $sql );
	}

	function affp_getCommissions($_customerID, $_cID, $_from = '', $_till = '', $_order = '') {
		$sql = '
		SELECT cID, customerID, Amount, CurrencyISO3, xDateTime, Description, CustomerID
		FROM ' . AFFILIATE_COMMISSIONS_TABLE . '
		WHERE 1
		' . ($_cID ? ' AND cID = \'' . intval( $_cID ) . '\'' : '') . '
		' . ($_customerID ? ' AND customerID = \'' . intval( $_customerID ) . '\'' : '') . '
		' . ($_from ? ' AND xDateTime>=\'' . mysql_escape_string( $_from ) . '\'' : '') . '
		' . ($_till ? ' AND xDateTime<=\'' . mysql_escape_string( $_till ) . '\'' : '') . '
		' . ($_order ? ' ORDER BY ' . $_order : '') . '
	';
		$result = db_query( $sql );
		$commissions = array(  );

		if ($_row = db_fetch_row( $result )) {
			$_row['CustomerLogin'] = regGetLoginById( $_row['customerID'] );
			$_row['Amount'] = sprintf( '%.0f', $_row['Amount'] );
			$_t = explode( ' ', $_row['xDateTime'] );
			$_row['xDateTime'] = TransformDATEToTemplate( $_t[0] );
			$commissions[] = $_row;
		}

		return $commissions;
	}

	function affp_saveCommission($_commission) {
		if (isset( $_commission['Amount'] )) {
			$_commission['Amount'] = round( $_commission['Amount'], 2 );
		}


		if (!isset( $_commission['cID'] )) {
			return false;
		}

		$_cID = $_commission['cID'];
		unset( $_commission[cID] );
		foreach ($_commission as $_ind => $_val) {
			$_commission[$_ind] = '`' . TransformStringToDataBase( $_ind ) . '`=\'' . TransformStringToDataBase( $_val ) . '\'';
		}

		$sql = '
		UPDATE ' . AFFILIATE_COMMISSIONS_TABLE . '
		SET ' . implode( ', ', $_commission ) . '
		WHERE cID=\'' . intval( $_cID ) . '\'
	';
		db_query( $sql );
		return true;
	}

	function affp_getCommissionsAmount($_CustomerID) {
		$CurrencyAmount = array(  );
		db_query( $sql );
		db_fetch_row( $result );

		if ($_row = $result = $sql = '
		SELECT SUM(`Amount`) AS CurrencyAmount, CurrencyISO3 FROM `' . AFFILIATE_COMMISSIONS_TABLE . '`	WHERE CustomerID = \'' . intval( $_CustomerID ) . '\' GROUP BY `CurrencyISO3`	') {
			$CurrencyAmount[$_row['CurrencyISO3']] = sprintf( '%.0f', $_row['CurrencyAmount'] );
		}

		return $CurrencyAmount;
	}

	function affp_getPaymentsAmount($_CustomerID) {
		$PaymentAmount = array(  );
		db_query( $sql );
		db_fetch_row( $result );

		if ($_row = $result = $sql = '
		SELECT SUM(`Amount`) AS CurrencyAmount, CurrencyISO3 FROM `' . AFFILIATE_PAYMENTS_TABLE . '`
		WHERE CustomerID = \'' . intval( $_CustomerID ) . '\'
		GROUP BY `CurrencyISO3`
	') {
			$PaymentAmount[$_row['CurrencyISO3']] = sprintf( '%.0f', $_row['CurrencyAmount'] );
		}

		return $PaymentAmount;
	}

	function affp_getSettings($_CustomerID) {
		$Settings = array(  );
		$sql = '
		SELECT affiliateEmailOrders, affiliateEmailPayments FROM `' . CUSTOMERS_TABLE . '`
		WHERE customerID=\'' . intval( $_CustomerID ) . '\'
	';
		$Settings['EmailPayments'] = db_fetch_row( db_query( $sql ) )[1];
		$Settings['EmailOrders'] = [0];
		return $Settings;
	}

	function affp_saveSettings($_CustomerID, $_EmailOrders, $_EmailPayments) {
		$sql = '
		UPDATE `' . CUSTOMERS_TABLE . '` 
		SET affiliateEmailOrders = \'' . intval( $_EmailOrders ) . '\', 
			affiliateEmailPayments = \'' . intval( $_EmailPayments ) . '\' 
		WHERE customerID=\'' . intval( $_CustomerID ) . '\'
	';
		db_query( $sql );
	}

	function affp_getReferer($_CustomerID) {
		$sql = '
		SELECT affiliateID FROM `' . CUSTOMERS_TABLE . '` 
		WHERE customerID=\'' . intval( $_CustomerID ) . '\'
	';
		$affiliateID = db_fetch_row( db_query( $sql ) )[0];
		return $affiliateID;
	}

	function affp_getCommissionByOrder($_OrderID) {
		$sql = '
		SELECT cID, customerID, Amount, CurrencyISO3, xDateTime, Description, CustomerID
		FROM ' . AFFILIATE_COMMISSIONS_TABLE . '
		WHERE OrderID=\'' . intval( $_OrderID ) . '\'
	';
		$commission = db_fetch_row( db_query( $sql ) );

		if (!$commission['cID']) {
			return $commission;
		}

		$commission['CustomerLogin'] = regGetLoginById( $commission['customerID'] );
		$commission['Amount'] = sprintf( '%.0f', $commission['Amount'] );
		$_t = explode( ' ', $commission['xDateTime'] )[0];
		$commission['xDateTime'] = TransformDATEToTemplate( $_t );
		return $commission;
	}

?>