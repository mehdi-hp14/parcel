<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function ZoneBelongsToCountry($zoneID, $country_iso_2) {
		$q = db_query( 'select count(*) from ' . ZONES_TABLE . ( ' where country_iso_2=\'' . $country_iso_2 . '\'' ) );
		$row = db_fetch_row( $q );

		if ($row[0] != 0) {
			if (trim( $zoneID ) == (bool)(int)$zoneID) {
				$q = db_query( 'select count(*) from ' . ZONES_TABLE . ( ' where country_iso_2=\'' . $country_iso_2 . '\' AND zoneID=' . $zoneID ) );
				$row = db_fetch_row( $q );
				return $row[0] != 0;
			}

			return false;
		}

		return true;
	}

	function znGetZones($country_iso_2 = null) {
		if ($country_iso_2 == null) {
			$q = db_query( 'select *,' . LanguagesManager::sql_constractSortField( ZONES_TABLE, 'zone_name' ) . ' from ' . ZONES_TABLE . ' ' . ' order by _zone_name_sort ' );
		} 
else {
			$q = db_query( 'select *,' . LanguagesManager::sql_constractSortField( ZONES_TABLE, 'zone_name' ) . ' from ' . ZONES_TABLE . ' ' . ( ' where country_iso_2=\'' . $country_iso_2 . '\' order by _zone_name_sort' ) );
		}

		$data = array(  );

		if ($r = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( ZONES_TABLE, $r );
			$data[] = $r;
		}

		return $data;
	}

	function znGetZonesById($country_iso_2) {
		if (( is_null( $country_iso_2 ) || $country_iso_2 == '' )) {
			$country_iso_2 = 'NULL';
		}

		$q = db_query( 'select zoneID,' . LanguagesManager::sql_prepareField( 'zone_name' ) . ' as zone_name, zone_code, country_iso_2 from ' . ZONES_TABLE . ' where country_iso_2=\'' . $country_iso_2 . '\' order by zone_name ' );
		$data = array(  );

		if ($r = db_fetch_row( $q )) {
			$data[] = $r;
		}

		return $data;
	}

	function znGetSingleZoneById($zoneID) {
		if (( is_null( $zoneID ) || $zoneID == '' )) {
			$zoneID = 'NULL';
		}

		$q = db_query( 'select *,' . LanguagesManager::sql_prepareField( 'zone_name' ) . ' as zone_name from ' . ZONES_TABLE . ' ' . ( ' where zoneID=' . $zoneID . ' ' ) );
		$r = db_fetch_row( $q );
		return $r;
	}

	function znDeleteZone($zoneID) {
		$tax_classes = taxGetTaxClasses(  );
		foreach ($tax_classes as $class) {
			taxDeleteZoneRate( $class['classID'], $zoneID );
		}

		db_query( 'update ' . CUSTOMER_ADDRESSES_TABLE . ' set zoneID=NULL where zoneID=\'' . $zoneID . '\'' );
		db_query( 'delete from ' . ZONES_TABLE . ' where zoneID=\'' . $zoneID . '\'' );
	}

	function znUpdateZone($zoneID, $zone, $zone_code, $country_iso_2) {
		$zone_code = TransformStringToDataBase( $zone_code );
		db_query( 'update ' . ZONES_TABLE . ' set  ' . LanguagesManager::sql_prepareFieldUpdate( 'zone_name', $zone ) . ',' . '  zone_code=\'' . $zone_code . '\\', ' . '  country_iso_2=\'' . $country_iso_2 . '\' ' . '  where zoneID=\'' . $zoneID . '\'' );
	}

	function znAddZone($val, $zone_code, $country_iso_2) {
		foreach ($val as $key => $value) {
			$key = str_replace( 'new_', '', $key );
			$val[$key] = $value;
		}

		$name_inj = LanguagesManager::sql_prepareFieldInsert( 'zone_name', $val );
		$zone_code = TransformStringToDataBase( $zone_code );
		db_query( 'insert into ' . ZONES_TABLE . '( ' . $name_inj['fields'] . ', zone_code, country_iso_2 )' . 'values( ' . $name_inj['values'] . ', \'' . $zone_code . '\', \'' . $country_iso_2 . '\' )' );
		return db_insert_id(  );
	}

?>