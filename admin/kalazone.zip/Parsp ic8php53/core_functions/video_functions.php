<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function GetVideos($productID) {
		$q = db_query( $sql );
		$q2 = db_query( 'select default_video from ' . PRODUCTS_TABLE . ' where productID = ' . $productID );
		$product = db_fetch_row( $q2 );
		$product[0];
		$default_video = $sql = 'select videoID, productID, filename from ' . PRODUCT_VIDEOS . ' where productID = ' . $productID;
		$res = array(  );

		if ($row = db_fetch_row( $q )) {
			if ((bool)$row['videoID'] == (bool)$default_video) {
				$row['default_video'] = 1;
			} 
else {
				$row['default_video'] = 0;
			}

			$res[] = $row;
		}

		return $res;
	}

		$q = function DeleteThreeVideos($videoID) {;
		db_fetch_row( $q );

		if ($video = db_query( 'select filename, productID from ' . PRODUCT_VIDEOS . ' where videoID=' . $videoID )) {
			if (( $video['filename'] != '' && $video['filename'] != null )) {
				if (file_exists( './uploads/products_videos/' . $video['filename'] )) {
					unlink( './uploads/products_videos/' . $video['filename'] );
				}
			}

			$q1 = ;
			db_fetch_row( $q1 );

			if ($product = db_query( 'select default_video from ' . PRODUCTS_TABLE . ' where productID=' . $video['productID'] )) {
				if ($product['default_video'] == $videoID) {
					db_query( 'update ' . PRODUCTS_TABLE . ' set default_video=NULL ' . ' where productID=' . $_GET['productID'] );
				}
			}

			db_query( 'delete from ' . PRODUCT_VIDEOS . ' where videoID=' . $videoID );
		}

	}

		$q = function DeleteFilenameVideo($videoID) {;
		db_fetch_row( $q );

		if ($filename = db_query( 'select filename from ' . PRODUCT_VIDEOS . ' where videoID=' . $videoID )) {
			if (file_exists( './uploads/products_videos/' . $filename['filename'] )) {
				unlink( './uploads/products_videos/' . $filename['filename'] );
			}

			db_query( 'delete from ' . PRODUCT_VIDEOS . ' where videoID=' . $videoID );
		}

	}

	function DeleteThumbnailVideo($videoID) {
		$q = db_query( 'select thumbnail from ' . PRODUCT_VIDEOS . ' where videoID=' . $videoID );

		if ($thumbnail = db_fetch_row( $q )) {
			if (file_exists( './uploads/products_videos/' . $thumbnail['thumbnail'] )) {
				unlink( './uploads/products_videos/' . $thumbnail['thumbnail'] );
			}

			db_query( 'update ' . PRODUCT_VIDEOS . ' set thumbnail=\'\'' . ' where videoID=' . $videoID );
		}

	}

	function UpdateVideos($productID, $fileNames, $default_video) {
		foreach ($fileNames as $key => $value) {
			db_query( 'update ' . PRODUCT_VIDEOS . ' set ' . '	filename=\'' . $value['filename'] . '\',  ' . 'where videoID=' . $key );
		}


		if ($default_video != -1) {
			db_query( 'update ' . PRODUCTS_TABLE . ' set default_video = ' . $default_video . ' where productID=\'' . $productID . '\'' );
		}

	}

	function AddNewVideos($productID, $filename, $default_video) {
		if (CONF_CHANGE_IMAGESIZE == 1) {
			if (trim( $_FILES[$filename]['name'] ) != '') {
				$new_filename = '';
				$tmp = $_FILES[$filename]['tmp_name'];
				$r = false;

				if (( $_FILES[$filename]['size'] != 0 && preg_match( '/\.(3gp|mp4|fla|flv|m4a|mov)$/i', $_FILES[$filename]['name'] ) )) {
					$r = move_uploaded_file( $tmp, './uploads/products_videos/' . $_FILES[$filename]['name'] );
				}


				if ($r) {
					copy( './uploads/products_videos/' . $_FILES[$filename]['name'], './uploads/products_videos/medium_' . $_FILES[$filename]['name'] );
					$new_filename = 'medium_' . $_FILES[$filename]['name'];
					SetRightsToUploadedFile( './uploads/products_videos/medium_' . $new_filename );
					unlink( './uploads/products_videos/' . $_FILES[$filename]['name'] );
				}


				if ($new_filename != '') {
					db_query( 'insert into ' . PRODUCT_VIDEOS . '(productID, filename)' . '		values( ' . $productID . ', ' . ' \'' . $new_filename . '\' ) ' );

					if ($default_video == -1) {
						$default_videoID = db_insert_id(  );
						db_query( 'update ' . PRODUCTS_TABLE . ' set default_video = ' . $default_videoID . ' where productID=\'' . $productID . '\'' );
						return null;
					}
				}
			}
		} 
else {
			if (trim( $_FILES[$filename]['name'] ) != '') {
				$new_filename = '';
				$r = false;

				if (( $_FILES[$filename]['size'] != 0 && preg_match( '/\.(3gp|mp4|fla|flv|m4a|mov)$/i', $_FILES[$filename]['name'] ) )) {
					$r = move_uploaded_file( $_FILES[$filename]['tmp_name'], './uploads/products_videos/' . $_FILES[$filename]['name'] );
				}


				if ($r) {
					$new_filename = $_FILES[$filename]['name'];
					SetRightsToUploadedFile( './uploads/products_videos/' . $new_filename );
				}


				if ($new_filename != '') {
					db_query( 'insert into ' . PRODUCT_VIDEOS . '(productID, filename)' . '		values( ' . $productID . ', ' . ' \'' . $new_filename . '\' ) ' );

					if ($default_video == -1) {
						$default_videoID = db_insert_id(  );
						db_query( 'update ' . PRODUCTS_TABLE . ' set default_video = ' . $default_videoID . ' where productID=\'' . $productID . '\'' );
					}
				}
			}
		}

	}

	function GetVideoCount($productID) {
		$count_pict = db_query( 'select COUNT(videoID) from ' . PRODUCT_VIDEOS . ' where productID=' . $productID . ' ' . 'AND filename!=\'\'' );
		$count_pict_row = db_fetch_row( $count_pict );
		return $count_pict_row[0];
	}

?>