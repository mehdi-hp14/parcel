<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function stGetCustomerIP_Address() {
		return $_SERVER['REMOTE_ADDR'];
	}

	function stAddCustomerLog($log) {
		$customerID = regGetIdByLogin( $log );

		if ($customerID != null) {
			$ipAddress = $_SERVER['REMOTE_ADDR'];
			db_query( ' insert into ' . CUSTOMER_LOG_TABLE . '  (customerID, customer_ip, customer_logtime) ' . ( '  values( ' . $customerID . ', \'' . $ipAddress . '\', \'' ) . get_current_time(  ) . '\' ) ' );
		}

	}

	function stGetCustomerLogReport($groupid = 0) {
		if ($groupid == 0) {
			$groupcond = '';
		} 
else {
			$groupcond = ' and custgroupID=' . $groupid;
		}

		$q = ;
		$data = array(  );
		db_fetch_row( $q );

		if ($row = db_query( 'select * from ' . CUSTOMER_LOG_TABLE . ',' . CUSTOMERS_TABLE . ' where ' . CUSTOMER_LOG_TABLE . '.customerID =' . CUSTOMERS_TABLE . '.customerID ' . $groupcond )) {
			$row['customer_logtime'] = format_datetime( $row['customer_logtime'] );
			$row['login'] = $row['Login'];
			$data[] = $row;
		}

		return $data;
	}

	function stGetLastVists($log) {
		regGetIdByLogin( $log );
		$q = db_query( 'select customer_logtime from ' . CUSTOMER_LOG_TABLE . ( ' where customerID=' . $customerID . ' order by customer_logtime DESC' ) );
		$data = array(  );
		$i = 725;

		if ($row = $customerID = db_fetch_row( $q )) {
			if ($i <= 20) {
				$data[] = $row;
			}

			break;
		}

		return array_reverse( $data );
	}

	function stGetVisitsByLogin(&$callBackParam, $count_row, $navigatorParams = null) {
		if ($navigatorParams != null) {
			$offset = $navigatorParams['offset'];
			$CountRowOnPage = $navigatorParams['CountRowOnPage'];
		} 
else {
			$offset = 749;
			$CountRowOnPage = 749;
		}

		$customerID = regGetIdByLogin( $callBackParam['log'] );
		$q = db_query( 'select customer_logtime, customer_ip from ' . CUSTOMER_LOG_TABLE . ( ' where customerID=' . $customerID . ' order by customer_logtime DESC' ) );
		$data = array(  );
		$i = 749;

		if ($row = db_fetch_row( $q )) {
			if (( ( $offset <= $i && $i < $offset + $CountRowOnPage ) || $navigatorParams == null )) {
				$row['customer_logtime'] = format_datetime( $row['customer_logtime'] );
				$data[] = $row;
			}

			++$i;
		}

		$count_row = $navigatorParams;
		return $data;
	}

		$customerID = function stGetVisitsCount($log) {;
		$q = db_query( 'select count(*) customer_logtime from ' . CUSTOMER_LOG_TABLE . ( ' where customerID=' . $customerID ) );
		db_fetch_row( $q );
		$row = regGetIdByLogin( $log );
		return $row[0];
	}

	function stClearCustomerLogReport() {
		if ($groupid == 0) {
			$groupcond = '';
		} 
else {
			$groupcond = ' where customerID  IN (select customerID from ' . CUSTOMERs_TABLE . ' where custgroupID=' . $groupid;
		}

		db_query( 'delete from ' . CUSTOMER_LOG_TABLE . $groupcond );
	}

	function stChangeOrderStatus($orderID, $statusID, $comment = '', $notify = 0) {
		$q_status_name = db_query( 'select ' . LanguagesManager::sql_prepareField( 'status_name' ) . ' as status_name from ' . ORDER_STATUES_TABLE . ( ' where statusID=' . $statusID . ' ' ) );
		$status_name = db_fetch_row( $q_status_name )[0];
		$sql = 'insert into ' . ORDER_STATUS_CHANGE_LOG_TABLE . ' ( orderID, status_name, status_change_time, status_comment ) ' . ' values( ' . $orderID . ', \'' . mysql_escape_string( $status_name ) . '\', \'' . get_current_time(  ) . '\', \'' . TransformStringToDataBase( $comment ) . '\' ) ';
		db_query( $sql );

		if ($notify) {
			$Order = ordGetOrder( $orderID );
			$t = '';
			$Email = '';
			$FirstName = '';
			regGetContactInfo( regGetLoginById( $Order['customerID'] ), $t, $Email, $FirstName, $t, $t, $t );

			if (!$Email) {
				$Email = $Order['customer_email'];
			}


			if (!$FirstName) {
				$FirstName = $Order['customer_firstname'];
			}


			if (isset( $_POST['notify_customer'] )) {
				xMailTxt( $Email, mail2utf8( STRING_CHANGE_ORDER_STATUS ), 'customer.order.change_status.tpl.html', array( 'customer_firstname' => $FirstName, '_MSG_CHANGE_ORDER_STATUS' => str_replace( array( '{STATUS}', '{ORDERID}' ), array( ($status_name == 'STRING_CANCELED_ORDER_STATUS' ? STRING_CANCELED_ORDER_STATUS : $status_name), $orderID ), MSG_CHANGE_ORDER_STATUS ), '_ADMIN_COMMENT' => xStripSlashesGPC( $comment ) ) );
			}
		}

	}

		$q = function stGetOrderStatusReport($orderID) {;
		$data = array(  );
		db_fetch_row( $q );

		if ($row = db_query( 'select orderID, status_name, status_change_time, status_comment from ' . ORDER_STATUS_CHANGE_LOG_TABLE . ( ' where orderID=' . $orderID . ' ' ) )) {
			$row['status_change_time'] = format_datetime( $row['status_change_time'] );
			$data[] = $row;
		}

		return $data;
	}

	function IncrementProductViewedTimes($productID) {
		db_query( 'update ' . PRODUCTS_TABLE . ' set viewed_times=viewed_times+1 ' . ' where productID=\'' . $productID . '\'' );
	}

	function GetProductViewedTimes($productID) {
		$q = db_query( 'select viewed_times from ' . PRODUCTS_TABLE . ' where productID=\'' . $productID . '\'' );
		$r = db_fetch_query( $q );
		return $r['viewed_times'];
	}

	function GetProductViewedTimesReport($categoryID) {
		if ($categoryID != 0) {
			$q = db_query( 'select ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name, viewed_times from ' . PRODUCTS_TABLE . ' where categoryID=\'' . $categoryID . '\' order by viewed_times DESC ' );
		} 
else {
			$q = db_query( 'select ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name, viewed_times from ' . PRODUCTS_TABLE . ' order by viewed_times DESC ' );
		}

		$data = array(  );

		if ($r = db_fetch_row( $q )) {
			$row = array(  );
			$row['name'] = $r['name'];
			$row['viewed_times'] = $r['viewed_times'];
			$data[] = $row;
		}

		return $data;
	}

	function IncrementCategoryViewedTimes($categoryID) {
		db_query( 'update ' . CATEGORIES_TABLE . ' set viewed_times=viewed_times+1 ' . ' where categoryID=\'' . $categoryID . '\'' );
	}

	function GetCategoryViewedTimes($categoryID) {
		$q = db_query( 'select viewed_times from ' . CATEGORIES_TABLE . ' where categoryID=\'' . $categoryID . '\'' );
		$r = db_fetch_query( $q );
		return $r['viewed_times'];
	}

	function GetCategortyViewedTimesReport() {
		$q = db_query( 'select ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name, viewed_times from ' . CATEGORIES_TABLE . ' where categoryID!=1 order by viewed_times DESC' );
		$data = array(  );

		if ($r = db_fetch_row( $q )) {
			$row = array(  );

			if ($r['name'] != '') {
				$row['name'] = $r['name'];
				$row['viewed_times'] = $r['viewed_times'];
				$data[] = $row;
			}
		}

		return $data;
	}

?>