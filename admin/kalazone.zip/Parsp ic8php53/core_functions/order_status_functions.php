<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function ostInstall() {
		$langs = explode( ',', INSTALL_LANGS );
		$i = 743;
		$fname = '';
		foreach ($langs as $lang) {
			++$i;
			$fname .= ' status_name_' . $lang;

			if ($i < count( $langs )) {
				$fname .= ',';
				continue;
			}
		}

		$values = explode( ',', INSTALL_ORDER_STATUSES );
		foreach ($values as ) {
			++$i;
			$fvalue = $value = str_replace( ';', '\\',\'', $value );
			db_query( 'insert into ' . ORDER_STATUES_TABLE . ' ( ' . $fname . ', sort_order ) values( \'' . $fvalue . '\') ' );
		}

	}

	function ostGetCanceledStatusId() {
		return 1;
	}

	function _correctOrderStatusName($orderStatus) {
		if ($orderStatus['statusID'] == ostGetCanceledStatusId(  )) {
			$orderStatus['status_name'] = STRING_CANCELED_ORDER_STATUS;
		}

	}

	function ostGetOtherStatus($statusID) {
		$q = db_query( 'select statusID, ' . LanguagesManager::sql_prepareField( 'status_name' ) . ' as status_name, sort_order from ' . ORDER_STATUES_TABLE . ( ' where statusID<>' . $statusID . ' ' ) . ' AND statusID<>' . ostGetCanceledStatusId(  ) );

		if ($row = db_fetch_row( $q )) {
			_correctOrderStatusName( &$row );
			$row['status_name'] = html_spchars( TransformDataBaseStringToText( $row['status_name'] ) );
			return $row;
		}

		return false;
	}

	function ostGetNewOrderStatus() {
		if (defined( 'CONF_NEW_ORDER_STATUS' )) {
			$begin_status = CONF_NEW_ORDER_STATUS;
			$q = db_query( 'select count(*) from ' . ORDER_STATUES_TABLE . ' where statusID=' . $begin_status );
			$row = db_fetch_row( $q );

			if ($row[0]) {
				return $begin_status;
			}

			return null;
		}

	}

	function ostGetOrderStatusName($statusID) {
		$q = db_query( 'select ' . LanguagesManager::sql_prepareField( 'status_name' ) . ' as status_name from ' . ORDER_STATUES_TABLE . ( ' where statusID=' . $statusID ) );
		$row = db_fetch_row( $q );

		if ($statusID == ostGetCanceledStatusId(  )) {
			$row['status_name'] = STRING_CANCELED_ORDER_STATUS;
		}

		return $row['status_name'];
	}

	function ostGetCompletedOrderStatus() {
		if (defined( 'CONF_COMPLETED_ORDER_STATUS' )) {
			$end_status = CONF_COMPLETED_ORDER_STATUS;
			$q = db_query( 'select count(*) from ' . ORDER_STATUES_TABLE . ' where statusID=' . $end_status );
			$row = db_fetch_row( $q );

			if ($row[0]) {
				return $end_status;
			}

			return null;
		}

	}

	function ostGetOrderStatues($fullList = true, $format = 'just') {
		$data = array(  );

		if ($fullList) {
			$q = db_phquery( 'SELECT * FROM ?#ORDER_STATUES_TABLE WHERE statusID=?', ostGetCanceledStatusId(  ) );
			$row = db_fetch_assoc( $q );

			if (!isset( $row[LanguagesManager::sql_prepareField( 'status_name' )] )) {
				$row[LanguagesManager::sql_prepareField( 'status_name' )] = '';
			}

			$r = array( 'statusID' => $row['statusID'], 'status_name' => $row[LanguagesManager::sql_prepareField( 'status_name' )], 'sort_order' => $row['sort_order'] );
			_correctOrderStatusName( &$r );
			$data[] = $r;
		}

		db_phquery( '
		SELECT *, ' . LanguagesManager::sql_prepareField( 'status_name' ) . ' AS status_name FROM ?#ORDER_STATUES_TABLE
		$q = WHERE statusID!=? ORDER BY sort_order ASC, status_name ASC', ostGetCanceledStatusId(  ) );

		if ($r = db_fetch_assoc( $q )) {
			LanguagesManager::ml_fillFields( ORDER_STATUES_TABLE, $r );
			$data[] = $r;
		}

		jmp;
		switch ($format) {
			case 'just': {
				break;
			}

			case 'html': {
				$data = xHtmlSpecialChars( $data );
				break;
				return $data;
			}
		}
	}

	function ostAddOrderStatus($name, $sort_order) {
		foreach ($name as $key => $value) {
			$key = str_replace( 'new_', '', $key );
			$name[$key] = $value;
		}

		$name_inj = LanguagesManager::sql_prepareFieldInsert( 'status_name', $name );
		db_phquery( 'INSERT ?#ORDER_STATUES_TABLE (' . $name_inj['fields'] . ', sort_order) VALUES(' . $name_inj['values'] . ',?)', $sort_order );
		return db_insert_id(  );
	}

	function ostUpdateOrderStatus($statusID, $status_name, $sort_order) {
		db_phquery( '
		UPDATE ?#ORDER_STATUES_TABLE SET ' . LanguagesManager::sql_prepareFieldUpdate( 'status_name', $status_name ) . ',sort_order=? 
		WHERE statusID=?', $sort_order, $statusID );
	}

	function ostDeleteOrderStatus($statusID) {
		$q = db_query( 'select count(*) from ' . ORDERS_TABLE . ' where statusID=' . $statusID );
		$r = db_fetch_row( $q );

		if ($r[0] != 0) {
			return false;
		}

		db_query( 'delete from ' . ORDER_STATUES_TABLE . ( ' where statusID=' . $statusID ) );
		return true;
	}

	function _changeIn_stock($orderID, $increase) {
		if (!CONF_CHECKSTOCK) {
			return null;
		}

		$q = db_query( 'select itemID, Quantity from ' . ORDERED_CARTS_TABLE . ( ' where orderID=' . $orderID ) );

		if ($item = db_fetch_row( $q )) {
			$Quantity = $item['Quantity'];
			$q1 = db_query( 'select productID from ' . SHOPPING_CART_ITEMS_TABLE . ' where itemID=' . $item['itemID'] );
			$product = db_fetch_row( $q1 );

			if (( $product['productID'] != null && trim( $product['productID'] ) != '' )) {
				if ($increase) {
					db_query( 'update ' . PRODUCTS_TABLE . ( ' set in_stock=in_stock + ' . $Quantity . ' ' ) . ' where productID=' . $product['productID'] );
				}

				db_query( 'update ' . PRODUCTS_TABLE . ( ' set in_stock=in_stock - ' . $Quantity . ' ' ) . ' where productID=' . $product['productID'] );
			}
		}

	}

	function _changeSOLD_counter($orderID, $increase) {
		$q = db_query( 'select itemID, Quantity from ' . ORDERED_CARTS_TABLE . ( ' where orderID=' . $orderID ) );

		if ($item = db_fetch_row( $q )) {
			$Quantity = $item['Quantity'];
			$q1 = db_query( 'select * from ' . SHOPPING_CART_ITEMS_TABLE . ' where itemID=' . $item['itemID'] );
			$product = db_fetch_row( $q1 );

			if (( $product['productID'] != null && trim( $product['productID'] ) != '' )) {
				if ($increase) {
					db_query( 'update ' . PRODUCTS_TABLE . ( ' set items_sold=items_sold + ' . $Quantity . ' ' ) . ' where productID=' . $product['productID'] );
				}

				db_query( 'update ' . PRODUCTS_TABLE . ( ' set items_sold=items_sold - ' . $Quantity . ' ' ) . ' where productID=' . $product['productID'] );
			}
		}

	}

	function ostSetOrderStatusToOrder($orderID, $statusID, $comment = '', $notify = 0) {
		$q1 = db_query( 'select statusID from ' . ORDERS_TABLE . ( ' where orderID=' . $orderID ) );
		$row = db_fetch_row( $q1 );
		$pred_statusID = $row['statusID'];

		if ((int)$pred_statusID == (int)$statusID) {
			return null;
		}


		if ($statusID == CONF_COMPLETED_ORDER_STATUS) {
			require_once( './core_functions/affiliate_functions.php' );
			affp_addCommissionFromOrder( $orderID );
		}


		if (( $pred_statusID != ostGetCanceledStatusId(  ) && $statusID == ostGetCanceledStatusId(  ) )) {
			_changeIn_stock( $orderID, true );
		} 
else {
			if (( $pred_statusID == ostGetCanceledStatusId(  ) && $statusID != ostGetCanceledStatusId(  ) )) {
				_changeIn_stock( $orderID, false );
			}
		}


		if (( $pred_statusID != CONF_COMPLETED_ORDER_STATUS && $statusID == CONF_COMPLETED_ORDER_STATUS )) {
			if (CONF_ACCOUNTS_ENABLE == 1) {
				$pininfo = updateSend( $orderID, $pred_statusID );
			}

			_changeSOLD_counter( $orderID, true );
		}

		db_query( 'update ' . ORDERS_TABLE . ( ' set statusID=' . $statusID . ' ' ) . ( ' where orderID=' . $orderID ) );
		stChangeOrderStatus( $orderID, $statusID, $comment, $notify );

		if ($pininfo) {
			return $pininfo;
		}

	}

?>