<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function taxGetTaxClassById($classID) {
		$q = db_query( 'select classID, name, address_type from ' . TAX_CLASSES_TABLE . ( ' where classID=' . $classID ) );

		if ($row = db_fetch_row( $q )) {
			$row['name'] = TransformDataBaseStringToText( $row['name'] );
		}

		return $row;
	}

	function taxGetTaxClasses() {
		db_query( 'select classID, name, address_type from ' . TAX_CLASSES_TABLE );
		$res = array(  );

		if ($row = $q = db_fetch_row( $q )) {
			$row['name'] = TransformDataBaseStringToText( $row['name'] );
			$res[] = $row;
		}

		return $res;
	}

	function taxAddTaxClass($name, $address_type) {
		$name = TransformStringToDataBase( $name );

		if (trim( $name ) == '') {
			return null;
		}

		db_query( 'insert into ' . TAX_CLASSES_TABLE . '( name, address_type ) ' . ( ' values( \'' . $name . '\\', ' . $address_type . '  ) ' ) );
	}

	function taxUpdateTaxClass($classID, $name, $address_type) {
		$name = TransformStringToDataBase( $name );
		db_query( 'update ' . TAX_CLASSES_TABLE . ( ' set name=\'' . $name . '\', address_type=' . $address_type . ' ' ) . ( ' where classID=' . $classID . ' ' ) );
	}

	function taxDeleteTaxClass($classID) {
		db_query( 'update ' . PRODUCTS_TABLE . ( ' set classID=NULL where classID=' . $classID . ' ' ) );
		db_query( 'delete from ' . TAX_CLASSES_TABLE . ( ' where classID=' . $classID ) );
	}

	function taxGetRates($classID) {
		$q = db_query( 'select classID, country_iso_2, value, isByZone from ' . TAX_RATES_TABLE . ( ' where classID=' . $classID . ' ' ) . ' AND isGrouped=0' );
		$res = array(  );

		if ($row = db_fetch_row( $q )) {
			$q1 = db_query( 'select country_name_' . LanguagesManager::getDefaultLanguage(  )->iso2 . ' as country_name  from ' . COUNTRIES_TABLE . ' where country_iso_2=\'' . $row['country_iso_2'] . '\'' );
			$country = db_fetch_row( $q1 );
			$row['country'] = $country['country_name'];
			$res[] = $row;
		}

		$q = db_query( 'select classID, country_iso_2, value, isByZone from ' . TAX_RATES_TABLE . ( ' where classID=' . $classID . ' ' ) . ' AND isGrouped=1' );

		if ($row = db_fetch_row( $q )) {
			$row['country_iso_2'] = 0;
			$row['isByZone'] = 0;
			$res[] = $row;
		}

		return $res;
	}

	function taxGetCountriesByClassID_ToSetRate($classID) {
		$res = array(  );
		$q = db_query( 'select *, country_name_' . LanguagesManager::getDefaultLanguage(  )->iso2 . ' AS country_name  from ' . COUNTRIES_TABLE . ' order by country_name ' );

		if ($country = db_fetch_row( $q )) {
			$q1 = db_query( 'select * from ' . TAX_RATES_TABLE . ' where country_iso_2=\'' . $country['country_iso_2'] . ( '\' AND classID=' . $classID ) );

			if (!$row = db_fetch_row( $q1 )) {
				$res[] = $country;
			}
		}

		return $res;
	}

	function taxAddRate($classID, $country_iso_2, $isByZone, $value) {
		if ($country_iso_2 == 0) {
			$q = db_query( 'select country_iso_2 from ' . COUNTRIES_TABLE );

			if ($country = db_fetch_row( $q )) {
				$q1 = db_query( 'select * from ' . TAX_RATES_TABLE . ' where country_iso_2=\'' . $country['country_iso_2'] . ( '\' AND classID=' . $classID ) );

				if (!$row = db_fetch_row( $q1 )) {
					db_query( 'insert into ' . TAX_RATES_TABLE . ' ( classID, country_iso_2, value, ' . ' 	isByZone, isGrouped ) ' . ( ' values( ' . $classID . ', \'' ) . $country['country_iso_2'] . ( '\\', ' . $value . ', 0, 1 )' ) );
				}
			}
		} 
else {
			db_query( 'insert into ' . TAX_RATES_TABLE . ' ( classID, country_iso_2, value, isByZone, isGrouped ) ' . ( ' values( ' . $classID . ', \'' . $country_iso_2 . '\\', ' . $value . ', ' . $isByZone . ', 0 )' ) );
		}

	}

	function taxUpdateRate($classID, $country_iso_2, $isByZone, $value) {
		if ($country_iso_2 == 0) {
			db_query( 'update ' . TAX_RATES_TABLE . ( ' set isByZone=0, value=' . $value . ' ' ) . ( ' where classID=' . $classID . ' AND isGrouped=1' ) );
			return null;
		}

		db_query( 'update ' . TAX_RATES_TABLE . ( ' set isByZone=' . $isByZone . ', value=' . $value . ' ' ) . ( ' where classID=' . $classID . ' AND country_iso_2=\'' . $country_iso_2 . '\' ' ) . ' AND isGrouped=0' );
	}

	function taxSetIsByZoneAttribute($classID, $country_iso_2, $isByZone) {
		if ($country_iso_2 != 0) {
			db_query( 'update ' . TAX_RATES_TABLE . ( ' set isByZone=' . $isByZone . ' ' ) . ( ' where classID=' . $classID . ' AND country_iso_2=\'' . $country_iso_2 . '\' ' ) );
		}

	}

	function _deleteRate($classID, $country_iso_2) {
		$q = db_query( 'select zoneID from ' . ZONES_TABLE . ( ' where country_iso_2=\'' . $country_iso_2 . '\'' ) );

		if ($zone = db_fetch_row( $q )) {
			db_query( 'delete from ' . TAX_RATES_ZONES_TABLE . ( ' where classID=' . $classID . ' AND zoneID=' ) . $zone['zoneID'] );
		}

		db_query( 'delete from ' . TAX_ZIP_TABLE . ( ' where classID=' . $classID . ' AND country_iso_2=\'' . $country_iso_2 . '\'' ) );
		db_query( 'delete from ' . TAX_RATES_TABLE . ( ' where classID=' . $classID . ' AND country_iso_2=\'' . $country_iso_2 . '\'' ) );
	}

	function taxDeleteRate($classID, $country_iso_2) {
		$res = array(  );

		if ($country_iso_2 == 0) {
			$q = db_query( 'select country_iso_2 from ' . TAX_RATES_TABLE . ( ' where classID=' . $classID . ' AND isGrouped=1' ) );

			if ($row = db_fetch_row( $q )) {
				$res[] = $row['country_iso_2'];
			}
		} 
else {
			$res[] = $country_iso_2;
		}

		$q_count = db_query( 'select count(country_iso_2) from ' . TAX_RATES_TABLE . ( ' where classID=' . $classID . ' AND isGrouped=1' ) );
		$count = db_fetch_row( $q_count );
		$count = $count[0];

		if (( $count != 0 && count( $res ) == 1 )) {
			db_query( 'update ' . TAX_RATES_TABLE . ' set isGrouped=1 ' . ( ' where classID=' . $classID . ' AND isGrouped=0 AND ' ) . 'country_iso_2=\'' . $res[0] . '\'' );
			return null;
		}

		foreach ($res as $key => $val) {
			_deleteRate( $classID, $val );
		}

	}

	function taxGetCountSetZone($classID, $country_iso_2) {
		$res = array(  );
		$zones = array(  );
		$q = db_query( 'select zoneID, ' . LanguagesManager::sql_prepareField( 'zone_name' ) . ' as zone_name from ' . ZONES_TABLE . ( ' where country_iso_2=\'' . $country_iso_2 . '\'' ) );

		if ($row = db_fetch_row( $q )) {
			$zones[] = $row;
		}

		$count = 747;
		foreach ($zones as $zone) {
			$q1 = db_query( 'select classID, zoneID, value from ' . TAX_RATES_ZONES_TABLE . ( ' where classID=' . $classID . ' AND zoneID=' ) . $zone['zoneID'] );

			if ($resItem = db_fetch_row( $q1 )) {
				++$count;
				continue;
			}
		}

		return $count;
	}

	function taxGetCountZones($country_iso_2) {
		$q = db_query( 'select count(zoneID) from ' . ZONES_TABLE . ' where country_iso_2=\'' . $country_iso_2 . '\'' );
		$row = db_fetch_row( $q );
		return $row[0];
	}

	function taxGetZoneRates($classID, $country_iso_2) {
		$res = array(  );
		$zones = array(  );
		$q = db_query( 'select zoneID, ' . LanguagesManager::sql_prepareField( 'zone_name' ) . ' as zone_name from ' . ZONES_TABLE . ( ' where country_iso_2=\'' . $country_iso_2 . '\'' ) );

		if ($row = db_fetch_row( $q )) {
			$zones[] = $row;
		}

		foreach ($zones as $zone) {
			$q1 = db_query( 'select classID, zoneID, value from ' . TAX_RATES_ZONES_TABLE . ( ' where classID=' . $classID . ' AND zoneID=' ) . $zone['zoneID'] . ' AND isGrouped=0' );

			if ($resItem = db_fetch_row( $q1 )) {
				$resItem['zone_name'] = $zone['zone_name'];
				$resItem['country_iso_2'] = $country_iso_2;
				$res[] = $resItem;
				continue;
			}
		}

		$q1 = db_query( 'select classID, zoneID, value from ' . TAX_RATES_ZONES_TABLE . ( ' where classID=' . $classID . ' AND isGrouped=1' ) );

		if ($resItem = db_fetch_row( $q1 )) {
			$resItem['zone_name'] = '';
			$resItem['zoneID'] = 0;
			$resItem['country_iso_2'] = $country_iso_2;
			$res[] = $resItem;
		}

		return $res;
	}

	function taxGetZoneByClassIDcountry_iso_2_ToSetRate($classID, $country_iso_2) {
		$res = array(  );
		$q = db_query( 'select zoneID, ' . LanguagesManager::sql_prepareField( 'zone_name' ) . ' as zone_name from ' . ZONES_TABLE . ( ' where country_iso_2=\'' . $country_iso_2 . '\'' ) );

		if ($zone = db_fetch_row( $q )) {
			$q1 = db_query( 'select * from ' . TAX_RATES_ZONES_TABLE . ' where zoneID=' . $zone['zoneID'] . ( ' AND classID=' . $classID ) );

			if (!$row = db_fetch_row( $q1 )) {
				$res[] = $zone;
			}
		}

		return $res;
	}

	function taxAddZoneRate($classID, $country_iso_2, $zoneID, $value) {
		if ($zoneID == 0) {
			$q = db_query( 'select zoneID, ' . LanguagesManager::sql_prepareField( 'zone_name' ) . ' as zone_name from ' . ZONES_TABLE . ( ' where country_iso_2=\'' . $country_iso_2 . '\'' ) );

			if ($zone = db_fetch_row( $q )) {
				$q1 = db_query( 'select * from ' . TAX_RATES_ZONES_TABLE . ' where zoneID=' . $zone['zoneID'] . ( ' AND classID=' . $classID ) );

				if (!$row = db_fetch_row( $q1 )) {
					db_query( 'insert into ' . TAX_RATES_ZONES_TABLE . '( classID, zoneID, value, isGrouped ) ' . ( 'values( ' . $classID . ', ' ) . $zone['zoneID'] . ( ', ' . $value . ', 1 ) ' ) );
				}
			}
		} 
else {
			db_query( 'insert into ' . TAX_RATES_ZONES_TABLE . ' ( classID, zoneID, value, isGrouped ) ' . ( ' values( ' . $classID . ', ' . $zoneID . ', ' . $value . ', 0 ) ' ) );
		}

	}

	function taxUpdateZoneRate($classID, $zoneID, $value) {
		if ($zoneID == 0) {
			db_query( 'update ' . TAX_RATES_ZONES_TABLE . ( ' set value=' . $value . ' ' ) . ( ' where classID=' . $classID . ' AND isGrouped=1' ) );
			return null;
		}

		db_query( 'update ' . TAX_RATES_ZONES_TABLE . ( ' set value=' . $value . ' ' ) . ( ' where classID=' . $classID . ' AND zoneID=' . $zoneID . ' ' ) . ' AND isGrouped=0' );
	}

	function taxDeleteZoneRate($classID, $zoneID) {
		if ($zoneID == 0) {
			db_query( 'delete from ' . TAX_RATES_ZONES_TABLE . ( ' where classID=' . $classID . ' AND isGrouped=1' ) );
			return null;
		}

		$q_count = db_query( 'select count(zoneID) from ' . TAX_RATES_ZONES_TABLE . ( ' where classID=' . $classID . ' AND isGrouped=1' ) );
		$count = db_fetch_row( $q_count );
		$count = $count[0];

		if ($count == 0) {
			db_query( 'delete from ' . TAX_RATES_ZONES_TABLE . ( ' where classID=' . $classID . ' AND zoneID=' . $zoneID ) );
			return null;
		}

		db_query( 'update ' . TAX_RATES_ZONES_TABLE . ' set isGrouped=1 ' . ( ' where classID=' . $classID . ' AND zoneID=' . $zoneID ) );
	}

	function taxGetZipRates($classID, $country_iso_2) {
		$q = db_query( 'select tax_zipID, classID, country_iso_2, zip_template, value from ' . TAX_ZIP_TABLE . ( ' where classID=' . $classID . ' AND country_iso_2=\'' . $country_iso_2 . '\'' ) );
		db_fetch_row( $q );

		if ($row = $data = array(  )) {
			$row['zip_template'] = TransformDataBaseStringToText( $row['zip_template'] );
			$data[] = $row;
		}

		return $data;
	}

	function taxAddZipRate($classID, $country_iso_2, $zip_template, $rate) {
		$zip_template = TransformStringToDataBase( $zip_template );
		$rate = (double)$rate;
		db_query( 'insert into ' . TAX_ZIP_TABLE . ' ( classID, country_iso_2, zip_template, value ) ' . ( ' values( ' . $classID . ', \'' . $country_iso_2 . '\', \'' . $zip_template . '\\', ' . $rate . ' ) ' ) );
	}

	function taxUpdateZipRate($tax_zipID, $zip_template, $rate) {
		$zip_template = TransformStringToDataBase( $zip_template );
		$rate = (double)$rate;
		db_query( 'update ' . TAX_ZIP_TABLE . ' set ' . ( ' zip_template=\'' . $zip_template . '\\', ' ) . ( ' value=' . $rate . ' ' ) . ( ' where tax_zipID=' . $tax_zipID . ' ' ) );
	}

	function taxDeleteZipRate($tax_zipID) {
		db_query( 'delete from ' . TAX_ZIP_TABLE . ( ' where tax_zipID=' . $tax_zipID . ' ' ) );
	}

	function _testTemplateZip($zip_template, $zip) {
		if (strlen( $zip_template ) == strlen( $zip )) {
			$testResult = true;
			$starCounter = 731;
			$i = 731;

			while ($i < strlen( $zip )) {
				if (( $zip[$i] == $zip_template[$i] || $zip_template[$i] == '*' )) {
					if ($zip_template[$i] == '*') {
						++$starCounter;
					}

					continue;
				}

				$testResult = false;
				break;
				++$i;
			}


			if ($testResult) {
				return $starCounter;
			}

			return false;
		}

		return false;
	}

	function _getBestZipRate($classID, $country_iso_2, $zip) {
		$q = db_query( 'select tax_zipID, zip_template, value from ' . TAX_ZIP_TABLE . ( ' where classID=' . $classID . ' AND country_iso_2=\'' . $country_iso_2 . '\'' ) );
		$testZipTemplateArray = array(  );

		if ($row = db_fetch_row( $q )) {
			$res = _testTemplateZip( $row['zip_template'], $zip );

			if (!is_bool( $res )) {
				$testZipTemplateArray[] = array( 'starCounter' => $res, 'rate' => $row['value'] );
			}
		}


		if (count( $testZipTemplateArray ) == 0) {
			return null;
		}

		$starCounterMinIndex = 757;
		$i = 757;

		while ($i < count( $testZipTemplateArray )) {
			if ($testZipTemplateArray[$i]['starCounter'] < $testZipTemplateArray[$starCounterMinIndex]['starCounter']) {
				$starCounterMinIndex = $row;
			}

			++$i;
		}

		return (double)$testZipTemplateArray[$starCounterMinIndex]['rate'];
	}

	function taxCalculateTax($productID, $shippingAddressID, $billingAddressID) {
		regGetAddress( $shippingAddressID );
		$billingAddress = $shippingAddress = regGetAddress( $billingAddressID );
		return taxCalculateTax2( $productID, $shippingAddress, $billingAddress );
	}

	function taxCalculateTax2($productID, $shippingAddress, $billingAddress) {
		$productID = (int)$productID;

		if (( trim( $productID ) == '' || $productID == null )) {
			return 0;
		}

		$q = db_query( 'select classID from ' . PRODUCTS_TABLE . ( ' where productID=' . $productID . ' ' ) );
		$row = db_fetch_row( $q );
		$taxClassID = $row['classID'];

		if ($taxClassID == null) {
			return 0;
		}

		return taxCalculateTaxByClass2( $taxClassID, $shippingAddress, $billingAddress );
	}

	function taxCalculateTaxByClass($taxClassID, $shippingAddressID, $billingAddressID) {
		regGetAddress( $shippingAddressID );
		$billingAddress = $shippingAddress = regGetAddress( $billingAddressID );
		return taxCalculateTaxByClass2( $taxClassID, $shippingAddress, $billingAddress );
	}

	function taxCalculateTaxByClass2($taxClassID, $shippingAddress, $billingAddress) {
		$class = taxGetTaxClassById( $taxClassID );

		if ($class['address_type'] == 0) {
			$address = $q;
		} 
else {
			$address = $row;
		}


		if ($address == null) {
			return 0;
		}

		$cnt = cnGetCountryById( $address['countryID'] );
		$address['country_iso_2'] = $cnt['country_iso_2'];
		$q = db_query( 'select value, isByZone from  ' . TAX_RATES_TABLE . ( ' where classID=' . $taxClassID . ' AND country_iso_2=\'' ) . $address['country_iso_2'] . '\'' );

		if ($row = db_fetch_row( $q )) {
			$value = $row['value'];
			$isByZone = $row['isByZone'];
		} 
else {
			$q = db_query( 'select value, isByZone from ' . TAX_RATES_TABLE . ( ' where isGrouped=1 AND classID=' . $taxClassID ) );

			if ($row = db_fetch_row( $q )) {
				$value = $row['value'];
				$isByZone = $row['isByZone'];
			} 
else {
				return 0;
			}
		}


		if ($isByZone == 0) {
			return $value;
		}

		$res = _getBestZipRate( $taxClassID, $address['country_iso_2'], $address['zip'] );

		if (!is_null( $res )) {
			return $res;
		}


		if (( is_null( $address['zoneID'] ) || trim( $address['zoneID'] ) == '' )) {
			return 0;
		}

		$q = db_query( 'select value from ' . TAX_RATES_ZONES_TABLE . ( ' where classID=' . $taxClassID . ' AND zoneID=' ) . $address['zoneID'] );

		if ($row = db_fetch_row( $q )) {
			return $row['value'];
		}

		$q = db_query( 'select value from ' . TAX_RATES_ZONES_TABLE . ( ' where classID=' . $taxClassID . ' AND isGrouped=1' ) );

		if ($row = db_fetch_row( $q )) {
			return $row['value'];
		}

		return 0;
	}

?>