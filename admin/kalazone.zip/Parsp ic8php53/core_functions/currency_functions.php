<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function currSetCurrentCurrency($currencyID) {
		$_SESSION['current_currency'] = $currencyID;

		if (isset( $_SESSION['log'] )) {
			db_query( 'UPDATE ' . CUSTOMERS_TABLE . ' SET CID=\'' . $currencyID . '\' WHERE Login=\'' . $_SESSION['log'] . '\'' );
		}

	}

	function currGetCurrentCurrencyUnitID() {
		if (isset( $_SESSION['current_currency'] )) {
			return $_SESSION['current_currency'];
		}


		if (isset( $_SESSION['log'] )) {
			$q = db_query( 'SELECT cust_password, CID FROM ' . CUSTOMERS_TABLE . ' WHERE Login=\'' . $_SESSION['log'] . '\'' );
			$customerInfo = db_fetch_row( $q );
			$_SESSION['current_currency'] = $customerInfo['CID'];

			if ($_SESSION['current_currency'] != null) {
				return (isset( $_SESSION['current_currency'] ) ? $_SESSION['current_currency'] : CONF_DEFAULT_CURRENCY);
			}

			return null;
		}

		$q = db_query( 'select count(CID) from ' . CURRENCY_TYPES_TABLE . ' where CID=' . CONF_DEFAULT_CURRENCY );
		$count = db_fetch_row( $q );
		$count = $count[0];

		if ($count == 0) {
			return null;
		}

		return CONF_DEFAULT_CURRENCY;
	}

	function currGetCurrencyByID($currencyID) {
		$q = db_query( 'select * from ' . CURRENCY_TYPES_TABLE . ( ' where CID=' . $currencyID . ' ' ) );
		$row = db_fetch_row( $q );

		if ($row) {
			LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
			$row['Name'] = TransformDataBaseStringToText( $row['Name'] );
			$row['code'] = TransformDataBaseStringToText( $row['code'] );
			$row['currency_iso_3'] = TransformDataBaseStringToText( $row['currency_iso_3'] );
		} 
else {
			$row = null;
		}

		return $row;
	}

	function currGetCurrencyByISO3($_ISO3) {
		$q = db_query( 'select * from ' . CURRENCY_TYPES_TABLE . ' where currency_iso_3=\'' . xEscapeSQLstring( $_ISO3 ) . '\' ' );
		$row = db_fetch_row( $q );

		if ($row) {
			LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
			$row['Name'] = TransformDataBaseStringToText( $row['Name'] );
			$row['code'] = TransformDataBaseStringToText( $row['code'] );
			$row['currency_iso_3'] = TransformDataBaseStringToText( $row['currency_iso_3'] );
		} 
else {
			$row = null;
		}

		return $row;
	}

		$q = function currGetAllCurrencies() {;
		$data = array(  );
		db_fetch_row( $q );

		if ($row = db_query( 'select * from ' . CURRENCY_TYPES_TABLE . ' order by sort_order' )) {
			LanguagesManager::ml_fillFields( CURRENCY_TYPES_TABLE, $row );
			$data[] = $row;
		}

		return $data;
	}

	function currDeleteCurrency($CID) {
		$q = db_query( 'select CID from ' . CURRENCY_TYPES_TABLE . ' where CID!=' . $CID );

		if ($currency = db_fetch_row( $q )) {
			db_query( 'update ' . CUSTOMERS_TABLE . ' set CID=' . $currency['CID'] . ' where CID=' . $CID );
		} 
else {
			db_query( 'update ' . CUSTOMERS_TABLE . ' set CID=NULL where CID=' . $CID );
		}

		db_query( 'delete from ' . CURRENCY_TYPES_TABLE . ( ' where CID=' . $CID ) );
	}

	function currUpdateCurrency($CID, $val, $currency_iso_3, $value, $where, $sort_order) {
		$currency_iso_3 = TransformStringToDataBase( $currency_iso_3 );
		$sort_order = (int)$sort_order;
		db_query( 'update ' . CURRENCY_TYPES_TABLE . ' set ' . str_replace( 'curr_', '', LanguagesManager::sql_prepareFieldUpdate( 'curr_Name', $val ) ) . ', ' . str_replace( 'curr_', '', LanguagesManager::sql_prepareFieldUpdate( 'curr_code', $val ) ) . ', ' . '	currency_value=\'' . $value . '\\', ' . ' 	where2show=\'' . $where . '\\', ' . '	sort_order=\'' . $sort_order . '\\', ' . '	currency_iso_3=\'' . $currency_iso_3 . '\' ' . ( ' where CID=' . $CID ) );
	}

	function currAddCurrency($curr, $currency_iso_3, $value, $where, $sort_order) {
		$currency_iso_3 = TransformStringToDataBase( $currency_iso_3 );
		$sort_order = (int)$sort_order;
		foreach ($curr as $key => $value) {
			$key = str_replace( 'curr_new_', '', $key );
			$curr[$key] = $value;
		}

		$name_inj = LanguagesManager::sql_prepareFieldInsert( 'name', $curr );
		$code_inj = LanguagesManager::sql_prepareFieldInsert( 'code', $curr );
		db_query( 'insert into ' . CURRENCY_TYPES_TABLE . ( ' (' . $name_inj['fields'] . ', ' . $code_inj['fields'] . ', currency_iso_3, currency_value, where2show, sort_order) ' ) . ' values (' . $name_inj['values'] . ', ' . $code_inj['values'] . ', \'' . $currency_iso_3 . '\', \'' . $value . '\', \'' . $where . '\', \'' . $sort_order . '\')' );
	}

?>