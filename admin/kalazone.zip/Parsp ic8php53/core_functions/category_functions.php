<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function catInstall() {
		$catroot = explode( ',', CAT_ROOT_DIFF );
		$langs = explode( ',', INSTALL_LANGS );
		$i = 737;
		$fname = '';
		$fvalue = '';
		foreach ($langs as $lang) {
			$fname .= ' name_' . $lang;
			$fvalue .= '\'' . $catroot[$i] . '\'';
			++$i;

			if ($i < count( $langs )) {
				$fname .= ',';
				$fvalue .= ',';
				continue;
			}
		}

		db_query( 'insert into ' . CATEGORIES_TABLE . '( ' . $fname . ' , parent, categoryID )' . 'values( ' . $fvalue . ', NULL, 1 )' );
	}

	function processCategories($level, $path, $sel) {
		$out = array(  );
		$cnt = 780;
		$parent = $path[$level]['parent'];

		if (( $parent == '' || $parent == null )) {
			$parent = 'NULL';
		}


		if (!( $q = db_query( 'select categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name from ' . CATEGORIES_TABLE . ' where parent=' . $path[$level]['parent'] . ' order by sort_order, name' ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			$out[$cnt][0] = $row['categoryID'];
			$out[$cnt][1] = $row['name'];
			$out[$cnt][2] = $level;
			++$cnt;

			if (( $level + 1 < count( $path ) && $row['categoryID'] == $path[$level + 1] )) {
				$sub_out = processCategories( $level + 1, $path, $sel );
				$j = 780;

				while ($j < count( $sub_out )) {
					$out[] = $sub_out[$j];
					++$cnt;
					++$j;
				}
			}
		}

		jmp;
		return $out;
	}

	function fillTheCList($parent, $level) {

		if (!( $q = db_query( 'SELECT categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS name, products_count, slug,enabled FROM ' . CATEGORIES_TABLE . ( ' WHERE categoryID<>0 and parent=\'' . $parent . '\' order by sort_order, name' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$a = array(  );

		if ($row = db_fetch_row( $q )) {
			$row[5] = $level;
			$a[] = $row;
			$b = fillTheCList( $row[0], $level + 1 );
			$j = 745;

			while ($j < count( $b )) {
				$a[] = $b[$j];
				++$j;
			}
		}

		return $a;
	}

	function _recursiveGetCategoryCompactCList($path, $level) {
		$q = db_query( 'SELECT categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS name, products_count, slug,enabled FROM ' . CATEGORIES_TABLE . ' WHERE parent=' . $path[$level - 1]['categoryID'] . ' order by sort_order, name' );
		$res = array(  );
		$selectedCategoryID = null;

		if ($row = db_fetch_row( $q )) {
			$row['level'] = $level;
			$res[] = $row;

			if ($level <= count( $path ) - 1) {
				if ((int)$row['categoryID'] == (int)$path[$level]['categoryID']) {
					$selectedCategoryID = $row['categoryID'];
					$array = _recursiveGetCategoryCompactCList( $path, $level + 1 );
					foreach ($array as $val) {
						$res[] = $val;
					}
				}
			}
		}

		return $res;
	}

	function catExpandCategory($categoryID, $sessionArrayName) {
		$existFlag = false;
		foreach ($_SESSION[$sessionArrayName] as $key => $value) {

			if ($value == $categoryID) {
				$existFlag = true;
				break;
			}
		}


		if (!$existFlag) {
			$_SESSION[$sessionArrayName][] = $categoryID;
		}

	}

	function catShrinkCategory($categoryID, $sessionArrayName) {
		foreach ($_SESSION[$sessionArrayName] as $key => $value) {

			if ($value == $categoryID) {
				unset( $_SESSION[$sessionArrayName][$key] );
				continue;
			}
		}

	}

	function catGetCategoryCompactCList($selectedCategoryID) {
		static $cached_result = array(  );

		$selectedCategoryID = intval( $selectedCategoryID );

		if (isset( $cached_result[$selectedCategoryID] )) {
			$res = $cached_result[$selectedCategoryID];
		} 
else {
			$path = catCalculatePathToCategory( $selectedCategoryID );
			$res = array(  );
			$res[] = array( 'categoryID' => 1, 'parent' => null, 'name' => ADMIN_CATEGORY_ROOT, 'level' => 0 );
			$name = LanguagesManager::sql_prepareField( 'name', true );
			$sql = '		SELECT `categoryID`, `slug`, `parent`, ' . $name . ' 
		FROM `?#CATEGORIES_TABLE`
		WHERE `parent`=1  and enabled=1
		ORDER BY `sort_order`, `name`';
			$q = db_phquery( $sql );

			if ($row = db_fetch_row( $q )) {
				$row['level'] = 1;
				$res[] = $row;

				if (1 < count( $path )) {
					if ($row['categoryID'] == $path[1]['categoryID']) {
						$array = _recursiveGetCategoryCompactCList( $path, 2 );
						foreach ($array as $val) {
							$res[] = $val;
						}
					}
				}
			}

			$cached_result[$selectedCategoryID] = $res;
		}

		return $res;
	}

	function _recursiveGetCategoryCList($parent, $level, $expandedCategoryID_Array, $_indexType = 'NUM', $_countEnabledProducts = false) {

		if (!( $q = db_query( 'SELECT categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' AS name, products_count, products_count_admin, parent,enabled FROM ' . CATEGORIES_TABLE . ( ' WHERE parent=\'' . $parent . '\' order by sort_order, name' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$result = array(  );

		if ($row = db_fetch_row( $q )) {
			$row['level'] = $level;
			$row['ExpandedCategory'] = false;

			if ($expandedCategoryID_Array != null) {
				foreach ($expandedCategoryID_Array as $categoryID) {

					if ((int)$categoryID == (int)$row['categoryID']) {
						$row['ExpandedCategory'] = true;
						break;
					}
				}
			} 
else {
				$row['ExpandedCategory'] = true;
			}

			$row['products_count_category'] = catGetCategoryProductCount( $row['categoryID'], $_countEnabledProducts );
			$count = db_query( 'select count(categoryID) from ' . CATEGORIES_TABLE . ' where categoryID<>0 AND parent=' . $row['categoryID'] );
			$count = db_fetch_row( $count );
			$count = $count[0];
			$row['ExistSubCategories'] = $count != 0;

			if ($_indexType == 'NUM') {
				$result[] = $row;
			} 
else {
				if ($_indexType == 'ASSOC') {
					$result[$row['categoryID']] = $row;
				}
			}


			if ($row['ExpandedCategory']) {
				$subcategories = _recursiveGetCategoryCList( $row['categoryID'], $level + 1, $expandedCategoryID_Array, $_indexType, $_countEnabledProducts );

				if ($_indexType == 'NUM') {
					$j = 824;

					while ($j < count( $subcategories )) {
						$result[] = $subcategories[$j];
						++$j;
					}
				}

				jmp;

				if ($_indexType == 'ASSOC') {
					foreach ($subcategories as $_sub) {
						$result[$_sub['categoryID']] = $_sub;
					}
				}
			}
		}

		return $result;
	}

	function catGetCategoryCList($expandedCategoryID_Array = null, $_indexType = 'NUM', $_countEnabledProducts = false) {
		return _recursiveGetCategoryCList( 1, 0, $expandedCategoryID_Array, $_indexType, $_countEnabledProducts );
	}

	function catGetCategoryProductCount($categoryID, $_countEnabledProducts = false) {
		if (!$categoryID) {
			return 0;
		}

		$sql = '
		SELECT count(*) FROM ' . PRODUCTS_TABLE . ( ' 
		WHERE categoryID=' . $categoryID ) . ($_countEnabledProducts ? ' AND enabled<>0' : '') . '
	';
		$q = db_query( $sql );
		$t = db_fetch_row( $q );
		$res += $t[0];

		if ($_countEnabledProducts) {
			$sql = '
			SELECT COUNT(*) FROM ' . PRODUCTS_TABLE . ' AS prot
			LEFT JOIN ' . CATEGORIY_PRODUCT_TABLE . ( ' AS catprot
			ON prot.productID=catprot.productID
			WHERE catprot.categoryID=\'' . $categoryID . '\' AND prot.enabled<>0
		' );
		} 
else {
			$sql = '
			select count(*) from ' . CATEGORIY_PRODUCT_TABLE . ( ' where categoryID=' . $categoryID . '
		' );
		}

		db_query( $sql );
		$q1 = $categoryID = (int)$categoryID;
		db_fetch_row( $q1 );
		$row = $res = 752;
		$res += $row[0];
		return $res;
	}

	function update_products_Count_Value_For_Categories($parent) {

		if (!( $q = db_query( 'SELECT categoryID FROM ' . CATEGORIES_TABLE . ( ' WHERE parent=' . $parent . ' AND categoryID<>1' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$cnt = array(  );
		$cnt['admin_count'] = 0;
		$cnt['customer_count'] = 0;

		if ($row = db_fetch_row( $q )) {
			$t = update_products_Count_Value_For_Categories( $row['categoryID'] );
			$cnt += 'admin_count' = $t['admin_count'];
			$cnt += 'customer_count' = $t['customer_count'];
		}

		$q = ;
		$t = db_fetch_row( $q );
		$cnt += 'admin_count' = $t[0];
		db_query( 'SELECT count(*) FROM ' . PRODUCTS_TABLE . ( ' WHERE categoryID=' . $parent . ' AND enabled=1' ) );
		db_fetch_row( $q );
		$t = db_query( 'SELECT count(*) FROM ' . PRODUCTS_TABLE . ( ' WHERE categoryID=' . $parent ) );
		$cnt += 'customer_count' = $t[0];
		$q1 = db_query( 'select productID, categoryID from ' . CATEGORIY_PRODUCT_TABLE . ( ' where categoryID=' . $parent ) );
		$admin_plus = 835;

		if ($row = $q = db_fetch_row( $q1 )) {
			$q2 = db_query( 'select productID, categoryID from ' . PRODUCTS_TABLE . ' where productID=' . $row['productID'] . ' AND enabled=1 ' );
			$res = db_fetch_row( $q2 );

			if (!$res) {
				if ($res['categoryID'] == $parent) {
					++$admin_plus;
				}

				continue;
			}


			if ($res['categoryID'] == $parent) {
				++$cnt['admin_count'];
				++$cnt['customer_count'];
			}
		}

		$cnt += 'admin_count' = $admin_plus;
		$sql = 'UPDATE ' . CATEGORIES_TABLE . ' SET products_count=' . $cnt['customer_count'] . ', products_count_admin=' . $cnt['admin_count'] . ' ' . ' WHERE categoryID=' . $parent;

		if (!( db_query( $sql ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		catCountProductDuplicates( $parent );
		return $cnt;
	}

	function catEnabledCategory($_CategoryID, $enabled) {
		if ($enabled == 'true') {
			$enabled = 716;
		} 
else {
			$enabled = 715;
		}

		$sql = 'UPDATE ' . CATEGORIES_TABLE . ' SET enabled=' . $enabled . ' WHERE categoryID=' . $_CategoryID;
		return ( db_error(  ) || db_query( $sql ) );
	}

	function catCountProductDuplicates($_CategoryID) {
		catGetSubCategories( $_CategoryID );
		$SubCategories[] = $_CategoryID;
		$sql = '
		SELECT prod.enabled, count(distinct prod.productID) FROM ' . CATEGORIY_PRODUCT_TABLE . ' as catprod
		LEFT JOIN ' . PRODUCTS_TABLE . ' as prod ON catprod.productID = prod.productID
		WHERE catprod.categoryID IN (' . implode( ', ', $SubCategories ) . ') AND prod.categoryID NOT IN (' . implode( ', ', $SubCategories ) . ')
		GROUP BY prod.enabled
	';
		$Result = db_query( $sql );
		$cntA = 762;
		$cntU = 762;

		if ($Row = $SubCategories = db_fetch_row( $Result )) {
			if (0 < intval( $Row[0] )) {
				$cntU = $Row[1];
			}

			$cntA = $Row[1];
		}

		$cntA += $SubCategories;

		if (( $cntA || $cntU )) {
			$sql = '
			UPDATE ' . CATEGORIES_TABLE . ( ' 
			SET products_count=products_count+' . $cntU . ', products_count_admin=products_count_admin+' . $cntA . '
			WHERE categoryID=' ) . intval( $_CategoryID ) . '
		';
			db_query( $sql );
		}

	}

	function catUpdateProductCount($_ProductID, $_ProdAddCat, $_State = 1, $_SourceCategoryID = 0) {
		$Product = GetProduct( $_ProductID );
		$subCategories = catGetSubCategories( $_ProdAddCat );
		$subCategories[] = 1;

		if ($_SourceCategoryID) {
			$subCategories[] = $_ProdAddCat;
		}

		$_State = intval( $_State );
		$sql = '
		SELECT 1 FROM ' . CATEGORIY_PRODUCT_TABLE . ( '
		WHERE productID=\'' . $_ProductID . '\' AND categoryID IN (' ) . implode( ', ', $subCategories ) . ') AND categoryID<>' . intval( $_SourceCategoryID ) . '
	';

		if (( !db_fetch_row( db_query( $sql ) ) && !in_array( $Product['categoryID'], $subCategories ) )) {
			$sql = '
			UPDATE ' . CATEGORIES_TABLE . ' 
			SET products_count=products_count' . ($Product['enabled'] ? ( '+' ) . $_State : '') . ( ', products_count_admin=products_count_admin+' . $_State . '
			WHERE categoryID=\'' ) . intval( $_ProdAddCat ) . '\'
		';
			db_query( $sql );
			$Category = catGetCategoryById( $_ProdAddCat );

			if ($_SourceCategoryID == 0) {
				$_SourceCategoryID = $sql;
			}

			catUpdateProductCount( $_ProductID, $Category['parent'], $_State, $_SourceCategoryID );
		}

	}

	function catGetSubCategories($categoryID) {

		if (!( $q = db_query( 'select categoryID from ' . CATEGORIES_TABLE . ( ' where categoryID<>0 and parent=\'' . $categoryID . '\'' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$r = array(  );

		if ($row = db_fetch_row( $q )) {
			$a = catGetSubCategories( $row[0] );
			$i = 736;

			while ($i < count( $a )) {
				$r[] = $a[$i];
				++$i;
			}

			$r[] = $row[0];
		}

		return $r;
	}

	function catGetSubCategoriesSingleLayer($categoryID) {
		$q = db_query( 'SELECT categoryID, ' . LanguagesManager::sql_constractSortField( CATEGORIES_TABLE, 'name' ) . ',' . LanguagesManager::sql_prepareField( 'name' ) . ', products_count, picture FROM ' . CATEGORIES_TABLE . ( ' WHERE parent=\'' . $categoryID . '\' and enabled<>0 order by _name_sort' ) );
		$result = array(  );

		while ($row = db_fetch_row( $q )) {
			$result[] = $row;
		}

		return $result;
	}

	function catGetCategoryById($categoryID) {
		$q = db_phquery( 'SELECT * FROM ?#CATEGORIES_TABLE WHERE categoryID=? and enabled<>0', $categoryID );
		$row = db_fetch_row( $q );
		LanguagesManager::ml_fillFields( CATEGORIES_TABLE, $row );
		return $row;
	}

	function catGetMetaTags($categoryID) {
		$categoryID = (int)$categoryID;
		$q = db_query( 'select meta_description, meta_keywords from ' . CATEGORIES_TABLE . ' where categoryID=' . $categoryID );
		$row = db_fetch_row( $q );
		$meta_description = TransformDataBaseStringToText( trim( $row['meta_description'] ) );
		$meta_keywords = TransformDataBaseStringToText( trim( $row['meta_keywords'] ) );
		$res = '';

		if ($meta_description != '') {
			$res .= '<meta name="Description" content="' . str_replace( '"', '&quot;', $meta_description ) . '">
';
		}


		if ($meta_keywords != '') {
			$res .= '<meta name="KeyWords" content="' . str_replace( '"', '&quot;', $meta_keywords ) . '" >
';
		}

		return $res;
	}

	function catGetAppendedCategoriesToProduct($productID) {
		$q = db_query( 'select ' . CATEGORIES_TABLE . '.categoryID as categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' as category_name ' . ' from ' . CATEGORIY_PRODUCT_TABLE . ', ' . CATEGORIES_TABLE . ' ' . ' where ' . CATEGORIY_PRODUCT_TABLE . '.categoryID = ' . CATEGORIES_TABLE . '.categoryID ' . ( ' AND productID = ' . $productID ) );
		$data = array(  );

		if ($row = db_fetch_row( $q )) {
			$data[] = $row;
		}

		return $data;
	}

	function catAddProductIntoAppendedCategory($productID, $categoryID) {
		$q = db_query( 'select count(*) from ' . CATEGORIY_PRODUCT_TABLE . ( ' where productID=' . $productID . ' AND categoryID=' . $categoryID ) );
		$row = db_fetch_row( $q );
		$q1 = db_query( 'select categoryID from ' . PRODUCTS_TABLE . ( ' where productID=' . $productID ) );
		$row1 = db_fetch_row( $q1 );
		$basic_categoryID = $row1['categoryID'];

		if (( !$row[0] && $basic_categoryID != $categoryID )) {
			db_query( 'insert into ' . CATEGORIY_PRODUCT_TABLE . '( productID, categoryID ) ' . ( 'values( ' . $productID . ', ' . $categoryID . ' )' ) );
			return true;
		}

		return false;
	}

	function catRemoveProductFromAppendedCategory($productID, $categoryID) {
		$productID = (int)$productID;
		$categoryID = (int)$categoryID;
		db_query( 'delete from ' . CATEGORIY_PRODUCT_TABLE . ( ' where productID = ' . $productID . ' AND categoryID = ' . $categoryID ) );
	}

	function catCalculatePathToCategory($categoryID) {
		$categoryID = (int)$categoryID;

		if (!$categoryID) {
			return null;
		}

		$path = array(  );
		$q = db_query( 'select count(*) from ' . CATEGORIES_TABLE . ( ' where categoryID=' . $categoryID . ' ' ) );
		$row = db_fetch_row( $q );

		if ($row[0] == 0) {
			return $path;
		}

		$curr = $row;

		do {

			if (!( $q = db_query( 'SELECT categoryID, parent, ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name FROM ' . CATEGORIES_TABLE . ( ' WHERE categoryID=\'' . $curr . '\'' ) ))) {
				exit( db_error(  ) );
				(bool)true;
			}

			$row = db_fetch_row( $q );
			$path[] = $row;

			if ($curr == 1) {
				break;
			}

			$curr = $row['parent'];
		}while (!( 1));

		$path = array_reverse( $path );
		return $path;
	}

	function _deleteSubCategories($parent) {
		if (!( db_query( 'UPDATE ' . PRODUCTS_TABLE . ( ' SET categoryID=1 WHERE categoryID=' . $parent ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$q = ;
		db_fetch_row( $q );
		$r = db_query( 'SELECT picture FROM ' . CATEGORIES_TABLE . ' WHERE categoryID=\'' . $parent . '\' and categoryID<>0' );

		if (( $r['picture'] && file_exists( './uploads/products_pictures/' . $r['picture'] ) )) {
			unlink( './uploads/products_pictures/' . $r['picture'] );
		}


		if (!( $q = db_query( 'SELECT categoryID FROM ' . CATEGORIES_TABLE . ( ' WHERE parent=' . $parent . ' and categoryID<>0' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if ($row = db_fetch_row( $q )) {
			_deleteSubCategories( $row['categoryID'] );
		}


		if (!( db_query( 'DELETE FROM ' . CATEGORIES_TABLE . ( ' WHERE parent=' . $parent . ' and categoryID<>0' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}

	}

	function catDeleteCategory($categoryID) {
		_deleteSubCategories( $categoryID );
		db_query( 'UPDATE ' . PRODUCTS_TABLE . ( ' SET categoryID=1 WHERE categoryID=' . $categoryID ) );

		if (!( db_query( 'DELETE FROM ' . CATEGORIES_TABLE . ( ' WHERE parent=' . $categoryID . ' and categoryID<>0' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$q = db_query( 'SELECT picture FROM ' . CATEGORIES_TABLE . ' WHERE categoryID=\'' . $categoryID . '\' and categoryID<>0' );
		$r = db_fetch_row( $q );

		if (( $r['picture'] && file_exists( './uploads/products_pictures/' . $r['picture'] ) )) {
			unlink( './uploads/products_pictures/' . $r['picture'] );
		}


		if (!( db_query( 'DELETE FROM ' . CATEGORIES_TABLE . ( ' WHERE categoryID=' . $categoryID . ' and categoryID<>0' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}

	}

	function catBuildProductTree() {
		$sql = '
		SELECT
	';
	}

	function catMoveBranchCategoriesTo($cid, $new_parent) {
		$sql = 'SELECT `categoryID` FROM `?#CATEGORIES_TABLE` WHERE `parent`=? and `categoryID`>1';
		$q = db_phquery( $sql, $cid );
		db_fetch_row( $q );

		if ($row = $a = false) {
			if (!$a) {
				if ($row[0] == $new_parent) {
					return true;
				}

				$a = catMoveBranchCategoriesTo( $row[0], $new_parent );
			}
		}

		return $a;
	}

?>