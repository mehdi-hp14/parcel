<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function optGetOptions() {
		$name = LanguagesManager::sql_constractSortField( PRODUCT_OPTIONS_TABLE, 'name', true );
		$sort_name = LanguagesManager::sql_getSortField( PRODUCT_OPTIONS_TABLE, 'name' );
		$sql = 'SELECT (SELECT COUNT(`' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . '`.`variantID`) 
			FROM `' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . '` 
			WHERE `' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . '`.`optionID` = `' . PRODUCT_OPTIONS_TABLE . '`.`optionID`
		) as `count_variants`,
		`' . PRODUCT_OPTIONS_TABLE . ( '`.*,
		' . $name . ' 
   		
	FROM `' ) . PRODUCT_OPTIONS_TABLE . '`
	ORDER BY `' . PRODUCT_OPTIONS_TABLE . ( '`.`sort_order`, ' . $sort_name . '	' );
		$q = db_phquery( $sql );

		if ($row = db_fetch_assoc( $q )) {
			LanguagesManager::ml_fillFields( PRODUCT_OPTIONS_TABLE, $row );
			$row['optionID'] = intval( $row['optionID'] );
			$row[0] = $row['optionID'];
			$row[2] = $row['sort_order'];
			$result[] = $row;
		}

		return $result;
	}

	function optGetOptionById($optionID) {
		$q = db_phquery( 'SELECT * FROM ?#PRODUCT_OPTIONS_TABLE WHERE optionID=?', $optionID );

		if ($row = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( PRODUCT_OPTIONS_TABLE, $row );
			return $row;
		}

	}

	function optUpdateOptions($updateOptions) {
		foreach ($updateOptions as $key => $val) {
			$update_sql = LanguagesManager::sql_prepareTableUpdate( PRODUCT_OPTIONS_TABLE, $val, array( '@name_(\w{2})@' => 'extra_option_' ) );
			$val['extra_option'] = xEscapeSQLstring( $val['extra_option'] );
			$val['extra_sort'] = (int)$val['extra_sort'];
			$s = 'update ' . PRODUCT_OPTIONS_TABLE . ( ' set ' . $update_sql . ', sort_order=\'' ) . $val['extra_sort'] . ( '\' where optionID=\'' . $key . '\';' );
			db_query( $s );
		}

	}

	function optAddOption($params) {
		$ml_dbqs = LanguagesManager::sql_prepareFieldInsert( 'name', $params );
		$dd = db_phquery( 'INSERT ' . PRODUCT_OPTIONS_TABLE . ' (' . $ml_dbqs['fields'] . ', sort_order) VALUES(' . $ml_dbqs['values'] . ',?)', $params['sort_order'] );
	}

	function optGetOptionValues($optionID) {
		$value = LanguagesManager::sql_constractSortField( PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE, 'option_value' );
		$value_sort = LanguagesManager::sql_getSortField( PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE, 'option_value' );
		$dbq = '		SELECT *, ' . $value . ' 
		FROM `?#PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE` ';

		if (!is_null( $optionID )) {
			$dbq .= 'WHERE `optionID` IN (?@)';
		}

		$dbq .= 'ORDER BY `optionID`, `sort_order`, ' . $value_sort;
		$q = db_phquery( $dbq, (array)$optionID );
		$result = array(  );

		if ($row = db_fetch_assoc( $q )) {
			$row['optionID'] = intval( $row['optionID'] );
			$row['variantID'] = intval( $row['variantID'] );
			$current = $row['optionID'];

			if (!isset( $result[$current] )) {
				$result[$current] = array(  );
			}

			$result[$current][] = LanguagesManager::ml_fillFields( PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE, $row );
		}


		if ($result) {
			return (( is_array( $optionID ) || is_null( $optionID ) ) ? $result : $result[$optionID]);
		}

	}

	function optOptionValueExists($optionID, $value_name) {
		$q = $value_name = TransformStringToDataBase( $value_name );
		db_fetch_row( $q );
		$row = db_query( 'select variantID from ' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . ' where optionID=' . $optionID . ' and option_value=\'' . $value_name . '\';' );

		if ($row) {
			return $row[0];
		}

		return false;
	}

	function optUpdateOptionValues($updateOptions) {
		foreach ($updateOptions as $key => $value) {
			$sql = '
			UPDATE ?#PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE SET ' . LanguagesManager::sql_prepareFieldUpdate( 'option_value', $value ) . ', sort_order=? 
			WHERE variantID=?
		';
			db_phquery( $sql, $value['sort_order'], $key );
		}

	}

	function optAddOptionValue($params) {
		if (LanguagesManager::ml_isEmpty( 'option_value', $params )) {
			return false;
		}

		$ml_dbqs = LanguagesManager::sql_prepareFieldInsert( 'option_value', $params );
		$sql = '
		INSERT ?#PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE (optionID, ' . $ml_dbqs['fields'] . ', sort_order) values(?, ' . $ml_dbqs['values'] . ',?) 
	';
		db_phquery( $sql, $params['optionID'], $params['sort_order'] );
		return db_insert_id(  );
	}

?>