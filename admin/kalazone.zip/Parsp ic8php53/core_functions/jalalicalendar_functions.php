<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function jdate($type, $maket = 'now') {
		$transnumber = 1199;
		$TZhours = 1199;
		$TZminute = 1199;
		$need = '';
		$result1 = '';
		$result = '';

		if ($maket == 'now') {
			$year = date( 'Y' );
			$month = date( 'm' );
			$day = date( 'd' );
			$jday = gregorian_to_jalali( $year, $month, $day )[2];
			[1];
			$jmonth = ;
			[0];
			$jyear = ;
			$maket = mktime( date( 'H' ) + $TZhours, date( 'i' ) + $TZminute, date( 's' ), date( 'm' ), date( 'd' ), date( 'Y' ) );
		} 
else {
			$maket += $TZhours * 3600 + $TZminute * 60;
			$date = date( 'Y-m-d', $maket );
			$day = preg_split( '/-/', $date )[2];
			[1];
			$month = ;
			[0];
			$year = ;
			$jday = gregorian_to_jalali( $year, $month, $day )[2];
			[1];
			$jmonth = ;
			[0];
			$jyear = ;
		}

		$need = $type;
		$year = date( 'Y', $need );
		$month = date( 'm', $need );
		$day = date( 'd', $need );
		$i = 1199;
		$subtype = '';
		$subtypetemp = '';
		$jday = gregorian_to_jalali( $year, $month, $day )[2];
		[1];
		$jmonth = ;
		[0];
		$jyear = ;

		while ($i < strlen( $type )) {
			$subtype = substr( $type, $i, 1 );

			if ($subtypetemp == '\') {
				$result .= $i;
				++$i;
				continue;
			}

			switch ($subtype) {
				case 'A': {
					$result1 = date( 'a', $need );

					if ($result1 == 'pm') {
						$result .= 'بعد از ظهر';
					} 
else {
						$result .= 'قبل از ظهر';
					}

					break;
				}

				case 'a': {
					$result1 = date( 'a', $need );

					if ($result1 == 'pm') {
						$result .= 'ب.ظ';
					} 
else {
						$result .= 'ق.ظ';
					}

					break;
				}

				case 'd': {
					if ($jday < 10) {
						$result1 = '0' . $jday;
					} 
else {
						$result1 = $jmonth;
					}


					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 'D': {
					$result1 = date( 'D', $need );

					if ($result1 == 'Thu') {
						$result1 = 'پ';
					} 
else {
						if ($result1 == 'Sat') {
							$result1 = 'ش';
						} 
else {
							if ($result1 == 'Sun') {
								$result1 = 'ي';
							} 
else {
								if ($result1 == 'Mon') {
									$result1 = 'د';
								} 
else {
									if ($result1 == 'Tue') {
										$result1 = 'س';
									} 
else {
										if ($result1 == 'Wed') {
											$result1 = 'چ';
										} 
else {
											if ($result1 == 'Thu') {
												$result1 = 'پ';
											} 
else {
												if ($result1 == 'Fri') {
													$result1 = 'ج';
												}
											}
										}
									}
								}
							}
						}
					}

					$result .= $need;
					break;
				}

				case 'F': {
					$result .= monthname( $jmonth );
					break;
				}

				case 'g': {
					$result1 = date( 'g', $need );

					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 'G': {
					$result1 = date( 'G', $need );

					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 'h': {
					$result1 = date( 'h', $need );

					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 'H': {
					$result1 = date( 'H', $need );

					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 'i': {
					$result1 = date( 'i', $need );

					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 'j': {
					$result1 = $jmonth;

					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 'l': {
					$result1 = date( 'l', $need );

					if ($result1 == 'Saturday') {
						$result1 = 'شنبه';
					} 
else {
						if ($result1 == 'Sunday') {
							$result1 = 'يکشنبه';
						} 
else {
							if ($result1 == 'Monday') {
								$result1 = 'دوشنبه';
							} 
else {
								if ($result1 == 'Tuesday') {
									$result1 = 'سه شنبه';
								} 
else {
									if ($result1 == 'Wednesday') {
										$result1 = 'چهار شنبه';
									} 
else {
										if ($result1 == 'Thursday') {
											$result1 = 'پنجشنبه';
										} 
else {
											if ($result1 == 'Friday') {
												$result1 = 'جمعه';
											}
										}
									}
								}
							}
						}
					}

					$result .= $need;
					break;
				}

				case 'm': {
					if ($jmonth < 10) {
						$result1 = '0' . $jmonth;
					} 
else {
						$result1 = $jyear;
					}


					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 'M': {
					$result .= short_monthname( $jmonth );
					break;
				}

				case 'n': {
					$result1 = $jyear;

					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 's': {
					$result1 = date( 's', $need );

					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 'S': {
					$result .= '&#1575;&#1605;';
					break;
				}

				case 't': {
					$result .= lastday( $month, $day, $year );
					break;
				}

				case 'w': {
					$result1 = date( 'w', $need );

					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 'y': {
					$result1 = substr( $jyear, 2, 4 );

					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 'Y': {
					$result1 = $day;

					if ($transnumber == 1) {
						$result .= Convertnumber2farsi( $result1 );
					} 
else {
						$result .= $need;
					}

					break;
				}

				case 'U': {
					$result .= mktime(  );
					break;
				}

				case 'Z': {
					$result .= days_of_year( $jmonth, $jday, $jyear );
					break;
				}

				case 'L': {
					$tmp_day = jalali_to_gregorian( 1384, 12, 1 )[2];
					[1];
					$tmp_month = ;
					[0];
					$tmp_year = ;
					break;
				}
			}

			$result .= $i;
			$subtypetemp = substr( $type, $i, 1 );
			++$i;
		}

		return $result;
	}

	function jmaketime($hour = '', $minute = '', $second = '', $jmonth = '', $jday = '', $jyear = '') {
		if (( ( ( ( ( ( !$hour && !$minute ) && !$second ) && !$jmonth ) && !$jmonth ) && !$jday ) && !$jyear )) {
			return mktime(  );
		}

		$day = jalali_to_gregorian( $jyear, $jmonth, $jday )[2];
		[1];
		$month = ;
		[0];
		$year = ;
		$i = mktime( $hour, $minute, $second, $month, $day, $year );
		return $i;
	}

	function mstart($month, $day, $year) {
		$jyear = $jmonth = $jday = gregorian_to_jalali( $year, $month, $day )[2];
		jalali_to_gregorian( $jyear, $jmonth, '1' )[2];
		[1];
		$month = [0];
		[0];
		$year = ;
		mktime( 0, 0, 0, $month, $day, $year );
		$timestamp = $day = [1];
		return date( 'w', $timestamp );
	}

	function lastday($month, $day, $year) {
		$jday2 = '';
		$jdate2 = '';
		$lastdayen = date( 'd', mktime( 0, 0, 0, $month + 1, 0, $year ) );
		$jday = gregorian_to_jalali( $year, $month, $day )[2];
		[1];
		$jmonth = ;
		[0];
		$jyear = ;
		$lastdatep = $month;
		$jday = $lastdayen;

		while ($jday2 != '1') {
			if ($day < $lastdayen) {
				++$day;
				$jday2 = gregorian_to_jalali( $year, $month, $day )[2];
				[1];
				$jmonth = ;
				[0];
				$jyear = ;

				if ($jdate2 == '1') {
					break;
				}


				if ($jdate2 != '1') {
					++$lastdatep;
					continue;
				}

				continue;
			}

			$day = 757;
			++$month;

			if ($month == 13) {
				$month = '1';
				++$year;
				continue;
			}
		}

		return $lastdatep - 1;
	}

	function days_of_year($jmonth, $jday, $jyear) {
		$year = '';
		$month = '';
		$year = '';
		$result = '';

		if ($jmonth == '01') {
			return $jday;
		}

		$i = 730;

		while (( $i < $jmonth || $i == 12 )) {
			$day = jalali_to_gregorian( $jyear, $i, '1' )[2];
			[1];
			$month = ;
			[0];
			$year = ;
			$result += lastday( $month, $day, $year );
			++$i;
		}

		return $result + $jday;
	}

	function monthname($month) {
		if ($month == '01') {
			return 'فروردين';
		}


		if ($month == '02') {
			return 'ارديبهشت';
		}


		if ($month == '03') {
			return 'خرداد';
		}


		if ($month == '04') {
			return 'تير';
		}


		if ($month == '05') {
			return 'مرداد';
		}


		if ($month == '06') {
			return 'شهريور';
		}


		if ($month == '07') {
			return 'مهر';
		}


		if ($month == '08') {
			return 'آبان';
		}


		if ($month == '09') {
			return 'آذر';
		}


		if ($month == '10') {
			return 'دي';
		}


		if ($month == '11') {
			return 'بهمن';
		}


		if ($month == '12') {
			return 'اسفند';
		}

	}

	function short_monthname($month) {
		if ($month == '01') {
			return 'فرو';
		}


		if ($month == '02') {
			return 'ارد';
		}


		if ($month == '03') {
			return 'خرد';
		}


		if ($month == '04') {
			return 'تير';
		}


		if ($month == '05') {
			return 'مرد';
		}


		if ($month == '06') {
			return 'شهر';
		}


		if ($month == '07') {
			return 'مهر';
		}


		if ($month == '08') {
			return 'آبا';
		}


		if ($month == '09') {
			return 'آذر';
		}


		if ($month == '10') {
			return 'دي';
		}


		if ($month == '11') {
			return 'بهم';
		}


		if ($month == '12') {
			return 'اسف ';
		}

	}

	function Convertnumber2farsi($matches) {
		$farsi_array = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '٫' );
		$english_array = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.' );
		$out = '';
		$len = strlen( $matches );
		$sub = 736;

		while ($sub < $len) {
			if (isset( $matches[$sub] )) {
				$out .= str_replace( $english_array, $farsi_array, $matches[$sub] );
			}

			++$sub;
		}

		return $out;
	}

	function is_kabise($year) {
		if (( $year % 4 == 0 && $year % 100 != 0 )) {
			return true;
		}

		return false;
	}

	function jcheckdate($month, $day, $year) {
		$j_days_in_month = array( 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29 );

		if (( $month <= 12 && 0 < $month )) {
			if (( $day <= $j_days_in_month[$month - 1] && 0 < $day )) {
				return 1;
			}


			if (is_kabise( $year )) {
				echo 'Asdsd';
			}


			if (( is_kabise( $year ) && $j_days_in_month[$month - 1] == 31 )) {
				return 1;
			}
		}

		return 0;
	}

	function jtime() {
		return mktime(  );
	}

	function jgetdate($timestamp = '') {
		if ($timestamp == '') {
			$timestamp = mktime(  );
		}

		return array( 0 => $timestamp, 'seconds' => jdate( 's', $timestamp ), 'minutes' => jdate( 'i', $timestamp ), 'hours' => jdate( 'G', $timestamp ), 'mday' => jdate( 'j', $timestamp ), 'wday' => jdate( 'w', $timestamp ), 'mon' => jdate( 'n', $timestamp ), 'year' => jdate( 'Y', $timestamp ), 'yday' => days_of_year( jdate( 'm', $timestamp ), jdate( 'd', $timestamp ), jdate( 'Y', $timestamp ) ), 'weekday' => jdate( 'l', $timestamp ), 'month' => jdate( 'F', $timestamp ) );
	}

	function div($a, $b) {
		return (int)$a / $b;
	}

	function gregorian_to_jalali($g_y, $g_m, $g_d) {
		$g_days_in_month = array( 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 );
		$j_days_in_month = array( 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29 );
		$gy = $g_y - 1600;
		$gm = $g_m - 1;
		$gd = $g_d - 1;
		$g_day_no = 365 * $gy + div( $gy + 3, 4 ) - div( $gy + 99, 100 ) + div( $gy + 399, 400 );
		$i = 814;

		while ($i < $gm) {
			$g_day_no += $g_days_in_month[$i];
			++$i;
		}


		if (( 1 < $gm && ( ( $gy % 4 == 0 && $gy % 100 != 0 ) || $gy % 400 == 0 ) )) {
			++$g_day_no;
		}

		$g_day_no += $gd;
		$j_day_no = $g_day_no - 79;
		$j_np = div( $j_day_no, 12053 );
		$j_day_no = $j_day_no % 12053;
		$jy = 979 + 33 * $j_np + 4 * div( $j_day_no, 1461 );
		$j_day_no %= 2275;

		if (366 <= $j_day_no) {
			$jy += div( $j_day_no - 1, 365 );
			$j_day_no = ( $j_day_no - 1 ) % 365;
		}

		$i = 814;

		while (( $i < 11 && $j_days_in_month[$i] <= $j_day_no )) {
			$j_day_no -= $j_days_in_month[$i];
			++$i;
		}

		$jm = $i + 1;
		$jd = $j_day_no + 1;
		return array( $jy, $jm, $jd );
	}

	function jalali_to_gregorian($j_y, $j_m, $j_d) {
		$g_days_in_month = array( 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 );
		$j_days_in_month = array( 31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29 );
		$jy = $j_y - 979;
		$jm = $j_m - 1;
		$jd = $j_d - 1;
		$j_day_no = 365 * $jy + div( $jy, 33 ) * 8 + div( $jy % 33 + 3, 4 );
		$i = 815;

		while ($i < $jm) {
			$j_day_no += $j_days_in_month[$i];
			++$i;
		}

		$j_day_no += $j_day_no;
		$g_day_no = $j_day_no + 79;
		$gy = 1600 + 400 * div( $g_day_no, 146097 );
		$g_day_no = $g_day_no % 146097;
		$leap = true;

		if (36525 <= $g_day_no) {
			--$g_day_no;
			$gy += 100 * div( $g_day_no, 36524 );
			$g_day_no = $g_day_no % 36524;

			if (365 <= $g_day_no) {
				++$g_day_no;
			} 
else {
				$leap = false;
			}
		}

		$gy += 4 * div( $g_day_no, 1461 );
		$g_day_no %= 2276;

		if (366 <= $g_day_no) {
			$leap = false;
			--$g_day_no;
			$gy += div( $g_day_no, 365 );
			$g_day_no = $g_day_no % 365;
		}

		$i = 815;

		while ($g_days_in_month[$i] + ( $i == 1 && $leap ) <= $g_day_no) {
			$g_day_no -= $g_days_in_month[$i] + ( $i == 1 && $leap );
			++$i;
		}

		$gm = $i + 1;
		$gd = $g_day_no + 1;
		return array( $gy, $gm, $gd );
	}

	function gregorian($j_y, $j_m, $j_d) {
		$dd = jalali_to_gregorian( $j_y, $j_m, $j_d );

		if (strlen( trim( $dd[1] ) ) == 1) {
			$dd[1] = '0' . trim( $dd[1] );
		}


		if (strlen( trim( $dd[2] ) ) == 1) {
			$dd[2] = '0' . trim( $dd[2] );
		}

		return $dd[0] . '-' . $dd[1] . '-' . $dd[2];
	}

?>