<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

		$customerID = function _calculateGeneralPriceDiscount($orderPrice, $log) {;
		db_query( 'select discount_id, price_range, percent_discount from ' . ORDER_PRICE_DISCOUNT_TABLE . ' order by price_range ' );
		$q = regGetIdByLogin( $log );
		$data = array(  );

		if ($row = db_fetch_row( $q )) {
			$data[] = $row;
		}


		if (count( $data ) != 0) {
			$i = 758;

			while ($i < count( $data ) - 1) {
				if (( $data[$i]['price_range'] < $orderPrice && $orderPrice < $data[$i + 1]['price_range'] )) {
					return $data[$i]['percent_discount'];
				}

				++$i;
			}


			if ($data[count( $data ) - 1]['price_range'] < $orderPrice) {
				return $data[count( $data ) - 1]['percent_discount'];
			}
		}

		return 0;
	}

	function dscCalculateDiscount($orderPrice, $log) {
		$dsc_by = _dscGetDiscountsArray( $orderPrice, $log );
		$coupon_discount = $dsc_by['coupon'];
		unset( $dsc_by[coupon] );
		$result_discount = (CONF_DISCOUNT_TYPE == '5' ? max( $dsc_by ) : array_sum( $dsc_by ));

		if ($result_discount + $coupon_discount < $orderPrice) {
			$discount = array( 'discount_percent' => $result_discount + $coupon_discount, 'discount_standart_unit' => ( $result_discount + $coupon_discount ) / 100 * $orderPrice, 'discount_current_unit' => ( $result_discount + $coupon_discount ) / 100 * $orderPrice, 'rest_standart_unit' => $orderPrice - ( $result_discount + $coupon_discount ) / 100 * $orderPrice, 'rest_current_unit' => show_priceWithOutUnit( $orderPrice - ( $result_discount + $coupon_discount ) / 100 * $orderPrice ) );
		} 
else {
			$discount = array( 'discount_percent' => 100, 'discount_standart_unit' => $orderPrice, 'discount_current_unit' => show_priceWithOutUnit( $orderPrice ), 'rest_standart_unit' => 0, 'rest_current_unit' => show_priceWithOutUnit( 0 ) );
		}

		return $discount;
	}

	function dscGetCartDiscounts($orderPrice, $log) {
		$dsc_by = _dscGetDiscountsArray( $orderPrice, $log );
		$coupon_discount = $dsc_by['coupon'];
		unset( $dsc_by[coupon] );
		$result_discount = (CONF_DISCOUNT_TYPE == '5' ? max( $dsc_by ) : array_sum( $dsc_by ));

		if (0 < $orderPrice - ( $result_discount + $coupon_discount ) / 100 * $orderPrice) {
			$discount = array( 'discount_percent' => $result_discount + $coupon_discount, 'discount_standart_unit' => ( $result_discount + $coupon_discount ) / 100 * $orderPrice, 'discount_current_unit' => show_priceWithOutUnit( ( $result_discount + $coupon_discount ) / 100 * $orderPrice ), 'rest_standart_unit' => $orderPrice - ( $result_discount + $coupon_discount ) / 100 * $orderPrice, 'rest_current_unit' => show_priceWithOutUnit( $orderPrice - ( $result_discount + $coupon_discount ) / 100 * $orderPrice ) );
		} 
else {
			$discount = array( 'discount_percent' => 100, 'discount_standart_unit' => $orderPrice, 'discount_current_unit' => show_priceWithOutUnit( $orderPrice ), 'rest_standart_unit' => 0, 'rest_current_unit' => show_priceWithOutUnit( 0 ) );
		}

		return $discount;
	}

	function __dscGetCartDiscounts($cart_subtotal, $log) {
		$dsc_by = _dscGetDiscountsArray( $cart_subtotal, $log );
		$coupon_discount = $dsc_by['coupon'];
		unset( $dsc_by[coupon] );
		$result_discount = (CONF_DISCOUNT_TYPE == '5' ? max( $dsc_by ) : array_sum( $dsc_by ));
		$r = array( 'discount_percent' => ($cart_subtotal ? $result_discount * 100 / $cart_subtotal : 0), 'coupon_discount' => array( 'su' => $coupon_discount, 'cu' => show_priceWithOutUnit( $coupon_discount ) ), 'other_discounts' => array( 'su' => $result_discount, 'cu' => show_priceWithOutUnit( $result_discount ) ), 'total' => array( 'su' => $cart_subtotal - $result_discount - $coupon_discount, 'cu' => show_priceWithOutUnit( $cart_subtotal - $result_discount - $coupon_discount ) ) );

		if ($r['total']['su'] < 0) {
			$r['total']['su'] = 0;
			$r['total']['cu'] = 0;
		}

		return $r;
	}

	function _dscGetDiscountsArray($cart_subtotal, $log) {
		return array( 'coupon' => (CONF_DSC_COUPONS_ENABLED == '1' ? _getDiscountByCoupon( $cart_subtotal ) / $cart_subtotal * 100 : 0), 'usergroup' => (( ( CONF_DISCOUNT_TYPE == 2 || CONF_DISCOUNT_TYPE == 5 ) || CONF_DISCOUNT_TYPE == 4 ) ? _getDiscountByCustomerGroup( $cart_subtotal, $log ) : 0), 'amount' => (( ( CONF_DISCOUNT_TYPE == 5 || CONF_DISCOUNT_TYPE == 3 ) || CONF_DISCOUNT_TYPE == 4 ) ? _getDiscountByAmount( $cart_subtotal ) : 0), 'orders' => (( CONF_DISCOUNT_TYPE == 5 || CONF_DISCOUNT_TYPE == 4 ) ? _getDiscountByOrdersSum( $cart_subtotal, $log ) : 0) );
	}

	function _getDiscountByCoupon($cart_subtotal) {
		ClassManager::includeClass( 'discount_coupon' );
		return discount_coupon::getDiscount( $cart_subtotal );
	}

	function _getDiscountByCustomerGroup($cart_subtotal, $log) {
		$discount_percent = 716;
		regGetIdByLogin( $log );

		if (!is_bool( $customerID =  )) {
			$customer_group = GetCustomerGroupByCustomerId( $customerID );
			$discount_percent = ($customer_group !== false ? $customer_group['custgroup_discount'] : 0);
		}

		return $discount_percent;
	}

	function _getDiscountByAmount($cart_subtotal) {
		if (!is_null( $cart_subtotal )) {
			$res = db_query( $sql );
			db_fetch_assoc( $res );
			$row = $sql = 'select * from ' . ORDER_PRICE_DISCOUNT_TABLE . ( ' where price_range<=' . $cart_subtotal . ' and discount_type=\'A\' order by price_range desc limit 1' );
			$discount_percent = ($row !== false ? $row['percent_discount'] : 0);
			return $discount_percent;
		}

		return 1;
	}

	function _getDiscountByOrdersSum($cart_subtotal, $log) {
		$order_status = CONF_ORDSTATUS_DELIVERED;
		$discount_percent = 746;
		$sql = 'select sum(order_amount) as orders_sum from ?#ORDERS_TABLE where customerID=?';
		$sql .= ($order_status ? ' and statusID=?' : '');
		$res = db_phquery( $sql, regGetIdByLogin( $log ), $order_status );
		$r = db_fetch_assoc( $res );
		$orders_sum = intval( $r['orders_sum'] );

		if (0 < $orders_sum) {
			$sql = 'select * from ' . ORDER_PRICE_DISCOUNT_TABLE . ( ' where price_range<=' . $orders_sum . ' and discount_type=\'O\' order by price_range desc limit 1' );
			$res = db_query( $sql );
			$row = db_fetch_assoc( $res );
			$discount_percent = ($row !== false ? $row['percent_discount'] : 0);
		}

		return $discount_percent;
	}

	function dscGetAllOrderPriceDiscounts() {
		return _dscGetAllDiscounts( 'A' );
	}

	function dscGetAllOrderSumDiscounts() {
		return _dscGetAllDiscounts( 'O' );
	}

	function dscAddOrderPriceDiscount($price_range, $percent_discount) {
		return _dscAddDiscount( $price_range, $percent_discount, 'A' );
	}

	function dscAddOrderSumDiscount($price_range, $percent_discount) {
		return _dscAddDiscount( $price_range, $percent_discount, 'O' );
	}

	function dscDeleteOrderPriceDiscount($discount_id) {
		return dscDeleteDiscount( $discount_id );
	}

	function dscUpdateOrderPriceDiscount($discount_id, $price_range, $percent_discount) {
		return dscUpdateDiscount( $discount_id, $price_range, $percent_discount );
	}

		$q = function _dscGetAllDiscounts($dsc_type = 'A') {;
		$data = array(  );
		db_fetch_row( $q );

		if ($row = db_query( 'select discount_id, price_range, percent_discount from ' . ORDER_PRICE_DISCOUNT_TABLE . ( ' where discount_type=\'' . $dsc_type . '\' order by price_range' ) )) {
			$row['price_range'] = intval( $row['price_range'] );
			$data[] = $row;
		}

		return $data;
	}

	function _dscAddDiscount($price_range, $percent_discount, $dsc_type = 'A') {
		$q = db_query( 'select price_range, percent_discount from ' . ORDER_PRICE_DISCOUNT_TABLE . ( ' where discount_type=\'' . $dsc_type . '\' and price_range=' . $price_range ) );

		if ($row = db_fetch_row( $q )) {
			return false;
		}

		db_query( 'insert into ' . ORDER_PRICE_DISCOUNT_TABLE . ' ( price_range, percent_discount, discount_type ) ' . ( ' values( ' . $price_range . ', ' . $percent_discount . ', \'' . $dsc_type . '\' )' ) );
		return true;
	}

	function dscDeleteDiscount($discount_id) {
		db_query( 'delete from ' . ORDER_PRICE_DISCOUNT_TABLE . ( ' where discount_id=' . $discount_id . ' ' ) );
	}

	function dscUpdateDiscount($discount_id, $price_range, $percent_discount) {
		$q = db_query( 'select price_range, percent_discount from ' . ORDER_PRICE_DISCOUNT_TABLE . ( ' where price_range=' . $price_range . ' AND discount_id <> ' . $discount_id ) );

		if ($row = db_fetch_row( $q )) {
			return false;
		}

		db_query( 'update ' . ORDER_PRICE_DISCOUNT_TABLE . ( ' set price_range=' . $price_range . ', percent_discount=' . $percent_discount . ' ' ) . ( ' where discount_id=' . $discount_id . ' ' ) );
		return true;
	}

?>