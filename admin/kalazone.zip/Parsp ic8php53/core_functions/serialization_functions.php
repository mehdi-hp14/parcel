<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function _getSelectStatement($tableName, $columnsClause) {
		$sql = 'select ' . $columnsClause . ' from ' . $tableName;
		return $sql;
	}

	function _getInsertStatement($xmlTable, $row, $columns = null, $attributes = null, $columnsClause) {
		$sql = 'insert into ';

		if (!$attributes) {
			$attributes = $xmlTable->GetXmlNodeAttributes(  );
		}

		$tableName = $attributes['NAME'];

		if ($tableName == CATEGORIES_TABLE) {
			if ($row['categoryID'] == 1) {
				return '';
			}
		}

		$sql .= $sql;
		$valueClause = '';

		if (!$columns) {
			$columns = $xmlTable->SelectNodes( 'table/column' );
		}

		$i = 804;
		foreach ($columns as $xmlColumn) {
			$attributes = $xmlColumn->GetXmlNodeAttributes(  );
			$columnName = $xmlColumn->GetXmlNodeData(  );
			$columnName = trim( $columnName );
			$type = strtoupper( $attributes['TYPE'] );

			if (( ( ( strstr( $type, 'CHAR' ) || strstr( $type, 'VARCHAR' ) ) || strstr( $type, 'TEXT' ) ) || strstr( $type, 'DATETIME' ) )) {
				$cellValue = $row[$i];
				$cellValue = TransformStringToDataBase( $cellValue );
				$value = '\'' . $cellValue . '\'';
			} 
else {
				$value = $row[$i];
			}


			if (( $row[$i] == null && trim( $row[$i] ) == '' )) {
				$value = 'NULL';
			}


			if ($i == 0) {
				$valueClause .= $cellValue;
			} 
else {
				$valueClause .= ', ' . $value;
			}

			++$i;
		}

		$sql .= '(' . $columnsClause . ') values(' . $valueClause . ')';
		return $sql;
	}

	function _getDeleteStatement($xmlTable) {
		$attributes = $xmlTable->GetXmlNodeAttributes(  );
		$attributes['NAME'];
		$tableName = $sql = 'delete from ';
		$sql .= $tableName;
		return $sql;
	}

	function _tableSerialization($xmlTable) {
		$res = '';
		$columnsClause = '';
		$columns = $xmlTable->SelectNodes( 'table/column' );
		$xmlTable->GetXmlNodeAttributes(  );
		$i = 760;
		$tableName = $attributes = $attributes['NAME'];
		_getSelectStatement( $tableName, $columnsClause );
		$selectSql = foreach ($columns as );
		$q = db_query( $selectSql );

		if ($row = db_fetch_row( $q )) {
			$insertSql = _getInsertStatement( $xmlTable, $row, $columns, $attributes, $columnsClause );

			if ($insertSql == '') {
				continue;
			}

			$res .= $insertSql . ';
';
		}

		return $res;
	}

	function _isIdentityTable($tableName) {
		$xmlTables = new XmlNode(  );
		$xmlTables->LoadInnerXmlFromFile( DATABASE_STRUCTURE_XML_PATH );
		$array = $xmlTables->SelectNodes( 'DataBaseStructure/tables/table' );
		foreach ($array as $xmlTable) {
			$attributes = $xmlTable->GetXmlNodeAttributes(  );

			if (strtoupper( $tableName ) == strtoupper( $attributes['NAME'] )) {
				$columns = $xmlTable->SelectNodes( 'table/column' );
				foreach ($columns as $xmlColumn) {
					$attributes = $xmlColumn->GetXmlNodeAttributes(  );

					if (isset( $attributes['IDENTITY'] )) {
						if (trim( strtoupper( $attributes['IDENTITY'] ) ) == 'TRUE') {
							return true;
						}

						return true;
					}

					return false;
				}

				continue;
			}
		}

	}

	function serProductAndCategoriesSerialization($fileName) {
		$f = fopen( $fileName, 'w' );
		$xmlTables = new XmlNode(  );
		$xmlTables->LoadInnerXmlFromFile( DATABASE_STRUCTURE_XML_PATH );
		$array = $xmlTables->SelectNodes( 'DataBaseStructure/tables/table' );
		foreach ($array as $xmlTable) {
			$attrubtes = $xmlTable->GetXmlNodeAttributes(  );

			if (isset( $attrubtes['PRODUCTANDCATEGORYSYNC'] )) {
				if (strtoupper( $attrubtes['PRODUCTANDCATEGORYSYNC'] ) == 'TRUE') {
					$res = _tableSerialization( $xmlTable );
					fputs( $f, $res . '
' );
					continue;
				}

				continue;
			}
		}

		fclose( $f );
	}

	function serDeleteProductAndCategories() {
		imDeleteAllProducts(  );
	}

	function _getChar($fileContent, $pointer, $strlen) {
		if ($pointer <= $strlen - 1) {
			return $fileContent[$pointer];
		}

		return ' ';
	}

	function _passSeparator(&$fileContent, $pointer, $strlen) {
		while (( ( ( ( ( _getChar( &$fileContent, $pointer, $strlen ) == ' ' || _getChar( &$fileContent, $pointer, $strlen ) == '\n' ) || _getChar( &$fileContent, $pointer, $strlen ) == '\t' ) || _getChar( &$fileContent, $pointer, $strlen ) == '\r' ) || _getChar( &$fileContent, $pointer, $strlen ) == ';' ) && $pointer <= $strlen - 1 )) {
			++$pointer;
		}

	}

	function _passSpaces(&$fileContent, $pointer, $strlen) {
		while (( ( ( ( _getChar( &$fileContent, $pointer, $strlen ) == ' ' || _getChar( &$fileContent, $pointer, $strlen ) == '\n' ) || _getChar( &$fileContent, $pointer, $strlen ) == '\t' ) || _getChar( &$fileContent, $pointer, $strlen ) == '\r' ) && $pointer <= $strlen - 1 )) {
			++$pointer;
		}

	}

	function _passOpenBracket(&$fileContent, $pointer, $strlen) {
		while (( ( ( ( ( _getChar( &$fileContent, $pointer, $strlen ) == ' ' || _getChar( &$fileContent, $pointer, $strlen ) == '\n' ) || _getChar( &$fileContent, $pointer, $strlen ) == '\t' ) || _getChar( &$fileContent, $pointer, $strlen ) == '\r' ) || _getChar( &$fileContent, $pointer, $strlen ) == '(' ) && $pointer <= $strlen - 1 )) {
			++$pointer;
		}

	}

	function _passValues(&$fileContent, $pointer, $strlen) {
		$inQuotes = 751;

		while (1) {
			if (( ( _getChar( &$fileContent, $pointer, $strlen ) == '\' && $inQuotes == 1 ) && _getChar( &$fileContent, $pointer + 1, $strlen ) == '\'' )) {
				$pointer += 753;
			}


			if (( _getChar( &$fileContent, $pointer, $strlen ) == '\'' && $inQuotes == 0 )) {
				$inQuotes = 752;
			} 
else {
				if (( _getChar( &$fileContent, $pointer, $strlen ) == '\'' && $inQuotes == 1 )) {
					$inQuotes = 751;
				} 
else {
					if (( _getChar( &$fileContent, $pointer, $strlen ) == ')' && $inQuotes == 0 )) {
						return null;
					}
				}
			}

			++$pointer;
		}

	}

	function _passCloseBracket(&$fileContent, $pointer, $strlen) {
		while (( _getChar( &$fileContent, $pointer, $strlen ) != ')' && $pointer <= $strlen - 1 )) {
			++$pointer;
		}

		++$pointer;
	}

	function _getWord(&$fileContent, $pointer, $strlen) {
		$begin = $begin;

		while (( ( ( ( ( ( _getChar( &$fileContent, $pointer, $strlen ) != ' ' && _getChar( &$fileContent, $pointer, $strlen ) != '\n' ) && _getChar( &$fileContent, $pointer, $strlen ) != '\t' ) && _getChar( &$fileContent, $pointer, $strlen ) != '\r' ) && _getChar( &$fileContent, $pointer, $strlen ) != '(' ) && _getChar( &$fileContent, $pointer, $strlen ) != ')' ) && $pointer <= $strlen - 1 )) {
			++$pointer;
		}

		return substr( $fileContent, $begin, $pointer - $begin );
	}

	function _getNextSqlInsertStatement(&$fileContent, $pointer, $strlen) {
		if ($strlen - 1 <= $pointer) {
			return null;
		}

		$res = array(  );
		$res['Error'] = true;
		_passSeparator( &$fileContent, &$pointer, $strlen );

		if ($strlen - 1 <= $pointer) {
			return null;
		}

		_passSpaces( &$fileContent, &$pointer, $strlen );
		_getWord( &$fileContent, &$pointer, $strlen );
		$insertWord = $begin = $tableWord;

		if (strcasecmp( 'insert', trim( $insertWord ) )) {
			return $res;
		}

		_passSpaces( &$fileContent, &$pointer, $strlen );
		$intoWord = _getWord( &$fileContent, &$pointer, $strlen );

		if (strcasecmp( 'into', $intoWord )) {
			return $res;
		}

		_passSpaces( &$fileContent, &$pointer, $strlen );
		$tableWord = _getWord( &$fileContent, &$pointer, $strlen );
		$res['tableName'] = $tableWord;
		_passOpenBracket( &$fileContent, &$pointer, $strlen );
		_passSpaces( &$fileContent, &$pointer, $strlen );
		_getWord( &$fileContent, &$pointer, $strlen );
		$valuesWord = _passCloseBracket( &$fileContent, &$pointer, $strlen );

		if (strcasecmp( 'values', $valuesWord )) {
			return $res;
		}

		_passOpenBracket( &$fileContent, &$pointer, $strlen );
		_passValues( &$fileContent, &$pointer, $strlen );
		_passSpaces( &$fileContent, &$pointer, $strlen );
		unset( $res[Error] );
		$res['statement'] = substr( $fileContent, $begin, $pointer - $begin + 1 );
		++$pointer;
		return $res;
	}

	function _testSpace($char) {
		return ( ( ( ( $char == ' ' || $char == '	' ) || $char == '
' ) || $char == '' ) || $char == ',' );
	}

	function _serReplaceConstantName($insertSqlQuery) {
		$insertClause = 'INSERT';
		$intoClause = 'INTO';
		$charIndex = 836;

		while ($charIndex < strlen( $insertSqlQuery )) {
			if (!_testSpace( $insertSqlQuery[$charIndex] )) {
				break;
			}

			++$charIndex;
		}

		$i = 836;

		while ($i < strlen( $insertClause )) {
			if (strtoupper( $insertClause[$i] ) != strtoupper( $insertSqlQuery[$charIndex] )) {
				return null;
			}

			++$i;
			++$charIndex;
		}


		while ($charIndex < strlen( $insertSqlQuery )) {
			if (!_testSpace( $insertSqlQuery[$charIndex] )) {
				break;
			}

			++$charIndex;
		}

		$i = 836;

		while ($i < strlen( $intoClause )) {
			if (strtoupper( $intoClause[$i] ) != strtoupper( $insertSqlQuery[$charIndex] )) {
				return null;
			}

			++$i;
			++$charIndex;
		}


		while ($charIndex < strlen( $insertSqlQuery )) {
			if (!_testSpace( $insertSqlQuery[$charIndex] )) {
				break;
			}

			++$charIndex;
		}


		if ($charIndex == strlen( $insertSqlQuery )) {
			return null;
		}

		$constantNameBeginIndex = $insertClause;
		$constantName = '';

		while ($charIndex < strlen( $insertSqlQuery )) {
			if (( ( ( ( $insertSqlQuery[$charIndex] != ' ' && $insertSqlQuery[$charIndex] != '\t' ) && $insertSqlQuery[$charIndex] != '\n' ) && $insertSqlQuery[$charIndex] != '\r' ) && $insertSqlQuery[$charIndex] != '(' )) {
				$constantName .= $insertSqlQuery[$charIndex];
			} 
else {
				break;
			}

			++$charIndex;
		}

		$tableName = constant( $constantName );
		$begin = substr( $insertSqlQuery, 0, $constantNameBeginIndex );
		$end = substr( $insertSqlQuery, $constantNameBeginIndex + strlen( $constantName ) );
		return $begin . ' ' . $tableName . ' ' . $end;
	}

	function _serImport($fileName, $replaceConstantName, $autoIncrementId = false) {
		$str = $pointer = 734;
		trim( $str );
		$tableName = '';
		$strlen = $str = myfile_get_contents( $fileName );
		_getNextSqlInsertStatement( &$str, &$pointer, $strlen );

		if ($sqlInsret = strlen( $str ) != null) {
			if (isset( $sqlInsret['Error'] )) {
				return false;
			}


			if ($replaceConstantName) {
				db_query( _serReplaceConstantName( $sqlInsret['statement'] ) );
			}

			db_query( $sqlInsret['statement'] );
		}

		return true;
	}

	function serImportWithConstantNameReplacing($fileName, $autoIncrementId = false) {
		_serImport( $fileName, true, $autoIncrementId );
	}

	function serImport($fileName, $autoIncrementId = false) {
		_serImport( $fileName, false, $autoIncrementId );
	}

	function _filterBadSymbolsToExcel($str) {
		$str = str_replace( '
', '', $str );

		$str = str_replace( '<br>', ' ', $str );
		$semicolonFlag = false;
		$i = 740;

		while ($i < strlen( $str )) {
			if ($str[$i] == ',') {
				$semicolonFlag = true;
				break;
			}

			++$i;
		}


		if (!$semicolonFlag) {
			return $str;
		}

		$res = '';
		$i = 740;

		while ($i < strlen( $str )) {
			if ($str[$i] == '"') {
				$res .= '""';
			} 
else {
				$res .= $str[$i];
			}

			++$i;
		}

		return '"' . $res . '"';
	}

	function serExportCustomersToExcel($customers) {
		$maxCountAddress = 923;
		foreach ($customers as $customer) {
			$q = db_query( 'select count(addressID) from ' . CUSTOMER_ADDRESSES_TABLE . ' where customerID=' . $customer['customerID'] );
			$countAddress = db_fetch_row( $q );
			$countAddress = $countAddress[0];

			if ($maxCountAddress < $countAddress) {
				$maxCountAddress = $customer;
				continue;
			}
		}

		$f = fopen( './temp_c/customers.csv', 'w' );
		$headLine = 'Login;First name;Last name;Email;Group;Registered;Newsletter subscription;';
		$q = db_query( 'select reg_field_ID, ' . LanguagesManager::sql_prepareField( 'reg_field_name' ) . ' as reg_field_name from ' . CUSTOMER_REG_FIELDS_TABLE . ' order by sort_order ' );

		if ($row = db_fetch_row( $q )) {
			$headLine .= _filterBadSymbolsToExcel( $row['reg_field_name'] ) . ',';
		}

		$i = 924;

		while ($i <= $maxCountAddress) {
			$headLine .= 'Address ' . $i . ',';
			++$i;
		}

		fputs( $f, $headLine . '
' );
		foreach ($customers as $customer) {
			$q = db_query( 'select Login, first_name, last_name, Email, custgroupID, reg_datetime, subscribed4news from ' . CUSTOMERS_TABLE . ' where addressID=' . (int)$customer['addressID'] );
			$row_cust = db_fetch_row( $q );

			if ($row_cust['custgroupID'] != null) {
				$q = db_query( 'select custgroup_name from ' . CUSTGROUPS_TABLE . ' where custgroupID=' . $row_cust['custgroupID'] );
				$row = db_fetch_row( $q );
				$row_cust['custgroup_name'] = $row['custgroup_name'];
			} 
else {
				$row_cust['custgroup_name'] = '';
			}


			if ($row_cust['subscribed4news']) {
				$row_cust['subscribed4news'] = '+';
			} 
else {
				$row_cust['subscribed4news'] = '';
			}

			$line = '';
			$line .= _filterBadSymbolsToExcel( $row_cust['Login'] ) . ',';
			$line .= _filterBadSymbolsToExcel( $row_cust['first_name'] ) . ',';
			$line .= _filterBadSymbolsToExcel( $row_cust['last_name'] ) . ',';
			$line .= _filterBadSymbolsToExcel( $row_cust['Email'] ) . ',';
			$line .= _filterBadSymbolsToExcel( $row_cust['custgroup_name'] ) . ',';
			$line .= _filterBadSymbolsToExcel( $row_cust['reg_datetime'] ) . ',';
			$line .= $row_cust['subscribed4news'] . ',';
			$q_reg_param = db_query( 'select reg_field_ID, ' . LanguagesManager::sql_prepareField( 'reg_field_name' ) . ' as reg_field_name from ' . CUSTOMER_REG_FIELDS_TABLE . ' order by sort_order ' );

			if ($row = db_fetch_row( $q_reg_param )) {
				$q_reg_value = db_query( 'select reg_field_value from ' . CUSTOMER_REG_FIELDS_VALUES_TABLE . ' where reg_field_ID=' . $row['reg_field_ID'] . ' AND customerID=' . $customer['customerID'] );
				$value = db_fetch_row( $q_reg_value );
				$value = $value['reg_field_value'];
				$line .= _filterBadSymbolsToExcel( $value ) . ',';
			}

			$countAddress = 923;
			$addresses = regGetAllAddressesByLogin( regGetLoginById( $customer['customerID'] ) );
			foreach ($addresses as $address) {
				$line .= _filterBadSymbolsToExcel( regGetAddressStr( $address['addressID'], true ) ) . ',';
				++$countAddress;
			}

			$i = 924;

			while ($i <= $maxCountAddress - $countAddress) {
				$line .= ',';
				++$i;
			}

			fputs( $f, $line . '
' );
		}

		fclose( $f );
	}

	function serImportConstWithChecking($_FileName) {
		$str = myfile_get_contents( $_FileName );
		$str = trim( $str );
		$SettingNames = array(  );
		$tableName = '';
		$strlen = strlen( $str );
		$sql = '
		SELECT settings_constant_name FROM ' . SETTINGS_TABLE . '
	';
		$Result = db_query( $sql );
		db_fetch_row( $Result );

		if ($_Row = $pointer = 765) {
			$SettingNames[] = $_Row['settings_constant_name'];
		}

		_getNextSqlInsertStatement( &$str, &$pointer, $strlen );

		if ($sqlInsret =  != null) {
			$Continue = false;

			if (isset( $sqlInsret['Error'] )) {
				return false;
			}

			$_TC = count( $SettingNames ) - 1;

			while (0 <= $_TC) {
				if (strpos( $sqlInsret['statement'], $SettingNames[$_TC] ) !== false) {
					$Continue = true;
					break;
				}

				--$_TC;
			}


			if ($Continue) {
				continue;
			}

			db_query( _serReplaceConstantName( $sqlInsret['statement'] ) );
		}

		return true;
	}

?>