<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function submitNewBankAcc($bankName, $accNo, $accHolder) {
		db_query( 'INSERT INTO ' . CBANKBILL_ACCOUNTS_DB_TABLE . ( ' (bankname, accountno, holder) VALUES("' . $bankName . '", "' . $accNo . '", "' . $accHolder . '")' ) );
	}

	function getBankAccounts() {
		db_query( 'SELECT * FROM ' . CBANKBILL_ACCOUNTS_DB_TABLE );

		if ($res = $q = db_fetch_row( $q )) {
			$data[] = $res;
		}

		return $data;
	}

	function delbankAcc($bankID) {
		db_query( 'DELETE FROM ' . CBANKBILL_ACCOUNTS_DB_TABLE . ( ' WHERE id=' . $bankID ) );
	}

	function getpendingOrdersForUserByLogin($login) {
		$customerID = regGetIdByLogin( $login );
		$q = db_query( 'SELECT orderID, order_amount FROM ' . ORDERS_TABLE . ' WHERE statusID= ' . CONF_NEW_ORDER_STATUS . ' and customerID = ' . $customerID );

		if ($res = db_fetch_row( $q )) {
			$res['order_amount'] = show_price( $res['order_amount'] );
			$data[] = $res;
		}

		return $data;
	}

	function addNewBill($login, $billfor, $account, $date, $billno, $amount) {
		$customerID = regGetIdByLogin( $login );
		db_query( 'INSERT INTO ' . BANKBILLS_TABLE . ( ' (customerID, billfor, Account, date, billno, amount) VALUES(' . $customerID . ', "' . $billfor . '", "' . $account . '", "' . $date . '", "' . $billno . '", "' . $amount . '")' ) );
	}

	function bankbillsList($page = 1) {
		$rowsPerPage = 750;
		$pageNum = 731;

		if ($page) {
			$pageNum = $htmlout;
		}

		$offset = ( $pageNum - 1 ) * $rowsPerPage;
		$query = 'SELECT * FROM ' . BANKBILLS_TABLE . ( ' LIMIT ' . $offset . ', ' . $rowsPerPage );

		if (!( $result = db_query( $query ))) {
			exit( 'Error, query failed' );
			(bool)true;
		}


		if ($row = db_fetch_row( $result )) {
			$row['login'] = regGetLoginById( $row['customerID'] );
			$htmlout[] = $row;
		}

		return $htmlout;
	}

	function pager($pageNum = 1) {
		$rowsPerPage = 786;
		$query = 'SELECT COUNT(id) AS id FROM ' . BANKBILLS_TABLE;

		if (!( $result = db_query( $query ))) {
			exit( 'Error, query failed' );
			(bool)true;
		}

		$row = db_fetch_row( $result );
		$numrows = $row['id'];
		$maxPage = ceil( $numrows / $rowsPerPage );

		if (1 < $pageNum) {
			$page = $pageNum - 1;
			$prev = ' <a href="admincp.php?tab=custord&sub=bank_bills&page=' . $page . '">< ' . ADMIN_BANK_PREV . '</a> ';
			$first = ' <a href="admincp.php?tab=custord&sub=bank_bills&page=1"><< ' . ADMIN_BANK_FIRST . '</a> ';
		}


		if ($pageNum < $maxPage) {
			$page = $pageNum + 1;
			$next = ' <a href="admincp.php?tab=custord&sub=bank_bills&page=' . $page . '">' . STRING_NEXT . ' ></a> ';
			$last = ' <a href="admincp.php?tab=custord&sub=bank_bills&page=' . $maxPage . '">' . ADMIN_BANK_LAST . ' >></a> ';
		}

		$htmlout .= $first . $prev . ' ' . ADMIN_BANK_SHOWING_PAGE . ( ' <strong>' . $pageNum . '</strong> ' ) . STRING_FROM . ( ' <strong>' . $maxPage . '</strong>  ' ) . $next . $last;
		return $htmlout;
	}

	function confirmbill($billID) {
		db_query( $query );

		if (!( $result = $query = 'SELECT * FROM ' . BANKBILLS_TABLE . ' WHERE id=' . $billID)) {
			exit( 'Error, query failed' );
			(bool)true;
		}

		$res = db_fetch_row( $result );

		if ($result) {
			$res['amount'];
			$cID = $amount = $res['customerID'];
			db_query( 'UPDATE ' . CUSTOMERS_TABLE . ' SET credit = credit + ' . $amount . ' WHERE customerID=' . $cID );
			db_query( 'UPDATE ' . BANKBILLS_TABLE . ' SET status = \'ok\' WHERE id=' . $billID );
		}

	}

	function dellbill($billID) {
		if (!( db_query( 'DELETE FROM ' . BANKBILLS_TABLE . ' WHERE id=' . $billID ))) {
			exit( mysql_error(  ) );
			(bool)true;
		}

	}

	define( 'CBANKBILL_ACCOUNTS_DB_TABLE', DBTABLE_PREFIX . 'bankbill_accounts' );
	define( 'CBANKBILL_DB_TABLE', DBTABLE_PREFIX . 'bankbills' );
?>