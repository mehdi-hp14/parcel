<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function GetCustomerGroupByCustomerId($customerID) {
		$customerID = (int)$customerID;
		$q = db_query( 'select custgroupID from ' . CUSTOMERS_TABLE . ( ' where customerID=' . $customerID ) );
		$customer = db_fetch_row( $q );

		if (( is_null( $customer['custgroupID'] ) || trim( $customer['custgroupID'] ) == '' )) {
			return false;
		}

		$q = db_query( 'select custgroupID, custgroup_name, custgroup_discount, sort_order from ' . CUSTGROUPS_TABLE . ' where custgroupID=' . $customer['custgroupID'] );
		$row = db_fetch_row( $q );
		$row['custgroup_name'] = TransformDataBaseStringToText( $row['custgroup_name'] );
		return $row;
	}

	function GetGroupById($groupID) {
		db_query( 'select * from ' . CUSTGROUPS_TABLE . ' where custgroupID=' . $groupID );
		$q = $groupID = (int)$groupID;
		$row = db_fetch_row( $q );
		$row['custgroup_name'] = TransformDataBaseStringToText( $row['custgroup_name'] );
		return $row;
	}

	function GetAllCustGroupsAccess($admin_departments) {
		db_query( 'select * from ' . CUSTGROUPS_TABLE . ' order by sort_order, custgroup_name ' );
		$data = array(  );

		if ($r = $q = db_fetch_row( $q )) {
			$row = array(  );
			$act_list = '';
			foreach ($admin_departments as $value) {
				$subact_list = '';
				foreach ($value['sub_departments'] as $val) {

					if (strstr( $r['action_list'], $val['id'] )) {
						$subact_list .= '<li>' . $val['name'] . '</li>';
						continue;
					}
				}


				if ($subact_list != '') {
					$act_list .= '<b>- ' . $value['name'] . ':</b><br><small><ul style=\'margin-right:20px;\'>' . $subact_list . '</ul></small>';
					continue;
				}
			}

			$row['act_list'] = $act_list;
			$row['custgroupID'] = $r['custgroupID'];
			$row['custgroup_name'] = TransformDataBaseStringToText( $r['custgroup_name'] );
			$row['custgroup_discount'] = $r['custgroup_discount'];
			$row['sort_order'] = $r['sort_order'];
			$data[] = $row;
		}

		return $data;
	}

	function GetAllCustGroups() {
		$q = db_query( 'select * from ' . CUSTGROUPS_TABLE . ' order by sort_order, custgroup_name ' );
		$data = array(  );

		if ($r = db_fetch_row( $q )) {
			$row = array(  );
			$row['custgroupID'] = $r['custgroupID'];
			$row['custgroup_name'] = TransformDataBaseStringToText( $r['custgroup_name'] );
			$row['custgroup_discount'] = $r['custgroup_discount'];
			$row['sort_order'] = $r['sort_order'];
			$data[] = $row;
		}

		return $data;
	}

	function DeleteCustGroup($custgroupID) {
		db_query( 'update ' . CUSTOMERS_TABLE . ' set custgroupID=NULL ' . ' where custgroupID=\'' . $custgroupID . '\'' );
		db_query( 'delete from ' . CUSTGROUPS_TABLE . ' where custgroupID=\'' . $custgroupID . '\'' );
	}

	function UpdateCustGroup($custgroupID, $custgroup_name, $custgroup_discount, $sort_order) {
		$custgroup_name = TransformStringToDataBase( $custgroup_name );
		db_query( 'update ' . CUSTGROUPS_TABLE . ' set  ' . 'custgroup_name=\'' . $custgroup_name . '\\', ' . 'custgroup_discount=\'' . (double)$custgroup_discount . '\\', ' . 'sort_order=\'' . (int)$sort_order . '\' ' . 'where custgroupID=\'' . $custgroupID . '\'' );
	}

	function Updateaccess($custgroupID, $action_list) {
		$custgroup_name = TransformStringToDataBase( $custgroup_name );
		db_query( 'update ' . CUSTGROUPS_TABLE . ' set  ' . 'action_list=\'' . $action_list . '\' ' . 'where custgroupID=\'' . $custgroupID . '\'' );
	}

	function AddCustGroup($custgroup_name, $custgroup_discount, $sort_order) {
		$custgroup_name = TransformStringToDataBase( $custgroup_name );
		db_query( 'insert into ' . CUSTGROUPS_TABLE . '( custgroup_name, custgroup_discount, sort_order ) ' . 'values( \'' . $custgroup_name . '\', \'' . (double)$custgroup_discount . '\', \'' . (int)$sort_order . '\' )' );
	}

?>