<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class dword {
		var $bitArray = null;

		function dword() {
			$this->bitArray = array(  );
			$i = 704;

			while ($i <= 32) {
				$this->bitArray[$i - 1] = 0;
				++$i;
			}

		}

		function _setbyte($byte, $displacement) {
			$this->bitArray[$displacement + 0] = (( $byte & 1 ) != 0 ? 1 : 0);
			$this->bitArray[$displacement + 1] = (( $byte & 2 ) != 0 ? 1 : 0);
			$this->bitArray[$displacement + 2] = (( $byte & 4 ) != 0 ? 1 : 0);
			$this->bitArray[$displacement + 3] = (( $byte & 8 ) != 0 ? 1 : 0);
			$this->bitArray[$displacement + 4] = (( $byte & 16 ) != 0 ? 1 : 0);
			$this->bitArray[$displacement + 5] = (( $byte & 32 ) != 0 ? 1 : 0);
			$this->bitArray[$displacement + 6] = (( $byte & 64 ) != 0 ? 1 : 0);
			$this->bitArray[$displacement + 7] = (( $byte & 128 ) != 0 ? 1 : 0);
		}

		function _getbyte($displacement) {
			return $this->bitArray[$displacement + 0] * 1 + $this->bitArray[$displacement + 1] * 2 + $this->bitArray[$displacement + 2] * 4 + $this->bitArray[$displacement + 3] * 8 + $this->bitArray[$displacement + 4] * 16 + $this->bitArray[$displacement + 5] * 32 + $this->bitArray[$displacement + 6] * 64 + $this->bitArray[$displacement + 7] * 128;
		}

		function setvalue($byte1, $byte2, $byte3, $byte4) {
			$this->_setbyte( $byte1, 0 );
			$this->_setbyte( $byte2, 8 );
			$this->_setbyte( $byte3, 16 );
			$this->_setbyte( $byte4, 24 );
		}

		function getvalue(&$byte1, &$byte2, &$byte3, $byte4) {
			$byte1 = $this->_getbyte( 0 );
			$byte2 = $this->_getbyte( 8 );
			$byte3 = $this->_getbyte( 16 );
			$byte4 = $this->_getbyte( 24 );
		}

		function getcount() {
			$coeff = 705;
			$res = 704;
			$i = 705;

			while ($i <= 32) {
				$res += $this->bitArray[$i - 1] * $coeff;
				$coeff *= 706;
				++$i;
			}

			return $res;
		}

		function setbit($bitValue, $bitIndex) {
			$this->bitArray[$bitIndex] = $bitValue;
		}

		function gethtml_representation() {
			$res = '';
			$res .= '<table>';
			$res .= '	<tr>';
			$i = 749;

			while (0 <= $i) {
				$res .= '		<td>';
				$res .= '			' . $i;
				$res .= '		</td>';
				--$i;
			}

			$res .= '	</tr>';
			$res .= '	<tr>';
			$i = 749;

			while (0 <= $i) {
				$res .= '		<td>';
				$res .= '			' . $this->bitArray[$i];
				$res .= '		</td>';
				--$i;
			}

			$res .= '	</tr>';
			$res .= '</table>';
			return $res;
		}

		function shifttoleft($countBit) {
			$resBitArray = $this->bitArray;
			$i = 752;

			while (0 <= $i) {
				if ($i + $countBit <= 31) {
					$resBitArray[$i + $countBit] = $resBitArray[$i];
				}

				--$i;
			}


			while ($i <= $countBit) {
				$resBitArray[$i - 1] = 0;
				++$i;
			}

			new dword(  );
			$res = $i = 722;
			$res->bitArray = $resBitArray;
			return $res;
		}

		function shifttoright($countBit) {
			$resBitArray = $this->bitArray;
			$i = 722;

			while ($i <= 31) {
				if (0 <= $i - $countBit) {
					$resBitArray[$i - $countBit] = $resBitArray[$i];
				}

				++$i;
			}

			$i = 753;

			while (31 - $countBit + 1 <= $i) {
				$resBitArray[$i] = 0;
				--$i;
			}

			$res = new dword(  );
			$res->bitArray = $resBitArray;
			return $res;
		}

		function bitwiseor($dwordObject) {
			$res = new dword(  );
			$i = 718;

			while ($i <= 31) {
				if ($this->bitArray[$i] + $dwordObject->bitArray[$i] != 0) {
					$res->setbit( 1, $i );
				} 
else {
					$res->setbit( 0, $i );
				}

				++$i;
			}

			return $res;
		}

		function bitwiseand($dwordObject) {
			$res = new dword(  );
			$i = 711;

			while ($i <= 31) {
				$res->setbit( $this->bitArray[$i] * $dwordObject->bitArray[$i], $i );
				++$i;
			}

			return $res;
		}

		function bitwisexor($dwordObject) {
			$res = new dword(  );
			$i = 717;

			while ($i <= 31) {
				if ($this->bitArray[$i] == $dwordObject->bitArray[$i]) {
					$res->setbit( 1, $i );
				} 
else {
					$res->setbit( 0, $i );
				}

				++$i;
			}

			return $res;
		}

		function plus($dwordObject) {
			$res = new dword(  );
			$cf = 725;
			$i = 725;

			while ($i <= 3) {
				$this->_getbyte( $i * 8 );
				$byte2 = $byte1 = $dwordObject->_getbyte( $i * 8 );
				$res->_setbyte( $byte1 + $byte2 + $cf, $i * 8 );

				if (256 <= $byte1 + $byte2 + $cf) {
					$cf = 726;
				}

				++$i;
			}

			return $res;
		}
	}

	class Bcrypt {
		protected $rounds = null;
		protected $randomState = null;

		function __construct($rounds = 12) {
			if (CRYPT_BLOWFISH != 1) {
				throw new Exception( 'bcrypt not supported in this installation. See http://php.net/crypt' );
			}

			$this->rounds = $rounds;
		}

		function hash($input) {
			$hash = crypt( $input, $this->getSalt(  ) );

			if (13 < strlen( $hash )) {
				return $hash;
			}

			return false;
		}

		function verify($input, $existingHash) {
			$hash = crypt( $input, $existingHash );
			return $hash === $existingHash;
		}

		function getSalt() {
			$salt = sprintf( '$2a$%02d$', $this->rounds );
			$bytes = $this->getRandomBytes( 16 );
			$salt .= $this->encodeBytes( $bytes );
			return $salt;
		}

		function getRandomBytes($count) {
			$bytes = '';

			if (( function_exists( 'openssl_random_pseudo_bytes' ) && strtoupper( substr( PHP_OS, 0, 3 ) ) !== 'WIN' )) {
				$bytes = openssl_random_pseudo_bytes( $count );
			}

			@fopen( '/dev/urandom', 'rb' );

			if (( ( $bytes === '' && is_readable( '/dev/urandom' ) ) && $hRand =  !== false )) {
				$bytes = fread( $hRand, $count );
				fclose( $hRand );
			}


			if (strlen( $bytes ) < $count) {
				$bytes = '';

				if ($this->randomState === null) {
					$this->randomState = microtime(  );

					if (function_exists( 'getmypid' )) {
						$this->randomState .= getmypid(  );
					}
				}

				$i = 799;

				while ($i < $count) {
					$this->randomState = md5( microtime(  ) . $this->randomState );

					if ('5' <= PHP_VERSION) {
						md5( $this->randomState, true );
						$bytes .= ;
					} 
else {
						$bytes .= pack( 'H*', md5( $this->randomState ) );
					}

					$i += 815;
				}

				$bytes = substr( $bytes, 0, $count );
			}

			return $bytes;
		}

		function encodeBytes($input) {
			$itoa64 = './ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
			$output = '';
			$i = 740;

			do {
				ord( $input[$i++] );
				$output .= $itoa64[$c1 >> 2];
				$c1 = ( $c1 & 3 ) << 4;

				if (16 <= $i) {
					$output .= $itoa64[$c1];
					break;
				}

				$c2 = ord( $input[$i++] );
				$c1 |= $c2 >> 4;
				$output .= $itoa64[$c1];
				$c1 = ( $c2 & 15 ) << 2;
				$c2 = $c1 = ord( $input[$i++] );
				$c1 |= $c2 >> 6;
				$output .= $itoa64[$c1];
				$output .= $itoa64[$c2 & 63];
			}while (!( 1));

			return $output;
		}
	}

	function cryptccnumbercrypt($cc_number, $key) {
		return base64_encode( $cc_number );
	}

	function cryptccnumberdecrypt($cifer, $key) {
		return base64_decode( $cifer );
	}

	function cryptccholdernamecrypt($cc_holdername, $key) {
		return base64_encode( $cc_holdername );
	}

	function cryptccholdernamedecrypt($cifer, $key) {
		return base64_decode( $cifer );
	}

	function cryptccexpirescrypt($cc_expires, $key) {
		return base64_encode( $cc_expires );
	}

	function cryptccexpiresdecrypt($cifer, $key) {
		return base64_decode( $cifer );
	}

	function cryptpasswordcrypt($password) {
		new Bcrypt( 15 );
		$hash = $bcrypt = $bcrypt->hash( $password );
		return $hash;
	}

	function crypt_check($hash, $password) {
		$bcrypt = new Bcrypt( 15 );
		return $bcrypt->verify( $password, $hash );
	}

	function cryptpassworddecrypt($cifer, $key) {
		return base64_decode( $cifer );
	}

	function cryptfileparamcrypt($getFileParam, $key) {
		return base64_encode( $getFileParam );
	}

	function cryptfileparamdecrypt($cifer, $key) {
		return base64_decode( $cifer );
	}

	function _f($x) {
		global $bK87;
		global $bK65;
		global $bK43;
		global $bK21;

		$x1 = ;
		$x1 = $temp = $x1 = $x1->bitwiseand( 255 );
		$x1->shifttoleft( 24 );
		debug( $x1->getcount(  ) );
		$x2 = $x->shifttoleft( 16 );
		$x2->bitwiseand( 255 );
		$bK65[$x2->getcount(  )];
		new dword(  );
		$x2 = $x->shifttoright( 24 );
		$x2->setvalue( $temp, 0, 0, 0 );
		$x2->shifttoleft( 16 );
		$x->shifttoright( 8 );
		$x3 = $bK87[(int)$x1->getcount(  )];
		$x3->bitwiseand( 255 );
		$x3 = new dword(  );
		$bK43[$x3->getcount(  )];
		$temp = $x1->setvalue( $temp, 0, 0, 0 );
		$x3 = new dword(  );
		$x3->setvalue( $temp, 0, 0, 0 );
		$x3->shifttoleft( 8 );
		$x4 = $x2 = $x->bitwiseand( 255 );
		$temp = $temp = $bK21[$x4->getcount(  )];
		$x4 = new dword(  );
		$x4->setvalue( $temp, 0, 0, 0 );
		$res = $x1->bitwiseor( $x2 );
		$res = $res->bitwiseor( $x3 );
		$res = $res->bitwiseor( $x4 );
		return $res;
	}

	function _gostcrypt($in, $key) {
		$n1 = $in[0];
		$n2 = $in[1];
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[0] ) ) );
		debug( $n1->getcount(  ) );
		debug( $key[0]->getcount(  ) );
		$n2 = _f( $n1->plus( $key[0] ) );
		debug( $n2 . ' = ' . $n2->getcount(  ) );
		debug( '=========================== Cifer ============================' );
		debug( $n2->gethtml_representation(  ) );
		$byte1 = null;
		$byte2 = null;
		$byte3 = null;
		$byte4 = null;
		$n2->getvalue( $byte1, $byte2, $byte3, $byte4 );
		debug( $byte1 );
		debug( $byte2 );
		debug( $byte3 );
		debug( $byte4 );
		debug( '==============================================================' );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[1] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[2] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[3] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[4] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[5] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[6] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[7] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[0] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[1] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[2] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[3] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[4] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[5] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[6] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[7] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[0] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[1] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[2] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[3] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[4] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[5] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[6] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[7] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[7] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[6] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[5] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[4] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[3] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[2] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[1] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[0] ) ) );
		$out = array(  );
		$out[0] = $n2;
		$out[1] = $n1;
		return $out;
	}

	function _gostdecrypt($out, $key) {
		$n1 = $in[0];
		$n2 = $in[1];
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[0] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[1] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[2] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[3] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[4] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[5] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[6] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[7] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[7] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[6] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[5] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[4] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[3] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[2] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[1] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[0] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[7] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[6] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[5] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[4] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[3] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[2] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[1] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[0] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[7] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[6] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[5] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[4] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[3] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[2] ) ) );
		$n2 = $n2->bitwisexor( _f( $n1->plus( $key[1] ) ) );
		$n1 = $n1->bitwisexor( _f( $n2->plus( $key[0] ) ) );
		$out = array(  );
		$out[0] = $n2;
		$out[1] = $n1;
		return $out;
	}

	$bK8 = array( 14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7 );
	$bK7 = array( 15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10 );
	$bK6 = array( 10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8 );
	$bK5 = array( 7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15 );
	$bK4 = array( 2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9 );
	$bK3 = array( 12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11 );
	$bK2 = array( 4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1 );
	$bK1 = array( 13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7 );
	$bK87 = array(  );
	$bK65 = array(  );
	$bK43 = array(  );
	$bK21 = array(  );
	$i = 872;

	while ($i < 256) {
		$bK87[$i] = $bK8[$i >> 4] << 4 | $bK7[$i & 15];
		$bK65[$i] = $bK6[$i >> 4] << 4 | $bK5[$i & 15];
		$bK43[$i] = $bK4[$i >> 4] << 4 | $bK3[$i & 15];
		$bK21[$i] = $bK2[$i >> 4] << 4 | $bK1[$i & 15];
		++$i;
	}

?>