<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function prdProductExists($productID) {
		$q = db_query( 'select count(*) from ' . PRODUCTS_TABLE . ' where productID=' . $productID );
		$row = db_fetch_row( $q );
		return $row[0] != 0;
	}

	function GetProduct($productID, $AsIs = false) {
		$productID = (int)$productID;
		$q = db_query( 'SELECT * FROM ' . PRODUCTS_TABLE . ' WHERE productID=\'' . $productID . '\'' );

		if ($product = db_fetch_row( $q )) {
			LanguagesManager::ml_fillFields( PRODUCTS_TABLE, $product );
			$product['ProductIsProgram'] = trim( $product['eproduct_filename'] ) != '';
			$sql = '
			SELECT pot.*,povt.* FROM ' . PRODUCT_OPTIONS_VALUES_TABLE . ' as povt
			LEFT JOIN ' . PRODUCT_OPTIONS_TABLE . ' as pot ON pot.optionID=povt.optionID 
			WHERE productID=' . $productID . '
		';
			$Result = db_query( $sql );
			$product['option_values'] = array(  );

			if ($_Row = db_fetch_assoc( $Result )) {
				LanguagesManager::ml_fillFields( PRODUCT_OPTIONS_TABLE, $_Row );
				LanguagesManager::ml_fillFields( PRODUCT_OPTIONS_VALUES_TABLE, $_Row );
				$_Row['value'] = $_Row['option_value'];
				$product['option_values'][] = $_Row;
			}


			if (!$AsIs) {
				$product['product_code'] = TransformDataBaseStringToText( $product['product_code'] );
			}

			$product['eproduct_filename'] = TransformDataBaseStringToText( $product['eproduct_filename'] );
			$product['meta_description'] = TransformDataBaseStringToText( $product['meta_description'] );
			$product['meta_keywords'] = TransformDataBaseStringToText( $product['meta_keywords'] );
			$product['Price'] = round( 100 * $product['Price'] ) / 100;
			$product['list_price'] = round( 100 * $product['list_price'] ) / 100;
			$product['date_added'] = format_datetime( $product['date_added'] );
			$product['date_modified'] = format_datetime( $product['date_modified'] );
			$lang = LanguagesManager::getCurrentLanguage(  )->iso2;
			$product['description'] = str_replace( '\"', '', $product['description_' . $lang] );
			$product['brief_description'] = $product['brief_description_' . $lang];
			$product['name'] = $product['name_' . $lang];
			return $product;
		}

		return false;
	}

	function UpdateProduct($product, $productID, $categoryID, $Price, $in_stock, $customers_rating, $list_price, $product_code, $sort_order, $ProductIsProgram, $eproduct_filename, $eproduct_available_days, $eproduct_download_times, $weight, $meta_description, $meta_keywords, $free_shipping, $is_account, $min_order_amount, $shipping_freight, $classID, $cod_link, $updateGCV = 1) {
		$product_code = TransformStringToDataBase( $product_code );
		$eproduct_filename = TransformStringToDataBase( $eproduct_filename );
		$meta_description = TransformStringToDataBase( $meta_description );
		$meta_keywords = TransformStringToDataBase( $meta_keywords );
		$cod_link = xEscapeSQLstring( $cod_link );
		$weight = (double)$weight;
		$shipping_freight = (double)$shipping_freight;
		$min_order_amount = (int)$min_order_amount;

		if ($min_order_amount == 0) {
			$min_order_amount = 989;
		}

		$eproduct_available_days = (int)$eproduct_available_days;

		if (!$ProductIsProgram) {
			$eproduct_filename = '';
		}


		if (!$free_shipping) {
			$free_shipping = 988;
		} 
else {
			$free_shipping = 989;
		}


		if (!$is_account) {
			$is_account = 988;
		} 
else {
			$is_account = 989;
		}

		$q = db_query( 'select eproduct_filename from ' . PRODUCTS_TABLE . ( ' where productID=' . $productID ) );
		$old_file_name = db_fetch_row( $q );
		$old_file_name = $old_file_name[0];

		if ($classID == null) {
			$classID = 'NULL';
		}


		if ($eproduct_filename != '') {
			if (trim( $_FILES[$eproduct_filename]['name'] ) != '') {
				if (( trim( $old_file_name ) != '' && file_exists( './uploads/products_files/' . $old_file_name ) )) {
					unlink( './uploads/products_files/' . $old_file_name );
				}


				if ($_FILES[$eproduct_filename]['size'] != 0) {
					$r = move_uploaded_file( $_FILES[$eproduct_filename]['tmp_name'], './uploads/products_files/' . $_FILES[$eproduct_filename]['name'] );
				}

				$eproduct_filename = trim( $_FILES[$eproduct_filename]['name'] );
				SetRightsToUploadedFile( './uploads/products_files/' . $eproduct_filename );
			} 
else {
				$eproduct_filename = $meta_description;
			}
		} 
else {
			$eproduct_filename = $meta_description;
		}

		$s = 'UPDATE ' . PRODUCTS_TABLE . ' SET ' . 'categoryID=\'' . $categoryID . '\\', ' . LanguagesManager::sql_prepareFieldUpdate( 'name', $product ) . ', ' . 'Price=\'' . $Price . '\\', ' . LanguagesManager::sql_prepareFieldUpdate( 'description', $product ) . ', ' . 'in_stock=\'' . $in_stock . '\\', ' . 'customers_rating=\'' . $customers_rating . '\\', ' . LanguagesManager::sql_prepareFieldUpdate( 'brief_description', $product ) . ', ' . 'list_price=\'' . $list_price . '\\', ' . 'product_code=\'' . $product_code . '\\', ' . 'sort_order=\'' . $sort_order . '\\', ' . 'date_modified=\'' . get_current_time(  ) . '\\', ' . ( 'eproduct_filename=\'' . $eproduct_filename . '\\', ' ) . ( 'eproduct_available_days=' . $eproduct_available_days . ', ' ) . ( 'eproduct_download_times=' . $eproduct_download_times . ',  ' ) . ( 'weight=' . $weight . ', meta_description=\'' . $meta_description . '\\', ' ) . ( 'meta_keywords=\'' . $meta_keywords . '\', free_shipping=' . $free_shipping . ', is_account=' . $is_account . ',' ) . ( 'min_order_amount = ' . $min_order_amount . ', ' ) . ( 'cod_link=\'' . $cod_link . '\\', ' ) . ( 'shipping_freight = ' . $shipping_freight . ' ' );

		if ($classID != null) {
			$s .= ( ', classID = ' . $classID . ' ' );
		}

		$s .= 'where productID=\'' . $productID . '\'';

		if (!( db_query( $s ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if (!( db_query( 'delete from ' . CATEGORIY_PRODUCT_TABLE . ( ' where productID = \'' . $productID . '\' and categoryID = \'' . $categoryID . '\'' ) ))) {
			exit( db_error(  ) );
			(bool)true;
		}


		if (( $updateGCV == 1 && CONF_UPDATE_GCV == '1' )) {
			update_products_Count_Value_For_Categories( 1 );
		}

	}

	function SetProductFile($productID, $eproduct_filename) {
		db_query( 'update ' . PRODUCTS_TABLE . ' set eproduct_filename=\'' . $eproduct_filename . '\' ' . ' where productID=' . $productID );
	}

	function AddProduct($product, $categoryID, $Price, $in_stock, $brief_description, $list_price, $product_code, $sort_order, $ProductIsProgram, $eproduct_filename, $eproduct_available_days, $eproduct_download_times, $weight, $meta_description, $meta_keywords, $free_shipping, $is_account, $min_order_amount, $shipping_freight, $classID, $cod_link, $updateGCV = 1) {
		TransformStringToDataBase( $product_code );
		$eproduct_filename = TransformStringToDataBase( $eproduct_filename );
		$meta_description = TransformStringToDataBase( $meta_description );
		$meta_keywords = TransformStringToDataBase( $meta_keywords );
		$cod_link = xEscapeSQLstring( $cod_link );

		if ($product['rating'] == '') {
			$product['rating'] = 0;
		}

		$customer_rating = $product['rating'];

		if ($free_shipping) {
			$free_shipping = 939;
		} 
else {
			$free_shipping = 938;
		}


		if ($is_account) {
			$is_account = 939;
		} 
else {
			$is_account = 938;
		}

		$is_account = 938;

		if ($classID == null) {
			$classID = 'NULL';
		}

		$weight = (double)$weight;
		$min_order_amount = (int)$min_order_amount;

		if ($min_order_amount == 0) {
			$min_order_amount = 939;
		}

		$eproduct_available_days = (int)$eproduct_available_days;

		if (!$ProductIsProgram) {
			$eproduct_filename = '';
		}


		if ($eproduct_filename != '') {
			if (trim( $_FILES[$eproduct_filename]['name'] ) != '') {
				if ($_FILES[$eproduct_filename]['size'] != 0) {
					$r = move_uploaded_file( $_FILES[$eproduct_filename]['tmp_name'], './uploads/products_files/' . $_FILES[$eproduct_filename]['name'] );
				}

				$eproduct_filename = trim( $_FILES[$eproduct_filename]['name'] );
				SetRightsToUploadedFile( './uploads/products_files/' . $eproduct_filename );
			}
		}

		$shipping_freight = (double)$shipping_freight;
		$ml_dbqs = LanguagesManager::sql_prepareFieldInsert( 'name', $product );
		$ml_dbqsd = LanguagesManager::sql_prepareFieldInsert( 'description', $product );
		$ml_dbqsbd = LanguagesManager::sql_prepareFieldInsert( 'brief_description', $product );

		if (LanguagesManager::ml_isEmpty( 'name', $product )) {
			$name = '?';
		}

		db_query( 'INSERT INTO ' . PRODUCTS_TABLE . ' ( categoryID, ' . $ml_dbqs['fields'] . ', ' . $ml_dbqsd['fields'] . ',' . '	customers_rating, Price, in_stock, ' . '	customer_votes, items_sold, enabled, ' . $ml_dbqsbd['fields'] . ', list_price, ' . '	product_code, sort_order, date_added, ' . ' eproduct_filename, eproduct_available_days, ' . ' eproduct_download_times, ' . '	weight, meta_description, meta_keywords, ' . '	free_shipping,is_account, min_order_amount, shipping_freight, classID, cod_link ' . ' ) ' . ' VALUES (\'' . $categoryID . '\',' . $ml_dbqs['values'] . ',' . $ml_dbqsd['values'] . ', ' . $customer_rating . ', \'' . $Price . '\', \'' . $in_stock . '\\', ' . '0, 0, 1, ' . $ml_dbqsbd['values'] . ', \'' . $list_price . '\', \'' . $product_code . '\', \'' . $sort_order . '\', \'' . get_current_time(  ) . '\',  ' . '\'' . $eproduct_filename . '\\', ' . $eproduct_available_days . ', ' . $eproduct_download_times . ',  ' . $weight . ', \'' . $meta_description . '\', \'' . $meta_keywords . '\\', ' . $free_shipping . ', ' . $is_account . ', ' . $min_order_amount . ', ' . $shipping_freight . ', ' . $classID . ', ' . '\'' . $cod_link . '\' ' . ');' );
		$insert_id = $product_code = db_insert_id(  );

		if (( $updateGCV == 1 && CONF_UPDATE_GCV == '1' )) {
			update_products_Count_Value_For_Categories( 1 );
		}

		return $insert_id;
	}

	function DeleteProduct($productID, $updateGCV = 1) {
		$whereClause = ' where productID=\'' . $productID . '\'';
		$q = db_query( 'select itemID from ' . SHOPPING_CART_ITEMS_TABLE . ' ' . $whereClause );

		if ($row = db_fetch_row( $q )) {
			db_query( 'delete from ' . SHOPPING_CARTS_TABLE . ' where itemID=' . $row['itemID'] );
		}

		db_query( 'update ' . SHOPPING_CART_ITEMS_TABLE . ' set productID=NULL ' . $whereClause );
		db_query( 'delete from ' . PRODUCTS_OPTIONS_SET_TABLE . $whereClause );
		db_query( 'delete from ' . PRODUCT_OPTIONS_VALUES_TABLE . $whereClause );
		db_query( 'delete from ' . PRODUCT_PICTURES . $whereClause );
		db_query( 'delete from ' . CATEGORIY_PRODUCT_TABLE . $whereClause );
		db_query( 'delete from ' . DISCUSSIONS_TABLE . $whereClause );
		db_query( 'delete from ' . SPECIAL_OFFERS_TABLE . $whereClause );
		db_query( 'delete from ' . RELATED_PRODUCTS_TABLE . $whereClause );
		db_query( 'delete from ' . RELATED_PRODUCTS_TABLE . ( ' where Owner=' . $productID ) );
		db_query( 'delete from ' . PRODUCTS_TABLE . $whereClause );

		if (( $updateGCV == 1 && CONF_UPDATE_GCV == '1' )) {
			update_products_Count_Value_For_Categories( 1 );
		}

		return true;
	}

	function DeleteAllProductsOfThisCategory($categoryID) {
		$q = db_query( 'select productID from ' . PRODUCTS_TABLE . ' where categoryID=\'' . $categoryID . '\'' );
		$res = true;

		if ($r = db_fetch_row( $q )) {
			if (!DeleteProduct( $r['productID'], 0 )) {
				$res = false;
			}
		}


		if (CONF_UPDATE_GCV == '1') {
			update_products_Count_Value_For_Categories( 1 );
		}

		return $res;
	}

	function GetExtraParametrs($productID) {
		static $ProductsExtras = array(  );

		if (!is_array( $productID )) {
			$ProductIDs = array( $productID );
			$IsProducts = false;
		} 
else {
			if (count( $productID )) {
				$ProductIDs = &$productID;

				$IsProducts = true;
			} 
else {
				return array(  );
			}
		}

		$ProductIDsCached = array_keys( $ProductsExtras );
		$ProductIDs = array_diff( $ProductIDs, $ProductIDsCached );

		if (count( $ProductIDs )) {
			$sql = '
			SELECT pot.*, ' . LanguagesManager::sql_constractSortField( PRODUCT_OPTIONS_TABLE, 'pot.name' ) . ', povt.*
			FROM ?#PRODUCT_OPTIONS_VALUES_TABLE as povt LEFT JOIN  ?#PRODUCT_OPTIONS_TABLE as pot ON pot.optionID=povt.optionID 
			WHERE povt.productID IN (?@) ORDER BY pot.sort_order, ' . LanguagesManager::sql_getSortField( PRODUCT_OPTIONS_TABLE, 'pot.name' ) . ' ';
			$Result = db_phquery( $sql, $ProductIDs );

			if ($_Row = db_fetch_assoc( $Result )) {
				LanguagesManager::ml_fillFields( PRODUCT_OPTIONS_VALUES_TABLE, $_Row );
				LanguagesManager::ml_fillFields( PRODUCT_OPTIONS_TABLE, $_Row );
				$b = null;

				if (( ( $_Row['option_type'] == 0 || $_Row['option_type'] == null ) && !LanguagesManager::ml_isEmpty( 'option_value', $_Row ) )) {
					$ProductsExtras[$_Row['productID']][] = $_Row;
				}


				if ($_Row['option_type'] == 1) {
					$sql = '
					SELECT povvt.*, ' . LanguagesManager::sql_constractSortField( PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE, 'povvt.option_value' ) . ', post.price_surplus
					FROM ' . PRODUCTS_OPTIONS_SET_TABLE . ' as post
					LEFT JOIN ' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . ' as povvt
					ON povvt.variantID=post.variantID
					WHERE povvt.optionID=' . $_Row['optionID'] . ' AND post.productID=' . $_Row['productID'] . ' AND povvt.optionID=' . $_Row['optionID'] . ' 
					ORDER BY povvt.sort_order, ' . LanguagesManager::sql_getSortField( PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE, 'povvt.option_value' ) . '
				';
					$q2 = db_query( $sql );
					$_Row['values_to_select'] = array(  );
					$i = 916;

					if ($_Rowue = db_fetch_assoc( $q2 )) {
						LanguagesManager::ml_fillFields( PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE, $_Rowue );
						$_Row['values_to_select'][$i] = array(  );
						$_Row['values_to_select'][$i]['option_value'] = xHtmlSpecialChars( $_Rowue['option_value'] );

						if (0 < $_Rowue['price_surplus']) {
							$_Row['values_to_select'][$i]['option_value'] = $_Row['values_to_select'][$i]['option_value'] . ' (+ ' . show_price( $_Rowue['price_surplus'] ) . ')';
						} 
else {
							if ($_Rowue['price_surplus'] < 0) {
								$_Row['values_to_select'][$i]['option_value'] = $_Row['values_to_select'][$i]['option_value'] . ' (- ' . show_price( 0 - $_Rowue['price_surplus'] ) . ')';
							}
						}

						$_Row['values_to_select'][$i]['option_valueWithOutPrice'] = $_Rowue['option_value'];
						$_Row['values_to_select'][$i]['price_surplus'] = show_priceWithOutUnit( $_Rowue['price_surplus'] );
						$_Row['values_to_select'][$i]['variantID'] = $_Rowue['variantID'];
						++$i;
					}

					$ProductsExtras[$_Row['productID']][] = $_Row;
				}
			}
		}


		if (!$IsProducts) {
			if (!count( $ProductsExtras )) {
				return array(  );
			}

			return $ProductsExtras[$productID];
		}

		return $ProductsExtras;
	}

	function _setPictures($product) {
		if (!is_null( $product['default_picture'] )) {
			$pictire = db_query( 'select filename, thumbnail, enlarged from ' . PRODUCT_PICTURES . ' where photoID=' . $product['default_picture'] );
			$pictire_row = db_fetch_row( $pictire );
			$product['picture'] = $pictire_row['filename'];
			$product['thumbnail'] = $pictire_row['thumbnail'];
			$product['big_picture'] = $pictire_row['enlarged'];

			if (!file_exists( './uploads/products_pictures/' . $product['picture'] )) {
				$product['picture'] = 0;
			}


			if (!file_exists( './uploads/products_pictures/' . $product['thumbnail'] )) {
				$product['thumbnail'] = 0;
			}


			if (!file_exists( './uploads/products_pictures/' . $product['big_picture'] )) {
				$product['big_picture'] = 0;
			}
		}

	}

	function GetProductInSubCategories(&$callBackParam, $count_row, $navigatorParams = null) {
		if ($navigatorParams != null) {
			$offset = $navigatorParams['offset'];
			$CountRowOnPage = $navigatorParams['CountRowOnPage'];
		} 
else {
			$offset = 828;
			$CountRowOnPage = 828;
		}

		$categoryID = $callBackParam['categoryID'];
		$subCategoryIDArray = catGetSubCategories( $categoryID );
		$cond = '';
		foreach ($subCategoryIDArray as $subCategoryID) {

			if ($cond != '') {
				$cond .= ' OR categoryID=' . $subCategoryID;
				continue;
			}

			$cond .= ( ' categoryID=' . $subCategoryID . ' ' );
		}

		$whereClause = '';

		if ($cond != '') {
			$whereClause = ' where ' . $cond;
		}

		$result = array(  );

		if ($whereClause == '') {
			$count_row = 828;
			return $result;
		}

		$q = db_query( 'select categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ', ' . LanguagesManager::sql_prepareField( 'brief_description' ) . ' , ' . ' customers_rating, Price, in_stock, ' . ' customer_votes, list_price, ' . ' productID, default_picture, sort_order from ' . PRODUCTS_TABLE . ' ' . $whereClause . ' order by sort_order ' );
		$i = 828;

		if ($row = db_fetch_row( $q )) {
			if (( ( $offset <= $i && $i < $offset + $CountRowOnPage ) || $navigatorParams == null )) {
				$row['PriceWithUnit'] = show_price( $row['Price'] );
				$row['list_priceWithUnit'] = show_price( $row['list_price'] );
				$row['SavePrice'] = show_price( $row['list_price'] - $row['Price'] );

				if ($row['list_price']) {
					$row['SavePricePercent'] = ceil( ( $row['list_price'] - $row['Price'] ) / $row['list_price'] * 100 );
				}

				_setPictures( &$row );
				$row['product_extra'] = GetExtraParametrs( $row['productID'] );
				$row['PriceWithOutUnit'] = show_priceWithOutUnit( $row['Price'] );
				$result[] = $row;
			}

			++$i;
		}

		$count_row = $result;
		return $result;
	}

	function prdGetProductByCategory(&$callBackParam, $count_row, $navigatorParams = null) {
		if ($navigatorParams != null) {
			$offset = $navigatorParams['offset'];
			$CountRowOnPage = $navigatorParams['CountRowOnPage'];
		} 
else {
			$offset = 890;
			$CountRowOnPage = 890;
		}

		$result = array(  );
		$categoryID = $callBackParam['categoryID'];
		$fullFlag = $callBackParam['fullFlag'];

		if ($fullFlag) {
			$conditions = array( ( ' categoryID=' . $categoryID . ' ' ) );
			$q = db_query( 'select productID from ' . CATEGORIY_PRODUCT_TABLE . ( ' where  categoryID=' . $categoryID ) );

			if ($products = db_fetch_row( $q )) {
				$conditions[] = ' productID=' . $products[0];
			}

			$data = array(  );
			foreach ($conditions as $cond) {
				$q = db_query( 'select categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ', ' . LanguagesManager::sql_prepareField( 'brief_description' ) . ', ' . ' customers_rating, Price, in_stock, ' . ' customer_votes, list_price, ' . ' productID, default_picture, sort_order, items_sold, enabled, product_code from ' . PRODUCTS_TABLE . ' where ' . $cond );

				if ($row = db_fetch_row( $q )) {
					$row['PriceWithUnit'] = show_price( $row['Price'] );
					$row['list_priceWithUnit'] = show_price( $row['list_price'] );
					$row['SavePrice'] = show_price( $row['list_price'] - $row['Price'] );

					if ($row['list_price']) {
						$row['SavePricePercent'] = ceil( ( $row['list_price'] - $row['Price'] ) / $row['list_price'] * 100 );
					}

					_setPictures( &$row );
					$row['product_extra'] = GetExtraParametrs( $row['productID'] );
					$row['PriceWithOutUnit'] = show_priceWithOutUnit( $row['Price'] );
					$data[] = $row;
				}
			}

			function _compare($row1, $row2) {
				if ((int)$row1['sort_order'] == (int)$row2['sort_order']) {
					return 0;
				}

				return ((int)$row1['sort_order'] < (int)$row2['sort_order'] ? -1 : 1);
			}

			usort( $data, '_compare' );
			$result = array(  );
			$i = 890;
			foreach ($data as $res) {

				if (( ( $offset <= $i && $i < $offset + $CountRowOnPage ) || $navigatorParams == null )) {
					$result[] = $res;
				}

				++$i;
			}

			$count_row = $fullFlag;
			return $result;
		}

		$q = db_query( 'select categoryID, ' . LanguagesManager::sql_prepareField( 'name' ) . ', ' . LanguagesManager::sql_prepareField( 'brief_description' ) . ', ' . ' customers_rating, Price, in_stock, ' . ' customer_votes, list_price, ' . ' productID, default_picture, sort_order, items_sold, enabled, product_code from ' . PRODUCTS_TABLE . ( ' where categoryID=' . $categoryID . ' order by sort_order, name' ) );
		$i = 890;

		if ($row = db_fetch_row( $q )) {
			if (( ( $offset <= $i && $i < $offset + $CountRowOnPage ) || $navigatorParams == null )) {
				$result[] = $row;
			}

			++$i;
		}

		$count_row = $fullFlag;
		return $result;
	}

	function getBestsellers($count) {
		_getSettingOptionValue( 'CONF_CHECKSTOCK' );

		if ($checkstock == 1) {
			$where = 'enabled = 1 AND categoryID > 1 AND in_stock > 0 AND Price > 0 AND items_sold > 0';
		} 
else {
			$where = 'enabled = 1 AND price > 0';
		}

		$q = $checkstock = db_query( 'SELECT productID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name, Price, ' . LanguagesManager::sql_prepareField( 'brief_description' ) . ' FROM ' . PRODUCTS_TABLE . ( ' WHERE ' . $where . ' ORDER BY items_sold DESC LIMIT ' . $count ) );

		if ($res = db_fetch_row( $q )) {
			$qq = db_query( 'SELECT filename as DefaultPic FROM ' . PRODUCT_PICTURES . '  WHERE productID=' . $res['productID'] );
			$ress = db_fetch_row( $qq );

			if ($ress['DefaultPic']) {
				$res['DefaultPic'] = $ress['DefaultPic'];
			} 
else {
				if (CONF_SHOW_NOIMAGE) {
					$res['DefaultPic'] = 'noimage';
				} 
else {
					$res['DefaultPic'] = 'no';
				}
			}

			$res['Price'] = show_price( $res['Price'] );
			$result[] = $res;
		}

		return $result;
	}

	function getBestviewed($count) {
		_getSettingOptionValue( 'CONF_CHECKSTOCK' );

		if ($checkstock == 1) {
			$where = 'enabled = 1 AND categoryID > 1 AND in_stock > 0 AND Price > 0';
		} 
else {
			$where = 'enabled = 1 AND categoryID > 1 AND Price > 0';
		}

		$q = $checkstock = db_query( 'SELECT productID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name, Price, ' . LanguagesManager::sql_prepareField( 'brief_description' ) . ' FROM ' . PRODUCTS_TABLE . ( ' WHERE ' . $where . ' ORDER BY viewed_times DESC LIMIT ' . $count ) );

		if ($res = db_fetch_row( $q )) {
			$qq = db_query( 'SELECT filename as DefaultPic FROM ' . PRODUCT_PICTURES . '  WHERE productID=' . $res['productID'] );
			$ress = db_fetch_row( $qq );

			if ($ress['DefaultPic']) {
				$res['DefaultPic'] = $ress['DefaultPic'];
			} 
else {
				if (CONF_SHOW_NOIMAGE) {
					$res['DefaultPic'] = 'noimage';
				} 
else {
					$res['DefaultPic'] = 'no';
				}
			}

			$res['Price'] = show_price( $res['Price'] );
			$result[] = $res;
		}

		return $result;
	}

	function getLatestadded($count) {
		$checkstock = _getSettingOptionValue( 'CONF_CHECKSTOCK' );

		if ($checkstock == 1) {
			$where = 'enabled = 1 AND categoryID > 1 AND in_stock > 0 AND Price > 0';
		} 
else {
			$where = 'enabled = 1 AND categoryID > 1 AND Price > 0';
		}

		$q = db_query( 'SELECT productID, ' . LanguagesManager::sql_prepareField( 'name' ) . ' as name, Price, ' . LanguagesManager::sql_prepareField( 'brief_description' ) . ' FROM ' . PRODUCTS_TABLE . ( ' WHERE ' . $where . ' ORDER BY ' ) . PRODUCTS_TABLE . ( '.productID DESC  LIMIT ' . $count ) );

		if ($res = db_fetch_row( $q )) {
			$qq = db_query( 'SELECT filename as DefaultPic FROM ' . PRODUCT_PICTURES . '  WHERE productID=' . $res['productID'] );
			$ress = db_fetch_row( $qq );

			if ($ress['DefaultPic']) {
				$res['DefaultPic'] = $ress['DefaultPic'];
			} 
else {
				if (CONF_SHOW_NOIMAGE) {
					$res['DefaultPic'] = 'noimage';
				} 
else {
					$res['DefaultPic'] = 'no';
				}
			}

			$res['Price'] = show_price( $res['Price'] );
			$result[] = $res;
		}

		return $result;
	}

	function _getConditionWithCategoryConjWithSubCategories($condition, $categoryID) {
		$new_condition = '';
		$categoryID_Array = catGetSubCategories( $categoryID );
		$categoryID_Array[] = (int)$categoryID;
		foreach ($categoryID_Array as $catID) {

			if ($new_condition != '') {
				$new_condition .= ' OR ';
			}

			$new_condition .= _getConditionWithCategoryConj( $condition, $catID );
		}

		return $new_condition;
	}

	function _getConditionWithCategoryConj($condition, $categoryID) {
		$category_condition = '';
		$q = db_query( 'select productID from ' . CATEGORIY_PRODUCT_TABLE . ( ' where categoryID=' . $categoryID ) );

		if ($product = db_fetch_row( $q )) {
			if ($category_condition != '') {
				$category_condition .= ' OR ';
			}

			$category_condition .= ' productID=' . $product[0];
		}


		if (0 < strlen( $category_condition )) {
			$category_condition = '(' . $category_condition . ')';
		}


		if ($condition == '') {
			if ($category_condition == '') {
				return 'categoryID=' . $categoryID;
			}

			return $category_condition . ' OR categoryID=' . $categoryID;
		}


		if ($category_condition == '') {
			return $condition . ' AND categoryID=' . $categoryID;
		}

		return  . '( ' . $condition . ' AND ' . $category_condition . ' ) OR ' . ( ' ( ' . $condition . ' AND categoryID=' . $categoryID . ' )' );
	}

	function _testExtraParametrsTemplate($productID, $template) {
		$categoryID = $template['categoryID'];
		foreach ($template as ) {
			if (!isset( $item['optionID'] )) {
				continue;
			}


			if ((bool)$key == 'categoryID') {
				continue;
			}

			$res = schOptionIsSetToSearch( $categoryID, $item['optionID'] );

			if ($res['set_arbitrarily'] == 1) {
				$valueFromForm = $item['value'];
			} 
else {
				if ((int)$item['value'] == 0) {
					continue;
				}

				$q = db_query( 'select ' . LanguagesManager::sql_prepareField( 'option_value' ) . ' from ' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . ' where variantID=' . $item['value'] );
				$option_value = db_fetch_row( $q );
				$valueFromForm = $option_value[0];
			}

			$q = db_query( 'select ' . LanguagesManager::sql_prepareField( 'option_value' ) . ' as option_value, option_type from ' . PRODUCT_OPTIONS_VALUES_TABLE . ' where optionID=' . $item['optionID'] . ( ' AND productID=' . $productID ) );

			if (!$row = db_fetch_row( $q )) {
				if (trim( $valueFromForm ) == '') {
					continue;
				}

				return false;
			}

			$option_value = $item = $row['option_value'];
			$option_type = $key = $row['option_type'];
			$valueFromDataBase = array(  );

			if ($option_type == 0) {
				$valueFromDataBase[] = $option_value;
			} 
else {
				$q = db_query( 'select productID, optionID, variantID from ' . PRODUCTS_OPTIONS_SET_TABLE . ' where optionID=' . $item['optionID'] . ( ' AND productID=' . $productID ) );

				if ($row = db_fetch_row( $q )) {
					$qstr = 'select ' . LanguagesManager::sql_prepareField( 'option_value' ) . ' as option_value from ' . PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE . ' where variantID=' . $row['variantID'];
					$q1 = db_query( $qstr );

					if ($option_value = db_fetch_row( $q1 )) {
						$valueFromDataBase[] = $option_value['option_value'];
					}
				}
			}


			if (trim( $valueFromForm ) != '') {
				$existFlag = false;
				foreach ($valueFromDataBase as $value) {

					if (strstr( (bool)trim( $value ), (bool)trim( $valueFromForm ) )) {
						$existFlag = true;
						break;
					}
				}


				if (!$existFlag) {
					return false;
				}

				continue;
			}
		}

		return true;
	}

	function _deletePercentSymbol($str) {
		$str = str_replace( '%', '', $str );
		return $str;
	}

	function prdSearchProductByTemplate(&$callBackParam, $count_row, $navigatorParams = null) {
		if ($navigatorParams != null) {
			$offset = $navigatorParams['offset'];
			$CountRowOnPage = $navigatorParams['CountRowOnPage'];
		} 
else {
			$offset = 1209;
			$CountRowOnPage = 1209;
		}


		if (isset( $callBackParam['search_simple'] )) {
			$i = 1209;

			while ($i < count( $callBackParam['search_simple'] )) {
				$callBackParam['search_simple'][$i] = TransformStringToDataBase( $callBackParam['search_simple'][$i] );
				++$i;
			}

			_deletePercentSymbol( &$callBackParam['search_simple'] );
		}


		if (isset( $callBackParam['name'] )) {
			$i = 1209;

			while ($i < count( $callBackParam['name'] )) {
				$callBackParam['name'][$i] = TransformStringToDataBase( $callBackParam['name'][$i] );
				++$i;
			}

			_deletePercentSymbol( &$callBackParam['name'][$i] );
		}


		if (isset( $callBackParam['product_code'] )) {
			$i = 1209;

			while ($i < count( $callBackParam['product_code'] )) {
				$callBackParam['product_code'][$i] = TransformStringToDataBase( $callBackParam['product_code'][$i] );
				++$i;
			}

			_deletePercentSymbol( &$callBackParam['product_code'] );
		}


		if (isset( $callBackParam['extraParametrsTemplate'] )) {
			foreach ($callBackParam['extraParametrsTemplate'] as $key => $value) {

				if (is_int( $key )) {
					$callBackParam['extraParametrsTemplate'][$key] = TransformStringToDataBase( $callBackParam['extraParametrsTemplate'][$key] );
					_deletePercentSymbol( &$callBackParam['extraParametrsTemplate'][$key] );
					continue;
				}
			}
		}

		$where_clause = '';

		if (isset( $callBackParam['search_simple'] )) {
			if (!count( $callBackParam['search_simple'] )) {
				$where_clause = ' where 0';
			} 
else {
				foreach ($callBackParam['search_simple'] as $value) {
					$where_clause .= ($where_clause ? ' AND' : '') . ' ( ' . LanguagesManager::sql_prepareField( 'name' ) . ' LIKE "%' . $value . '%" OR
				' . LanguagesManager::sql_prepareField( 'description' ) . ' LIKE "%' . $value . '%" OR
				' . LanguagesManager::sql_prepareField( 'brief_description' ) . ' LIKE "%' . $value . '%") ';
				}


				if ($where_clause != '') {
					$where_clause = ' where categoryID>1 and enabled=1 and ' . $where_clause;
				} 
else {
					$where_clause = 'where categoryID>1 and enabled=1';
				}
			}
		} 
else {
			if (isset( $callBackParam['enabled'] )) {
				if ($where_clause != '') {
					$where_clause .= ' AND ';
				}

				$where_clause .= ' enabled=' . $callBackParam['enabled'];
			}


			if (isset( $callBackParam['name'] )) {
				foreach ($callBackParam['name'] as $name) {

					if (0 < strlen( $name )) {
						$where_clause .= ($where_clause ? ' AND' : '') . ' ( ' . LanguagesManager::sql_prepareField( 'name' ) . ' LIKE "%' . $name . '%" )';
						continue;
					}
				}
			}


			if (isset( $callBackParam['product_code'] )) {
				foreach ($callBackParam['product_code'] as $product_code) {

					if ($where_clause != '') {
						$where_clause .= ' AND ';
					}

					$where_clause .= ' product_code LIKE \'%' . $product_code . '%\' ';
				}
			}


			if (isset( $callBackParam['price'] )) {
				$price = $callBackParam['price'];

				if (( trim( $price['from'] ) != '' && $price['from'] != null )) {
					if ($where_clause != '') {
						$where_clause .= ' AND ';
					}

					$from = ConvertPriceToUniversalUnit( $price['from'] );
					$where_clause .=  . $from . '<=Price ';
				}


				if (( trim( $price['to'] ) != '' && $price['to'] != null )) {
					if ($where_clause != '') {
						$where_clause .= ' AND ';
					}

					$to = ConvertPriceToUniversalUnit( $price['to'] );
					$where_clause .= ( ' Price<=' . $to . ' ' );
				}
			}


			if (isset( $callBackParam['categoryID'] )) {
				$searchInSubcategories = false;

				if (isset( $callBackParam['searchInSubcategories'] )) {
					if ($callBackParam['searchInSubcategories']) {
						$searchInSubcategories = true;
					} 
else {
						$searchInSubcategories = false;
					}
				}


				if ($searchInSubcategories) {
					$where_clause = _getConditionWithCategoryConjWithSubCategories( $where_clause, $callBackParam['categoryID'] );
				} 
else {
					$where_clause = _getConditionWithCategoryConj( $where_clause, $callBackParam['categoryID'] );
				}
			}


			if ($where_clause != '') {
				$where_clause = 'where ' . $where_clause;
			}
		}

		$order_by_clause = 'order by _name_sort';

		if (isset( $callBackParam['sort'] )) {
			if (( ( ( ( ( ( ( ( ( ( ( $callBackParam['sort'] == 'categoryID' || $callBackParam['sort'] == '_name_sort' ) || $callBackParam['sort'] == 'brief_description' ) || $callBackParam['sort'] == 'in_stock' ) || $callBackParam['sort'] == 'Price' ) || $callBackParam['sort'] == 'customer_votes' ) || $callBackParam['sort'] == 'customers_rating' ) || $callBackParam['sort'] == 'list_price' ) || $callBackParam['sort'] == 'sort_order' ) || $callBackParam['sort'] == 'items_sold' ) || $callBackParam['sort'] == 'product_code' ) || $callBackParam['sort'] == 'shipping_freight' )) {
				$order_by_clause = ' order by ' . $callBackParam['sort'] . ' ASC ';

				if (isset( $callBackParam['direction'] )) {
					if ($callBackParam['direction'] == 'DESC') {
						$order_by_clause = ' order by ' . $callBackParam['sort'] . ' DESC ';
					}
				}
			}
		} 
else {
			$order_by_clause = ' order by sort_order ASC ';
		}

		$sqlQueryCount = 'select count(*),' . LanguagesManager::sql_constractSortField( PRODUCTS_TABLE, 'name' ) . '  from ' . PRODUCTS_TABLE . ( ( ( ' ' ) . $where_clause . ' ' ) . $order_by_clause );
		$q = db_query( $sqlQueryCount );
		$products_count = db_fetch_row( $q );
		$products_count = $products_count[0];
		$sqlQuery = 'select *,' . LanguagesManager::sql_constractSortField( PRODUCTS_TABLE, 'name' ) . ', ' . LanguagesManager::sql_prepareField( 'name' ) . ', ' . LanguagesManager::sql_prepareField( 'brief_description' ) . ', ' . LanguagesManager::sql_prepareField( 'description' ) . ' from ' . PRODUCTS_TABLE . ( ( ( ' ' ) . $where_clause . ' ' ) . $order_by_clause );
		$q = db_query( $sqlQuery );
		$result = array(  );
		$i = 1209;

		if (( 0 <= $offset && $offset <= $products_count )) {

			if ($row = db_fetch_row( $q )) {
				if (isset( $callBackParam['extraParametrsTemplate'] )) {
					$testResult = _testExtraParametrsTemplate( $row['productID'], $callBackParam['extraParametrsTemplate'] );

					if (!$testResult) {
						continue;
					}
				}


				if (( ( $offset <= $i && $i < $offset + $CountRowOnPage ) || $navigatorParams == null )) {
					$row['PriceWithUnit'] = show_price( $row['Price'] );
					$row['in_stock_fa'] = fa_get_persian_number( $row['in_stock'] );
					$row['list_priceWithUnit'] = show_price( $row['list_price'] );
					$row['SavePrice'] = show_price( $row['list_price'] - $row['Price'] );

					if ($row['list_price']) {
						$row['SavePricePercent'] = ceil( ( $row['list_price'] - $row['Price'] ) / $row['list_price'] * 100 );
					}

					_setPictures( &$row );
					$row['product_extra'] = GetExtraParametrs( $row['productID'] );
					$row['PriceWithOutUnit'] = show_priceWithOutUnit( $row['Price'] );

					if (0 < (double)$row['shipping_freight']) {
						$row['shipping_freightUC'] = show_price( $row['shipping_freight'] );
					}

					LanguagesManager::ml_fillFields( PRODUCTS_TABLE, $row );
					$row['product_code'] = TransformDataBaseStringToText( $row['product_code'] );
					$result[] = $row;
				}

				++$i;
			}
		}

		$count_row = $result;
		return $result;
	}

	function prdGetMetaKeywordTag($productID) {
		$q = $productID = (int)$productID;
		db_fetch_row( $q );

		if ($row = db_query( 'select meta_description from ' . PRODUCTS_TABLE . ( ' where productID=' . $productID ) )) {
			return TransformDataBaseStringToText( trim( $row['meta_description'] ) );
		}

		return '';
	}

	function prdGetMetaTags($productID) {
		$productID = (int)$productID;
		$q = db_query( 'select meta_description, meta_keywords from ' . PRODUCTS_TABLE . ' where productID=' . $productID );
		$row = db_fetch_row( $q );
		$meta_description = TransformDataBaseStringToText( trim( $row['meta_description'] ) );
		$meta_keywords = TransformDataBaseStringToText( trim( $row['meta_keywords'] ) );
		$res = '';

		if ($meta_description != '') {
			$res .= '<meta name="Description" content="' . str_replace( '"', '&quot;', $meta_description ) . '">
';
		}


		if ($meta_keywords != '') {
			$res .= '<meta name="KeyWords" content="' . str_replace( '"', '&quot;', $meta_keywords ) . '" >
';
		}

		return $res;
	}

	function _prepareSearchExtraParameters($template) {
		$sqls_joins = array(  );
		$sqls_options = array(  );
		$categoryID = $template['categoryID'];
		$sqls_params = array(  );
		$cnt = 881;
		$_count = 881;
		foreach ($template as $key => $item) {

			if (!isset( $item['optionID'] )) {
				continue;
			}


			if ($item['value'] === '') {
				continue;
			}


			if ($key === 'categoryID') {
				continue;
			}

			$res = schOptionIsSetToSearch( $categoryID, $item['optionID'] );

			if (( $res['set_arbitrarily'] && $item['value'] === '0' )) {
				continue;
			}


			if ($res['set_arbitrarily']) {
				$sqls_joins[] = '
				LEFT JOIN ?#PRODUCT_OPTIONS_VALUES_TABLE PrdOptVal' . $cnt . ' ON p.productID=PrdOptVal' . $cnt . '.productID
				LEFT JOIN ?#PRODUCTS_OPTIONS_SET_TABLE PrdOptSet' . $cnt . ' ON p.productID=PrdOptSet' . $cnt . '.productID
				LEFT JOIN ?#PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE PrdOptValVar' . $cnt . ' ON 
					PrdOptSet' . $cnt . '.optionID=PrdOptValVar' . $cnt . '.optionID AND
					PrdOptSet' . $cnt . '.variantID=PrdOptValVar' . $cnt . '.variantID
			';
				$search_name = 'option_value_' . $_count++;
				$sqls_params[$search_name] = '%' . _searchPatternReplace( $item['value'] ) . '%';
				$sqls_options[] = '
				PrdOptVal' . $cnt . '.optionID=' . intval( $item['optionID'] ) . '
				AND 
				(
				( PrdOptVal' . $cnt . '.option_type=1
				AND PrdOptValVar' . $cnt . '.' . LanguagesManager::sql_prepareField( 'option_value' ) . ' LIKE ?' . $search_name . ') OR (
				PrdOptVal' . $cnt . '.option_type=0
				AND PrdOptVal' . $cnt . '.' . LanguagesManager::sql_prepareField( 'option_value' ) . ' LIKE ?' . $search_name . ')
				)
			';
			} 
else {
				$sqls_joins[] = '
				LEFT JOIN ?#PRODUCT_OPTIONS_VALUES_TABLE PrdOptVal' . $cnt . ' ON p.productID=PrdOptVal' . $cnt . '.`productID`
				LEFT JOIN ?#PRODUCTS_OPTIONS_SET_TABLE PrdOptSet' . $cnt . ' ON p.productID=PrdOptSet' . $cnt . '.`productID`
			';
				$qtmp = db_phquery( 'select ' . LanguagesManager::sql_prepareField( 'option_value' ) . ' from ?#PRODUCTS_OPTIONS_VALUES_VARIANTS_TABLE' . ' where optionID=? and variantID=?', intval( $item['optionID'] ), intval( $item['value'] ) );
				$rowtmp = db_fetch_row( $qtmp );

				if ($rowtmp) {
					$item_text_value = $rowtmp[0];
				} 
else {
					$item_text_value = '';
				}

				$search_name = 'option_value_' . $_count++;
				$sqls_params[$search_name] = '%' . $item_text_value . '%';
				$sqls_options[] = '
				PrdOptVal' . $cnt . '.optionID=' . intval( $item['optionID'] ) . ' 
				AND 
				(
					( PrdOptVal' . $cnt . '.option_type=1 AND PrdOptSet' . $cnt . '.variantID=' . intval( $item['value'] ) . ')
					 OR 
					(PrdOptVal' . $cnt . '.option_type=0 AND PrdOptVal' . $cnt . '.' . LanguagesManager::ml_getLangFieldName( 'option_value' ) . ' LIKE ?' . $search_name . ')
				)';
			}

			++$cnt;
		}

		return array( 'where' => $sqls_options, 'join' => $sqls_joins, 'params' => $sqls_params );
	}

	function _searchPatternReplace($string) {
		static $patterns = array( 0 => '/\\/', 1 => '/%/', 2 => '/_/', 3 => '/(^|[^\/]{1})(\?)/', 4 => '/([\/]{1})(\?)/', 5 => '/(^|[^\/]{1})(\*)/', 6 => '/([\/]{1})(\*)/', 7 => '/(^|[^\/]{1})\+/', 8 => '/([\/]{1})\+/' );
		static $replacements = array( 0 => '\\\\', 1 => '\%', 2 => '\_', 3 => '\1_', 4 => '?', 5 => '\1%', 6 => '*', 7 => '\1 ', 8 => '+' );

		return preg_replace( $patterns, $replacements, $string );
	}

?>