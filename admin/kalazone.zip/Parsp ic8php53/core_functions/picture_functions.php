<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	function GetPictures($productID) {
		$q = db_query( $sql );
		$q2 = db_query( 'select default_picture from ' . PRODUCTS_TABLE . ' where productID = ' . $productID );
		$product = db_fetch_row( $q2 );
		$product[0];
		$default_picture = $sql = 'select photoID, productID, filename, thumbnail, enlarged from ' . PRODUCT_PICTURES . ' where productID = ' . $productID;
		$res = array(  );

		if ($row = db_fetch_row( $q )) {
			if ((bool)$row['photoID'] == (bool)$default_picture) {
				$row['default_picture'] = 1;
			} 
else {
				$row['default_picture'] = 0;
			}

			$res[] = $row;
		}

		return $res;
	}

	function DeleteThreePictures($photoID) {
		$q = db_query( 'select filename, thumbnail, enlarged, productID from ' . PRODUCT_PICTURES . ' where photoID=' . $photoID );

		if ($picture = db_fetch_row( $q )) {
			if (( $picture['filename'] != '' && $picture['filename'] != null )) {
				if (file_exists( './uploads/products_pictures/' . $picture['filename'] )) {
					unlink( './uploads/products_pictures/' . $picture['filename'] );
				}
			}


			if (( $picture['thumbnail'] != '' && $picture['thumbnail'] != null )) {
				if (file_exists( './uploads/products_pictures/' . $picture['thumbnail'] )) {
					unlink( './uploads/products_pictures/' . $picture['thumbnail'] );
				}
			}


			if (( $picture['enlarged'] != '' && $picture['enlarged'] != null )) {
				if (file_exists( './uploads/products_pictures/' . $picture['enlarged'] )) {
					unlink( './uploads/products_pictures/' . $picture['enlarged'] );
				}
			}

			$q1 = db_query( 'select default_picture from ' . PRODUCTS_TABLE . ' where productID=' . $picture['productID'] );

			if ($product = db_fetch_row( $q1 )) {
				if ($product['default_picture'] == $photoID) {
					db_query( 'update ' . PRODUCTS_TABLE . ' set default_picture=NULL ' . ' where productID=' . $_GET['productID'] );
				}
			}

			db_query( 'delete from ' . PRODUCT_PICTURES . ' where photoID=' . $photoID );
		}

	}

	function DeleteFilenamePicture($photoID) {
		$q = db_query( 'select filename from ' . PRODUCT_PICTURES . ' where photoID=' . $photoID );

		if ($filename = db_fetch_row( $q )) {
			if (file_exists( './uploads/products_pictures/' . $filename['filename'] )) {
				unlink( './uploads/products_pictures/' . $filename['filename'] );
			}

			db_query( 'update ' . PRODUCT_PICTURES . ' set filename=\'\'' . ' where photoID=' . $photoID );
		}

	}

	function DeleteThumbnailPicture($photoID) {
		$q = db_query( 'select thumbnail from ' . PRODUCT_PICTURES . ' where photoID=' . $photoID );

		if ($thumbnail = db_fetch_row( $q )) {
			if (file_exists( './uploads/products_pictures/' . $thumbnail['thumbnail'] )) {
				unlink( './uploads/products_pictures/' . $thumbnail['thumbnail'] );
			}

			db_query( 'update ' . PRODUCT_PICTURES . ' set thumbnail=\'\'' . ' where photoID=' . $photoID );
		}

	}

	function DeleteEnlargedPicture($photoID) {
		$q = db_query( 'select enlarged from ' . PRODUCT_PICTURES . ' where photoID=' . $photoID );

		if ($enlarged = db_fetch_row( $q )) {
			if (file_exists( './uploads/products_pictures/' . $enlarged['enlarged'] )) {
				unlink( './uploads/products_pictures/' . $enlarged['enlarged'] );
			}

			db_query( 'update ' . PRODUCT_PICTURES . ' set enlarged=\'\'' . ' where photoID=' . $photoID['enlarged'] );
		}

	}

	function UpdatePictures($productID, $fileNames, $default_picture) {
		foreach ($fileNames as $key => $value) {
			db_query( 'update ' . PRODUCT_PICTURES . ' set ' . '	filename=\'' . $value['filename'] . '\',  ' . '	thumbnail=\'' . $value['thumbnail'] . '\' , ' . '	enlarged=\'' . $value['enlarged'] . '\' ' . 'where photoID=' . $key );
		}


		if ($default_picture != -1) {
			db_query( 'update ' . PRODUCTS_TABLE . ' set default_picture = ' . $default_picture . ' where productID=\'' . $productID . '\'' );
		}

	}

	function SetImgSize($img, $width, $height) {
		if (preg_match( '/jpg$/', $img )) {
			$srcImage = ImageCreateFromJPEG( $img );
		}


		if (preg_match( '/jpeg$/', $img )) {
			$srcImage = ImageCreateFromJPEG( $img );
		}


		if (preg_match( '/gif$/', $img )) {
			$srcImage = ImageCreateFromGIF( $img );
		}


		if (preg_match( '/png$/', $img )) {
			$srcImage = imagecreatefromPNG( $img );
		}

		$srcWidth = ImageSX( $srcImage );
		$srcHeight = ImageSY( $srcImage );

		if (( $width < $srcWidth || $height < $srcHeight )) {
			$ratioWidth = $srcWidth / $width;
			$ratioHeight = $srcHeight / $height;

			if ($ratioWidth < $ratioHeight) {
				$destWidth = $srcWidth / $ratioHeight;
				$destHeight = $height;
			} 
else {
				$destWidth = $width;
				$destHeight = $srcHeight / $ratioWidth;
			}

			$resImage = ImageCreateTrueColor( $destWidth, $destHeight );
			$colourBlack = imagecolorallocate( $resImage, 0, 0, 0 );
			imagecolortransparent( $resImage, $colourBlack );
			ImageCopyResampled( $resImage, $srcImage, 0, 0, 0, 0, $destWidth, $destHeight, $srcWidth, $srcHeight );
			unlink( $img );

			if (preg_match( '/jpg$/', $img )) {
				ImageJPEG( $resImage, $img, 100 );
			}


			if (preg_match( '/jpeg$/', $img )) {
				ImageJPEG( $resImage, $img, 100 );
			}


			if (preg_match( '/gif$/', $img )) {
				ImageGIF( $resImage, $img );
			}


			if (preg_match( '/png$/', $img )) {
				imagepng( $resImage, $img );
			}

			ImageDestroy( $srcImage );
			ImageDestroy( $resImage );
		}

	}

	function AddNewPictures($productID, $filename, $thumbnail, $enlarged, $default_picture) {
		if (CONF_CHANGE_IMAGESIZE == 1) {
			if (trim( $_FILES[$filename]['name'] ) != '') {
				$new_filename = '';
				$new_thumbnail = '';
				$new_enlarged = '';
				$tmp = $_FILES[$filename]['tmp_name'];
				$r = false;

				if (( $_FILES[$filename]['size'] != 0 && preg_match( '/\.(jpg|jpeg|gif|jpe|pcx|bmp)$/i', $_FILES[$filename]['name'] ) )) {
					$r = move_uploaded_file( $tmp, './uploads/products_pictures/' . $_FILES[$filename]['name'] );
				}


				if ($r) {
					copy( './uploads/products_pictures/' . $_FILES[$filename]['name'], './uploads/products_pictures/large_' . $_FILES[$filename]['name'] );
					copy( './uploads/products_pictures/' . $_FILES[$filename]['name'], './uploads/products_pictures/small_' . $_FILES[$filename]['name'] );
					copy( './uploads/products_pictures/' . $_FILES[$filename]['name'], './uploads/products_pictures/medium_' . $_FILES[$filename]['name'] );
					$new_enlarged = 'large_' . $_FILES[$filename]['name'];
					SetRightsToUploadedFile( './uploads/products_pictures/' . $new_enlarged );
					SetImgSize( './uploads/products_pictures/' . $new_enlarged, CONF_ENLARGED_WIDTH, CONF_ENLARGED_HEIGHT );
					$new_thumbnail = 'small_' . $_FILES[$filename]['name'];
					SetRightsToUploadedFile( './uploads/products_pictures/' . $new_thumbnail );
					SetImgSize( './uploads/products_pictures/' . $new_thumbnail, CONF_THUMBNAILSIZE_WIDTH, CONF_THUMBNAILSIZE_HEIGHT );
					$new_filename = 'medium_' . $_FILES[$filename]['name'];
					SetRightsToUploadedFile( './uploads/products_pictures/medium_' . $new_filename );
					SetImgSize( './uploads/products_pictures/' . $new_filename, CONF_DEFUALTPIC_WIDTH, CONF_DEFUALTPIC_HEIGHT );
					unlink( './uploads/products_pictures/' . $_FILES[$filename]['name'] );
				}


				if ($new_filename != '') {
					db_query( 'insert into ' . PRODUCT_PICTURES . '(productID, filename, thumbnail, enlarged)' . '		values( ' . $productID . ', ' . ' \'' . $new_filename . '\\', ' . ' \'' . $new_thumbnail . '\\', ' . ' \'' . $new_enlarged . '\' ) ' );

					if ($default_picture == -1) {
						$default_pictureID = db_insert_id(  );
						db_query( 'update ' . PRODUCTS_TABLE . ' set default_picture = ' . $default_pictureID . ' where productID=\'' . $productID . '\'' );
						return null;
					}
				}
			}
		} 
else {
			if (trim( $_FILES[$filename]['name'] ) != '') {
				$new_filename = '';
				$new_thumbnail = '';
				$new_enlarged = '';
				$r = false;

				if (( $_FILES[$filename]['size'] != 0 && preg_match( '/\.(jpg|jpeg|gif|jpe|pcx|bmp)$/i', $_FILES[$filename]['name'] ) )) {
					$r = move_uploaded_file( $_FILES[$filename]['tmp_name'], './uploads/products_pictures/' . $_FILES[$filename]['name'] );
				}


				if ($r) {
					$new_filename = $_FILES[$filename]['name'];
					SetRightsToUploadedFile( './uploads/products_pictures/' . $new_filename );
				}

				$r = false;

				if (( $_FILES[$thumbnail]['size'] != 0 && preg_match( '/\.(jpg|jpeg|gif|jpe|pcx|bmp)$/i', $_FILES[$thumbnail]['name'] ) )) {
					$r = move_uploaded_file( $_FILES[$thumbnail]['tmp_name'], './uploads/products_pictures/' . $_FILES[$thumbnail]['name'] );
				}


				if ($r) {
					$new_thumbnail = $_FILES[$thumbnail]['name'];
					SetRightsToUploadedFile( './uploads/products_pictures/' . $new_thumbnail );
				}

				$r = false;

				if (( $_FILES[$enlarged]['size'] != 0 && preg_match( '/\.(jpg|jpeg|gif|jpe|pcx|bmp)$/i', $_FILES[$enlarged]['name'] ) )) {
					$r = move_uploaded_file( $_FILES[$enlarged]['tmp_name'], './uploads/products_pictures/' . $_FILES[$enlarged]['name'] );
				}


				if ($r) {
					$new_enlarged = $_FILES[$enlarged]['name'];
					SetRightsToUploadedFile( './uploads/products_pictures/' . $new_enlarged );
				}


				if ($new_filename != '') {
					db_query( 'insert into ' . PRODUCT_PICTURES . '(productID, filename, thumbnail, enlarged)' . '		values( ' . $productID . ', ' . ' \'' . $new_filename . '\\', ' . ' \'' . $new_thumbnail . '\\', ' . ' \'' . $new_enlarged . '\' ) ' );

					if ($default_picture == -1) {
						$default_pictureID = db_insert_id(  );
						db_query( 'update ' . PRODUCTS_TABLE . ' set default_picture = ' . $default_pictureID . ' where productID=\'' . $productID . '\'' );
					}
				}
			}
		}

	}

	function GetThumbnail($productID) {
		$q = db_query( 'select default_picture from ' . PRODUCTS_TABLE . ' where productID=' . $productID );

		if ($product = db_fetch_row( $q )) {
			$q2 = db_query( 'select filename, thumbnail, enlarged from ' . PRODUCT_PICTURES . ' where photoID=\'' . $product['default_picture'] . '\' and productID=' . $productID );

			if ($picture = db_fetch_row( $q2 )) {
				if (( file_exists( './uploads/products_pictures/' . $picture['thumbnail'] ) && 0 < strlen( $picture['thumbnail'] ) )) {
					return $picture['thumbnail'];
				}


				if (( file_exists( './uploads/products_pictures/' . $picture['filename'] ) && 0 < strlen( $picture['filename'] ) )) {
					return $picture['filename'];
				}
			} 
else {
				$q2 = db_query( 'select filename, thumbnail, enlarged from ' . PRODUCT_PICTURES . ' where productID=' . $productID );

				if ($picture = db_fetch_row( $q2 )) {
					if (( file_exists( './uploads/products_pictures/' . $picture['thumbnail'] ) && 0 < strlen( $picture['thumbnail'] ) )) {
						return $picture['thumbnail'];
					}


					if (( file_exists( './uploads/products_pictures/' . $picture['filename'] ) && 0 < strlen( $picture['filename'] ) )) {
						return $picture['filename'];
					}
				}
			}
		}

		return '';
	}

	function GetPictureCount($productID) {
		$count_pict = db_query( 'select COUNT(photoID) from ' . PRODUCT_PICTURES . ' where productID=' . $productID . ' ' . 'AND filename!=\'\'' );
		$count_pict_row = db_fetch_row( $count_pict );
		return $count_pict_row[0];
	}

	function GetThumbnailCount($productID) {
		$count_pict = db_query( 'select COUNT(photoID) from ' . PRODUCT_PICTURES . ' where productID=' . $productID . ' ' . 'AND thumbnail!=\'\'' );
		$count_pict_row = db_fetch_row( $count_pict );
		return $count_pict_row[0];
	}

	function GetEnlargedPictureCount($productID) {
		$count_pict = db_query( 'select COUNT(photoID) from ' . PRODUCT_PICTURES . ' where productID=' . $productID . ' ' . 'AND enlarged!=\'\'' );
		$count_pict_row = db_fetch_row( $count_pict );
		return $count_pict_row[0];
	}

	function generate_favicon($postvars, $filename) {
		$valid_exts = array( 'jpg', 'jpeg', 'gif', 'png' );
		$ext = end( explode( '.', strtolower( trim( $postvars['image'] ) ) ) );

		if ($postvars['image_size'] <= 179200) {
			if (in_array( $ext, $valid_exts )) {
				if (( $ext == 'jpg' || $ext == 'jpeg' )) {
					$image = imagecreatefromjpeg( $postvars['image_tmp'] );
				} 
else {
					if ($ext == 'gif') {
						$image = imagecreatefromgif( $postvars['image_tmp'] );
					} 
else {
						if ($ext == 'png') {
							$image = imagecreatefrompng( $postvars['image_tmp'] );
						}
					}
				}


				if ($image) {
					$height = getimagesize( $postvars['image_tmp'] )[1];
					[0];
					$width = ;
					$newwidth = $postvars['image_dimensions'];
					$newheight = $postvars['image_dimensions'];
					$tmp = imagecreatetruecolor( $newwidth, $newheight );
					imagecopyresampled( $tmp, $image, 0, 0, 0, 0, $newwidth, $newheight, $width, $height );

					if (!( imagejpeg( $tmp, $filename, 100 ))) {
						exit( 'Could not make image file' );
						(bool)true;
					}


					if (file_exists( $filename )) {
						rename( $filename, $filename . '.ico' );
						return MSG_INFORMATION_SAVED;
					}

					return 'File was not created.';
				}

				return 'Could not create image file.';
			}

			return 'Invalid file type. You must upload an image file. (jpg, jpeg, gif, png).';
		}

		return 'File size too large. Max allowed file size is 175kb.';
	}

?>