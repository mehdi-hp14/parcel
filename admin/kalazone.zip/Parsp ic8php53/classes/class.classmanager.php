<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class ClassManager {
		function includeClass($ClassName) {
			if (!class_exists( strtolower( $ClassName ), false )) {
				if (!file_exists( 'class.' . strtolower( $ClassName ) . '.php' )) {
					return false;
				}

				include_once( DIR_CLASSES . '/class.' . strtolower( $ClassName ) . '.php' );

				if (( isset( $_GET['debug'] ) && $_GET['debug'] == 'files' )) {
					$backtrace = debug_backtrace(  );
					$backtrace = $backtrace[2];
					$backtrace = str_replace( realpath( DIR_ROOT ) . DIRECTORY_SEPARATOR, '', $backtrace['file'] ) . ':' . $backtrace['line'];
					print ( '<pre>
include ' . $ClassName . '
' ) . $backtrace . '
</pre>';
				}
			}

			return true;
		}

		function getInstance($ClassName) {
			$Object = null;

			if (ClassManager::includeClass( $ClassName )) {
				$Object = new $ClassName(  );
			}

			return $Object;
		}
	}

?>