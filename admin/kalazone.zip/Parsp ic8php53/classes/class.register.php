<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class Register extends Singleton {
		var $Variables = null;

		function Register() {
			$this->Variables = array(  );
		}

		function set(&$Variable, $Value) {
			$this->Variables[$Variable] = &$Value;

		}

		function assign($Variable, $Value) {
			$this->Variables[$Variable] = $Value;
		}

		function get($Variable) {
			if (!isset( $this->Variables[$Variable] )) {
				$this->Variables[$Variable] = null;
				return $this->Variables[$Variable];
			}

			return $this->Variables[$Variable];
		}

		function is_set($Variable) {
			return isset( $this->Variables[$Variable] );
		}
	}

?>