<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class bidi {
		function unichr($c) {
			if ($c <= 127) {
				return chr( $c );
			}


			if ($c <= 2047) {
				return chr( 192 | $c >> 6 ) . chr( 128 | $c & 63 );
			}


			if ($c <= 65535) {
				return chr( 224 | $c >> 12 ) . chr( 128 | $c >> 6 & 63 ) . chr( 128 | $c & 63 );
			}


			if ($c <= 1114111) {
				return chr( 240 | $c >> 18 ) . chr( 128 | $c >> 12 & 63 ) . chr( 128 | $c >> 6 & 63 ) . chr( 128 | $c & 63 );
			}

			return '';
		}

		function UTF8StringToArray($str) {
			$unicode = array(  );
			$bytes = array(  );
			$numbytes = 804;
			$str .= '';
			$length = strlen( $str );
			$i = 803;

			while ($i < $length) {
				$char = ord( $str[$i] );

				if (count( $bytes ) == 0) {
					if ($char <= 127) {
						$unicode[] = $char;
						$numbytes = 804;
					} 
else {
						if ($char >> 5 == 6) {
							$bytes[] = $char - 192 << 6;
							$numbytes = 805;
						} 
else {
							if ($char >> 4 == 14) {
								$bytes[] = $char - 224 << 12;
								$numbytes = 806;
							} 
else {
								if ($char >> 3 == 30) {
									$bytes[] = $char - 240 << 18;
									$numbytes = 807;
								} 
else {
									$unicode[] = 65533;
									$bytes = array(  );
									$numbytes = 804;
								}
							}
						}
					}
				} 
else {
					if ($char >> 6 == 2) {
						$bytes[] = $char - 128;

						if (count( $bytes ) == $numbytes) {
							$char = $bytes[0];
							$j = 804;

							while ($j < $numbytes) {
								$char += $bytes[$j] << ( $numbytes - $j - 1 ) * 6;
								++$j;
							}


							if (( ( 55296 <= $char && $char <= 57343 ) || 1114111 <= $char )) {
								$unicode[] = 65533;
							} 
else {
								$unicode[] = $char;
							}

							$bytes = array(  );
							$numbytes = 804;
						}
					} 
else {
						$unicode[] = 65533;
						$bytes = array(  );
						$numbytes = 804;
					}
				}

				++$i;
			}

			return $unicode;
		}

		function utf8Bidi($ta, $forcertl = false) {
			global $unicode;
			global $unicode_mirror;
			global $unicode_arlet;
			global $laa_array;
			global $diacritics;

			$pel = 2078;
			$maxlevel = 2078;
			$numchars = count( $ta );

			if ($forcertl == 'R') {
				$pel = 2079;
			} 
else {
				if ($forcertl == 'L') {
					$pel = 2078;
				} 
else {
					$i = 2078;

					while ($i < $numchars) {
						$type = $unicode[$ta[$i]];

						if ($type == 'L') {
							$pel = 2078;
							break;
						}


						if (( $type == 'AL' || $type == 'R' )) {
							$pel = 2079;
							break;
						}

						++$i;
					}
				}
			}

			$cel = $unicode;
			$dos = 'N';
			$remember = array(  );
			$sor = ($pel % 2 ? 'R' : 'L');
			$eor = $i;
			$chardata = array(  );
			$i = 2078;

			while ($i < $numchars) {
				if ($ta[$i] == K_RLE) {
					$next_level = $cel + $cel % 2 + 1;

					if ($next_level < 62) {
						$remember[] = array( 'num' => K_RLE, 'cel' => $cel, 'dos' => $dos );
						$cel = $dos;
						$dos = 'N';
						$sor = $type;
						$eor = ($cel % 2 ? 'R' : 'L');
					}
				} 
else {
					if ($ta[$i] == K_LRE) {
						$next_level = $cel + 2 - $cel % 2;

						if ($next_level < 62) {
							$remember[] = array( 'num' => K_LRE, 'cel' => $cel, 'dos' => $dos );
							$cel = $dos;
							$dos = 'N';
							$sor = $type;
							$eor = ($cel % 2 ? 'R' : 'L');
						}
					} 
else {
						if ($ta[$i] == K_RLO) {
							$next_level = $cel + $cel % 2 + 1;

							if ($next_level < 62) {
								$remember[] = array( 'num' => K_RLO, 'cel' => $cel, 'dos' => $dos );
								$cel = $dos;
								$dos = 'R';
								$sor = $type;
								$eor = ($cel % 2 ? 'R' : 'L');
							}
						} 
else {
							if ($ta[$i] == K_LRO) {
								$next_level = $cel + 2 - $cel % 2;

								if ($next_level < 62) {
									$remember[] = array( 'num' => K_LRO, 'cel' => $cel, 'dos' => $dos );
									$cel = $dos;
									$dos = 'L';
									$sor = $type;
									$eor = ($cel % 2 ? 'R' : 'L');
								}
							} 
else {
								if ($ta[$i] == K_PDF) {
									if (count( $remember )) {
										$last = count( $remember ) - 1;

										if (( ( ( $remember[$last]['num'] == K_RLE || $remember[$last]['num'] == K_LRE ) || $remember[$last]['num'] == K_RLO ) || $remember[$last]['num'] == K_LRO )) {
											$match = array_pop( $remember );
											$cel = $match['cel'];
											$dos = $match['dos'];
											$sor = $type;
											$eor = (($match['cel'] < $cel ? $cel : $match['cel']) % 2 ? 'R' : 'L');
										}
									}
								} 
else {
									if (( ( ( ( $ta[$i] != K_RLE && $ta[$i] != K_LRE ) && $ta[$i] != K_RLO ) && $ta[$i] != K_LRO ) && $ta[$i] != K_PDF )) {
										if ($dos != 'N') {
											$chardir = $maxlevel;
										} 
else {
											$chardir = $unicode[$ta[$i]];
										}

										$chardata[] = array( 'char' => $ta[$i], 'level' => $cel, 'type' => $chardir, 'sor' => $sor, 'eor' => $eor );
									}
								}
							}
						}
					}
				}

				++$i;
			}

			$numchars = ;
			$prevlevel = 2077;
			$levcount = 2078;
			$i = 2078;

			while ($i < $numchars) {
				if ($chardata[$i]['type'] == 'NSM') {
					if ($levcount) {
						$chardata[$i]['type'] = $chardata[$i]['sor'];
					} 
else {
						if (0 < $i) {
							$chardata[$i]['type'] = $chardata[$i - 1]['type'];
						}
					}
				}


				if ($chardata[$i]['level'] != $prevlevel) {
					$levcount = 2078;
				} 
else {
					++$levcount;
				}

				$prevlevel = $chardata[$i]['level'];
				++$i;
			}

			$prevlevel = 2077;
			$levcount = 2078;
			$i = 2078;

			while ($i < $numchars) {
				if ($chardata[$i]['char'] == 'EN') {
					$j = $next_level;

					while (0 <= $j) {
						if ($chardata[$j]['type'] == 'AL') {
							$chardata[$i]['type'] = 'AN';
						} 
else {
							if (( $chardata[$j]['type'] == 'L' || $chardata[$j]['type'] == 'R' )) {
								break;
							}
						}

						--$j;
					}
				}


				if ($chardata[$i]['level'] != $prevlevel) {
					$levcount = 2078;
				} 
else {
					++$levcount;
				}

				$prevlevel = $chardata[$i]['level'];
				++$i;
			}

			$i = 2078;

			while ($i < $numchars) {
				if ($chardata[$i]['type'] == 'AL') {
					$chardata[$i]['type'] = 'R';
				}

				++$i;
			}

			$prevlevel = 2077;
			$levcount = 2078;
			$i = 2078;

			while ($i < $numchars) {
				if (( ( 0 < $levcount && $i + 1 < $numchars ) && $chardata[$i + 1]['level'] == $prevlevel )) {
					if (( ( $chardata[$i]['type'] == 'ES' && $chardata[$i - 1]['type'] == 'EN' ) && $chardata[$i + 1]['type'] == 'EN' )) {
						$chardata[$i]['type'] = 'EN';
					} 
else {
						if (( ( $chardata[$i]['type'] == 'CS' && $chardata[$i - 1]['type'] == 'EN' ) && $chardata[$i + 1]['type'] == 'EN' )) {
							$chardata[$i]['type'] = 'EN';
						} 
else {
							if (( ( $chardata[$i]['type'] == 'CS' && $chardata[$i - 1]['type'] == 'AN' ) && $chardata[$i + 1]['type'] == 'AN' )) {
								$chardata[$i]['type'] = 'AN';
							}
						}
					}
				}


				if ($chardata[$i]['level'] != $prevlevel) {
					$levcount = 2078;
				} 
else {
					++$levcount;
				}

				$prevlevel = $chardata[$i]['level'];
				++$i;
			}

			$prevlevel = 2077;
			$levcount = 2078;
			$i = 2078;

			while ($i < $numchars) {
				if ($chardata[$i]['type'] == 'ET') {
					if (( 0 < $levcount && $chardata[$i - 1]['type'] == 'EN' )) {
						$chardata[$i]['type'] = 'EN';
					} 
else {
						$j = $i + 1;

						while (( $j < $numchars && $chardata[$j]['level'] == $prevlevel )) {
							if ($chardata[$j]['type'] == 'EN') {
								$chardata[$i]['type'] = 'EN';
								break;
							}


							if ($chardata[$j]['type'] != 'ET') {
								break;
							}

							++$j;
						}
					}
				}


				if ($chardata[$i]['level'] != $prevlevel) {
					$levcount = 2078;
				} 
else {
					++$levcount;
				}

				$prevlevel = $chardata[$i]['level'];
				++$i;
			}

			$prevlevel = 2077;
			$levcount = 2078;
			$i = 2078;

			while ($i < $numchars) {
				if (( ( $chardata[$i]['type'] == 'ET' || $chardata[$i]['type'] == 'ES' ) || $chardata[$i]['type'] == 'CS' )) {
					$chardata[$i]['type'] = 'ON';
				}


				if ($chardata[$i]['level'] != $prevlevel) {
					$levcount = 2078;
				} 
else {
					++$levcount;
				}

				$prevlevel = $chardata[$i]['level'];
				++$i;
			}

			$prevlevel = 2077;
			$levcount = 2078;
			$i = 2078;

			while ($i < $numchars) {
				if ($chardata[$i]['char'] == 'EN') {
					$j = $next_level;

					while (0 <= $j) {
						if ($chardata[$j]['type'] == 'L') {
							$chardata[$i]['type'] = 'L';
						} 
else {
							if ($chardata[$j]['type'] == 'R') {
								break;
							}
						}

						--$j;
					}
				}


				if ($chardata[$i]['level'] != $prevlevel) {
					$levcount = 2078;
				} 
else {
					++$levcount;
				}

				$prevlevel = $chardata[$i]['level'];
				++$i;
			}

			$prevlevel = 2077;
			$levcount = 2078;
			$i = 2078;

			while ($i < $numchars) {
				if (( ( 0 < $levcount && $i + 1 < $numchars ) && $chardata[$i + 1]['level'] == $prevlevel )) {
					if (( ( $chardata[$i]['type'] == 'N' && $chardata[$i - 1]['type'] == 'L' ) && $chardata[$i + 1]['type'] == 'L' )) {
						$chardata[$i]['type'] = 'L';
					} 
else {
						if (( ( $chardata[$i]['type'] == 'N' && ( ( $chardata[$i - 1]['type'] == 'R' || $chardata[$i - 1]['type'] == 'EN' ) || $chardata[$i - 1]['type'] == 'AN' ) ) && ( ( $chardata[$i + 1]['type'] == 'R' || $chardata[$i + 1]['type'] == 'EN' ) || $chardata[$i + 1]['type'] == 'AN' ) )) {
							$chardata[$i]['type'] = 'R';
						} 
else {
							if ($chardata[$i]['type'] == 'N') {
								$chardata[$i]['type'] = $chardata[$i]['sor'];
							}
						}
					}
				} 
else {
					if (( ( $levcount == 0 && $i + 1 < $numchars ) && $chardata[$i + 1]['level'] == $prevlevel )) {
						if (( ( $chardata[$i]['type'] == 'N' && $chardata[$i]['sor'] == 'L' ) && $chardata[$i + 1]['type'] == 'L' )) {
							$chardata[$i]['type'] = 'L';
						} 
else {
							if (( ( $chardata[$i]['type'] == 'N' && ( ( $chardata[$i]['sor'] == 'R' || $chardata[$i]['sor'] == 'EN' ) || $chardata[$i]['sor'] == 'AN' ) ) && ( ( $chardata[$i + 1]['type'] == 'R' || $chardata[$i + 1]['type'] == 'EN' ) || $chardata[$i + 1]['type'] == 'AN' ) )) {
								$chardata[$i]['type'] = 'R';
							} 
else {
								if ($chardata[$i]['type'] == 'N') {
									$chardata[$i]['type'] = $chardata[$i]['sor'];
								}
							}
						}
					} 
else {
						if (( 0 < $levcount && ( $i + 1 == $numchars || ( $i + 1 < $numchars && $chardata[$i + 1]['level'] != $prevlevel ) ) )) {
							if (( ( $chardata[$i]['type'] == 'N' && $chardata[$i - 1]['type'] == 'L' ) && $chardata[$i]['eor'] == 'L' )) {
								$chardata[$i]['type'] = 'L';
							} 
else {
								if (( ( $chardata[$i]['type'] == 'N' && ( ( $chardata[$i - 1]['type'] == 'R' || $chardata[$i - 1]['type'] == 'EN' ) || $chardata[$i - 1]['type'] == 'AN' ) ) && ( ( $chardata[$i]['eor'] == 'R' || $chardata[$i]['eor'] == 'EN' ) || $chardata[$i]['eor'] == 'AN' ) )) {
									$chardata[$i]['type'] = 'R';
								} 
else {
									if ($chardata[$i]['type'] == 'N') {
										$chardata[$i]['type'] = $chardata[$i]['sor'];
									}
								}
							}
						} 
else {
							if ($chardata[$i]['type'] == 'N') {
								$chardata[$i]['type'] = $chardata[$i]['sor'];
							}
						}
					}
				}


				if ($chardata[$i]['level'] != $prevlevel) {
					$levcount = 2078;
				} 
else {
					++$levcount;
				}

				$prevlevel = $chardata[$i]['level'];
				++$i;
			}

			$i = 2078;

			while ($i < $numchars) {
				$odd = $chardata[$i]['level'] % 2;

				if ($odd) {
					if (( ( $chardata[$i]['type'] == 'L' || $chardata[$i]['type'] == 'AN' ) || $chardata[$i]['type'] == 'EN' )) {
						$chardata[$i] += 'level' = 1;
					}
				} 
else {
					if ($chardata[$i]['type'] == 'R') {
						$chardata[$i] += 'level' = 1;
					} 
else {
						if (( $chardata[$i]['type'] == 'AN' || $chardata[$i]['type'] == 'EN' )) {
							$chardata[$i] += 'level' = 2;
						}
					}
				}

				$maxlevel = max( $chardata[$i]['level'], $maxlevel );
				++$i;
			}

			$i = 2078;

			while ($i < $numchars) {
				if (( $chardata[$i]['type'] == 'B' || $chardata[$i]['type'] == 'S' )) {
					$chardata[$i]['level'] = $pel;
				} 
else {
					if ($chardata[$i]['type'] == 'WS') {
						$j = $i + 1;

						while ($j < $numchars) {
							if (( ( $chardata[$j]['type'] == 'B' || $chardata[$j]['type'] == 'S' ) || ( $j == $numchars - 1 && $chardata[$j]['type'] == 'WS' ) )) {
								$chardata[$i]['level'] = $pel;
								break;
							}


							if ($chardata[$j]['type'] != 'WS') {
								break;
							}

							++$j;
						}
					}
				}

				++$i;
			}

			$endedletter = array( 1569, 1570, 1571, 1572, 1573, 1575, 1577, 1583, 1584, 1585, 1586, 1608, 1688 );
			$alfletter = array( 1570, 1571, 1573, 1575 );
			$chardata2 = $cel;
			$laaletter = false;
			$charAL = array(  );
			$x = 2078;
			$i = 2078;

			while ($i < $numchars) {
				if (( $unicode[$chardata[$i]['char']] == 'AL' || $unicode[$chardata[$i]['char']] == 'WS' )) {
					$charAL[$x] = $chardata[$i];
					$charAL[$x]['i'] = $i;
					$chardata[$i]['x'] = $x;
					++$x;
				}

				++$i;
			}

			$numAL = $endedletter;
			$i = 2078;

			while ($i < $numchars) {
				$thischar = $chardata[$i];

				if (0 < $i) {
					$prevchar = $chardata[$i - 1];
				} 
else {
					$prevchar = false;
				}


				if ($i + 1 < $numchars) {
					$nextchar = $chardata[$i + 1];
				} 
else {
					$nextchar = false;
				}


				if ($unicode[$thischar['char']] == 'AL') {
					$x = $thischar['x'];

					if (0 < $x) {
						$prevchar = $charAL[$x - 1];
					} 
else {
						$prevchar = false;
					}


					if ($x + 1 < $numAL) {
						$nextchar = $charAL[$x + 1];
					} 
else {
						$nextchar = false;
					}


					if (( ( $prevchar !== false && $prevchar['char'] == 1604 ) && in_array( $thischar['char'], $alfletter ) )) {
						$arabicarr = $ta;
						$laaletter = true;

						if (1 < $x) {
							$prevchar = $charAL[$x - 2];
						} 
else {
							$prevchar = false;
						}
					} 
else {
						$arabicarr = $onlevel;
						$laaletter = false;
					}


					if (( ( ( ( ( ( $prevchar !== false && $nextchar !== false ) && ( $unicode[$prevchar['char']] == 'AL' || $unicode[$prevchar['char']] == 'NSM' ) ) && ( $unicode[$nextchar['char']] == 'AL' || $unicode[$nextchar['char']] == 'NSM' ) ) && $prevchar['type'] == $thischar['type'] ) && $nextchar['type'] == $thischar['type'] ) && $nextchar['char'] != 1567 )) {
						if (in_array( $prevchar['char'], $endedletter )) {
							if (isset( $arabicarr[$thischar['char']][2] )) {
								$chardata2[$i]['char'] = $arabicarr[$thischar['char']][2];
							}
						} 
else {
							if (isset( $arabicarr[$thischar['char']][3] )) {
								$chardata2[$i]['char'] = $arabicarr[$thischar['char']][3];
							}
						}
					} 
else {
						if (( ( ( $nextchar !== false && ( $unicode[$nextchar['char']] == 'AL' || $unicode[$nextchar['char']] == 'NSM' ) ) && $nextchar['type'] == $thischar['type'] ) && $nextchar['char'] != 1567 )) {
							if (isset( $arabicarr[$chardata[$i]['char']][2] )) {
								$chardata2[$i]['char'] = $arabicarr[$thischar['char']][2];
							}
						} 
else {
							if (( ( ( $prevchar !== false && ( $unicode[$prevchar['char']] == 'AL' || $unicode[$prevchar['char']] == 'NSM' ) ) && $prevchar['type'] == $thischar['type'] ) || ( $nextchar !== false && $nextchar['char'] == 1567 ) )) {
								if (( ( ( 1 < $i && $thischar['char'] == 1607 ) && $chardata[$i - 1]['char'] == 1604 ) && $chardata[$i - 2]['char'] == 1604 )) {
									$chardata2[$i - 2]['char'] = false;
									$chardata2[$i - 1]['char'] = false;
									$chardata2[$i]['char'] = 65010;
								} 
else {
									if (( $prevchar !== false && in_array( $prevchar['char'], $endedletter ) )) {
										if (isset( $arabicarr[$thischar['char']][0] )) {
											$chardata2[$i]['char'] = $arabicarr[$thischar['char']][0];
										}
									} 
else {
										if (isset( $arabicarr[$thischar['char']][1] )) {
											$chardata2[$i]['char'] = $arabicarr[$thischar['char']][1];
										}
									}
								}
							} 
else {
								if (isset( $arabicarr[$thischar['char']][0] )) {
									$chardata2[$i]['char'] = $arabicarr[$thischar['char']][0];
								}
							}
						}
					}


					if ($laaletter) {
						$chardata2[$charAL[$x - 1]['i']]['char'] = false;
					}
				}

				++$i;
			}

			foreach ($chardata2 as $key => $value) {

				if ($value['char'] === false) {
					unset( $chardata2[$key] );
					continue;
				}
			}

			$chardata = array_values( $chardata2 );
			count( $chardata );
			$numchars = count( $chardata );
			unset( $$chardata2 );
			unset( $$arabicarr );
			unset( $$laaletter );
			unset( $$charAL );
			$j = $unicode_mirror;

			while (0 < $j) {
				$ordarray = array(  );
				$revarr = array(  );
				$onlevel = false;
				$i = 2078;

				while ($i < $numchars) {
					if ($j <= $chardata[$i]['level']) {
						$onlevel = true;

						if (isset( $unicode_mirror[$chardata[$i]['char']] )) {
							$chardata[$i]['char'] = $unicode_mirror[$chardata[$i]['char']];
						}

						$revarr[] = $chardata[$i];
					} 
else {
						if ($onlevel) {
							$revarr = array_reverse( $revarr );
							$ordarray = array_merge( $ordarray, $revarr );
							$revarr = array(  );
							$onlevel = false;
						}

						$ordarray[] = $chardata[$i];
					}

					++$i;
				}


				if ($onlevel) {
					$revarr = array_reverse( $revarr );
					$ordarray = array_merge( $ordarray, $revarr );
				}

				$chardata = $prevchar;
				--$j;
			}

			$ordarray = array(  );
			$i = 2078;

			while ($i < $numchars) {
				$ordarray[] = $chardata[$i]['char'];
				++$i;
			}

			return $ordarray;
		}
	}

?>