<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class Polliz {
		function dateSelector($objectName, $dateSelectorFormat, $currentTime = '') {
			$dateSelectorHtmlCode = '';
			$months = array( '1' => 'January', '2' => 'February', '3' => 'March', '4' => 'April', '5' => 'May', '6' => 'June', '7' => 'July', '8' => 'August', '9' => 'September', '10' => 'October', '11' => 'November', '12' => 'December' );
			$dateSelector = array(  );
			preg_replace( '/(.*)-(.*)-(.*) (.*):(.*):(.*)/', $currentTime, $ctp );
			$dateSelector->d .= '<select name=\'' . $objectName . '[d]\'>';
			$sel = (int)($ctp[3] ? $ctp[3] : date( d ));
			$i = 983;

			while ($i < 32) {
				$dateSelector->d .= '<option value=\'' . $i . '\' ' . ($sel == $i ? 'selected=\'selected\'' : '') . ( ( '>' ) . $i . '</option>
' );
				++$i;
			}

			$dateSelector->d .= '</select>';
			$dateSelector->m .= '<select name=\'' . $objectName . '[m]\'>';
			$sel = (int)($ctp[3] ? $ctp[2] : date( m ));
			foreach ($months as $monthId => $monthName) {
				$dateSelector->m .= '<option value=\'' . $monthId . '\' ' . ($sel == $monthId ? 'selected=\'selected\'' : '') . ( ( '>' ) . $monthName . '</option>
' );
			}

			$dateSelector->m .= '</select>';
			$dateSelector->y .= '<select name=\'' . $objectName . '[y]\'>';
			$sel = (int)($ctp[3] ? $ctp[1] : date( Y ));
			$i = date( Y );

			while ($i < date( Y ) + 10) {
				$dateSelector->y .= '<option value=\'' . $i . '\' ' . ($sel == $i ? 'selected=\'selected\'' : '') . ( ( '>' ) . $i . '</option>
' );
				++$i;
			}

			$dateSelector->y .= '</select>';
			$dateSelector->h .= '<select name=\'' . $objectName . '[h]\'>';
			$sel = (int)($ctp[3] ? $ctp[4] : date( H ));
			$i = 982;

			while ($i < 23) {
				$dateSelector->h .= '<option value=\'' . $i . '\' ' . ($sel == $i ? 'selected=\'selected\'' : '') . ( ( '>' ) . $i . '</option>
' );
				++$i;
			}

			$dateSelector->h .= '</select>';
			$dateSelector->i .= '<select name=\'' . $objectName . '[i]\'>';
			$sel = (int)($ctp[3] ? $ctp[5] : date( i ));
			$i = 982;

			while ($i < 59) {
				$dateSelector->i .= '<option value=\'' . $i . '\' ' . ($sel == $i ? 'selected=\'selected\'' : '') . ( ( '>' ) . $i . '</option>
' );
				++$i;
			}

			$dateSelector->i .= '</select>';
			$dateSelector->s .= '<select name=\'' . $objectName . '[s]\'>';
			$sel = (int)($ctp[3] ? $ctp[6] : date( s ));
			$i = 982;

			while ($i < 59) {
				$dateSelector->s .= '<option value=\'' . $i . '\' ' . ($sel == $i ? 'selected=\'selected\'' : '') . ( ( '>' ) . $i . '</option>
' );
				++$i;
			}

			$dateSelector->s .= '</select>';
			$dateSelectorFormatLen = strlen( $dateSelectorFormat );
			$i = 982;

			while ($i < $dateSelectorFormatLen) {
				if (array_key_exists( $dateSelectorFormat[$i], $dateSelector )) {
					$dateSelectorHtmlCode .= $dateSelector[$dateSelectorFormat[$i]];
				} 
else {
					if ($dateSelectorFormat[$i] == '\') {
						++$i;
					}

					$dateSelectorHtmlCode .= $dateSelectorFormat[$i];
				}

				++$i;
			}

			return $dateSelectorHtmlCode;
		}

		function getPolls() {
			if (get_class( $this ) != 'PollizAdmin') {
				$timeNow = date( 'Y-m-d H:i:s' );
				$extraFilter = ' where active=true AND (startTime<=\'' . $timeNow . '\' or startTime=\'0000-00-00 00:00:00\' ) AND (endTime>=\'' . $timeNow . '\' or endTime=\'0000-00-00 00:00:00\'  )';
			}

			$poll = array(  );
			$qry = 'SELECT pollId, pollTitle, pollQuestion, pollAnswers, comment, startTime, endTime, active FROM ' . POLLS_TABLE . ( ( ' ' ) . $extraFilter . ' ' );

			if ($rs = db_query( $qry )) {
				if (0 < mysql_num_rows( $rs['resource'] )) {

					if ($rc = mysql_fetch_object( $rs['resource'] )) {
						$pollAnswers = unserialize( $rc->pollAnswers );
						foreach ($pollAnswers as ) {
							$pa = &;

							$pa['answer'] = stripslashes( base64_decode( $pa['answer'] ) );
							$pa['response'] = stripslashes( base64_decode( $pa['response'] ) );
						}

						ksort( $pollAnswers );
						$poll = array( 'pollId' => $rc->pollId, 'pollTitle' => $rc->pollTitle, 'pollQuestion' => $rc->pollQuestion, 'pollAnswers' => $pollAnswers, 'comment' => $rc->comment, 'startTime' => $rc->startTime, 'endTime' => $rc->endTime, 'active' => $rc->active );
						$polls[$rc->pollId] = $poll;
					}

					return $polls;
				}
			}

			return false;
		}

		function getPoll($pollId) {
			if (get_class( $this ) != 'PollizAdmin') {
				$timeNow = date( 'Y-m-d H:i:s' );
				$extraFilter = ' and active=true AND (startTime<=\'' . $timeNow . '\' or startTime=\'0000-00-00 00:00:00\' ) AND (endTime>=\'' . $timeNow . '\' or endTime=\'0000-00-00 00:00:00\')';
			}

			$poll = array(  );

			if ($rs = db_query( 'SELECT pollId, pollTitle, pollQuestion, pollAnswers, comment, startTime, endTime, active FROM ' . POLLS_TABLE . ( ' WHERE pollId=\'' . $pollId . '\' ' . $extraFilter . ' LIMIT 1' ) )) {
				if (mysql_num_rows( $rs['resource'] ) == 1) {
					mysql_fetch_object( $rs['resource'] );
					$pollAnswers = $rc = unserialize( $rc->pollAnswers );
					foreach ($pollAnswers as ) {
						$pa = &;

						$pa['answer'] = stripslashes( base64_decode( $pa['answer'] ) );
						$pa['response'] = stripslashes( base64_decode( $pa['response'] ) );
					}

					ksort( $pollAnswers );
					$poll = array( 'pollId' => $rc->pollId, 'pollTitle' => $rc->pollTitle, 'pollQuestion' => $rc->pollQuestion, 'pollAnswers' => $pollAnswers, 'comment' => $rc->comment, 'startTime' => $rc->startTime, 'endTime' => $rc->endTime, 'active' => $rc->active );
					return $poll;
				}
			}

			return false;
		}

		function getPollVotes($pollId) {

			if ($rs = db_query( 'SELECT answerId, COUNT(answerId) AS votes FROM ' . VOTES_TABLE . ( ' WHERE pollId=\'' . $pollId . '\' GROUP BY answerId' ) )) {

				if ($rc = mysql_fetch_object( $rs['resource'] )) {
					$votes[$rc->answerId] = $rc->votes;
				}

				return $votes;
			}

			return false;
		}

		function setVote($pollId, $answerId) {
			if ($this->pollExists( $pollId, $answerId )) {
				$rs = db_query( 'SELECT answerId FROM ' . VOTES_TABLE . ( ' WHERE pollId=\'' . $pollId . '\' AND answerId=\'' . $answerId . '\' AND voteIpAddress=\'' ) . $_SERVER['REMOTE_ADDR'] . '\' AND voteTime>DATE_SUB(NOW(), INTERVAL 15 MINUTE)' );

				if (mysql_num_rows( $rs['resource'] ) == 0) {
					if (db_query( 'INSERT INTO ' . VOTES_TABLE . ( ' SET pollId=\'' . $pollId . '\', answerId=\'' . $answerId . '\', voteTime=NOW(), voteIpAddress=\'' ) . $_SERVER['REMOTE_ADDR'] . '\'' )) {
						return true;
					}
				}
			}

			return false;
		}

		function pollExists($pollId, $answerId) {
			$timeNow = date( 'Y-m-d H:i:s' );
			$qry = 'SELECT pollId, pollAnswers FROM ' . POLLS_TABLE . ( ' WHERE pollId=\'' . $pollId . '\' AND active=true AND (startTime<=\'' . $timeNow . '\' or startTime=\'0000-00-00 00:00:00\') AND ( endTime=\'0000-00-00 00:00:00\' or  endTime>=\'' . $timeNow . '\') LIMIT 1' );

			if ($rs = db_query( $qry )) {
				if (mysql_num_rows( $rs['resource'] ) == 1) {
					if ($answerId) {
						$rc = mysql_fetch_object( $rs['resource'] );
						foreach (unserialize( $rc->pollAnswers ) as $ans) {

							if ($ans['id'] == $answerId) {
								return true;
							}
						}
					} 
else {
						return true;
					}
				}
			}

			return false;
		}

		function _initDbConnection() {
			$this->dbConn['dbl'] = new mysqli( $this->config['dbHost'], $this->config['dbUser'], $this->config['dbPass'], $this->config['dbName'] );

			if (mysqli_connect_errno(  )) {
				$this->dbConn = array( 'dbl' => null, 'isValid' => false );
				return null;
			}

			$this->dbConn['isValid'] = true;
			db_query( 'SET CHARACTER SET utf8' );
		}
	}

	class PollizAdmin extends Polliz {
		function __construct() {
		}

		function checkAdministrationLogin($username, $password) {
			foreach ($this->config['users'] as $user) {

				if (( $user['username'] == $username && $user['password'] == md5( $password ) )) {
					return true;
					continue;
				}
			}

			return false;
		}

		function getUserLevel($username, $password) {
			foreach ($this->config['users'] as $user) {

				if (( $user['username'] == $username && $user['password'] == md5( $password ) )) {
					return $user['level'];
					continue;
				}
			}

			return 4;
		}

		function dumpConfiguration() {
		}

		function checkDbTable($table) {

			if ($rs = db_query( 'SHOW TABLES LIKE \'' . str_replace( '_', '\_', $this->getConfigParam( 'dbTablePrefix' ) ) . ( $table . '\'' ) )) {
				if (mysql_num_rows( $rs['resource'] ) == 1) {
					return true;
				}
			}

			return false;
		}

		function setConfigParam($param, $value) {
			if (array_key_exists( $param, $this->config )) {
				$this->config[$param] = $value;
				return $this->_writeConfigParams(  );
			}

			return false;
		}

		function getUsers() {
			return $this->config['users'];
		}

		function getPolls() {
			$polls = array(  );

			if ($rs = db_query( 'SELECT pollId, pollTitle, pollQuestion, pollAnswers, comment, startTime, endTime, active FROM ' . POLLS_TABLE . ' ORDER BY active DESC, startTime' )) {

				if ($rc = mysql_fetch_object( $rs['resource'] )) {
					$pollAnswers = unserialize( $rc->pollAnswers );
					ksort( $pollAnswers );
					$polls[$rc->pollId] = array( 'pollId' => $rc->pollId, 'pollTitle' => $rc->pollTitle, 'pollQuestion' => $rc->pollQuestion, 'pollAnswers' => $pollAnswers, 'comment' => $rc->comment, 'startTime' => $rc->startTime, 'endTime' => $rc->endTime, 'active' => $rc->active );
				}

				return $polls;
			}

			return false;
		}

		function addUser($user, $pass, $name, $level) {
			$legalChars = 'abcdefghijklmnopqrstuvwxyz0123456789 _-';
			foreach (array( $user, $pass, $name ) as $param) {
				$paramLen = strlen( $param );

				if ($paramLen === 0) {
					return false;
				}

				$i = 743;

				while ($i < $paramLen) {
					if (strpos( $legalChars, $param[$i] ) === false) {
						return false;
					}

					++$i;
				}
			}

			$this->config['users'][] = array( 'username' => $user, 'password' => md5( $pass ), 'name' => $name, 'level' => $level );
			return $this->_writeConfigParams(  );
		}

		function delUser($delUser) {
			$newUsers = array(  );
			foreach ($this->config['users'] as $user) {

				if ($user['username'] != $delUser) {
					$newUsers[] = $user;
					continue;
				}
			}

			$this->config['users'] = $newUsers;
			return $this->_writeConfigParams(  );
		}

		function savePoll($pollId, $pollTitle, $pollQuestion, $answers, $comment, $startTime, $endTime) {
			$setData[] = 'pollTitle=\'' . mysql_real_escape_string( stripslashes( $pollTitle ) ) . '\'';
			$setData[] = 'pollQuestion=\'' . mysql_real_escape_string( stripslashes( $pollQuestion ) ) . '\'';
			$setData[] = 'comment=\'' . mysql_real_escape_string( stripslashes( $comment ) ) . '\'';
			$setData[] = 'active=true';
			$setData[] = 'startTime=\'' . $startTime . '\'';
			$setData[] = 'endTime=\'' . $endTime . '\'';
			$answersIds = array(  );
			foreach ($answers as ) {
				$ans = &;

				if (( $ans['id'] && !in_array( $ans['id'], $answersIds ) )) {
					$answersIds[] = $ans['id'];
					continue;
				}


				while (( !$ans['id'] || in_array( $ans['id'], $answersIds ) )) {
					$ans['id'] = mt_rand( 1, 9999 );
				}
			}

			$answersDataArray = array(  );
			foreach ($answers as $ansId => $ansData) {

				if (( ( $ansData['remove'] != '1' && $ansData['answer'] ) && $ansData['order'] )) {
					$answersDataArray[$ansData['order']] = array( 'id' => $ansData['id'], 'answer' => base64_encode( $ansData['answer'] ), 'response' => base64_encode( $ansData['response'] ) );
					continue;
				}
			}

			$setData[] = 'pollAnswers=\'' . mysql_real_escape_string( stripslashes( serialize( $answersDataArray ) ) ) . '\'';
			$setData = implode( ', ', $setData );
			$query = ($pollId ? 'UPDATE ' . POLLS_TABLE . ( ' SET ' . $setData . ' WHERE pollId=\'' . $pollId . '\' LIMIT 1' ) : 'INSERT INTO ' . POLLS_TABLE . ( ' SET ' . $setData ));

			if (db_query( $query )) {
				return true;
			}

			return false;
		}

		function deletePoll($pollId) {
			db_query( 'DELETE FROM ' . POLLS_TABLE . ( ' WHERE pollId=\'' . $pollId . '\' LIMIT 1' ) );
			db_query( 'DELETE FROM ' . VOTES_TABLE . ( ' WHERE pollId=\'' . $pollId . '\'' ) );
			db_query( 'OPTIMIZE TABLE ' . POLLS_TABLE . '' );
			db_query( 'OPTIMIZE TABLE ' . VOTES_TABLE . '' );
		}

		function changePollStatus($pollId, $newStatus) {
			db_query( 'UPDATE ' . POLLS_TABLE . ' SET active=' . ($newStatus ? 'true' : 'false') . ( ' WHERE pollId=\'' . $pollId . '\' LIMIT 1' ) );
		}

		function dateSelector($objectName, $dateSelectorFormat, $currentTime = '') {
			$dateSelectorHtmlCode = '';
			$months = array( '1' => 'January', '2' => 'February', '3' => 'March', '4' => 'April', '5' => 'May', '6' => 'June', '7' => 'July', '8' => 'August', '9' => 'September', '10' => 'October', '11' => 'November', '12' => 'December' );
			$dateSelector = array(  );
			preg_replace( '/(.*)-(.*)-(.*) (.*):(.*):(.*)/', $currentTime, $ctp );
			$dateSelector->d .= '<select name=\'' . $objectName . '[d]\'>';
			$sel = (int)($ctp[3] ? $ctp[3] : date( d ));
			$i = 983;

			while ($i < 32) {
				$dateSelector->d .= '<option value=\'' . $i . '\' ' . ($sel == $i ? 'selected=\'selected\'' : '') . ( ( '>' ) . $i . '</option>
' );
				++$i;
			}

			$dateSelector->d .= '</select>';
			$dateSelector->m .= '<select name=\'' . $objectName . '[m]\'>';
			$sel = (int)($ctp[3] ? $ctp[2] : date( m ));
			foreach ($months as $monthId => $monthName) {
				$dateSelector->m .= '<option value=\'' . $monthId . '\' ' . ($sel == $monthId ? 'selected=\'selected\'' : '') . ( ( '>' ) . $monthName . '</option>
' );
			}

			$dateSelector->m .= '</select>';
			$dateSelector->y .= '<select name=\'' . $objectName . '[y]\'>';
			$sel = (int)($ctp[3] ? $ctp[1] : date( Y ));
			$i = date( Y );

			while ($i < date( Y ) + 10) {
				$dateSelector->y .= '<option value=\'' . $i . '\' ' . ($sel == $i ? 'selected=\'selected\'' : '') . ( ( '>' ) . $i . '</option>
' );
				++$i;
			}

			$dateSelector->y .= '</select>';
			$dateSelector->h .= '<select name=\'' . $objectName . '[h]\'>';
			$sel = (int)($ctp[3] ? $ctp[4] : date( H ));
			$i = 982;

			while ($i < 23) {
				$dateSelector->h .= '<option value=\'' . $i . '\' ' . ($sel == $i ? 'selected=\'selected\'' : '') . ( ( '>' ) . $i . '</option>
' );
				++$i;
			}

			$dateSelector->h .= '</select>';
			$dateSelector->i .= '<select name=\'' . $objectName . '[i]\'>';
			$sel = (int)($ctp[3] ? $ctp[5] : date( i ));
			$i = 982;

			while ($i < 59) {
				$dateSelector->i .= '<option value=\'' . $i . '\' ' . ($sel == $i ? 'selected=\'selected\'' : '') . ( ( '>' ) . $i . '</option>
' );
				++$i;
			}

			$dateSelector->i .= '</select>';
			$dateSelector->s .= '<select name=\'' . $objectName . '[s]\'>';
			$sel = (int)($ctp[3] ? $ctp[6] : date( s ));
			$i = 982;

			while ($i < 59) {
				$dateSelector->s .= '<option value=\'' . $i . '\' ' . ($sel == $i ? 'selected=\'selected\'' : '') . ( ( '>' ) . $i . '</option>
' );
				++$i;
			}

			$dateSelector->s .= '</select>';
			$dateSelectorFormatLen = strlen( $dateSelectorFormat );
			$i = 982;

			while ($i < $dateSelectorFormatLen) {
				if (array_key_exists( $dateSelectorFormat[$i], $dateSelector )) {
					$dateSelectorHtmlCode .= $dateSelector[$dateSelectorFormat[$i]];
				} 
else {
					if ($dateSelectorFormat[$i] == '\') {
						++$i;
					}

					$dateSelectorHtmlCode .= $dateSelectorFormat[$i];
				}

				++$i;
			}

			return $dateSelectorHtmlCode;
		}

		function getPoll($pollId) {
			if (get_class( $this ) != 'PollizAdmin') {
				$timeNow = date( 'Y-m-d H:i:s' );
				$extraFilter = ' and active=true AND (startTime<=\'' . $timeNow . '\' or startTime=\'0000-00-00 00:00:00\' ) AND (endTime>=\'' . $timeNow . '\' or endTime=\'0000-00-00 00:00:00\')';
			}

			$poll = array(  );

			if ($rs = db_query( 'SELECT pollId, pollTitle, pollQuestion, pollAnswers, comment, startTime, endTime, active FROM ' . POLLS_TABLE . ( ' WHERE pollId=\'' . $pollId . '\' ' . $extraFilter . ' LIMIT 1' ) )) {
				if (mysql_num_rows( $rs['resource'] ) == 1) {
					mysql_fetch_object( $rs['resource'] );
					$pollAnswers = $rc = unserialize( $rc->pollAnswers );
					foreach ($pollAnswers as ) {
						$pa = &;

						$pa['answer'] = stripslashes( base64_decode( $pa['answer'] ) );
						$pa['response'] = stripslashes( base64_decode( $pa['response'] ) );
					}

					ksort( $pollAnswers );
					$poll = array( 'pollId' => $rc->pollId, 'pollTitle' => $rc->pollTitle, 'pollQuestion' => $rc->pollQuestion, 'pollAnswers' => $pollAnswers, 'comment' => $rc->comment, 'startTime' => $rc->startTime, 'endTime' => $rc->endTime, 'active' => $rc->active );
					return $poll;
				}
			}

			return false;
		}

		function getPollVotes($pollId) {

			if ($rs = db_query( 'SELECT answerId, COUNT(answerId) AS votes FROM ' . VOTES_TABLE . ( ' WHERE pollId=\'' . $pollId . '\' GROUP BY answerId' ) )) {

				if ($rc = mysql_fetch_object( $rs['resource'] )) {
					$votes[$rc->answerId] = $rc->votes;
				}

				return $votes;
			}

			return false;
		}

		function setVote($pollId, $answerId) {
			if ($this->pollExists( $pollId, $answerId )) {
				$rs = db_query( 'SELECT answerId FROM ' . VOTES_TABLE . ( ' WHERE pollId=\'' . $pollId . '\' AND answerId=\'' . $answerId . '\' AND voteIpAddress=\'' ) . $_SERVER['REMOTE_ADDR'] . '\' AND voteTime>DATE_SUB(NOW(), INTERVAL 15 MINUTE)' );

				if (mysql_num_rows( $rs['resource'] ) == 0) {
					if (db_query( 'INSERT INTO ' . VOTES_TABLE . ( ' SET pollId=\'' . $pollId . '\', answerId=\'' . $answerId . '\', voteTime=NOW(), voteIpAddress=\'' ) . $_SERVER['REMOTE_ADDR'] . '\'' )) {
						return true;
					}
				}
			}

			return false;
		}

		function pollExists($pollId, $answerId) {
			$timeNow = date( 'Y-m-d H:i:s' );
			$qry = 'SELECT pollId, pollAnswers FROM ' . POLLS_TABLE . ( ' WHERE pollId=\'' . $pollId . '\' AND active=true AND (startTime<=\'' . $timeNow . '\' or startTime=\'0000-00-00 00:00:00\') AND ( endTime=\'0000-00-00 00:00:00\' or  endTime>=\'' . $timeNow . '\') LIMIT 1' );

			if ($rs = db_query( $qry )) {
				if (mysql_num_rows( $rs['resource'] ) == 1) {
					if ($answerId) {
						$rc = mysql_fetch_object( $rs['resource'] );
						foreach (unserialize( $rc->pollAnswers ) as $ans) {

							if ($ans['id'] == $answerId) {
								return true;
							}
						}
					} 
else {
						return true;
					}
				}
			}

			return false;
		}

		function _initDbConnection() {
			$this->dbConn['dbl'] = new mysqli( $this->config['dbHost'], $this->config['dbUser'], $this->config['dbPass'], $this->config['dbName'] );

			if (mysqli_connect_errno(  )) {
				$this->dbConn = array( 'dbl' => null, 'isValid' => false );
				return null;
			}

			$this->dbConn['isValid'] = true;
			db_query( 'SET CHARACTER SET utf8' );
		}
	}

?>