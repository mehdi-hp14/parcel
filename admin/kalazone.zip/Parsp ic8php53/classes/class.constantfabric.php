<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class constantfabric {
		function generateconstant($_ConstantName) {
			static $GeneratorCounter = 1001;

			if (!$_ConstantName) {
				return false;
			}


			if (defined( $_ConstantName )) {
				return false;
			}

			define( $_ConstantName, $GeneratorCounter );
			return $GeneratorCounter++;
		}
	}

?>