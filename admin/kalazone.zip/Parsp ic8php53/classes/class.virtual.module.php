<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class virtualmodule {
		var $id = null;
		var $title = null;
		var $description = null;
		var $sort_order = null;
		var $ModuleType = null;
		var $ModuleConfigID = null;
		var $MethodsTable = null;
		var $DebugMode = null;
		var $ModuleVersion = 1;
		var $Settings = array(  );
		var $SettingsFields = array(  );
		var $LanguageDir = null;
		var $TemplatesDir = null;
		var $SingleInstall = false;
		var $LogFile = './temp_c/general_msg.log';

		function virtualmodule($_ModuleConfigID = 0) {
			$this->_initdebugmode(  );
			$this->_connectlanguagefile(  );
			$this->_initvars(  );
			$this->ModuleConfigID = $_ModuleConfigID;

			if ($_ModuleConfigID) {
				$this->title .= ' (' . $_ModuleConfigID . ')';
				$_TC = count( $this->Settings ) - 1;

				while (0 <= $_TC) {
					$this->Settings->$_ModuleConfigID .= '_' . $_ModuleConfigID;
					--$_TC;
				}
			}

		}

		function getmoduleconfigid() {
			return $this->ModuleConfigID;
		}

		function settings_list() {
			return $this->Settings;
		}

		function get_id() {
			if ($this->ModuleConfigID) {
				return $this->ModuleConfigID;
			}

			$sql = 'select module_id from ' . MODULES_TABLE . ' where module_name=\'' . $this->title . '\' ';
			$q = db_query( $sql );
			$row = db_fetch_row( $q );
			return (int)$row['module_id'];
		}

		function is_installed() {

			if (!$q = $constants = '\'' . implode( '\', \'', $this->settings_list(  ) ) . '\'') {
				exit( db_error(  ) );
			}

			db_fetch_row( $q )[0];
			$cnt = db_query( '
			SELECT COUNT(*) FROM ' . SETTINGS_TABLE . '
			WHERE settings_constant_name IN (' . $constants . ')' );
			return $cnt != 0;
		}

		function uninstall($_ConfigID = 0) {
			$_ConfigID = ((int)$_ConfigID ? (int)$_ConfigID : $this->ModuleConfigID);
			$constants = '\'' . implode( ($_ConfigID ? '_' . $_ConfigID : '') . '\', \'', $this->settings_list(  ) ) . ($_ConfigID ? '_' . $_ConfigID : '') . '\'';

			if ($this->MethodsTable) {
				$sql = '
				UPDATE ' . $this->MethodsTable . '
				SET module_id=NULL WHERE module_id=' . $_ConfigID . '
			';
				db_query( $sql );
			}

			$sql = '
			DELETE FROM ' . SETTINGS_TABLE . '
			WHERE settings_constant_name IN (' . $constants . ')
		';

			if (!db_query( $sql )) {
				exit( db_error(  ) );
			}

			$sql = '
			DELETE FROM ' . MODULES_TABLE . ' 
			WHERE module_id=' . $_ConfigID . '
		';
			db_query( $sql );
		}

		function install() {
			db_query( 'insert into ' . MODULES_TABLE . ' ( module_name, ModuleClassName )  values( \'' . $this->title . '\', \'' . get_class( $this ) . '\' ) ' );
			$NewModuleConfigID = db_insert_id(  );
			$this->ModuleConfigID = $NewModuleConfigID;
			$sql = '
			UPDATE ' . MODULES_TABLE . '
			SET module_name=\'' . $this->title . ($this->SingleInstall ? '' : ' (' . $NewModuleConfigID . ')') . '\'
			WHERE module_id=' . $NewModuleConfigID . '
		';
			db_query( $sql );
			$this->_initsettingfields(  );
			$this->SettingsFields = xescapesqlstring( $this->SettingsFields );
			foreach ($this->Settings as $_SettingName) {
				$sql = '
				INSERT INTO ' . SETTINGS_TABLE . '
				(
					settings_groupID, settings_constant_name, 
					settings_value, 
					settings_title, 
					settings_description, 
					settings_html_function, 
					sort_order
				)
				VALUES (
					' . settinggetfreegroupid(  ) . ', \'' . $_SettingName . ($this->SingleInstall ? '' : '_' . $NewModuleConfigID) . '\',
					\'' . (isset( $this->SettingsFields[$_SettingName]['settings_value'] ) ? $this->SettingsFields[$_SettingName]['settings_value'] : '') . '\',
					\'' . (isset( $this->SettingsFields[$_SettingName]['settings_title'] ) ? $this->SettingsFields[$_SettingName]['settings_title'] : '') . '\',
					\'' . (isset( $this->SettingsFields[$_SettingName]['settings_description'] ) ? $this->SettingsFields[$_SettingName]['settings_description'] : '') . '\',
					\'' . (isset( $this->SettingsFields[$_SettingName]['settings_html_function'] ) ? $this->SettingsFields[$_SettingName]['settings_html_function'] : '') . '\',
					\'' . (isset( $this->SettingsFields[$_SettingName]['sort_order'] ) ? $this->SettingsFields[$_SettingName]['sort_order'] : '') . '\'
				)';

				if (!db_query( $sql )) {
					exit( db_error(  ) );
					continue;
				}
			}

		}

		function constant1($var) {
			db_query( '
			SELECT settings_value FROM ' . SETTINGS_TABLE . '

			if (!$q = WHERE settings_constant_name IN (' . $var . ')' )) {
				exit( db_error(  ) );
			}

			return db_fetch_row( $q );
		}

		function _getsettingvalue($_SettingName) {
			return constant( $_SettingName . ($this->ModuleConfigID ? '_' . $this->ModuleConfigID : '') );
		}

		function _getsettingrealname($_SettingName) {
			return $_SettingName . (( !$this->ModuleConfigID && !$this->SingleInstall ) ? '_' . $this->ModuleConfigID : '');
		}

		function _defined($_SettingName) {
			return defined( $_SettingName . (( !$this->ModuleConfigID && !$this->SingleInstall ) ? '_' . $this->ModuleConfigID : '') );
		}

		function getmoduletype() {
			return $this->ModuleType;
		}

		function _connectlanguagefile() {
			$LanguageFile = $this->LanguageDir . LanguagesManager::getDefaultLanguage(  )->iso2 . '.' . strtolower( get_class( $this ) ) . '.php';

			if (file_exists( $LanguageFile )) {
				require_once( $LanguageFile );
			}

		}

		function _convertcurrency($_Value, $_FromType, $_ToType) {
			if (!intval( $_FromType )) {
				if (strlen( $_FromType ) == 3) {
					currgetcurrencybyiso3( $_FromType );
					$FromCurrency = ;
				} 
else {
					$FromCurrency = array( 'currency_value' => 1 );
				}
			} 
else {
				$FromCurrency = currgetcurrencybyid( $_FromType );
			}


			if (!intval( $_ToType )) {
				if (strlen( $_ToType ) == 3) {
					currgetcurrencybyiso3( $_ToType );
					$ToCurrency = ;
				} 
else {
					$ToCurrency = array( 'currency_value' => 1 );
				}
			} 
else {
				$ToCurrency = currgetcurrencybyid( $_ToType );
			}

			return $_Value / $FromCurrency['currency_value'] * $ToCurrency['currency_value'];
		}

		function _initvars() {
		}

		function _initsettingfields() {
		}

		function gettitle() {
			return $this->title;
		}

		function _writelogmessage($_LogType, $_Message) {
			switch ($_LogType) {
				case MODULE_LOG_CURL: {
					$this->LogFile = './temp_c/curl_msg.log';
					break;
				}

				case MODULE_LOG_FEDEX: {
					$this->LogFile = './temp_c/fedex_msg.log';
				}
			}


			if ($this->LogFile) {
				$fp = fopen( $this->LogFile, 'a' );
				fwrite( $fp, '
' . date( 'Y-m-d H:i:s ' ) . '

' . $_Message . '
' );
				fclose( $fp );
			}

		}

		function _initdebugmode() {
			global $DebugMode;

			$this->DebugMode = $DebugMode;
		}

		function debugmessage($_Title, $_Msg) {
			if ($this->DebugMode) {
				echo '<br /><b>' . $_Title . '</b><br />' . $_Msg;
			}

		}
	}

	define( 'SHIPPING_RATE_MODULE', 1 );
	define( 'PAYMENT_MODULE', 2 );
	define( 'SMSMAIL_MODULE', 3 );
	define( 'MODULE_LOG_CURL', 1 );
	define( 'MODULE_LOG_FEDEX', 2 );
	@ini_set( 'max_execution_time', 0 );
?>