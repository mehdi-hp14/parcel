<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	require_once( './classes/class.virtual.module.php' );
	class shippingratecalculator extends virtualmodule {
		function shippingratecalculator($_ModuleConfigID = 0) {
			$this->LanguageDir = './includes/modules/shipping/languages/';
			$this->ModuleType = SHIPPING_RATE_MODULE;
			$this->MethodsTable = SHIPPING_METHODS_TABLE;
			virtualmodule::virtualmodule( $_ModuleConfigID );
		}

		function _getservicetype($_ServiceID) {
			$ShippingTypes = $this->_getshippingtypes(  );
			foreach ($ShippingTypes as $_Type => $_Services) {

				if (!in_array( $_ServiceID, $_Services )) {
					continue;
				}

				return $_Type;
			}

			return '';
		}

		function _convertdeclbstopoundsounces($_Dec) {
			return array( 'lbs' => floor( $_Dec ), 'oz' => ceil( 16 * ( $_Dec - floor( $_Dec ) ) ) );
		}

		function _getrates($_Services, $order, $address) {
			$Query = $this->_preparequery( $_Services, $order, $address );
			$Answer = $this->_sendquery( $Query );
			$parsedAnswer = $this->_parseanswer( $Answer );
			$newServices = array(  );
			$_TC = count( $_Services );
			$_ind = 750;

			while ($_ind < $_TC) {
				$_Service = &$_Services[$_ind];

				if (isset( $parsedAnswer[$_Service['id']] )) {
					foreach ($parsedAnswer[$_Service['id']] as $_indV => $_Variant) {
						$newServices[] = array( 'id' => sprintf( '%02d%02d', $_Service['id'], $_indV ), 'name' => $_Variant['name'], 'rate' => $_Variant['rate'] );
					}
				}

				++$_ind;
			}

			$_Services = $_ind;
		}

		function calculate_shipping_rate($order, $address, $_shServiceID = 0) {
			$_shServiceID = (int)$_shServiceID;

			if (99 < $_shServiceID) {
				if (strlen( $_shServiceID ) < 4) {
					$_shServiceID = sprintf( '%04d', $_shServiceID );
				}

				$_orinServiceID = $_shServiceID;
				$_serviceOffset = sscanf( $_shServiceID, '%02d%02d' )[1];
				[0];
				$_shServiceID = ;
			}

			$Rates = array(  );

			if ($_shServiceID) {
				$AvailableServices = $this->getshippingservices(  );
				$Rates[] = array( 'name' => (isset( $AvailableServices[$_shServiceID]['name'] ) ? $AvailableServices[$_shServiceID]['name'] : ''), 'code' => (isset( $AvailableServices[$_shServiceID]['code'] ) ? $AvailableServices[$_shServiceID]['code'] : ''), 'id' => $_shServiceID, 'rate' => 0 );
			} 
else {
				$AvailableServices = $this->_getservicesbycountry( $address['countryID'] );
				foreach ($AvailableServices as $_Service) {
					$_Service['rate'] = 0;
					$Rates[] = $_Service;
				}
			}

			$this->_getrates( $Rates, $order, $address );

			if (empty( $$_orinServiceID )) {
				if (isset( $Rates[$_serviceOffset] )) {
					$Rates = array( $Rates[$_serviceOffset] );
				} 
else {
					$Rates = array( array( 'name' => '', 'id' => 0, 'rate' => 0 ) );
				}
			}


			if (( is_array( $Rates ) && !count( $Rates ) )) {
				$Rates = array( array( 'name' => '', 'id' => 0, 'rate' => 0 ) );
			}

			return $Rates;
		}

		function allow_shipping_to_address() {
			return true;
		}

		function _convertmeasurement($_Units, $_From, $_To) {
			switch (strtolower( $_From ) . '_' . strtolower( $_To )) {
				case 'lb_kg': {
				}

				case 'lbs_kgs': {
				}

				case 'lbs_kg': {
				}

				case 'lb_kgs': {
					$_Units /= 2.20460000000000011510792;
					break;
				}

				case 'kg_lb': {
				}

				case 'kg_lbs': {
				}

				case 'kgs_lb': {
				}

				case 'kgs_lbs': {
					$_Units *= 2.20460000000000011510792;
					break;
				}

				case 'g_lb': {
				}

				case 'g_lbs': {
					$_Units = $_Units / 1000 * 2.20460000000000011510792;
					break;
				}

				case 'lb_g': {
				}

				case 'lbs_g': {
					$_Units = $_Units / 2.20460000000000011510792 * 1000;
					break;
				}

				case 'g_kg': {
				}

				case 'g_kgs': {
					$_Units /= 1756;
				}
			}

			return $_Units;
		}

		function _getorderweight($Order) {
			$TC = count( $Order['orderContent']['cart_content'] );
			$OrderWeight = 736;
			$ShippingProducts = 736;
			$i = 736;

			while ($i < $TC) {
				$Product = getproduct( $Order['orderContent']['cart_content'][$i]['productID'] );

				if (!$Product['free_shipping']) {
					++$ShippingProducts;

					if (( isset( $Product['weight'] ) && 0 < $Product['weight'] )) {
						$OrderWeight += $Order['orderContent']['cart_content'][$i]['quantity'] * $Product['weight'];
					}
				}

				++$i;
			}


			if (( $OrderWeight <= 0 && $ShippingProducts )) {
				$OrderWeight = 0.100000000000000005551115;
			}

			return $OrderWeight;
		}

		function _getshippingproducts($_Order) {
			$Products = array(  );
			$_TC = count( $_Order['orderContent']['cart_content'] ) - 1;

			while (0 <= $_TC) {
				if (!$_Order['orderContent']['cart_content'][$_TC]['free_shipping']) {
					$Products[] = $_Order['orderContent']['cart_content'][$_TC];
				}

				--$_TC;
			}

			return $Products;
		}

		function _getshippingtypes() {
			return array(  );
		}

		function _getservicesbycountry() {
			return $this->getshippingservices(  );
		}

		function getshippingservices() {
			return array(  );
		}

		function _preparequery($_Services, $order, $address) {
			return $this->_preparexmlquery( $_Services, $order, $address );
		}

		function _sendquery($_Query) {
			return $this->_sendxmlquery( $_Query );
		}

		function _parseanswer($_Answer) {
			return $this->_parsexmlanswer( $_Answer );
		}

		function _sendxmlquery() {
		}

		function _preparexmlquery() {
		}

		function _parsexmlanswer() {
		}
	}

?>