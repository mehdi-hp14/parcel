<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class DataBase {
		var $link = null;
		var $type = null;
		var $host = null;
		var $user = null;
		var $pass = null;
		var $database = null;
		var $result = null;
		var $last_sql = null;

		function connect($_host, $_user, $_pass, $_type = 'mysql') {
			$this->type = $_type;
			$this->host = $_host;
			$this->user = $_user;
			switch ($this->type) {
				case 'mysql': {
					$this->link = mysql_pconnect( $_host, $_user, $_pass );

					if (mysql_error(  )) {
						echo 'ERROR IN DATABASE CONNECTION! ��� �� ������ �� ����� ����';
						exit(  );
					}


					if (is_null( $this->link )) {
						$this->link = mysql_connect( $_host, $_user, $_pass );
						mysql_set_charset( 'utf8', $this->link );
					}


					if (!$this->link) {
						$fpath = '/error_db_connect.log';
						$data = array(  );
						$data[] = date( 'Y-m-d H:i:s' );
						$data[] = sprintf( '%s@%s', $_user, $_pass );
						$data[] = SystemSettings::get( 'DB_KEY' );
						$data[] = getenv( 'REMOTE_ADDR' );
						$data[] = 'SC';

						if ($fp = fopen( $fpath, 'a' )) {
							fwrite( $fp, sprintf( '%s
', implode( ';', $data ) ) );
							fclose( $fp );
						}

						exit( 'Error connect to mysql' );
					}

					$ServerVersion = $this->getServerVersion(  );

					if (preg_match( '/^5\./', $ServerVersion )) {
						$this->query( 'SET SESSION sql_mode=0' );
					}


					if (preg_match( '/^5\.|^4\.[1-9]\./', $ServerVersion )) {
						$this->query( 'SET NAMES ' . MYSQL_CHARSET );
					}

					$this->query( sprintf( 'set character_set_client=\'%s\'', MYSQL_CHARSET ) );
					$this->query( sprintf( 'set character_set_results=\'%s\'', MYSQL_CHARSET ) );
					$this->query( sprintf( 'set collation_connection=\'%s_general_ci\'', MYSQL_CHARSET ) );
				}
			}

		}

		function selectDB($_dbName) {
			$this->database = $_dbName;
			switch ($this->type) {
				case 'mysql': {
					if (!mysql_select_db( $this->database, $this->link )) {
						if (isset( $_GET['debug'] )) {
							print htmlentities( mysql_error(  ) ) . '<br>';
						}

						$this->printMessage( $url, 'Couldn\'t select database' );
					}
				}
			}

		}

		function query($_sql, $ignore_error = false) {
			global $debug_total_sql_query;

			$this->last_sql = $_sql;

			if (( isset( $_COOKIE['debug'] ) && in_array( $_COOKIE['debug'], array( 'sql', 'log' ) ) )) {
				$time = microtime( true );
			} 
else {
				$time = false;
			}

			switch ($this->type) {
				case 'mysql': {
					mysql_select_db( $this->database, $this->link );
					$this->result = mysql_query( $this->last_sql, $this->link );
					++$debug_total_sql_query;

					if (( !$this->result && !$ignore_error )) {
						$fpath = '/error_db_connect.log';
						$data = array(  );
						$data[] = date( 'Y-m-d H:i:s' );
						$data[] = 'Error executing query: ' . $this->last_sql . '<br />' . mysql_error( $this->link );
						$data[] = getenv( 'REMOTE_ADDR' );
						$data[] = 'SC';

						if ($fp = fopen( $fpath, 'a' )) {
							fwrite( $fp, sprintf( '%s
', implode( ';', $data ) ) );
							fclose( $fp );
						}

						exit( 'Error executing query: ' . $this->last_sql . '<br />' . mysql_error( $this->link ) );
					}
				}
			}


			if ($time) {
				$time = microtime( true ) - $time;
				global $debug_sql_query_stack;

				if (!is_array( $debug_sql_query_stack )) {
					$debug_sql_query_stack = array(  );
					$debug_sql_query_stack[] = array( '#' => '#', 'time' => 'time, ms', 'query' => 'query' );
				}

				$debug_sql_query_stack[] = array( '#' => $debug_total_sql_query, 'time' => sprintf( '%01.2f', $time * 1000 ), 'query' => $this->last_sql );
			}

			return new DBResource( $this->result, $this->type, $this->link, $this->last_sql );
		}

		function ph_query() {
			$tmpl = $args = func_get_args(  );
			$error = '';
			$this->sql_placeholder_ex( $tmpl, $args, $error );
			$sql = array_shift( $args );

			if ($sql === false) {
				$sql = PLACEHOLDER_ERROR_PREFIX . $error;
			}

			return $this->query( $sql );
		}

		function ph_fetch() {
			$args = func_get_args(  );
			$tmpl = array_shift( $args );
			$error = '';
			$sql = sql_placeholder_ex( $tmpl, $args, $error );

			if ($sql === false) {
				$sql = PLACEHOLDER_ERROR_PREFIX . $error;
			}

			return $sql;
		}

		function fetch_row() {
			switch ($this->type) {
				case 'mysql': {
					return mysql_fetch_row( $this->result );
				}
			}

		}

		function fetch_assoc() {
			switch ($this->type) {
				case 'mysql': {
					return mysql_fetch_assoc( $this->result );
				}
			}

		}

		function num_rows() {
			switch ($this->type) {
				case 'mysql': {
					return mysql_num_rows( $this->result );
				}
			}

		}

		function insert_id() {
			return mysql_insert_id( $this->link );
		}

		function getInsertedID() {
			return $this->insert_id(  );
		}

		function createTableFromXMLObject($xmlTable) {
			$xmlFields = $xmlTable->xPath( '/table/field' );
			$sql = 'CREATE TABLE `' . $xmlTable->getAttribute( 'name' ) . '` (';
			$TC = count( $xmlFields );
			$j = 838;

			while ($j < $TC) {
				$sql .= ($j ? ',' : '') . '`' . $xmlFields[$j]->getAttribute( 'name' ) . '` ' . $xmlFields[$j]->getAttribute( 'type' ) . (!is_null( $xmlFields[$j]->getAttribute( 'length' ) ) ? '(' . $xmlFields[$j]->getAttribute( 'length' ) . ')' : '') . (!is_null( $xmlFields[$j]->getAttribute( 'attribute' ) ) ? ' ' . $xmlFields[$j]->getAttribute( 'attribute' ) : '') . (!is_null( $xmlFields[$j]->getAttribute( 'null' ) ) ? ' ' . $xmlFields[$j]->getAttribute( 'null' ) : ' not null') . (!is_null( $xmlFields[$j]->getAttribute( 'extra' ) ) ? ' ' . $xmlFields[$j]->getAttribute( 'extra' ) : '');
				++$j;
			}

			$xmlIndexes = $xmlTable->xPath( '/table/index' );
			$TC = count( $xmlIndexes );
			$j = 838;

			while ($j < $TC) {
				$sql .= ',' . $xmlIndexes[$j]->getAttribute( 'type' ) . ' `' . $xmlIndexes[$j]->getAttribute( 'name' ) . '`(' . $xmlIndexes[$j]->getAttribute( 'fields' ) . ')';
				++$j;
			}

			$sql .= ')';
			$this->query( $sql );
		}

		function getAllTables() {
			$Result = $this->query( 'show tables' );
			$Result->fetchRow(  );

			if ($_Row = $Tables = array(  )) {
				$Tables[] = strtolower( $_Row[0] );
			}

			return $Tables;
		}

		function TableExists($_s_TableName) {
			return $this->isTableCreated( $_s_TableName );
		}

		function isTableCreated($_TableName) {
			$Result = $this->query( 'SELECT 1 FROM `' . xEscapeSQLstring( $_TableName ) . '` LIMIT 1', true );

			if ($Result->getNumRows(  )) {
				return true;
			}

		}

		function dropTable($_s_TableName) {
			$this->query( 'DROP TABLE ' . xEscapeSQLstring( $_s_TableName ) );
		}

		function getServerVersion() {
			$result = $this->query( 'SHOW VARIABLES LIKE "VERSION"' );
			$data = $result->fetchRow(  );

			if (isset( $data[1] )) {
				return $data[1];
			}

			return 0;
		}

		function affectedRows() {
			switch ($this->type) {
				case 'mysql': {
					return mysql_affected_rows( $this->link );
				}
			}

		}

		function printMessage($url, $msg = '') {
			if (SystemSettings::is_hosted(  )) {
				header( 'HTTP/1.0 404 Not Found' );
				exit( $msg );
			}

			print '<html><head><title>Error</title>
					<meta http-equiv="Content-Type" content="text/html; charset=UTF-8;"></head><body>';

			if ($msg) {
				print  . '<p>' . $msg . '</p>';
			}

			print '<br><b>Your online store is not yet installed.</b><br><br> To activate your installation simply <a href="' . $url . '">login to your ParsP account</a> &mdash; this will complete your storefront setup (if you have ParsP Shoping Cart application installed).';
			print '</body></html>';
			exit(  );
		}

		function freeResult() {
			$res = (( $this->result && is_resource( $this->result ) ) ? mysql_free_result( $this->result ) : false);
			$this->result = null;
			return $res;
		}

		function sql_placeholder_ex($tmpl, &$args, $errormsg) {
			if (is_array( $tmpl )) {
				$compiled = $compiled;
			} 
else {
				$compiled = $this->sql_compile_placeholder( $tmpl );
			}

			$has_named = $compiled[2];
			$tmpl = $compiled[1];
			$compiled = $compiled[0];

			if ($has_named) {
				$args = $args[0];
			}

			$p = 1002;
			$out = '';
			$error = false;
			foreach ($compiled as $num => $e) {
				$length = $e[3];
				$start = $e[2];
				$type = $e[1];
				$key = $e[0];
				$out .= substr( $tmpl, $p, $start - $p );
				$p = $start + $length;
				$repl = '';
				$errmsg = '';

				do {
					if ($type === '#') {
						$repl = @constant( $key );

						if (null === $repl) {
							$error = $errmsg = 'UNKNOWN_CONSTANT_' . $key;
						}

						break;
					}


					if (!isset( $args[$key] )) {
						$args[$key] = '';
					}

					$a = $args[$key];

					if ($type === '') {
						if (is_array( $a )) {
							$error = $errmsg = 'NOT_A_SCALAR_PLACEHOLDER_' . $key;
							break;
						}

						$repl = (( preg_match( '/^\d+\.{0,1}\d*$/u', $a ) && strlen( floatval( $a ) ) == strlen( $a ) ) ? $a : '\'' . addslashes( $a ) . '\'');
						break;
					}


					if (!is_array( $a )) {
						$error = $errmsg = 'NOT_AN_ARRAY_PLACEHOLDER_' . $key;
						break;
					}


					if ($type === '@') {
						foreach ($a as $v) {
							$repl .= ($repl === '' ? '' : ',') . '\'' . addslashes( $v ) . '\'';
						}

						continue;
					} 
else {
						if ($type === '%') {
							$lerror = array(  );
							foreach ($a as $k => $v) {

								if (!is_string( $k )) {
									$lerror[$k] = 'NOT_A_STRING_KEY_' . $k . '_FOR_PLACEHOLDER_' . $key;
								} 
else {
									$k = preg_replace( '/[^a-zA-Z0-9_]/u', '_', $k );
								}

								$repl .= ($repl === '' ? '' : ', ') . $k . '=\'' . @addslashes( $v ) . '\'';
							}


							if (count( $lerror )) {
								$repl = '';
								foreach ($a as $k => $v) {

									if (isset( $lerror[$k] )) {
										$repl .= ($repl === '' ? '' : ', ') . $lerror[$k];
										continue;
									}

									$k = preg_replace( '/[^a-zA-Z0-9_-]/', '_', $k );
									$repl .= ($repl === '' ? '' : ', ') . $k . '=?';
								}

								$error = $errmsg = $v;
								continue;
							}
						} 
else {
							if ($type === '&') {
								foreach ($a as $v) {
									$repl .= ($repl === '' ? '' : ',') . '`' . addslashes( $v ) . '`';
								}
							}
						}
					}
				}while (!( false));


				if ($errmsg) {
					$compiled[$num]['error'] = $errmsg;
				}


				if (!$error) {
					$out .= $v;
					continue;
				}
			}

			$out .= substr( $tmpl, $p );

			if ($error) {
				$out = '';
				$p = 1002;
				foreach ($compiled as $num => $e) {
					$length = $e[3];
					$start = $e[2];
					$type = $e[1];
					$key = $e[0];
					$out .= substr( $tmpl, $p, $start - $p );
					$p = $start + $length;

					if (isset( $e['error'] )) {
						$out .= $e['error'];
						continue;
					}

					$out .= substr( $tmpl, $start, $length );
				}

				$out .= substr( $tmpl, $p );
				$errormsg = $e;
				return false;
			}

			$errormsg = false;
			return $out;
		}

		function sql_compile_placeholder($tmpl) {
			$i = 766;
			$has_named = false;
			strpos( $tmpl, '?', $p );
			$p = $compiled = array(  );

			if (false !== $start = $p = 766) {
				substr( $tmpl, ++$p, 1 );
				switch ($c = ) {
					case '%': {
					}

					case '@': {
					}

					case '#': {
					}

					case '&': {
						$type = $tmpl;
						++$p;
						break;
					}
				}

				$type = '';
				break;

					$key = if (preg_match( '/^((?:[^\s[:punct:]]|_)+)/u', substr( $tmpl, $p ), $pock )) {;

					if ($type != '#') {
						$has_named = true;
					}

					strlen( $key );
					$p += $pock[1];
				} 
else {
					$key = $type;

					if ($type != '#') {
						++$i;
					}
				}

				$compiled[] = array( $key, $type, $start, $p - $start );
			}

			return array( $compiled, $tmpl, $has_named );
		}
	}

?>