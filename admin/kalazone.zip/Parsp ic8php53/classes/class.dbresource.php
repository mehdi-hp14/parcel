<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class DBResource {
		var $Result = null;
		var $Type = 'mysql';
		var $Link = null;
		var $SQL = '';

		function DBResource($_Result, $_Type, $_Link, $_SQL) {
			$this->Result = $_Result;
			$this->Type = $_Type;
			$this->Link = $_Link;
			$this->SQL = $_SQL;
		}

		function fetchRow($i = null) {
			switch ($this->Type) {
				case 'mysql': {
					if (is_null( $i )) {
						return mysql_fetch_row( $this->Result );
					}

					$r = mysql_fetch_row( $this->Result );
					return $r[$i];
				}
			}

		}

		function fetchAssoc() {
			switch ($this->Type) {
				case 'mysql': {
					return mysql_fetch_assoc( $this->Result );
				}
			}

		}

		function fetchArrayAssoc($key_field = null) {
			$array = array(  );

			if ($row = $this->fetchAssoc(  )) {
				if (is_null( $key_field )) {
					$array[] = $row;
				}

				$array[$row[$key_field]] = $row;
			}

			return $array;
		}

		function getInsertID() {
			switch ($this->Type) {
				case 'mysql': {
					return mysql_insert_id(  );
				}
			}

		}

		function getNumRows() {
			switch ($this->Type) {
				case 'mysql': {
					return mysql_num_rows( $this->Result );
				}
			}

		}
	}

?>