<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class ActionsController {
		var $__action_sources = null;
		var $__current_data = null;
		var $__action_source = null;
		var $__action = null;
		var $__params = array(  );

		function preAction($action) {
			safeMode( $action != 'main' );
		}

		function postAction($action) {
		}

		function ActionsController() {
			$this->registerStandardSources(  );
		}

		function registerSource(&$source_id, $source_data) {
			$this->__action_sources[$source_id] = &$source_data;

		}

		function registerStandardSources() {
			$Register = &Register::getInstance(  );
			$GetVars = &$Register->get( VAR_GET );

			if (isset( $GetVars['caller'] )) {
				ClassManager::includeClass( 'jshttprequest' );
				$JsHttpRequest = new JsHttpRequest( 'str_default_charset' )(  );
			}

			global $_REQUEST;

			$this->registerSource( ACTCTRL_AJAX, $_REQUEST );
			$this->registerSource( ACTCTRL_POST, $Register->get( VAR_POST ) );
			$this->registerSource( ACTCTRL_GET, $Register->get( VAR_GET ) );
		}

		function exec($controller_name, $sources = array( 0 => , 1 => , 2 => , 3 =>  ), $params = array(  )) {
			$controller = new $controller_name(  );
			$controller->__params = $params;
			$controller->__exec( $sources );
		}

		function __exec_cust($data) {
			$this->registerSource( ACTCTRL_CUST, $data );
			return $this->__exec( ACTCTRL_CUST );
		}

		function __exec($sources = null) {
			if (!is_array( $sources )) {
				$sources = array( $sources );
			}

			foreach ($sources as $source) {

				if (!isset( $this->__action_sources[$source]['action'] )) {
					continue;
				}


				if (!method_exists( $this, $this->__action_sources[$source]['action'] )) {
					pear_dump( 'No action handler' );
					exit(  );
				}

				$this->__current_data = &$this->__action_sources[$source];

				$this->__action_source = $source;
				$this->__action = $this->__action_sources[$source]['action'];
				switch ($source) {
					case ACTCTRL_GET: {
						renderURL( 'action=', '', true );
						break;
					}
				}

				$this->preAction( $this->__action );
				$return = $this->$this->__action(  );
				$this->postAction( $this->__action );
				return $return;
			}


			if (!$this->__action) {
				$this->__current_data = &$this->__action_sources[ACTCTRL_GET];

				$this->__action_source = ACTCTRL_GET;
				$this->__action = 'main';
				$this->preAction( $this->__action );
				$return = $this->$this->__action(  );
			}

		}

		function getData($key = null, $key2 = null) {
			if (is_null( $key )) {
				return $this->__current_data;
			}


			if (is_null( $key2 )) {
				return (isset( $this->__current_data[$key] ) ? $this->__current_data[$key] : '');
			}

			return (isset( $this->__current_data[$key][$key2] ) ? $this->__current_data[$key][$key2] : '');
		}

		function existsData($key) {
			return isset( $this->__current_data[$key] );
		}

		function setData($key, $value) {
			$this->__current_data[$key] = $value;
		}

		function main() {
		}
	}

	define( 'ACTCTRL_GET', 'get' );
	define( 'ACTCTRL_POST', 'post' );
	define( 'ACTCTRL_AJAX', 'ajax' );
	define( 'ACTCTRL_CUST', 'custom' );
?>