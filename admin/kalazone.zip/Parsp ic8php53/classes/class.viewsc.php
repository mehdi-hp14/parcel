<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class ViewSC extends Smarty {
		function __construct() {
			parent::Smarty(  );
			$optimize_enable = true;
			$this->security = true;
			$this->compile_check = ( true || !$optimize_enable );
			$this->security_settings['ALLOW_CONSTANTS'] = true;
			$this->security_settings['PHP_HANDLING'] = false;
			$this->security_settings['MODIFIER_FUNCS'] = array(  );
			$this->security_settings['PHP_TAGS'] = false;
			$this->security_settings['IF_FUNCS'] = array( 'true', 'false', 'null', 'NULL' );
			$this->security_settings['INCLUDE_ANY'] = false;
			$this->secure_dir = array( DIR_TPLS );
			$this->php_handling = SMARTY_PHP_QUOTE;
			$compile_dir = DIR_COMPILEDTEMPLATES;

			if ($optimize_enable) {
				$compile_dir .= '/' . LanguagesManager::getCurrentLanguage(  )->iso2 . '/';
			}

			checkPath( $compile_dir );
			$this->compile_dir = $compile_dir;
			$this->template_dir = DIR_TPLS;
			$this->cache_dir = DIR_SMARTY_CACHE;
			$this->caching = false;

			if ($optimize_enable) {
				$this->register_prefilter( array( 'ViewSC', 'optimizeTranslate' ) );
			}

			return $this;
		}

		function optimizeTranslateCallback($matches) {
			if (!isset( $matches[2] )) {
				$matches[2] = 'translate';
			}

			$result = '';
			switch ($matches[2]) {
				case 'translate': {
					$result = translate( $matches[1] );
					$result = '{literal}' . $result . '{/literal}';
					break;
				}

				case 'transcape': {
					$result = htmlspecialchars( translate( $matches[1] ), ENT_QUOTES );
					$result = '{literal}' . $result . '{/literal}';
					break;
				}
			}

			$result = $matches[0];
			break;

			if (true) {
			}

			return $result;
		}

		function optimizeTranslate(&$source, $smarty) {
			$patterns = array( '@\{["\']{0,1}([\w_]+)["\']{0,1}\|(translate|transcape)\}@', '@\{lbl_(\w+)\}@' );
			foreach ($patterns as $pattern) {
				$source = preg_replace_callback( $pattern, array( 'ViewSC', 'optimizeTranslateCallback' ), $source );
			}

			return $source;
		}
	}

?>