<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class JsHttpRequest {
		var $SCRIPT_ENCODING = 'windows-1251';
		var $SCRIPT_DECODE_MODE = '';
		var $LOADER = null;
		var $ID = null;
		var $RESULT = null;
		var $_uniqHash = null;
		var $_magic = 14623;
		var $_prevDisplayErrors = null;
		var $_contentTypes = array( 'script' => 'text/javascript', 'xml' => 'text/plain', 'form' => 'text/html', '' => 'text/plain' );
		var $_toUtfFailed = false;
		var $_nonAsciiChars = '';
		var $_unicodeConvMethod = null;
		var $_emergBuffer = null;
		var $_encTables = array( 'windows-1251' => array( 0 => 1026, 1 => 1027, 2 => 8218, 3 => 1107, 4 => 8222, 5 => 8230, 6 => 8224, 7 => 8225, 8 => 8364, 9 => 8240, 10 => 1033, 11 => 8249, 12 => 1034, 13 => 1036, 14 => 1035, 15 => 1039, 16 => 1106, 17 => 8216, 18 => 8217, 19 => 8220, 20 => 8221, 21 => 8226, 22 => 8211, 23 => 8212, 24 => 152, 25 => 8482, 26 => 1113, 27 => 8250, 28 => 1114, 29 => 1116, 30 => 1115, 31 => 1119, 32 => 160, 33 => 1038, 34 => 1118, 35 => 1032, 36 => 164, 37 => 1168, 38 => 166, 39 => 167, 40 => 1025, 41 => 169, 42 => 1028, 43 => 171, 44 => 172, 45 => 173, 46 => 174, 47 => 1031, 48 => 176, 49 => 177, 50 => 1030, 51 => 1110, 52 => 1169, 53 => 181, 54 => 182, 55 => 183, 56 => 1105, 57 => 8470, 58 => 1108, 59 => 187, 60 => 1112, 61 => 1029, 62 => 1109, 63 => 1111, 64 => 1040, 65 => 1041, 66 => 1042, 67 => 1043, 68 => 1044, 69 => 1045, 70 => 1046, 71 => 1047, 72 => 1048, 73 => 1049, 74 => 1050, 75 => 1051, 76 => 1052, 77 => 1053, 78 => 1054, 79 => 1055, 80 => 1056, 81 => 1057, 82 => 1058, 83 => 1059, 84 => 1060, 85 => 1061, 86 => 1062, 87 => 1063, 88 => 1064, 89 => 1065, 90 => 1066, 91 => 1067, 92 => 1068, 93 => 1069, 94 => 1070, 95 => 1071, 96 => 1072, 97 => 1073, 98 => 1074, 99 => 1075, 100 => 1076, 101 => 1077, 102 => 1078, 103 => 1079, 104 => 1080, 105 => 1081, 106 => 1082, 107 => 1083, 108 => 1084, 109 => 1085, 110 => 1086, 111 => 1087, 112 => 1088, 113 => 1089, 114 => 1090, 115 => 1091, 116 => 1092, 117 => 1093, 118 => 1094, 119 => 1095, 120 => 1096, 121 => 1097, 122 => 1098, 123 => 1099, 124 => 1100, 125 => 1101, 126 => 1102, 127 => 1103 ), 'koi8-r' => array( 0 => 9472, 1 => 9474, 2 => 9484, 3 => 9488, 4 => 9492, 5 => 9496, 6 => 9500, 7 => 9508, 8 => 9516, 9 => 9524, 10 => 9532, 11 => 9600, 12 => 9604, 13 => 9608, 14 => 9612, 15 => 9616, 16 => 9617, 17 => 9618, 18 => 9619, 19 => 8992, 20 => 9632, 21 => 8729, 22 => 8730, 23 => 8776, 24 => 8804, 25 => 8805, 26 => 160, 27 => 8993, 28 => 176, 29 => 178, 30 => 183, 31 => 247, 32 => 9552, 33 => 9553, 34 => 9554, 35 => 1105, 36 => 9555, 37 => 9556, 38 => 9557, 39 => 9558, 40 => 9559, 41 => 9560, 42 => 9561, 43 => 9562, 44 => 9563, 45 => 9564, 46 => 9565, 47 => 9566, 48 => 9567, 49 => 9568, 50 => 9569, 51 => 1025, 52 => 9570, 53 => 9571, 54 => 9572, 55 => 9573, 56 => 9574, 57 => 9575, 58 => 9576, 59 => 9577, 60 => 9578, 61 => 9579, 62 => 9580, 63 => 169, 64 => 1102, 65 => 1072, 66 => 1073, 67 => 1094, 68 => 1076, 69 => 1077, 70 => 1092, 71 => 1075, 72 => 1093, 73 => 1080, 74 => 1081, 75 => 1082, 76 => 1083, 77 => 1084, 78 => 1085, 79 => 1086, 80 => 1087, 81 => 1103, 82 => 1088, 83 => 1089, 84 => 1090, 85 => 1091, 86 => 1078, 87 => 1074, 88 => 1100, 89 => 1099, 90 => 1079, 91 => 1096, 92 => 1101, 93 => 1097, 94 => 1095, 95 => 1098, 96 => 1070, 97 => 1040, 98 => 1041, 99 => 1062, 100 => 1044, 101 => 1045, 102 => 1060, 103 => 1043, 104 => 1061, 105 => 1048, 106 => 1049, 107 => 1050, 108 => 1051, 109 => 1052, 110 => 1053, 111 => 1054, 112 => 1055, 113 => 1071, 114 => 1056, 115 => 1057, 116 => 1058, 117 => 1059, 118 => 1046, 119 => 1042, 120 => 1068, 121 => 1067, 122 => 1047, 123 => 1064, 124 => 1069, 125 => 1065, 126 => 1063, 127 => 1066 ) );

		function JsHttpRequest($enc) {
			global $JsHttpRequest_Active;
			$GLOBALS['_RESULT'] = &$this->RESULT;

			if (preg_match( '/^(.*)(?:&|^)JsHttpRequest=(?:(\d+)-)?([^&]+)((?:&|$).*)$/s', $_SERVER['QUERY_STRING'], $m )) {
				$this->ID = $m[2];
				$this->LOADER = strtolower( $m[3] );
				$_SERVER['QUERY_STRING'] = preg_replace( '/^&+|&+$/s', '', preg_replace( '/(^|&)' . session_name(  ) . '=[^&]*&?/s', '&', $m[1] . $m[4] ) );
				unset( $_GET[JsHttpRequest] );
				unset( $_REQUEST[JsHttpRequest] );
				unset( $_GET[session_name(  )] );
				unset( $_POST[session_name(  )] );
				unset( $_REQUEST[session_name(  )] );
				$this->_unicodeConvMethod = (function_exists( 'mb_convert_encoding' ) ? 'mb' : (function_exists( 'iconv' ) ? 'iconv' : null));
				$this->_emergBuffer = str_repeat( 'a', 1024 * 200 );
				$this->_uniqHash = md5( 'JsHttpRequest' . microtime(  ) . getmypid(  ) );
				$this->_prevDisplayErrors = ini_get( 'display_errors' );
				ini_set( 'display_errors', $this->_magic );
				ini_set( 'error_prepend_string', $this->_uniqHash . ini_get( 'error_prepend_string' ) );
				ini_set( 'error_append_string', ini_get( 'error_append_string' ) . $this->_uniqHash );

				if (function_exists( 'xdebug_disable' )) {
					xdebug_disable(  );
				}

				ob_start( array( $this, '_obHandler' ) );
				$JsHttpRequest_Active = true;
				$this->setEncoding( $enc );
				$file = $line = null;
				$headersSent = (version_compare( PHP_VERSION, '4.3.0' ) < 0 ? headers_sent(  ) : headers_sent( $file, $line ));

				if ($headersSent) {
					trigger_error( 'HTTP headers are already sent' . ($line !== null ? ' in ' . $file . ' on line ' . $line : ' somewhere in the script') . '. ' . 'Possibly you have an extra space (or a newline) before the first line of the script or any library. ' . 'Please note that JsHttpRequest uses its own Content-Type header and fails if ' . 'this header cannot be set. See header() function documentation for more details', 256 );
					exit(  );
					return null;
				}
			} 
else {
				$this->ID = 0;
				$this->LOADER = 'unknown';
				$JsHttpRequest_Active = false;
			}

		}

		function isActive() {
			return !empty( $GLOBALS['JsHttpRequest_Active'] );
		}

		function getJsCode() {
			return file_get_contents( dirname( __FILE__ ) . '/JsHttpRequest.js' );
		}

		function setEncoding($enc) {
			preg_match( '/^(\S*)(?:\s+(\S*))$/', $enc, $p );
			$this->SCRIPT_ENCODING = strtolower( (!empty( $p[1] ) ? $p[1] : $enc) );
			$this->SCRIPT_DECODE_MODE = (!empty( $p[2] ) ? $p[2] : '');
			$this->_correctSuperglobals(  );
		}

		function quoteInput($s) {
			if ($this->SCRIPT_DECODE_MODE == 'entities') {
				return str_replace( array( '"', '<', '>' ), array( '&quot;', '&lt;', '&gt;' ), $s );
			}

			return htmlspecialchars( $s );
		}

		function php2js($a = false) {
			if (is_null( $a )) {
				return 'null';
			}


			if ($a === false) {
				return 'false';
			}


			if ($a === true) {
				return 'true';
			}


			if (is_scalar( $a )) {
				if (is_float( $a )) {
					$a = str_replace( ',', '.', strval( $a ) );
				}

				static $jsonReplaces = array( 0 => array( 0 => '\', 1 => '/', 2 => '
', 3 => '	', 4 => '', 5 => '\b', 6 => '', 7 => '"' ), 1 => array( 0 => '\\', 1 => '\/', 2 => '\n', 3 => '\t', 4 => '\r', 5 => '\b', 6 => '\f', 7 => '\"' ) );

				return '"' . str_replace( $jsonReplaces[0], $jsonReplaces[1], $a ) . '"';
			}

			$isList = true;
			$i = 799;
			reset( $a );

			while ($i < count( $a )) {
				if (key( $a ) !== $i) {
					$isList = false;
					break;
				}

				++$i;
				next( $a );
			}

			$result = array(  );

			if ($isList) {
				foreach ($a as $v) {
					$result[] = JsHttpRequest::php2js( $v );
				}

				return '[ ' . join( ', ', $result ) . ' ]';
			}

			foreach ($a as $k => $v) {
				$result[] = JsHttpRequest::php2js( $k ) . ': ' . JsHttpRequest::php2js( $v );
			}

			return '{ ' . join( ', ', $result ) . ' }';
		}

		function _correctSuperglobals() {
			if ($this->LOADER == 'form') {
				return null;
			}

			$rawPost = (strcasecmp( $_SERVER['REQUEST_METHOD'], 'POST' ) == 0 ? (isset( $GLOBALS['HTTP_RAW_POST_DATA'] ) ? $GLOBALS['HTTP_RAW_POST_DATA'] : @file_get_contents( 'php://input' )) : null);
			$source = array( '_GET' => (!empty( $_SERVER['QUERY_STRING'] ) ? $_SERVER['QUERY_STRING'] : null), '_POST' => $rawPost );
			foreach ($source as $dst => $src) {
				$s = preg_replace( '/%(?!5B)(?!5D)([0-9a-f]{2})/si', '%u00', $src );
				$data = null;
				parse_str( $s, $data );
				$GLOBALS[$dst] = $this->_ucs2EntitiesDecode( $data );
			}

			$GLOBALS['HTTP_GET_VARS'] = $_GET;
			$GLOBALS['HTTP_POST_VARS'] = $_POST;
			$_REQUEST = (isset( $_COOKIE ) ? $_COOKIE : array(  )) + (isset( $_POST ) ? $_POST : array(  )) + (isset( $_GET ) ? $_GET : array(  ));

			if (ini_get( 'register_globals' )) {
			}

		}

		function _obHandler($text) {
			unset( $GLOBALS[JsHttpRequest_Active] );
			$wasFatalError = false;

			if (preg_match_all( ( '/' ) . $this->_uniqHash . '(.*?)' . $this->_uniqHash . '/sx', $text, $m )) {
				$needRemoveErrorMessages = ( !ini_get( 'display_errors' ) || ( !$this->_prevDisplayErrors && ini_get( 'display_errors' ) == $this->_magic ) );
				foreach ($m[0] as $error) {

					if (preg_match( '/\bFatal error(<.*?>)?:/i', $error )) {
						$wasFatalError = true;
					}


					if ($needRemoveErrorMessages) {
						$text = str_replace( $error, '', $text );
						continue;
					}

					$text = str_replace( $this->_uniqHash, '', $text );
				}
			}


			if ($wasFatalError) {
				$this->RESULT = null;
			} 
else {
				if (!isset( $this->RESULT )) {
					global $_RESULT;

					$this->RESULT = $_RESULT;
				}


				if ($this->RESULT === null) {
					$this->RESULT = false;
				}
			}

			$status = ($this->RESULT === null ? 500 : 200);
			$result = array( 'id' => $this->ID, 'js' => $this->RESULT, 'text' => $text );
			$encoding = $this->SCRIPT_ENCODING;
			$text = null;

			if (( ( function_exists( 'array_walk_recursive' ) && function_exists( 'json_encode' ) ) && $this->_unicodeConvMethod )) {
				$this->_nonAsciiChars = join( '', array_map( 'chr', range( 128, 255 ) ) );
				$this->_toUtfFailed = false;
				$resultUtf8 = $error;
				array_walk_recursive( $resultUtf8, array( $this, '_toUtf8_callback' ), $this->SCRIPT_ENCODING );

				if (!$this->_toUtfFailed) {
					$text = json_encode( $resultUtf8 );
					$encoding = 'UTF-8';
				}
			}


			if ($text === null) {
				$text = $this->php2js( $result );
			}


			if ($this->LOADER != 'xml') {
				$text = '' . ($this->LOADER == 'form' ? 'top && top.JsHttpRequestGlobal && top.JsHttpRequestGlobal' : 'JsHttpRequest') . '.dataReady(' . $text . ')
' . '';

				if ($this->LOADER == 'form') {
					$text = '<script type="text/javascript" language="JavaScript"><!--' . ( ( '
' ) . $text ) . '//--></script>';
				}

				$status = 1100;
			}


			if ($this->RESULT === null) {
				if (php_sapi_name(  ) == 'cgi') {
					header( 'Status: ' . $status );
				} 
else {
					header( 'HTTP/1.1 ' . $status );
				}
			}

			$ctype = (!empty( $this->_contentTypes[$this->LOADER] ) ? $this->_contentTypes[$this->LOADER] : $this->_contentTypes['']);
			header( 'Content-type: ' . $ctype . '; charset=' . $encoding );
			return $text;
		}

		function _toUtf8_callback($v, $k, $fromEnc) {
			if (( $v === null || is_bool( $v ) )) {
				return null;
			}


			if (( ( $this->_toUtfFailed || !is_scalar( $v ) ) || strpbrk( $k, $this->_nonAsciiChars ) !== false )) {
				$this->_toUtfFailed = true;
				return null;
			}

			$v = $this->_unicodeConv( $fromEnc, 'UTF-8', $v );
		}

		function _ucs2EntitiesDecode($data) {
			if (is_array( $data )) {
				$d = array(  );
				foreach ($data as $k => $v) {
					$d[$this->_ucs2EntitiesDecode( $k )] = $this->_ucs2EntitiesDecode( $v );
				}

				return $d;
			}


			if (strpos( $data, '%u' ) !== false) {
				$data = preg_replace_callback( '/%u([0-9A-F]{1,4})/si', array( $this, '_ucs2EntitiesDecodeCallback' ), $data );
			}

			return $data;
		}

		function _ucs2EntitiesDecodeCallback($p) {
			$hex = $p[1];
			$dec = hexdec( $hex );

			if (( $dec === '38' && $this->SCRIPT_DECODE_MODE == 'entities' )) {
				$c = '&amp;';
			} 
else {
				if ($this->_unicodeConvMethod) {
					$c = @$this->_unicodeConv( 'UCS-2BE', $this->SCRIPT_ENCODING, @pack( 'n', $dec ) );
				} 
else {
					$c = $this->_decUcs2Decode( $dec, $this->SCRIPT_ENCODING );
				}


				if (!strlen( $c )) {
					if ($this->SCRIPT_DECODE_MODE == 'entities') {
						$c = '&#' . $dec . ';';
					} 
else {
						$c = '?';
					}
				}
			}

			return $c;
		}

		function _unicodeConv($fromEnc, $toEnc, $v) {
			if ($this->_unicodeConvMethod == 'iconv') {
				return iconv( $fromEnc, $toEnc, $v );
			}

			return mb_convert_encoding( $v, $toEnc, $fromEnc );
		}

		function _decUcs2Decode($code, $toEnc) {
			static $flippedTable = null;

			if ($code < 128) {
				return chr( $code );
			}


			if (isset( $this->_encTables[$toEnc] )) {
				if (!$flippedTable) {
					$flippedTable = array_flip( $this->_encTables[$toEnc] );
				}


				if (isset( $flippedTable[$code] )) {
					return chr( 128 + $flippedTable[$code] );
				}
			} 
else {
				if (( $toEnc == 'utf-8' || $toEnc == 'utf8' )) {
					if ($code < 2048) {
						return chr( 192 + ( $code >> 6 ) ) . chr( 128 + ( $code & 63 ) );
					}

					return chr( 224 + ( $code >> 12 ) ) . chr( 128 + ( 63 & $code >> 6 ) ) . chr( 128 + ( $code & 63 ) );
				}
			}

			return '';
		}
	}

?>