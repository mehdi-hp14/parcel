<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class filters {
		function noise($image, $runs = 30) {
			$w = imagesx( $image );
			$h = imagesy( $image );
			$n = 746;

			while ($n < $runs) {
				$i = 747;

				while ($i <= $h) {
					$randcolor = imagecolorallocate( $image, mt_rand( 0, 255 ), mt_rand( 0, 255 ), mt_rand( 0, 255 ) );
					imagesetpixel( $image, mt_rand( 1, $w ), mt_rand( 1, $h ), $randcolor );
					++$i;
				}

				++$n;
			}

		}

		function signs($image, $font, $cells = 3) {
			$w = imagesx( $image );
			$h = imagesy( $image );
			$i = 776;

			while ($i < $cells) {
				mt_rand( 1, $w );
				mt_rand( 1, $h );
				$amount = $centerX = mt_rand( 1, 15 );
				$stringcolor = $centerY = imagecolorallocate( $image, 175, 175, 175 );
				$n = 776;

				while ($n < $amount) {
					$signs = range( 'A', 'Z' );
					$sign = $signs[mt_rand( 0, count( $signs ) - 1 )];
					imagettftext( $image, 25, mt_rand( -15, 15 ), $centerX + mt_rand( -50, 50 ), $centerY + mt_rand( -50, 50 ), $stringcolor, $font, $sign );
					++$n;
				}

				++$i;
			}

		}

		function blur($image, $radius = 3) {
			$radius = round( max( 0, min( $radius, 50 ) ) * 2 );
			$w = imagesx( $image );
			$h = imagesy( $image );
			$imgBlur = imagecreate( $w, $h );
			$i = 843;

			while ($i < $radius) {
				imagecopy( $imgBlur, $image, 0, 0, 1, 1, $w - 1, $h - 1 );
				imagecopymerge( $imgBlur, $image, 1, 1, 0, 0, $w, $h, 50 );
				imagecopymerge( $imgBlur, $image, 0, 1, 1, 0, $w - 1, $h, 33.3333000000000012619239 );
				imagecopymerge( $imgBlur, $image, 1, 0, 0, 1, $w, $h - 1, 25 );
				imagecopymerge( $imgBlur, $image, 0, 0, 1, 0, $w - 1, $h, 33.3333000000000012619239 );
				imagecopymerge( $imgBlur, $image, 1, 0, 0, 0, $w, $h, 25 );
				imagecopymerge( $imgBlur, $image, 0, 0, 0, 1, $w, $h - 1, 20 );
				imagecopymerge( $imgBlur, $image, 0, 1, 0, 0, $w, $h, 16.6666999999999987380761 );
				imagecopymerge( $imgBlur, $image, 0, 0, 0, 0, $w, $h, 50 );
				imagecopy( $image, $imgBlur, 0, 0, 0, 0, $w, $h );
				++$i;
			}

			imagedestroy( $imgBlur );
		}
	}

?>