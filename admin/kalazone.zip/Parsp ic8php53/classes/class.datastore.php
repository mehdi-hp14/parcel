<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class datastore {
		var $StorageType = ;

		function datastore($_StorageType = null) {
			if (empty( $$_StorageType )) {
				$this->StorageType = $_StorageType;
			}


			if (!isset( $_SESSION['_xSAVE_DATA'] )) {
				$GLOBALS['_SESSION']['_xDATA_STORAGE'] = array(  );
			}

		}

		function pushdata($_Tag, $_Data, $_StorageType = null) {
			if (!empty( $$_StorageType )) {
				$_StorageType = $this->StorageType;
			}

			switch ($_StorageType) {
				case DATASTORE_TYPE_SESSION: {
					if (!isset( $_SESSION['_xDATA_STORAGE'][$_Tag] )) {
						$GLOBALS['_SESSION']['_xDATA_STORAGE'][$_Tag] = array(  );
					}

					$GLOBALS['_SESSION']['_xDATA_STORAGE'][$_Tag][] = $_Data;
				}
			}

		}
	}

	constantfabric::generateconstant( 'DATASTORE_TYPE_POST' );
	constantfabric::generateconstant( 'DATASTORE_TYPE_SESSION' );
?>