<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	class fURL {
		var $__path = '';
		var $__path_settings = array(  );

		function get_real_path($urlEntry = null) {
			$Register = &Register::getInstance(  );

			$path = $Register->get( 'FURL_PATH' );

			if (( !$path && isset( $_GET['__furl_path'] ) )) {
				$path = $_GET['__furl_path'];
			}


			if (is_null( $urlEntry )) {
				$urlEntry = &$Register->get( VAR_URL );

				if (!is_object( $urlEntry )) {
					ClassManager::includeClass( 'URL' );
					$urlEntry = new URL(  );
					$urlEntry->loadFromServerInfo(  );
				}
			}

			return preg_replace( '/\/[^\/]+$/u', '/', str_replace( $path, '', $urlEntry->getPath(  ) ) );
		}

		function exec($path = null) {
			if (is_null( $path )) {
				$path = (isset( $_GET['__furl_path'] ) ? $_GET['__furl_path'] : '');
			}

			$fURL = new fURL(  );
			$fURL->__path = $path;
			$fURL->__parsePath(  );
			$fURL->__updateSystemVars(  );
		}

		function __updateSystemVars() {
			$get_vars = $this->__renderGetString(  );
			$_SERVER['REQUEST_URI'] = fURL::get_real_path(  );
			renderURL( $get_vars . '&__furl_path=' . (isset( $this->__path_settings['language_iso2'] ) ? '&lang_iso2=' . $this->__path_settings['language_iso2'] : ''), '', true );
		}

		function __renderGetString() {
			if (!isset( $this->__path_settings['update_sys_handler'] )) {
				$this->__path_settings['update_sys_handler'] = '';
			}

			$get_vars = '';
			switch ($this->__path_settings['update_sys_handler']) {
				case 'category': {
					$categoryEntry = new Category(  );
					$categoryEntry->loadBySlug( $this->__path_settings['category_slug'] );

					if ($categoryEntry->categoryID) {
						$get_vars .= '&categoryID=' . $categoryEntry->categoryID . '&category_slug=' . $this->__path_settings['category_slug'];
					} 
else {
						$get_vars .= '&categoryID=' . $this->__path_settings['category_slug'];
					}


					if ($this->__path_settings['category_search']) {
						$get_vars .= '&ukey=category_search';
					} 
else {
						$get_vars .= '&ukey=category';
					}


					if (isset( $this->__path_settings['page'] )) {
						$get_vars .= '&page=' . $this->__path_settings['page'];
					}


					if (isset( $this->__path_settings['view_content'] )) {
						$get_vars .= '&page=' . $this->__path_settings['view_content'];
					}

					break;
				}

				case 'product': {
					$productEntry = new Product(  );
					$productEntry->loadBySlug( $this->__path_settings['product_slug'] );

					if ($productEntry->productID) {
						$categoryID = $productEntry->categoryID;
						$get_vars .= '&productID=' . $productEntry->productID . '&product_slug=' . $this->__path_settings['product_slug'];
					} 
else {
						$productEntry->loadByID( $this->__path_settings['product_slug'] );
						$categoryID = $productEntry->categoryID;
						$get_vars .= '&productID=' . $this->__path_settings['product_slug'];
					}

					$Register = &Register::getInstance(  );

					$Register->set( 'categoryID', $categoryID );

					if (isset( $this->__path_settings['product_widget'] )) {
						$get_vars .= '&ukey=product_widget';
					} 
else {
						$get_vars .= ($this->__path_settings['ukey'] != 'reviews' ? '&ukey=product' : '&ukey=discuss_product');
					}

					break;
				}
			}


			if (isset( $this->__path_settings['ukey'] )) {
				$get_vars .= '&ukey=' . $this->__path_settings['ukey'];
			}

			$get_vars .= (isset( $this->__path_settings['page'] ) ? '&news_page=' . $this->__path_settings['page'] : '');
			$get_vars .= (isset( $this->__path_settings['view_content'] ) ? '&news_page=' . $this->__path_settings['view_content'] : '');
			break;

			if (isset( $this->__path_settings['get'] )) {
				$get_vars .= $this->__path_settings['get'];
			}

			return $get_vars;
		}

		function convertGetToPath(&$request, $get) {
			if (!MOD_REWRITE_SUPPORT) {
				return null;
			}

			unset( $get[__furl_path] );
			$Register = &Register::getInstance(  );

			$rest_part = '';

			if (preg_match( '@([^\?\&]+)([\?\&].*)$@msi', $request, $sp )) {
				$rest_part = $sp[2];
				$request = $sp[1];
				$sp = $sp[0];
			}

			$request = str_replace( '?', '', $request );
			$urlEntry = $Register->get( VAR_URL );

			if (isset( $get['lang_iso2'] )) {
				$defaultLanguage = &LanguagesManager::getDefaultLanguage(  );

				$request .= ($defaultLanguage->iso2 == $get['lang_iso2'] ? '' : $get['lang_iso2'] . '/');
				unset( $get[lang_iso2] );
			}


			if (isset( $get['refid'] )) {
				$request .= 'referral/' . $get['refid'] . '/';
				unset( $get[refid] );
				unset( $get[ukey] );
			} 
else {
				if (isset( $get['categoryID'] )) {
					$request .= 'category/' . $get['categoryID'] . '/' . (isset( $get['category_slug'] ) ? $get['category_slug'] : $get['categoryID']) . '/';

					if (( isset( $get['ukey'] ) && $get['ukey'] == 'product_comparison' )) {
						$request .= 'compare/';
					}


					if (( isset( $get['ukey'] ) && $get['ukey'] == 'category_search' )) {
						$request = str_replace( 'category_search/', '', $request );
						$request .= 'search/';
					}

					unset( $get[category_slug] );
					unset( $get[categoryID] );
					unset( $get[ukey] );
					unset( $get[did] );

					if (( isset( $get['page'] ) || isset( $get['view_content'] ) )) {
						if (isset( $get['page'] )) {
							$request .= ( 'page' . $get['page'] . '/' );
							unset( $get[page] );
						} 
else {
							$request .= ( 'page' . $get['view_content'] . '/' );
							unset( $get[view_content] );
						}
					}
				} 
else {
					if (( isset( $get['product_slug'] ) || ( isset( $get['productID'] ) && $get['ukey'] != 'cart' ) )) {
						if (( isset( $get['ukey'] ) && $get['ukey'] == 'product_widget' )) {
							$request .= 'product_widget/';
						} 
else {
							$request .= 'product/';
						}

						$request .= $get['productID'] . '/' . (isset( $get['product_slug'] ) ? $get['product_slug'] : $get['productID']) . (( isset( $get['ukey'] ) && $get['ukey'] == 'discuss_product' ) ? '/reviews/' : '/');
						unset( $get[product_slug] );
						unset( $get[productID] );
						unset( $get[ukey] );
						unset( $get[did] );
					} 
else {
						if (isset( $get['ukey'] )) {
							switch ($get['ukey']) {
								case 'transaction_result': {
									$request .= 'transaction/' . (isset( $get['transaction_result'] ) ? $get['transaction_result'] . '/' : '');
									unset( $get[transaction_result] );
									break;
								}

								case 'product_comparison': {
									$request .= 'compare/';
									break;
								}

								case 'user_details': {
									$request .= 'MyAccount/';
									break;
								}

								case 'news': {
									$get['ukey'] = 'blog';
								}

								case 'show_price': {
									if (!strpos( $request, 'Price-List' )) {
										$request .= 'Price-List/';
									}

									$request .= (isset( $get['sort'] ) ? $get['sort'] . '/' . (isset( $get['direction'] ) ? $get['direction'] : '') : '');
									unset( $get[show_price] );
									unset( $get[ukey] );
									unset( $get[sort] );
									unset( $get[direction] );
									break;
								}

								case 'feedback': {
									$request .= 'Contact-Us/';
									break;
								}

								case 'cart': {
									$request .= ( $get['ukey'] . '/' );

									if (( ( $get['ukey'] == 'news' || $get['ukey'] == 'blog' ) && isset( $get['news_page'] ) )) {
										$request .= ( 'page' . $get['news_page'] . '/' );
										unset( $get[news_page] );
										unset( $get[page] );
									}


									if (array_key_exists( 'blog_id', $get )) {
										$request .= $get['blog_id'] . '/';
										unset( $get[blog_id] );
									}

									break;
								}
							}

							$request .= ( $get['ukey'] . '/' );
							unset( $get[ukey] );
							unset( $get[did] );
						}
					}
				}
			}


			if (isset( $get['show_all'] )) {
				$request .= 'all/';
				unset( $get[show_all] );
				unset( $get[page] );
			} 
else {
				if (( isset( $get['page'] ) || isset( $get['view_content'] ) )) {
					if (isset( $get['view_content'] )) {
						$request .= 'page/' . $get['view_content'] . '/' . $get['view_slug'] . '/';
						unset( $get[view_content] );
						unset( $get[view_slug] );
					} 
else {
						$request .= 'page/' . $get['page'] . '/' . $get['view_slug'] . '/';
						unset( $get[page] );
						unset( $get[view_slug] );
					}
				} 
else {
					if (isset( $get['offset'] )) {
						$request .= 'offset' . $get['offset'] . '/';
						unset( $get[offset] );
					}
				}
			}


			if (isset( $get['register'] )) {
				$request .= 'register/';
				unset( $get[register] );
			}

			$request .= $Register;
			$request = str_replace( 'TitlePage.html', '', $request );
			$request = str_replace( 'TitlePage/', '', $request );
			$request = str_replace( array( 'home/', 'page1/', 'offset0/' ), '', $request );
		}

		function __parsePath() {
			$path_parts = explode( '/', $this->__path );
			$this->__path_settings = array(  );
			$parts_num = count( $path_parts );
			$i = 980;

			while ($i++ < $parts_num) {
				$part_value = array_shift( $path_parts );

				if (!$part_value) {
					break;
				}

				switch ($i) {
					case 1: {
						if (strlen( $part_value ) == 2) {
							LanguagesManager::getLanguageByISO2( $part_value );
							$languageEntry = ;

							if (( !is_null( $languageEntry ) && $languageEntry->enabled )) {
								LanguagesManager::setCurrentLanguage( $languageEntry->id, false );
								$this->__path_settings['language_iso2'] = $part_value;
								$this->__path_settings->get .= '&lang_iso2=' . $part_value;
							}

							break;
						}


						if (in_array( $part_value, array( 'facebook', 'vkontakte' ) )) {
							$this->__path_settings['store_mode'] = $part_value;
							$this->__path_settings->get .= '&store_mode=' . $part_value;
							break;
						}
					}
				}

				switch ($part_value) {
					case 'referral': {
						$this->__path_settings['get'] = '&refid=' . array_shift( $path_parts );
						continue;
					}

					case 'category': {
						$this->__path_settings['category_slug'] = str_replace( '.html', '', array_shift( $path_parts ) );
						$this->__path_settings['category_search'] = false;

						if (( isset( $path_parts[0] ) && $path_parts[0] == 'search' )) {
							$this->__path_settings['category_search'] = true;
						}

						$this->__path_settings['update_sys_handler'] = 'category';
						continue;
					}

					case 'product_widget': {
						$this->__path_settings['product_widget'] = true;
					}

					case 'product': {
						$this->__path_settings['update_sys_handler'] = 'product';
						$this->__path_settings['product_slug'] = str_replace( '.html', '', array_shift( $path_parts ) );
						continue;
					}

					case 'blog': {
						$part_value = 'news';
					}

					case 'news': {
						$this->__path_settings['ukey'] = str_replace( '.html', '', $part_value );

						if (( isset( $path_parts[0] ) && strpos( $path_parts[0], 'page' ) === 0 )) {
							$this->__path_settings['page'] = intval( substr( $path_parts[0], 4 ) );
						}


						if (0 < intval( $path_parts[0] )) {
							$this->__path_settings['get'] = '&blog_id=' . intval( $path_parts[0] );
						}

						continue;
					}

					case 'compare': {
						$this->__path_settings['ukey'] = 'product_comparison';
						$this->__path_settings['update_sys_handler'] = '';
						continue;
					}

					case 'myaccount': {
						$this->__path_settings['ukey'] = 'user_details';
						continue;
					}

					case 'transaction': {
						$this->__path_settings['ukey'] = 'transaction_result';
						$this->__path_settings->get .= '&transaction_result=' . array_shift( $path_parts );
						continue;
					}
				}


				if (strpos( $part_value, 'page' ) === 0) {
					$part_value = str_replace( '.html', '', $part_value );
					$this->__path_settings->get .= '&page=' . intval( substr( $part_value, 4 ) );
				} 
else {
					if (strpos( $part_value, 'offset' ) === 0) {
						$part_value = str_replace( '.html', '', $part_value );
						$this->__path_settings->get .= '&offset=' . intval( substr( $part_value, 6 ) );
					} 
else {
						if (strpos( $part_value, 'all' ) === 0) {
							$this->__path_settings->get .= '&show_all=1';
						} 
else {
							if (!array_key_exists( 'ukey', $this->__path_settings )) {
								$this->__path_settings['ukey'] = str_replace( array( '.html', '.php' ), '', $part_value );
							}
						}
					}
				}

				continue;
				break;
			}

		}
	}

?>