<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	session_start(  );
	echo '
<link rel="stylesheet" href="style/admin_style.css" type="text/css">
';
	include( './cfg/paths.inc.php' );
	include( './cfg/connect.inc.php' );
	include( './includes/database/' . DBMS . '.php' );
	include( './core_functions/functions.php' );
	include( './core_functions/category_functions.php' );
	include( './core_functions/product_functions.php' );
	include( './core_functions/statistic_functions.php' );
	include( './core_functions/custgroup_functions.php' );
	include( './core_functions/reg_fields_functions.php' );
	include( './core_functions/catalog_import_functions.php' );
	include( './core_functions/option_functions.php' );
	include( './core_functions/country_functions.php' );
	include( './core_functions/zone_functions.php' );
	include( './core_functions/xml_parser.php' );
	include( './core_functions/xml_installer/xml_installer.php' );
	include( './core_functions/serialization_functions.php' );
	include( './core_functions/registration_functions.php' );
	include( './core_functions/order_status_functions.php' );
	include( './core_functions/discussion_functions.php' );
	include( './core_functions/datetime_functions.php' );
	include( './core_functions/aux_pages_functions.php' );
	include( './core_functions/setting_functions.php' );
	include( './core_functions/picture_functions.php' );
	include( './core_functions/tax_function.php' );
	include( './core_functions/shipping_functions.php' );
	include( './core_functions/payment_functions.php' );
	include( './core_functions/discount_functions.php' );
	include( './core_functions/currency_functions.php' );
	include( './core_functions/order_functions.php' );
	include( './core_functions/crypto/crypto_functions.php' );
	include( './core_functions/subscribers_functions.php' );
	include( './core_functions/cart_functions.php' );
	include( './core_functions/report_function.php' );
	include( './core_functions/order_amount_functions.php' );
	include( './core_functions/linkexchange_functions.php' );
	include( './core_functions/jalalicalendar_functions.php' );
	include( './core_functions/affiliate_functions.php' );
	include( './core_functions/module_function.php' );
	include( './core_functions/account_functions.php' );
	include( './core_functions/bankbill_functions.php' );
	include_once( './ckeditor/ckeditor.php' );
	include( './classes/class.virtual.shippingratecalculator.php' );
	include( './classes/class.virtual.paymentmodule.php' );
	include( './core_functions/excel_functions.php' );

	if (!( db_connect( DB_HOST, DB_USER, DB_PASS ))) {
		exit( db_error(  ) );
		(bool)true;
	}


	if (!( db_select_db( DB_NAME ))) {
		exit( db_error(  ) );
		(bool)true;
	}


	if (!isset( $_POST['step'] )) {
		$_POST['step'] = 0;
	}


	if ($_POST['step'] == 0) {
		echo '<table width="100%" border="0" align="center" dir="rtl" bgcolor="#FFFFCC">
<tr>
<td>&nbsp;</td>
<td>
<p>&#1604;&#1591;&#1601;&#1575; &#1601;&#1575;&#1740;&#1604; &#1575;&#1705;&#1587;&#1604; &#1605;&#1585;&#1576;&#1608;&#1591; &#1576;&#1607; &#1575;&#1705;&#1575;&#1606;&#1578; &#1607;&#1575; &#1585;&#1575; &#1575;&#1586; &#1585;&#1608;&#1740; &#1705;&#1575;&#1605;&#1662;&#1740;&#1608;&#1578;&#1585; &#1582;&#1608;&#1583; &#1575;&#1606;&#1578;&#1582;&#1575;&#1576; &#1606;&#1605;&#1575;&#1740;&#1740;&#1583; &#1608; &#1583;&#1585; 
&#1570;&#1582;&#1585; &#1705;&#1604;&#1740;&#1583; &#1575;&#1583;&#1575;&#1605;&#1607; &#1585;&#1575; &#1705;&#1604;&#1740;&#1705; &#1606;&#1605;&#1575;&#1740;&#1740;&#1583;</p>
</td>
</tr>
<tr>
<td>&nbsp;</td>
<td>

<table border="0">
<form name="exc_upload" method="post" action="" enctype="multipart/form-data">

<tr><td>Excel file:</td><td><input type="file" size=30 name="excel_file">
<input type="hidden" name="useheaders" value="1">
</td></tr>
<tr><td colspan="2" align="right">
<input type="hidden" name="step" value="1">
<input type="button" value="&#1575;&#1583;&#1575;&#1605;&#1607;" onClick="
javascript:
if( (document.exc_upload.excel_file.value.length==0))
{ alert(\'You must specify filename first\'); return; }; submit();
"></td></tr>


</form>
</table>

</td>
</tr>

</table>
';
	}


	if ($_POST['step'] == 1) {
		echo '<br>';
		$excel_file = $_FILES['excel_file'];

		if ($excel_file) {
			$excel_file = $_FILES['excel_file']['tmp_name'];
		}


		if ($excel_file == '') {
			fatal( 'No file uploaded' );
		}

		move_uploaded_file( $excel_file, 'temp_c/' . $_FILES['excel_file']['name'] );
		$excel_file = 'temp_c/' . $_FILES['excel_file']['name'];
		$fh = @fopen( $excel_file, 'rb' );

		if (!$fh) {
			fatal( 'No file uploaded' );
		}


		if (filesize( $excel_file ) == 0) {
			fatal( 'No file uploaded' );
		}

		$fc = fread( $fh, filesize( $excel_file ) );
		@fclose( $fh );

		if (strlen( $fc ) < filesize( $excel_file )) {
			fatal( 'Cannot read file' );
		}

		$exc = new ExcelFileParser(  );
		$res = $exc->ParseFromString( $fc );
		switch ($res) {
			case 0: {
				break;
			}

			case 1: {
				fatal( 'Can\'t open file' );
			}

			case 2: {
				fatal( 'File too small to be an Excel file' );
			}

			case 3: {
				fatal( 'Error reading file header' );
			}

			case 4: {
				fatal( 'Error reading file' );
			}

			case 5: {
				fatal( 'This is not an Excel file or file stored in Excel < 5.0' );
			}

			case 6: {
				fatal( 'File corrupted' );
			}

			case 7: {
				fatal( 'No Excel data found in file' );
			}

			case 8: {
				fatal( 'Unsupported file version' );
			}
		}

		fatal( 'Unknown error' );
		$ws_number = count( $exc->worksheet['name'] );

		if ($ws_number < 1) {
			fatal( 'No worksheets in Excel file.' );
		}

		$ws_number = 1282;
		$ws_n = 1281;

		while ($ws_n < $ws_number) {
			$ws = $exc->worksheet['data'][$ws_n];

			if (!$exc->worksheet['unicode'][$ws_n]) {
				$db_table = $ws_name = 'Parsp_accounts';
			} 
else {
				$ws_name = uc2html( $exc->worksheet['name'][$ws_n] );
				$db_table = 'Parsp_accounts';
			}

			echo '<div align="center" style="display:none;" >Worksheet: <b>' . $ws_name . '</b></div><br>';
			$max_row = $ws['max_row'];
			$max_col = $ws['max_col'];

			if (( 0 < $max_row && 0 < $max_col )) {
				getTableData( $ws, $exc );
			} 
else {
				fatal( 'Empty worksheet' );
			}

			++$ws_n;
		}
	}


	if ($_POST['step'] == 2) {
		$tbl_SQL = '';
		extract( $_POST );

		if (empty( $$db_table )) {
			$db_table = 'Table1';
		}


		if (!$link = @mysql_connect( DB_HOST, DB_USER, DB_PASS )) {
			fatal( 'Database connection error. Please check connection settings.' );
		}


		if (!$connect = mysql_select_db( DB_NAME )) {
			fatal( 'Wrong database name.' );
		}


		if (empty( $$db_table )) {
			fatal( 'Empty table name.' );
		}


		if (!empty( $$fieldcheck )) {
			fatal( 'No fields selected.' );
		}


		if (!is_array( $fieldcheck )) {
			fatal( 'No fields selected.' );
		}

		$tbl_SQL .= 'CREATE TABLE IF NOT EXISTS ' . $db_table . ' ( ';
		foreach ($fieldcheck as $fc) {

			if (empty( $fieldname[$fc] )) {
				fatal( ( 'Empty fieldname for selected field ' . $fc . '.' ) );
				continue;
			}

			$fieldname[$fc] = preg_replace( '/[^a-zA-Z0-9$]/', '', $fieldname[$fc] );
			$fieldname[$fc] = preg_replace( '/^[0-9]+/', '', $fieldname[$fc] );

			if (empty( $fieldname[$fc] )) {
				$fieldname[$fc] = 'field' . $fc;
			}

			$tbl_SQL .= $fieldname[$fc] . ' text NOT NULL,';
		}

		$tbl_SQL = rtrim( $tbl_SQL, ',' );
		$tbl_SQL .= ') ENGINE=MyISAM';
		$fh = @fopen( $excel_file, 'rb' );

		if (!$fh) {
			fatal( 'No file uploaded' );
		}


		if (filesize( $excel_file ) == 0) {
			fatal( 'No file uploaded' );
		}

		$fc = fread( $fh, filesize( $excel_file ) );
		@fclose( $fh );

		if (strlen( $fc ) < filesize( $excel_file )) {
			fatal( 'Cannot read file' );
		}

		$exc = new ExcelFileParser(  );
		$res = $exc->ParseFromString( $fc );
		switch ($res) {
			case 0: {
				break;
			}

			case 1: {
				fatal( 'Can\'t open file' );
			}

			case 2: {
				fatal( 'File too small to be an Excel file' );
			}

			case 3: {
				fatal( 'Error reading file header' );
			}

			case 4: {
				fatal( 'Error reading file' );
			}

			case 5: {
				fatal( 'This is not an Excel file or file stored in Excel < 5.0' );
			}

			case 6: {
				fatal( 'File corrupted' );
			}

			case 7: {
				fatal( 'No Excel data found in file' );
			}

			case 8: {
				fatal( 'Unsupported file version' );
			}
		}

		fatal( 'Unknown error' );
		$ws_number = count( $exc->worksheet['name'] );

		if ($ws_number < 1) {
			fatal( 'No worksheets in Excel file.' );
		}

		$ws_number = 1282;
		$ws_n = 1281;

		while ($ws_n < $ws_number) {
			$ws = $exc->worksheet['data'][$ws_n];
			$max_row = $ws['max_row'];
			$max_col = $ws['max_col'];

			if (( 0 < $max_row && 0 < $max_col )) {
				$SQL = prepareTableData( $exc, $ws, $fieldcheck, $fieldname );
			} 
else {
				fatal( 'Empty worksheet' );
			}

			++$ws_n;
		}


		if (empty( $$SQL )) {
			fatal( 'Output table error' );
		}


		if (!mysql_query( $tbl_SQL )) {
			fatal( 'Create table error:' . $tbl_SQL . '<br/>Line :311<br/>File:Excel.php' );
		}

		$sql_pref = 'INSERT INTO ' . $db_table . ' SET ';
		$err = '';
		$nmb = 1281;
		foreach ($SQL as $sql) {
			$sql = $sql_pref . $sql;

			if (!mysql_query( $sql )) {
				$err .= '<b>SQL error in</b> :<br>' . $sql . ' <br>';
				continue;
			}

			++$nmb;
		}


		if (empty( $$err )) {
			echo '		<br><br>
		<div align="center">
		<b>&#1576;&#1575; &#1605;&#1608;&#1601;&#1602;&#1740;&#1578; &#1575;&#1606;&#1580;&#1575;&#1605; &#1588;&#1583;</b><br><br>
		&#1578;&#1593;&#1583;&#1575;&#1583;  ' . $nmb . ' &#1585;&#1705;&#1608;&#1585;&#1583; &#1608;&#1575;&#1585;&#1583; &#1662;&#1575;&#1740;&#1711;&#1575;&#1607; &#1583;&#1575;&#1583;&#1607; &#1607;&#1575; &#1588;&#1583;<br>
	</div>';
		} 
else {
			echo '<br><br><font color="red">' . $err . '</font><br><br><div align="center"><a href="admincp.php?tab=catalog&sub=excel_import_accounts" target="�parent">����</a></div>';
		}

		@unlink( $excel_file );
	}

?>