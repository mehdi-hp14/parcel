<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	$admin_tab = array( 'id' => 'conf', 'sort_order' => 30, 'name' => ADMIN_SETTINGS, 'sub_departments' => array( array( 'id' => 'setting', 'name' => ADMIN_SETTINGS ), array( 'id' => 'currencies', 'name' => ADMIN_CURRENCY_TYPES ), array( 'id' => 'shipping', 'name' => STRING_SHIPPING_TYPE ), array( 'id' => 'payment', 'name' => STRING_PAYMENT_TYPE ), array( 'id' => 'taxes', 'name' => ADMIN_TAXES ), array( 'id' => 'countries', 'name' => ADMIN_COUNTRIES ), array( 'id' => 'zones', 'name' => ADMIN_ZONES ), array( 'id' => 'cities', 'name' => ADMIN_CITIES ), array( 'id' => 'googleanalytic', 'name' => ADMIN_GOOGLEANLYTIC ), array( 'id' => 'googlesitemap', 'name' => ADMIN_GOOGLESITEMAP ) ) );
	add_department( $admin_tab );
?>