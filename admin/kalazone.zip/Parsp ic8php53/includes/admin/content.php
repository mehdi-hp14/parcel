<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	$admin_tab = array( 'id' => 'content', 'sort_order' => 30, 'name' => ADMIN_CONTENT, 'sub_departments' => array( array( 'id' => 'aux_pages', 'name' => ADMIN_AUX_PAGES ), array( 'id' => 'home_text', 'name' => HOME_TEXT ), array( 'id' => 'contactus', 'name' => AUX_PAGE_TEXT . ' ' . STRING_FEEDBACK ), array( 'id' => 'survey', 'name' => ADMIN_VOTING ), array( 'id' => 'linkexchange', 'name' => STRING_MODULES_LINKEXCHANGE ), array( 'id' => 'news', 'name' => ADMIN_NEWS ) ) );
	add_department( $admin_tab );
?>