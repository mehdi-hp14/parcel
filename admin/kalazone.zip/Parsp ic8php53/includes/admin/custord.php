<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	$admin_tab = array( 'id' => 'custord', 'sort_order' => 20, 'name' => ADMIN_ORDERS, 'sub_departments' => array( array( 'id' => 'new_orders', 'name' => ADMIN_NEW_ORDERS ), array( 'id' => 'pending_orders', 'name' => ADMIN_PENDING_ORDERS ), array( 'id' => 'order_statuses', 'name' => ADMIN_ORDER_STATUES ), array( 'id' => 'affiliate', 'name' => ADMIN_AFFILIATE ), array( 'id' => 'discounts', 'name' => ADMIN_DISCOUNTS ), array( 'id' => 'coupons', 'name' => ADMIN_DISCOUNTS_COUPONS ), (mysql_num_rows( mysql_query( 'SHOW TABLES LIKE \'%' . CBANKBILL_DB_TABLE . '%\'' ) ) == 1 ? array( 'id' => 'bank_bills', 'name' => ADMIN_BANK_BILLS ) : '') ) );
	add_department( $admin_tab );
?>