<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	$admin_tab = array( 'id' => 'adv', 'sort_order' => 45, 'name' => ADMIN_ADVERTIESMENT, 'sub_departments' => array( array( 'id' => 'inblock', 'name' => ADMIN_ADVERTIESMENT_INBLOCK ), array( 'id' => 'incategory', 'name' => ADMIN_ADVERTIESMENT_INCATEGORY ) ) );
	add_department( $admin_tab );
?>