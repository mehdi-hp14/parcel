<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	$admin_tab = array( 'id' => 'layout', 'sort_order' => 35, 'name' => ADMIN_LAYOUT, 'sub_departments' => array( array( 'id' => 'templates', 'name' => TEMPLATE ), array( 'id' => 'logo', 'name' => STRING_LOGO ), array( 'id' => 'icon', 'name' => STRING_ICON ), array( 'id' => 'languages', 'name' => ADMIN_LANGUAGES ) ) );
	add_department( $admin_tab );
?>