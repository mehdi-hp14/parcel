<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	if (( empty( $$address_book ) && isset( $_SESSION['log'] ) )) {
		if (isset( $_GET['delete'] )) {
			$aID = (int)$_GET['delete'];

			if (regGetAddressByLogin( $aID, $_SESSION['log'] )) {
				redDeleteAddress( $aID );
			}
		}


		if (isset( $_POST['save'] )) {
			$aID = (int)$_POST['DefaultAddress'];

			if (regGetAddressByLogin( $aID, $_SESSION['log'] )) {
				regSetDefaultAddressIDByLogin( $_SESSION['log'], $aID );
			}
		}

		$addresses = regGetAllAddressesByLogin( $_SESSION['log'] );

		while ($i < count( $addresses )) {
			$addresses[$i]['addressStr'] = regGetAddressStr( $addresses[$i]['addressID'] );
			++$i;
		}

		regGetDefaultAddressIDByLogin( $_SESSION['log'] );
		$defaultAddressID = $i = 774;
		$smarty->assign( 'defaultAddressID', $defaultAddressID );
		$smarty->assign( 'addresses', $addresses );
		$smarty->assign( 'main_content_template', 'address_book.tpl.html' );
	}

?>