<?php
/**
*
* @ IonCube v8.3.3 Loader By DoraemonPT
* @ PHP 5.3
* @ Decoder version : 1.0.0.7
* @ Author     : DoraemonPT
* @ Release on : 09.05.2014
* @ Website    : http://EasyToYou.eu
*
**/

	if (isset( $_SESSION['log'] )) {
		if (0 < CONF_SESSION_TIMEOUT) {
			if ($_SESSION['timeout'] + CONF_SESSION_TIMEOUT * 60 < time(  )) {
				unset( $_SESSION[log] );
				unset( $_SESSION[pass] );
				unset( $_SESSION[timeout] );
				echo '<script>
   if (window.toolbar.visible == false)
   {
    alert(\'' . ADMIN_SESSION_EXPIRED . STRING_COUPON_EXPIRED . '\');
    window.close();
   }
   </script>';
				echo '<script type="text/javascript">
            if (parent.location!="") 
                {
                  alert("' . ADMIN_SESSION_EXPIRED . STRING_COUPON_EXPIRED . '");
                  parent.location="admincp.php";
                }                                                                    
           </script>';
			}
		}


		if (!( $q = db_query( 'SELECT cust_password FROM ' . CUSTOMERS_TABLE . ' WHERE Login=\'' . $_SESSION['log'] . '\'' ))) {
			exit( db_error(  ) );
			(bool)true;
		}

		$row = db_fetch_row( $q );

		if (( ( !$row || !isset( $_SESSION['pass'] ) ) || strcmp( $row[0], $_SESSION['pass'] ) )) {
			unset( $_SESSION[log] );
			unset( $_SESSION[pass] );
		}
	}

?>